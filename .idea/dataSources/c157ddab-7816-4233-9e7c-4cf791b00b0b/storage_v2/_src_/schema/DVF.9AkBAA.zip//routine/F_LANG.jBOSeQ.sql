create FUNCTION     "F$LANG" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Lang'); END;
/

