create FUNCTION     "F$LANGUAGE" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Language'); END;
/

