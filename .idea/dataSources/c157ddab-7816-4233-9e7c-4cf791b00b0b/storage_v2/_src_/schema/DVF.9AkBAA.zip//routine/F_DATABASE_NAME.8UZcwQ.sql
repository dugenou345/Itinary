create FUNCTION     "F$DATABASE_NAME" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Database_Name'); END;
/

