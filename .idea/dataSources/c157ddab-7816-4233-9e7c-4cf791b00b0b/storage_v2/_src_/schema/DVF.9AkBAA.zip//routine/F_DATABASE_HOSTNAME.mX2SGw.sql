create FUNCTION     "F$DATABASE_HOSTNAME" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Database_Hostname'); END;
/

