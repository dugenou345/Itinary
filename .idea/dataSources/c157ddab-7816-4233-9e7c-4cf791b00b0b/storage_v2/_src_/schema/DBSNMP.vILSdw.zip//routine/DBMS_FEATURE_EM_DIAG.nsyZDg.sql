create PROCEDURE dbms_feature_em_diag
(feature_boolean OUT number,
 aux_count       OUT number,
 info            OUT clob)
AS
BEGIN
 dbms_feature_em_int(feature_boolean, aux_count, info, 'Diagnostic');
END;
/

