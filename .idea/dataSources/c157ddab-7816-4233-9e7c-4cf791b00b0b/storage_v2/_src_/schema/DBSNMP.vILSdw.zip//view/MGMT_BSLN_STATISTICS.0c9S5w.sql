create view MGMT_BSLN_STATISTICS
            (BSLN_GUID, DATASOURCE_GUID, COMPUTE_DATE, SUBINTERVAL_CODE, SAMPLE_COUNT, AVERAGE, MINIMUM, MAXIMUM, SDEV,
             PCTILE_25, PCTILE_50, PCTILE_75, PCTILE_90, PCTILE_95, EST_SAMPLE_COUNT, EST_SLOPE, EST_INTERCEPT,
             EST_FIT_QUALITY, EST_PCTILE_99, EST_PCTILE_999, EST_PCTILE_9999)
as
select bs.bsln_guid
      ,bsln.datasource_guid(bsln.target_uid(bb.dbid, i.instance_number),
                            bsln.metric_uid(bs.metric_id))
      ,bs.compute_date
      ,bs.timegroup
      ,bs.sample_count
      ,bs.average
      ,bs.minimum
      ,bs.maximum
      ,bs.sdev
      ,bs.pctile_25
      ,bs.pctile_50
      ,bs.pctile_75
      ,bs.pctile_90
      ,bs.pctile_95
      ,bs.est_sample_count
      ,bs.est_slope
      ,bs.est_intercept
      ,bs.est_fit_quality
      ,bs.pctile_99
      ,bs.est_pctile_999
      ,bs.est_pctile_9999
  from bsln_statistics bs, bsln_baselines bb, sys.gv_$instance i
 where bs.bsln_guid = bb.bsln_guid
   and bb.instance_name = i.instance_name
   and bs.timegrouping = bb.timegrouping
/

comment on table MGMT_BSLN_STATISTICS is 'Database Metric Baseline Statistics (10.2)'
/

