create PROCEDURE
  SI_setAvgClrFtr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
1b9 12c
SJHmrbLy9d2VXLGgeVfWKpmJHFYwg/DQf8sVfHTpWBKe0MPmcak+LlU8CV3DSh3g4OZWWWMG
5BpsWun13bdzzReq/gZiPMwv4UwcsbN6IDMiIYZLeVARJaREAgEv1tCeiju7crYNBGiUpbaL
4+CjoBlC+oxPAL2Hn7Uarnmwtkz4VK1Gh1AJynIBFS53SidLzDaTln8OFI3mzDgMes2wObyH
jKZ2kNU12l1+Z3wNOnzqfeHJQjfNt4Gp7I3NGNkNF/kjO267ZrH6/G5vXvm8F0o7MiVNdt+W
Jk0RTQ==
/

