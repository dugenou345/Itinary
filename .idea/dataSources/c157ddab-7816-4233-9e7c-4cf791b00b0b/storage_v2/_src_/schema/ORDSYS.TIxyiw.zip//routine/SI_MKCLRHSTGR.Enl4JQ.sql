create FUNCTION
  SI_mkClrHstgr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f5 f3
VuzTDmjHLycpAB7sJfWQZjo/+VcwgwFKLcusZ3RAkEIYSvGlOVlQ1XHv0qCxbVLg9Wkf0nOG
NVl8gyYptUMemmw1hsovQiNopSL4wR57u9o8EQRADt32Yblc+yTrPpDTvYdw7nFazWe4w+ZK
k6PJh/rxSJ5ys+Zk13WMG1gXW3XDoX7y9yEPpIgphfE1YI9UoHcDVk8kxS97tfi8xeq6O8LR
Wmjm0Ft2d4AeDRnt+3zBZzQ=
/

