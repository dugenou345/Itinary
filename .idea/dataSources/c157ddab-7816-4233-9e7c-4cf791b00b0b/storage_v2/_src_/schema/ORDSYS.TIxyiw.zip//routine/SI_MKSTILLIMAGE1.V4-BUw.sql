create FUNCTION
  SI_mkStillImage1 wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b6 d2
Lr25Ye5W1+QeSBYkoHDIovtuV7Iwg1zwLcsVfHSiWE6UHCm0vl63deD3V/GG4y3gZ+ezSOSd
fOOe7in1vz+/EXaJnoRjQhB3wRCTEe1o4nMijiuRArvz1q6Vv6bLZ2kTzz/lCfKJxr2oUVGR
4GWWVN5+Ixrna/QEF0iUlXHl/4aifsBqfEG1zAWfeFddzv+bKZwzarlEiT58gA==
/

