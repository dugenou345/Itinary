create FUNCTION
  SI_ScoreByTexture wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
12e 113
WlbT9QiADZja0G/TdBdKXsAVShswg3muNZ4VfC/SaOqKLUQIHQAqKXfRGiYU/VBeKCUDaY7S
/hve6Tb+8ddHiv9+H9hvHGJCQeSBYUf8bE5O+VSLwoTvrzdXt6zHks2Zkl56IYAav1XvfllA
5U2f48eng38WHXutETOzfGUuyEG6Ja+tVFisB20RmTf9tMBxjPQQa7hdFEm5ff2Xt7LUwxQA
iqfex/IwkKgE0A9I/SQaiSP1FrF1k8sFYG1obya1EXcBmO0Z7ftPl/II
/

