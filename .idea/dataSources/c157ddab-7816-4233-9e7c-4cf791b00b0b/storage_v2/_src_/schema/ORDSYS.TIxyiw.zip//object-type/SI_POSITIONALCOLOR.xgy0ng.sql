create TYPE SI_PositionalColor
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
  (
     --attributes
     SI_ColorPositions  colorPositions,
     --
     --Methods
     CONSTRUCTOR FUNCTION SI_PositionalColor
     (sourceImage IN SI_StillImage)
     return SELF AS RESULT DETERMINISTIC,
     --
     MEMBER FUNCTION SI_Score
     (SELF  IN SI_PositionalColor,
      image IN SI_StillImage)
     RETURN DOUBLE PRECISION DETERMINISTIC
) INSTANTIABLE
  NOT FINAL;
/

