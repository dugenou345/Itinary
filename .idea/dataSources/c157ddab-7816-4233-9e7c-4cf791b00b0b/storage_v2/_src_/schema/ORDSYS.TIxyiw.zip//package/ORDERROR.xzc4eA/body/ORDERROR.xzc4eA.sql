create PACKAGE BODY         ORDError wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
30a 1a5
COv6joXj5D5BVpDKG+/Vma3SocAwg2PxcvZqyo7Gv/8P7qhQNmBwVZ+Trhu86NBsxXIXk9wJ
l9zadBX5qujemDJMgD620jqGTuT86jt+QQGZUd8nL0COX4b4daGcAebjw2JYOYlJLxSzNfeL
SvK7o834aueBjid38UCp7GtERXOQBjy/ST72odfyJeRWep05vJ05P1M5P+QdbwFRs2NhQG+B
0UKb1UL8OepjcHoqppayVGCM625+e+ftuwQSaRbW4cE7KtsOb962UH/5z0QMsyvGCDFX6GqT
Q3acZnKMXb1WwIevQaEHCTK7rAh+AOotQMsqjgMpmef+LTG8ANeXlUTk9q+Cn4WEDSF3DMtn
kRZZg+lCUpztEaQqRNATzR6djR5qY509ThHB4rAQsaSIboMTrsgXoLI=
/

