create PACKAGE        ORD_AUDIO AUTHID CURRENT_USER AS
---------------------------
-- FUNCTIONS AND PROCEDURES
---------------------------

--
-- Description:  Copies multimedia data from BLOBs within the database to an
-- external data source.
-- Input:
--  src: The BLOB location of the data to be exported (or copied) to the
--  destination location
--  dest_location: The location to which the source data is to be exported.
--  (File directory object)
--  dest_name: The name of the destination file.
--  Exceptions: ORDSourceExceptions.INCOMPLETE_SOURCE_INFORMATION
--              ORDSourceExceptions.IO_ERROR

  PROCEDURE export (
    src IN BLOB,
    dest_location IN VARCHAR2,
    dest_name IN VARCHAR2
    );

-- Description: Import data from the specified external data source to the
-- BLOB specified by the dest parameter.
-- Input:
--  dest: The BLOB location to receive the data
--  source_type: The type of the source data.  (FILE or URL)
--  source_location: The location from which the source data is to be
--  imported.
--  source_name: The name of the source data.
--  Exceptions:ORDSourceExceptions.NULL_SOURCE

  PROCEDURE  importFrom (
    dest IN OUT NOCOPY BLOB,
    source_type IN VARCHAR2,
    source_location IN VARCHAR2,
    source_name IN VARCHAR2
    );

-- Description: Import data from the specified external data source to the
-- BLOB specified by the dest parameter.
-- Input:
--  dest: The BLOB location to receive the data
--  source_type: The type of the source data.  (FILE or URL)
--  source_location: The location from which the source data is to be imported.
--  source_name: The name of the source data.
--  format: The format of the data.
--  mime_type: The MIME type of the data.
--  Exceptions: ORDSourceExceptions.NULL_SOURCE

  PROCEDURE  importFrom (
    dest IN OUT NOCOPY BLOB,
    source_type IN VARCHAR2,
    source_location IN VARCHAR2,
    source_name IN VARCHAR2,
    format OUT VARCHAR2,
    mime_type OUT VARCHAR2
    );

-- Description: Reads the audio BFILE data to get the values of the media
-- attributes for supported formats and then stores them in the input CLOB.
-- This procedure populates the CLOB with a set of format and application
-- properties in XML form.
-- Input:
--  audioBfile: The audio data represented as BFILE.
--  attributes: The CLOB to hold the XML attribute information extracted by
-- the getProperties procedure.  This CLOB is populated with a set of format
--  and application properties of the audio BFILE data in XML form.
--  Exceptions: ORDSourceExceptions.EMPTY_SOURCE

  PROCEDURE  getProperties (
    audioBfile IN OUT NOCOPY BFILE,
    attributes IN OUT NOCOPY CLOB
    );

-- Description: Reads the audio BFILE data to get the values of the media attributes
-- for supported formats and then returns them as explicit parameters.
-- This procedure extracts the properties for these attributes
-- of the audio data: duration, MIME types, compression type, format, encoding type,
-- number of channels, sampling rate, and sample size.
-- Input:
--  audioBfile: The audio data represented as BFILE.
--  mimeType: The MIME type of the audio data.
--  format: The format of the audio data.
--  encoding: The encoding type of the audio data.
--  numberOfChannels: The number of channels in the audio data.
--  samplingRate: The sampling rate in samples per second at which the audio data
--  was recorded.
--  sampleSize: The sample width or number of samples of audio in the data.
--  compressionType: The compression type of the audio data.
--  audioDuration: The total time required to play the audio data.
--  Exceptions: ORDSourceExceptions.EMPTY_SOURCE

  PROCEDURE  getProperties (
    audioBfile IN OUT NOCOPY BFILE,
    mimeType OUT VARCHAR2,
    format OUT VARCHAR2,
    encoding OUT VARCHAR2,
    numberOfChannels OUT INTEGER,
    samplingRate OUT INTEGER,
    sampleSize OUT INTEGER,
    compressionType OUT VARCHAR2,
    audioDuration OUT INTEGER
    );

-- Description: Reads the audio BLOB data to get the values of the media attributes
-- for supported formats and then stores them in the input CLOB.  This procedure
-- populates the CLOB with a set of format and application properties in XML form.
-- Input:
--  audioBLOB: The audio data represented as BLOB.
--  attributes: The CLOB to hold the XML attribute information extracted by the
--  getProperties procedure.  This CLOB is populated with a set of format and
--  application
--  properties of the audio BFILE data in XML form.
--  Exceptions: ORDSourceExceptions.EMPTY_SOURCE

  PROCEDURE  getProperties (
    audioBlob IN BLOB,
    attributes IN OUT NOCOPY CLOB
    );

--  Description: Reads the audio BLOB data to get the values of the media attributes
--  for supported formats and then  returns them as explicit parameters.
--  This procedure extracts the properties for these attributes
--  of the audio data: duration, MIME types, compression type, format, encoding type,
--  number of channels, sampling rate, and sample size.
--  Input:
--    audioBLOB: The audio data represented as BLOB.
--    mimeType: The MIME type of the audio data.
--    format: The format of the audio data.
--    encoding: The encoding type of the audio data.
--    numberOfChannels: The number of channels in the audio data.
--    samplingRate: The sampling rate in samples per second at which the audio data
--    was recorded.
--    sampleSize: The sample width or number of samples of audio in the data.
--    compressionType: The compression type of the audio data.
--    audioDuration: The total time required to play the audio data.
--    Exceptions: ORDSourceExceptions.EMPTY_SOURCE

  PROCEDURE  getProperties (
    audioBlob IN BLOB,
    mimeType OUT VARCHAR2,
    format  OUT VARCHAR2,
    encoding OUT VARCHAR2,
    numberOfChannels OUT INTEGER,
    samplingRate OUT INTEGER,
    sampleSize  OUT INTEGER,
    compressionType OUT VARCHAR2,
    audioDuration OUT INTEGER
    );
END;
/

