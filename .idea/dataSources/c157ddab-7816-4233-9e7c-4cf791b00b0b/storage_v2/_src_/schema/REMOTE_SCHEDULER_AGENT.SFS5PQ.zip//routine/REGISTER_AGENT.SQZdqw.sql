create PROCEDURE                        register_agent wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
134 124
J82VR5HIRoI/JhUYAa1TucF7Y4AwgwHQmMsVfHTpWPiUMaManiZ0dMo5eH8uoqHIkBUEf8OU
mR2ltWYhNBR6MXsz97tBbqI98xj2JG4g/vmr3ISqvh9YL4MtxEuE9/ymFCpQNF9aZkIDf9N6
+WtK5zsoxS0PoFuLjO+UIUv5UX7FdBf666tsJ8GjNtWn9i03p1IqZVwHHdP9FyQH6Q11Ijjw
8C2G0+7/QnRWMnQ9ZkQRBpYDV5d5/JrxZgwmm+Xs106bgA+8GQQ9EVyJ30BzumHseqbm9lnY

/

