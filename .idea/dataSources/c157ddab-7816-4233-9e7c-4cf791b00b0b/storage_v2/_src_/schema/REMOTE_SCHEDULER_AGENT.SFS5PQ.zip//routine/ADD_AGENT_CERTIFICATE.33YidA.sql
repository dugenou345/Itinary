create procedure                        add_agent_certificate wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
38c 1f6
NgqRGy7W4P63/Yk/uMplN0mOoB0wgwL37UgVfI4C2k6OGefxAsN3nxbr8BCh2BufkRNmG5n7
O1R7w196z6RJ/yg15Zxa+UjP/wCwJRiomicUB+v6pLxyJOq/erWHlg+chu4j3MlGXZdUvWzx
i8+sya19lIHja2Hg7wRUbg47PBY7hrL9UZ5fMT7XTMsbnYTyuiVPqPHyZc9faWX+N/iAhQ/E
ZbY2k81kBX7j/CTImBGgCwOVWQRy2e39g/RXQhKT2P1x4RNU8HWwSMgX0A9P6je7ZwxbWBBH
XkdG0l7JIKd6YvC2QD3JKqeXUR3UUHVsuLnsRFukbC2XI4Bl5dBKnoyGShF9At+UUAR4zRV5
Tx4dY/69JVMhzcKMeVmgBXhWlt8QRRUwoQxdYRbnWhzHpIcFdgFpcnkN2KDI31gXAvJruDsG
2liaSMwiWl9A1gl19MLrWFMXdk4bFS8jruDrRbmj+MYZEQXOrLXiT/mmGsiaog==
/

