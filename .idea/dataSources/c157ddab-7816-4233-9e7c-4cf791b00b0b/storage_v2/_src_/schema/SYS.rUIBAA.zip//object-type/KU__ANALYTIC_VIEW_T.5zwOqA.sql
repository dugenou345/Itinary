create type ku$_analytic_view_t force as object
(
  obj_num         number,              /* object number of the analytic view */
  schema_obj      ku$_schemaobj_t,                          /* schema object */
  def_meas        varchar2(128),                          /* default measure */
  def_aggr        varchar2(128),                      /* default aggregation */
  def_aggr_fn     ku$_hcs_aggr_fn_t,                  /* default aggregation */
  src_list        ku$_hcs_src_list_t,                     /* list of sources */
  dim_list        ku$_analytic_view_dim_list_t,                /* dimensions */
  meas_list       ku$_analytic_view_meas_list_t,                 /* measures */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  cache_meas_list ku$_hcs_av_cache_mlst_list_t,           /* cache meas list */
  dyn_all_cache   number(1),                    /* dynamic all cache enabled */
  fact_cols_list  ku$_av_fact_cols_list_t,                   /* fact columns */
  qry_xform_enabled number(1),                    /* query transform enabled */
  qry_xform_rely    number(1)                        /* query transform rely */
)
not persistable
/

