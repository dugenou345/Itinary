create type       "SYS_YOID0000019159$"              as object( "SYS_NC00001$" NUMBER)
/

