create TYPE     ku$_LogLine1010 FORCE IS OBJECT
        (
                logLineNumber   NUMBER,                 -- Line # in log file
                errorNumber     NUMBER,                 -- Error number
                LogText         VARCHAR2(2000)          -- Log entry text
        )
PERSISTABLE -- Part of ku$_LogEntry
/

