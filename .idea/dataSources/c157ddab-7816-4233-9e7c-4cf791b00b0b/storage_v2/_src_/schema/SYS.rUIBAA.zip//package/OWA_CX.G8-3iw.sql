create PACKAGE owa_cx IS  NL_CHAR CONSTANT varchar2(1) := chr(10);  SP_CHAR CONSTANT varchar2(1) := chr(32);  BS_CHAR CONSTANT varchar2(1) := chr(8);  HT_CHAR CONSTANT varchar2(1) := chr(9);  XP_CHAR CONSTANT varchar2(1) := chr(33);  end owa_cx;
/

