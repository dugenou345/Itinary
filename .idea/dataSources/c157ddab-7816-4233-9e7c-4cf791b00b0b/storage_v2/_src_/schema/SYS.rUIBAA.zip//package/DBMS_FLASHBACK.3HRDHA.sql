create package dbms_flashback AUTHID CURRENT_USER as
-- By default this package don't need PL/SQL replication in DG
-- except for some procedures for which appropriate PRAGMAs added.
PRAGMA SUPPLEMENTAL_LOG_DATA(DEFAULT, NONE);
 ----------------
 -- OVERVIEW
 -- Procedures for enabling and disabling dbms_flashback.
 --
 ---------------------------
 -- PROCEDURES AND FUNCTIONS

procedure enable_at_time(query_time in TIMESTAMP);

procedure enable_at_system_change_number(query_scn in NUMBER);

procedure disable;

function  get_system_change_number return NUMBER;

-- Transaction backout constants
nocascade        constant binary_integer := 1;
nocascade_force  constant binary_integer := 2;
nonconflict_only constant binary_integer := 3;
cascade          constant binary_integer := 4;

-- Transaction backout interfaces
procedure transaction_backout(numtxns number,
                              xids    xid_array,
                              options binary_integer default nocascade,
                              scnhint number         default 0);
-- All the overloaded transaction_backout procedures are not supported
-- for DG rolling upgrade. If UNSUPPORTED is set and user invokes it
-- on the primary while the DG upgrade is going on, user error is thrown.
PRAGMA SUPPLEMENTAL_LOG_DATA(transaction_backout, UNSUPPORTED);
procedure transaction_backout(numtxns  number,
                              xids     xid_array,
                              options  binary_integer default nocascade,
                              timehint timestamp);
PRAGMA SUPPLEMENTAL_LOG_DATA(transaction_backout, UNSUPPORTED);
procedure transaction_backout(numTxns number,
                              names   txname_array,
                              options binary_integer default nocascade,
                              scnhint number         default 0);
PRAGMA SUPPLEMENTAL_LOG_DATA(transaction_backout, UNSUPPORTED);
procedure transaction_backout(numTxns  number,
                              names    txname_array,
                              options  binary_integer default nocascade,
                              timehint timestamp);
PRAGMA SUPPLEMENTAL_LOG_DATA(transaction_backout, UNSUPPORTED);

end;
/

