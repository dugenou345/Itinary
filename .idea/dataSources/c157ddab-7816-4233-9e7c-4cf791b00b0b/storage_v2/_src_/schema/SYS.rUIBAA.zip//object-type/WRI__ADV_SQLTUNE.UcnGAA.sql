create type wri$_adv_sqltune under wri$_adv_abstract_t
(
  overriding MEMBER PROCEDURE sub_execute(task_id IN NUMBER,
                                          err_num OUT NUMBER),
  overriding MEMBER PROCEDURE sub_reset(task_id IN NUMBER),
  overriding MEMBER PROCEDURE sub_resume(task_id IN NUMBER,
                                         err_num OUT NUMBER),
  overriding MEMBER PROCEDURE sub_delete(task_id IN NUMBER),
  overriding MEMBER PROCEDURE sub_delete_execution(task_id IN NUMBER,
                                                   execution_name IN VARCHAR2),
  overriding MEMBER PROCEDURE sub_get_script(task_id        IN NUMBER,
                                             type           IN VARCHAR2,
                                             buffer         IN OUT NOCOPY CLOB,
                                             rec_id         IN NUMBER,
                                             act_id         IN NUMBER,
                                             execution_name IN VARCHAR2,
                                             object_id      IN NUMBER),
  overriding MEMBER PROCEDURE sub_get_report(task_id        IN NUMBER,
                                             type           IN VARCHAR2,
                                             level          IN VARCHAR2,
                                             section        IN VARCHAR2,
                                             buffer         IN OUT NOCOPY CLOB,
                                             execution_name IN VARCHAR2,
                                             object_id      IN NUMBER),
  overriding member procedure sub_param_validate(task_id IN NUMBER,
                                                 name    IN VARCHAR2,
                                                 value   IN OUT VARCHAR2)
) NOT FINAL
/

