create PACKAGE dbms_goldengate_auth AUTHID CURRENT_USER AS

-- Grants the privileges needed by a user to be an administrator for OGG
-- Integration with XStreamOut
-- INPUT:
--   grantee          - the user to whom privileges are granted
--   privilege_type   - CAPTURE, APPLY, both(*)
--   grant_select_privileges - should the select_catalog_role be granted?
--   do_grants        - should the privileges be granted ?
--   file_name        - name of the file to which the script will be written
--   directory_name   - the directory where the file will be written
--   grant_optional_privileges - comma-separated list of optional prvileges
--                               to grant: XBADMIN, DV_XSTREAM_ADMIN,
--                               DV_GOLDENGATE_ADMIN
-- OUTPUT:
--   if grant_select_privileges = TRUE
--     grant select_catalog_role to grantee
--   if grant_select_privileges = FALSE
--     grant a min set of privileges to grantee
--   if do_grants = TRUE
--     the grant statements are to be executed.
--   if do_grants = FALSE
--     the grant statements are not executed.
--   If file_name is not NULL,
--     then the script is written to it.
-- NOTES:
--   An error is raised if do_grants is false and file_name is null.
--   The file i/o is done using the package utl_file.
--   The file is opened in append mode.
--   The CREATE DIRECTORY command should be used to create directory_name.
--   If do_grant is true, each statement is appended to the script
--     only if it executed successfully.
PROCEDURE grant_admin_privilege(
  grantee           IN VARCHAR2,
  privilege_type    IN VARCHAR2 DEFAULT '*',
  grant_select_privileges IN BOOLEAN DEFAULT TRUE,
  do_grants        IN BOOLEAN DEFAULT TRUE,
  file_name        IN VARCHAR2 DEFAULT NULL,
  directory_name   IN VARCHAR2 DEFAULT NULL,
  grant_optional_privileges IN VARCHAR2 DEFAULT NULL,
  container        IN VARCHAR2 DEFAULT 'CURRENT');
PRAGMA SUPPLEMENTAL_LOG_DATA(grant_admin_privilege, MANUAL_WITH_COMMIT);


-- Revokes the privileges needed by a user to be an administrator for OGG
-- Integration with XStreamOut
-- INPUT:
--   grantee          - the user from whom privileges are revoked
--   privilege_type   - CAPTURE, APPLY, both(*)
--   revoke_select_privileges - should the select_catalog_role be revoked?
--   do_revokes       - should the privileges be revoked ?
--   file_name        - name of the file to which the script will be written
--   directory_name   - the directory where the file will be written
--   revoke_optional_privileges - comma-separated list of optional prvileges
--                                to revoke: XBADMIN, DV_XSTREAM_ADMIN,
--                                DV_GOLDENGATE_ADMIN
-- OUTPUT:
--   if revoke_select_privileges = TRUE
--     revoke select_catalog_role from grantee
--   if revoke_select_privileges = FALSE
--     revoke a min set of privileges from grantee
--   if do_revokes = TRUE
--     the revoke statements are to be executed.
--   if do_revokes = FALSE
--     the revoke statements are not executed.
--   If file_name is not NULL,
--     then the script is written to it.
-- NOTES:
--   An error is raised if do_grants is false and file_name is null.
--   The file i/o is done using the package utl_file.
--   The file is opened in append mode.
--   The CREATE DIRECTORY command should be used to create directory_name.
--   If do_grants is true, each statement is appended to the script
--     only if it executed successfully.
PROCEDURE revoke_admin_privilege(
  grantee           IN VARCHAR2,
  privilege_type    IN VARCHAR2 DEFAULT '*',
  revoke_select_privileges IN BOOLEAN DEFAULT TRUE,
  do_revokes        IN BOOLEAN DEFAULT TRUE,
  file_name        IN VARCHAR2 DEFAULT NULL,
  directory_name   IN VARCHAR2 DEFAULT NULL,
  revoke_optional_privileges IN VARCHAR2 DEFAULT NULL,
  container        IN VARCHAR2 DEFAULT 'CURRENT');
PRAGMA SUPPLEMENTAL_LOG_DATA(revoke_admin_privilege, MANUAL_WITH_COMMIT);

END dbms_goldengate_auth;
/

