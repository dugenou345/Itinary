create TYPE kupc$_workererror FORCE UNDER kupc$_worker_msg (
                                error         kupc$_JobInfo,
                                errcnt        NUMBER,
                                workerid      NUMBER,
                                last_msg      NUMBER,
        CONSTRUCTOR FUNCTION kupc$_workererror(
                                err      kupc$_JobInfo,
                                ecnt     NUMBER,
                                wid      NUMBER,
                                lstmsg   NUMBER
                               ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_workererror(
                                err      kupc$_JobInfo,
                                ecnt     NUMBER,
                                lstmsg   NUMBER
                               ) RETURN SELF AS RESULT
        )
/

