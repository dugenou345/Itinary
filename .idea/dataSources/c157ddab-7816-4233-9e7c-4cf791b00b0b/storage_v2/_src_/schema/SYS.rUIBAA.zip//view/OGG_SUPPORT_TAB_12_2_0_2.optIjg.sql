create view OGG_SUPPORT_TAB_12_2_0_2 (OWNER, NAME, TYPE#, OBJ#, GENSBY) as
select u.name owner, o.name name, o.type#, o.obj#,
 (case
  /* INTERNAL - The following are tables that are system maintained.
     These are internal, so no SUPPORT_MODE given */
  when ( exists (select 1 from system.logstdby$skip_support s
                 where s.name = u.name and action = 0))
    or bitand(o.flags,
                2                                       /* temporary object */
              + 16                                      /* secondary object */
              + 32                                  /* in-memory temp table */
              + 128                           /* dropped table (RecycleBin) */
             ) != 0
    or bitand(t.flags,
                134217728  /* 0x08000000          in-memory temporary table */
              + 536870912  /* 0x20000000  Mapping Tab for Phys rowid of IOT */
             ) != 0
    or bitand(t.property,
                512        /* 0x00000200               iot OVeRflow segment */
              + 8192       /* 0x00002000                       nested table */
              + 4194304    /* 0x00400000             global temporary table */
              + 8388608    /* 0x00800000   session-specific temporary table */
              + 134217728  /* 0x08000000                    Is a Sub object */
              + 4294967296 /* 0x100000000                              Cube */
              + 8589934592 /* 0x200000000                      FBA Internal */
              + (2*4294967296*4294967296) /* PF3 0x00000002    XML TokenSet */
              + 144115188075855872   /* PF2 0x02000000  rowid mapping table */
             ) != 0
    or (bitand(t.property,  2147483648) != 0   /* 0x80000000 eXternal TaBle */
        and bitand(t.property, power(2,90)) = 0) /* but NOT hybrid part tab */
    or bitand(t.trigflag,
                536870912  /* 0x20000000                  DDLs autofiltered */
               ) != 0
    or exists (select 1 from sys.secobj$ so           /* ODCI storage table */
               where o.obj# = so.secobj#)
    or exists (select 1 from sys.opqtype$ opq       /* XML OR storage table */
               where o.obj# = opq.obj#
                 and bitand(opq.flags, 32) = 32)
    or (bitand(t.property, 131072) != 0 and                  /* AQ spill table */
         o.name like 'AQ$\_%\_P' escape '\')
     or (bitand(t.property, 131072) != 0 and            /* AQ commit q table */
         o.name like 'AQ$\_%\_C' escape '\')
     or (bitand(t.property, 131072) != 0 and                  /* internal AQ */
         o.name like 'AQ$\_%\_H' escape '\')
     or (bitand(t.property, 131072) != 0 and                 /* internal AQ  */
         o.name like 'AQ$\_%\_I' escape '\')    /* Internal AQ table */
  then -1
  -----------------------------------------
  /* SUPPORT_MODE "NONE" */
  when exists
     (select 1 from sys.col$ c
               where t.obj# = c.obj#
             /* Table has a 32k column with a unique idx/constraint on it */
        and ((c.type# in (1, 23) and (bitand(c.property, 128) = 128                 /* column stored in LOB */
       and c.length between 4001 and 6398
       and (exists                                  /* Unique index on vc32k */
            (select null
             from ind$ i, icol$ ic
             where i.bo# = t.obj#
               and ic.obj# = i.obj#
               and c.intcol# = ic.intcol#
               and bitand(i.property, 1) = 1                       /* Unique */
            )
           or exists                  /* Primary or unique constraint on 32k */
            (select null
             from cdef$ cd, ccol$ ccol
             where cd.obj# = t.obj#
               and cd.obj# = ccol.obj#
               and cd.con# = ccol.con#
               and cd.type# in (2,3)
               and ccol.intcol# = c.intcol#
            ))))
             /* ADT typed table with BFILE attribute */
             or (bitand(t.property, 1) = 1 and
                 c.type# = 114 /* BFILE */ and
                 exists(select 1
                        from sys.col$ c1
                        where c1.obj#=t.obj# and
                              c1.name = 'SYS_NC_ROWINFO$' and
                              c1.type# = 121))
             /* Relational table with ADT column having BFILE attribute */
             or (bitand(t.property, 1) = 0 and
                 c.type# = 114 /* BFILE */ and
                 bitand(c.property, 32) = 32 /* hidden */ and
                 exists (select 1
                         from sys.col$ c1
                         where c1.obj#=t.obj# and
                               c1.col# = c.col# and
                               bitand(c1.property, 32) = 0 /* not hidden */ and
                               c1.type# = 121))
             /* Any table (relational or typed) that has an unsupported */
             /* built-in ADT */
             or (c.type# in (58, 121, 123) and
     (exists
      (select 1 from obj$ o3, coltype$ ct3, user$ u3
       where u3.user# = o3.owner#
         and c.obj# = ct3.obj#
         and c.intcol# = ct3.intcol#
         and ct3.toid = o3.oid$
         and exists (select 1 from system.logstdby$skip_support sk
                      where sk.action=-11
                        and sk.name = u3.name   /* type owner */
                        and sk.name2 = o3.name  /* type name  */))))
             /* Anydata column with unpacked storage columns */
             or (c.type#=58 and exists (
                   select 1 from coltype$ ct
                     where ct.obj#=c.obj#
                       and ct.intcol# = c.intcol#
                       and ct.toid = '00000000000000000000000000020011'
                       and bitand(ct.flags, 131072) = 131072))
             /* table doesnt have at least one scalar column */
             or ((c.type# in (8,24,58,112,113,114,115,121,122,123)
                  or bitand(c.property, 128) = 128)
             and (bitand(t.property, 1) = 0          /* not a typed table or */
             and 0 = (select count(*) from sys.col$ c2
               where t.obj# = c2.obj#
               and bitand(c2.property, 32)  != 32              /* Not hidden */
               and bitand(c2.property, 8)   != 8              /* Not virtual */
               and bitand(c2.property, 128) != 128      /* not stored in lob */
               and (c2.type# in ( 1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  12,                                /* DATE */
                                  23,                                 /* RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  208,                             /* UROWID */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
     ))))))
    /* OLAP AW$ table */
    or (bitand(t.property, power(2,69 /*PF3 */)) != 0)
    or  (bitand(t.property, power(2,73)) != 0)            /* Hybrid Part table */
    or (bitand(t.property, 1024) = 1024         /* Sorted hash cluster table */
        and exists (select 1 from clu$ cl
                     where cl.obj#=t.bobj#
                       and bitand(cl.spare1, 8388608) != 0))
  then 3
  ------------------------------------------
  /* SUPPORT_MODE "ID KEY" */
  when (bitand(t.property, 1 ) = 1     /* 0x00000001             typed table */
        AND ((bitand(t.property, 4096) = 4096)                     /* pk oid */
             OR exists
              (select 1
               from  sys.col$ c1
               where c1.obj# = t.obj# and
                     ((c1.type# = 58 and ( (exists (select 1 from coltype$ ct
                    where ct.obj#=c1.obj#
                    and   ct.intcol# = c1.intcol#
                    and   ct.toid = '00000000000000000000000000020011'
                    and   bitand(ct.flags, 131072) = 131072))  or  (exists (select 1 from coltype$ ct
                    where ct.obj#=c1.obj#
                    and   ct.intcol# = c1.intcol#
                    and /* SYS.XMLTYPE */
                    ct.toid != '00000000000000000000000000020100'
                    and /* SYS.ANYDATA */
                    ct.toid != '00000000000000000000000000020011')) ))          /* Opaque */
                        /* Non-hidden varray or varray stored in table in an */
                        /* ADT typed table.                                  */
                     /* Identify ADT typed tables containing unsupported:    */
                     /* Varray, REF, or nested table types.                  */
                      or ((exists
                           (select 1 from sys.col$ c2
                             where c2.obj# = t.obj# and
                                   c2.name = 'SYS_NC_ROWINFO$' and
                                   c2.type# = 121)) and
                          (c1.type#=122 or (c1.type# = 123 and bitand(c1.property, 4) = 4) or (c1.type# = 111 and bitand(c1.property, 8) = 8)))))))
    /* Table has a Temporal Validity column */
    or (bitand(t.property, 4611686018427387904) != 0)
             -----------------------------------------
             /* unsupp view joins col$, here we subquery it */
    or exists (select 1 from sys.col$ c
               where t.obj# = c.obj#
             -----------------------------------------
             /*  ignore any hidden columns in this subquery */
               and bitand(c.property, 32) != 32                /* Not hidden */
             -----------------------------------------
             /* table has an unsupported datatype */
               and ((c.type# not in (
                                  1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  8,                                 /* LONG */
                                  12,                                /* DATE */
                                  24,                            /* LONG RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  112,                     /* CLOB and NCLOB */
                                  113,                               /* BLOB */
                                  114,                              /* BFILE */
                                  115,                              /* CFILE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  208,                             /* UROWID */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
                  and (c.type# != 23                      /* RAW not RAW OID */
                  or (c.type# = 23 and bitand(c.property, 2) = 2))
                  and (c.type# != 58                               /* OPAQUE */
                    or (c.type# = 58 and ( (exists (select 1 from coltype$ ct
                    where ct.obj#=c.obj#
                    and   ct.intcol# = c.intcol#
                    and   ct.toid = '00000000000000000000000000020011'
                    and   bitand(ct.flags, 131072) = 131072))  or  (exists (select 1 from coltype$ ct
                    where ct.obj#=c.obj#
                    and   ct.intcol# = c.intcol#
                    and /* SYS.XMLTYPE */
                    ct.toid != '00000000000000000000000000020100'
                    and /* SYS.ANYDATA */
                    ct.toid != '00000000000000000000000000020011')) )))
                  and (c.type# != 111                        /* Internal REF */
                    or  (c.type# = 111 and bitand(c.property, 8) = 8))
                  and (c.type# != 121                                 /* ADT */
                    or ( (c.type#=121 and
       (exists
         (select 1 from sys.col$ c2
           where t.obj# = c2.obj#
             and c.col# = c2.col#
             and (c2.type# = 122         or                  /* Nested Table */
                                            /* BFILE */
                 (c2.type# = 123 and bitand(c2.property, 4) = 4) or        /* Varray */
                 (c2.type# = 58 and ( (exists (select 1 from coltype$ ct
                    where ct.obj#=c2.obj#
                    and   ct.intcol# = c2.intcol#
                    and   ct.toid = '00000000000000000000000000020011'
                    and   bitand(ct.flags, 131072) = 131072))  or  (exists (select 1 from coltype$ ct
                    where ct.obj#=c2.obj#
                    and   ct.intcol# = c2.intcol#
                    and /* SYS.XMLTYPE */
                    ct.toid != '00000000000000000000000000020100'
                    and /* SYS.ANYDATA */
                    ct.toid != '00000000000000000000000000020011')) )) or        /* Opaque */
                 (c2.type# = 111 and bitand(c2.property, 8) = 8))))) or
                         (c.type#=121 and
                          /* For non-typed tables, Primary keys on ADT attrs */
                          /* are disallowed.  Pkeys should be supported on   */
                          /* typed tables.                                   */
                          (bitand(t.property, 1 ) = 0 and exists
                            (select 1 from
                              sys.ccol$ ccol, sys.col$ c2, sys.cdef$ cd
                              where c.obj# = c2.obj#
                                and c.obj# = cd.obj#
                                and c.obj# = ccol.obj#
                                and c.col# = c2.col#
                                and ccol.con# = cd.con#
                                and ccol.intcol# = c2.intcol#
                                and bitand(c2.property, 32) = 32   /* Hidden */
                                and cd.type# = 2)))))         /* Primary key */
                  and (c.type# != 123                              /* Varray */
                       or (c.type# = 123 and bitand(c.property, 4) = 4)))
            /* RNW (Replace null with) column */
            or bitand(c.property, 1099511627776) != 0))
  then 0
  ---------------------------------------------
  /* SUPPORT_MODE "PLSQL" */
  when (bitand(t.property, 131072) != 0 or               /* AQ queue tables */
        (bitand(t.property, 1) = 1 and
         exists (select 1 from sys.opqtype$ opq        /* Hierarchy enabled */
                   where opq.obj# = t.obj# and
                         opq.type=1 and
                         bitand(opq.flags,512) = 512)) or
        (exists (select 1                            /* Topology/ Georaster */
                 from sys.obj$ o2, sys.coltype$ ct2, sys.user$ u2
                 where o.obj# = ct2.obj# and
                       u2.user# = o2.owner# and
                       ct2.toid = o2.oid$ and
                       u2.name='MDSYS' and
                       (o2.name = 'SDO_TOPO_GEOMETRY' or
                        o2.name = 'SDO_GEORASTER')))
  ) then 2
  ----------------------------------------------
  /* SUPPORT_MODE "FULL" */
  else 1 end) gensby
  from sys.obj$ o, sys.user$ u, sys.tab$ t
  where o.owner# = u.user#
  and o.obj# = t.obj#
/

