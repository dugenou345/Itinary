create type ku$_ind_compart_t force as object
(
  obj_num       number,                           /* obj# of comp. partition */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  dataobj_num   number,                          /* data layer object number */
  base_obj_num  number,                                     /* obj# of table */
  part_num      number,                                  /* partition number */
  hiboundlen    number,             /* length of high bound value expression */
  hiboundval    varchar2(4000),       /* text of high-bound value expression */
  hiboundvalc   clob,                                      /* clob text of " */
  subpartcnt    number,                           /* number of subpartitions */
  subparts      ku$_ind_part_list_t,                        /* subpartitions */
  flags         number,                                     /* for any flags */
  defts_name    varchar2(128),    /* default TABLESPACE; NULL if unspecified */
  defblocksize  number,          /* blocksize in bytes of default TABLESPACE */
  defpctfree    number,                                   /* default PCTFREE */
  definitrans   number,                                  /* default INITRANS */
  defmaxtrans   number,                                  /* default MAXTRANS */
  definiexts    number,  /* default INITIAL extent size; NULL if unspecified */
  defextsize    number,     /* default NEXT extent size; NULL if unspecified */
  defminexts    number,           /* default MINEXTENTS; NULL if unspecified */
  defmaxexts    number,           /* default MAXEXTENTS; NULL if unspecified */
  defextpct     number,          /* default PCTINCREASE; NULL if unspecified */
  deflists      number,      /* default FREELISTS value; NULL if unspecified */
  defgroups     number,         /* default FREELIST GROUPS (N/A for indexes) */
  deflogging    number,                         /* default LOGGING attribute */
  defbufpool    number,                         /* default BUFFER_POOL value */
  analyzetime   varchar2(19),                /* timestamp when last analyzed */
  samplesize    number,                          /* samplesize for histogram */
  rowcnt        number,                                    /* number of rows */
  blevel        number,                                      /* B-tree level */
  leafcnt       number,                             /* number of leaf blocks */
  distkey       number,                           /* number of distinct keys */
  lblkkey       number,             /* average number of leaf blocks per key */
  dblkkey       number,             /* average number of data blocks per key */
  clufac        number,                                 /* clustering factor */
  spare1        number,
  spare2        number,
  spare3        number,
  defmaxsize    number               /* default MAXSIZE; NULL if unspecified */
)
not persistable
/

