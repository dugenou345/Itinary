create type       "SYS_YOID0000017194$"              as object( "SYS_NC00001$" NUMBER, "SYS_NC00002$" NUMBER)
/

