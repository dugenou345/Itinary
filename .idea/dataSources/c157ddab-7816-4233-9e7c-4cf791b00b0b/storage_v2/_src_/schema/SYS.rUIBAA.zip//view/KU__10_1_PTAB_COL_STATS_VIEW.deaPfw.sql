create view KU$_10_1_PTAB_COL_STATS_VIEW
            (TAB_OBJ_NUM, P_OBJ_NUM, COLNAME, INTCOL_NUM, DISTCNT, LOWVAL, HIVAL, DENSITY, NULL_CNT, AVGCLN, CFLAGS,
             EAV, HIST_GRAM_LIST, HIST_GRAM_MIN, HIST_GRAM_MAX)
as
select  c.obj#, hh.obj#, c.name, hh.intcol#, hh.distcnt,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.lowval is null
                         then hh.lowval
                         else utl_raw.substr(hh.lowval,1,
                                          least(UTL_RAW.LENGTH(hh.lowval), 32))
                         end
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.hival is null
                         then hh.hival
                         else utl_raw.substr(hh.hival, 1,
                                           least(UTL_RAW.LENGTH(hh.hival), 32))
                         end
               else null
          end,
          hh.density, hh.null_cnt, hh.avgcln, bitand(hh.spare2, 3),
          bitand(hh.spare2, 4),
          cast(multiset(select value(hv)
                        from   sys.ku$_histgrm_view hv
                        where  hv.obj_num = hh.obj#
                           and hv.intcol_num = hh.intcol#)
                        as ku$_histgrm_list_t),
          (select value(hminv)
           from   sys.ku$_10_1_histgrm_min_view hminv
           where  hminv.obj_num = hh.obj#
              and hminv.intcol_num = hh.intcol#),
          (select value(hmaxv)
           from   sys.ku$_10_1_histgrm_max_view hmaxv
           where  hmaxv.obj_num = hh.obj#
              and hmaxv.intcol_num = hh.intcol#)
  from    sys.obj$ o, sys.col$ c, sys.tabpart$ tp, sys.hist_head$ hh
  where   hh.obj# = tp.obj# AND
          tp.bo# = c.obj# AND
          o.obj# = hh.obj# AND
          hh.intcol# = c.intcol# and
          -- Need to remove rows for user defined stats.  Look in qosp.h
          -- for macros likeQOS_IS_*_STATS_EXTN.  This is where the next 3
          -- lines were taken from.
          NOT (BITAND(c.property,65576) = 65576 AND
               LENGTH(c.name) > 6 AND
               SUBSTR(c.name, 1, 6) = 'SYS_ST')
UNION ALL
  select  c.obj#, hh.obj#, c.name, hh.intcol#, hh.distcnt,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.lowval is null
                         then hh.lowval
                         else utl_raw.substr(hh.lowval,1,
                                          least(UTL_RAW.LENGTH(hh.lowval), 32))
                         end
               else null
          end,
          case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
               then case when hh.hival is null
                         then hh.hival
                         else utl_raw.substr(hh.hival, 1,
                                           least(UTL_RAW.LENGTH(hh.hival), 32))
                         end
               else null
          end,
          hh.density, hh.null_cnt, hh.avgcln, bitand(hh.spare2, 3),
          bitand(hh.spare2, 4),
          cast(multiset(select value(hv)
                        from   sys.ku$_histgrm_view hv
                        where  hv.obj_num = hh.obj#
                           and hv.intcol_num = hh.intcol#)
                        as ku$_histgrm_list_t),
          (select value(hminv)
           from   sys.ku$_10_1_histgrm_min_view hminv
           where  hminv.obj_num = hh.obj#
              and hminv.intcol_num = hh.intcol#),
          (select value(hmaxv)
           from   sys.ku$_10_1_histgrm_max_view hmaxv
           where  hmaxv.obj_num = hh.obj#
              and hmaxv.intcol_num = hh.intcol#)
  from    sys.obj$ o, sys.col$ c, sys.hist_head$ hh,  sys.tabcompart$ tcp,
          sys.tabsubpart$ tsp
  where   hh.obj# = tsp.obj# AND
          tsp.pobj# = tcp.obj# AND
          tcp.bo# = c.obj# AND
          o.obj# = hh.obj# AND
          hh.intcol# = c.intcol# and
          -- Need to remove rows for user defined stats.  Look in qosp.h
          -- for macros likeQOS_IS_*_STATS_EXTN.  This is where the next 3
          -- lines were taken from.
          NOT (BITAND(c.property,65576) = 65576 AND
               LENGTH(c.name) > 6 AND
               SUBSTR(c.name, 1, 6) = 'SYS_ST')
/

