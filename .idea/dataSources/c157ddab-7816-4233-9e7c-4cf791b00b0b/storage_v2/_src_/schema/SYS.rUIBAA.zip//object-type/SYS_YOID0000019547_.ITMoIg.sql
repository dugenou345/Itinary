create type       "SYS_YOID0000019547$"              as object( "SYS_NC00001$" CHARACTER(3 BYTE), "SYS_NC00002$" CHARACTER(11 BYTE))
/

