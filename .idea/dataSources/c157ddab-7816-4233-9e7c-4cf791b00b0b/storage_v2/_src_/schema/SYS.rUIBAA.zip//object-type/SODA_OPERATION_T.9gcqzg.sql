create TYPE SODA_Operation_T FORCE
                                      
authid current_user
AS OPAQUE VARYING (*)
USING library DBMS_SODAOPR_LIB
(
    --  Methods
    MEMBER FUNCTION acquire_Lock
    RETURN SODA_Operation_T,

    MEMBER FUNCTION as_Of_SCN (scn NUMBER)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION as_Of_Timestamp (tstamp VARCHAR2)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION count
    RETURN NUMBER,

    MEMBER FUNCTION key (key VARCHAR2)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION filter (qbe VARCHAR2)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION get_Cursor
    RETURN SODA_Cursor_T,

    MEMBER FUNCTION get_Data_Guide (format    PLS_INTEGER DEFAULT 1,
                                    flag      PLS_INTEGER DEFAULT 0)
    RETURN CLOB,

    MEMBER FUNCTION get_One
    RETURN SODA_Document_T,

    MEMBER FUNCTION keys (key_List SODA_Key_List_T)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION limit (limit NUMBER)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION remove
    RETURN NUMBER,

    MEMBER FUNCTION replace_One (document SODA_Document_T)
    RETURN NUMBER,

    MEMBER FUNCTION replace_One_And_Get (document SODA_Document_T)
    RETURN SODA_Document_T,

    MEMBER FUNCTION sample (pct      DOUBLE PRECISION,
                            seed     NUMBER DEFAULT NULL,
                            method   PLS_INTEGER DEFAULT 1)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION skip (offset NUMBER)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION version (version VARCHAR2)
    RETURN SODA_Operation_T,

    MEMBER FUNCTION hint (hint VARCHAR2)
    RETURN SODA_Operation_T

) FINAL NOT PERSISTABLE;
/

