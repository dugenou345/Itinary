create view KU$_AUDIT_POLICY_VIEW
            (POLICY_NUM, SCHEMA_OBJ, TYPE, CONDITION, CONDITION_EVAL, PRIVILEGE_OPTIONS, SYS_ACTION_OPTIONS,
             XS_ACTION_OPTIONS, OLS_ACTION_OPTIONS, DP_ACTION_OPTIONS, DL_ACTION_OPTIONS, OBJ_ACTION_OPTIONS,
             ROLE_OPTIONS)
as
select
  pol.policy#,
  value(o),
  pol.type,
  pol.condition,
  pol.condition_eval,
  cast(multiset(select spm.privilege, spm.name,
                       bitand(spm.property, (power(2, 32)-1))
                from sys.system_privilege_map spm
                where bitand(pol.type, 1) = 1 and
                      substr(pol.syspriv, -spm.privilege+1, 1) = 'S'
                       ) as ku$_audit_sys_priv_list_t
      ),
  cast(multiset(select asa.action, asa.name
                from sys.auditable_system_actions asa
                where bitand(pol.type, 2) = 2 and
                      asa.type = 4 and
                      substr(pol.sysactn, asa.action+1, 1) = 'S'
                       ) as ku$_audit_act_list_t
      ),
  cast(multiset(select ata.action, ata.name
                from sys.auditable_system_actions ata
                where bitand(pol.type, 2) = 2 and
                      ata.type = 6 and
                      substr(pol.sysactn, ((select max(action)+1 from
                        sys.auditable_system_actions where type = 4) +
                          ata.action+1), 1) = 'S'
                       ) as ku$_audit_act_list_t
      ),
  cast(multiset(select ata.action, ata.name
                from sys.auditable_system_actions ata
                where bitand(pol.type, 2) = 2 and
                      ata.type = 8 and
                      substr(pol.sysactn, ((select max(action)+1 from
                         sys.auditable_system_actions where type = 4) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 6) +
                         ata.action+1), 1) = 'S'
                       ) as ku$_audit_act_list_t
      ),
  cast(multiset(select ata.action, ata.name
                from sys.auditable_system_actions ata
                where bitand(pol.type, 2) = 2 and
                      ata.type = 10 and
                      substr(pol.sysactn, ((select max(action)+1 from
                         sys.auditable_system_actions where type = 4) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 6) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 8) +
                         ata.action+1), 1) = 'S'
                       ) as ku$_audit_act_list_t
      ),
  cast(multiset(select ata.action, ata.name
                from sys.auditable_system_actions ata
                where bitand(pol.type, 2) = 2 and
                      ata.type = 11 and
                      substr(pol.sysactn, ((select max(action)+1 from
                         sys.auditable_system_actions where type = 4) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 6) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 8) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 10) +
                           (select count(*)+1 from
                             sys.auditable_system_actions where type = 7) +
                         ata.action+1), 1) = 'S'
                       ) as ku$_audit_act_list_t
      ),
  cast(multiset(
      select aoa.action, value(ao) , aoa.name
      from sys.auditable_object_actions aoa, sys.aud_object_opt$ opt,
           sys.ku$_schemaobj_view ao
      where opt.policy# = pol.policy# and
        opt.object# = ao.obj_num and
        bitand(pol.type, 4) = 4 and          /* Audit policy has Object option */
        opt.type = 2 and                         /* Schema Object audit option */
        substr(opt.action#, aoa.action+1, 1) = 'S'
                       ) as ku$_auditp_obj_list_t
      ),
  cast(multiset(
      select u.user#, u.name
      from sys.aud_object_opt$ opt, sys.user$ u
      where opt.policy# = pol.policy# and
        opt.object# = u.user# and
        bitand(pol.type, 32) = 32 and          /* Audit policy has Role option */
        opt.type = 1                                      /* Role audit option */
                       ) as ku$_audit_pol_role_list_t
      )
from sys.aud_policy$ pol, ku$_schemaobj_view o
where o.obj_num = pol.policy#
/

