create view USER_TAB_SUBPARTITIONS
            (TABLE_NAME, PARTITION_NAME, SUBPARTITION_NAME, HIGH_VALUE, HIGH_VALUE_LENGTH, PARTITION_POSITION,
             SUBPARTITION_POSITION, TABLESPACE_NAME, PCT_FREE, PCT_USED, INI_TRANS, MAX_TRANS, INITIAL_EXTENT,
             NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, MAX_SIZE, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING,
             COMPRESSION, COMPRESS_FOR, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, SAMPLE_SIZE,
             LAST_ANALYZED, BUFFER_POOL, FLASH_CACHE, CELL_FLASH_CACHE, GLOBAL_STATS, USER_STATS, INTERVAL,
             SEGMENT_CREATED, INDEXING, READ_ONLY, INMEMORY, INMEMORY_PRIORITY, INMEMORY_DISTRIBUTE,
             INMEMORY_COMPRESSION, INMEMORY_DUPLICATE, INMEMORY_SERVICE, INMEMORY_SERVICE_NAME, CELLMEMORY,
             MEMOPTIMIZE_READ, MEMOPTIMIZE_WRITE)
as
select po.name, po.subname, so.subname,
       tsp.hiboundval, tsp.hiboundlen,
       dense_rank() over (partition by po.name order by tcp.part#),
       row_number() over (partition by po.name,po.subname
                          order by tsp.subpart#),
       ts.name,  tsp.pctfree$,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tsp.pctused$),
       tsp.initrans, tsp.maxtrans,
       decode(bitand(tsp.flags, 65536), 65536,
              ds.initial_stg * ts.blocksize, s.iniexts * ts.blocksize),
       decode(bitand(tsp.flags, 65536), 65536,
              ds.next_stg * ts.blocksize, s.extsize * ts.blocksize),
       decode(bitand(tsp.flags, 65536), 65536, ds.minext_stg, s.minexts),
       decode(bitand(tsp.flags, 65536), 65536, ds.maxext_stg, s.maxexts),
       decode(bitand(tsp.flags, 65536), 65536,
              ds.maxsiz_stg * ts.blocksize,
              decode(bitand(s.spare1, 4194304), 4194304, bitmapranges, NULL)),
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
              decode(bitand(tsp.flags, 65536), 65536, ds.pctinc_stg, s.extpct)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tsp.flags, 65536), 65536,
                     decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                     decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tsp.flags, 65536), 65536,
                     decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                     decode(s.groups, 0, 1, s.groups))),
       decode(mod(trunc(tsp.flags / 4), 2), 0, 'YES', 'NO'),
       case when (bitand(tsp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 4), 4, 'ENABLED', 'DISABLED')
       else
         decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED')
       end,
       case when (bitand(tsp.flags, 65536) = 65536) then
          decode(bitand(ds.flags_stg, 4), 4,
          case when bitand(ds.cmpflag_stg, 3) = 1 then 'BASIC'
               when bitand(ds.cmpflag_stg, 3) = 2 then 'ADVANCED'
               else concat(decode(ds.cmplvl_stg, 1, 'QUERY LOW',
                                                 2, 'QUERY HIGH',
                                                 3, 'ARCHIVE LOW',
                                                    'ARCHIVE HIGH'),
                           decode(bitand(ds.flags_stg, 524288), 524288,
                                  ' ROW LEVEL LOCKING', '')) end,
           null)
       else
         decode(bitand(s.spare1, 2048), 0, null, 2048,
           case when bitand(s.spare1, 16777216) = 16777216
                     then 'ADVANCED'
                when bitand(s.spare1, 100663296) = 33554432  -- 0x2000000
                     then concat('QUERY LOW',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 100663296) = 67108864  -- 0x4000000
                     then concat('QUERY HIGH',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 100663296) = 100663296 -- 0x2000000+0x4000000
                     then concat('ARCHIVE LOW',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 134217728) = 134217728 -- 0x8000000
                     then concat('ARCHIVE HIGH',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                else 'BASIC' end, null)
       end,
       tsp.rowcnt, tsp.blkcnt, tsp.empcnt, tsp.avgspc, tsp.chncnt,
       tsp.avgrln, tsp.samplesize, tsp.analyzetime,
       decode(bitand(decode(bitand(tsp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 3),
              1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(decode(bitand(tsp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 12)/4,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(decode(bitand(tsp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 48)/16,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tsp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tsp.flags, 8), 0, 'NO', 'YES'),
       decode(bitand(tsp.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(tsp.flags, 65536), 65536, 'NO', 'YES'),
       decode(bitand(tsp.flags, 2097152), 2097152, 'OFF', 'ON'),
       decode(bitand(tsp.flags, 67108864), 67108864, 'YES', 'NO'),
       --INMEMORY
       case when (bitand(tsp.flags, 65536) = 65536) then
          -- flags/imcflag_stg (stgdef.h
          decode(bitand(ds.flags_stg, 6291456),
                2097152, 'ENABLED',
                4194304, 'DISABLED', 'DISABLED')
       else
          -- ktsscflg (ktscts.h)
          decode(bitand(s.spare1, 70373039144960),
                4294967296, 'ENABLED',
                70368744177664, 'DISABLED', 'DISABLED')
       end,
       -- INMEMORY_PRIORITY
       case when (bitand(tsp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 4), 4,
                decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 7936),
                256, 'NONE',
                512, 'LOW',
                1024, 'MEDIUM',
                2048, 'HIGH',
                4096, 'CRITICAL', 'UNKNOWN'), null),
                'NONE'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 34359738368), 34359738368,
                decode(bitand(s.spare1, 61572651155456),
                8796093022208, 'LOW',
                17592186044416, 'MEDIUM',
                35184372088832, 'HIGH',
                52776558133248, 'CRITICAL', 'NONE'),
                'NONE'),
                null)
       end,
       -- INMEMORY_DISTRIBUTE
       case when (bitand(tsp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 1), 1,
                       decode(bitand(ds.imcflag_stg, (16+32)),
                              16,  'BY ROWID RANGE',
                              32,  'BY PARTITION',
                              48,  'BY SUBPARTITION',
                               0,  'AUTO'),
                  null), null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
               decode(bitand(s.spare1, 8589934592), 8589934592,
                        decode(bitand(s.spare1, 206158430208),
                        68719476736,   'BY ROWID RANGE',
                        137438953472,  'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        null),
                  null)
       end,
       -- INMEMORY_COMPRESSION
       case when (bitand(tsp.flags, 65536) = 65536) then
        decode(bitand(ds.flags_stg, 6291456),
               2097152,
               decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              2,   'NO MEMCOMPRESS',
                              8,   'FOR DML',
                              10,  'FOR QUERY LOW',
                              64,  'FOR QUERY HIGH',
                              66,  'FOR CAPACITY LOW',
                              72,  'FOR CAPACITY HIGH',
                              130, 'AUTO', 'UNKNOWN'),
                4194304,
                decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              128, 'NO INMEMORY', null),
                null)
       else
         decode(bitand(s.spare1, 70373039144960), 4294967296,
                decode(bitand(s.spare1, 1941325217792),
                              17179869184,  'NO MEMCOMPRESS',
                              274877906944, 'FOR DML',
                              292057776128, 'FOR QUERY LOW',
                              549755813888, 'FOR QUERY HIGH',
                              566935683072, 'FOR CAPACITY LOW',
                              824633720832, 'FOR CAPACITY HIGH',
                              1116691496960, 'AUTO', 'UNKNOWN'),
                70368744177664,
                decode(bitand(s.spare1, 1941325217792),
                              1099511627776, 'NO INMEMORY',
                              null),
                null)
       end,
       -- INMEMORY_DUPLICATE
       case when (bitand(tsp.flags, 65536) = 65536) then
        decode(bitand(ds.flags_stg, 2097152), 2097152,
               decode(bitand(ds.imcflag_stg, (8192+16384)),
                              8192,   'NO DUPLICATE',
                              16384,  'DUPLICATE',
                              24576,  'DUPLICATE ALL',
                              null),
                null)
       else
          decode(bitand(s.spare1, 4294967296), 4294967296,
                   decode(bitand(s.spare1, 6597069766656),
                           2199023255552, 'NO DUPLICATE',
                           4398046511104, 'DUPLICATE',
                           6597069766656, 'DUPLICATE ALL', null),
                null)
       end,
       -- INMEMORY_SERVICE
       case when (bitand(tsp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'DEFAULT'), 'DEFAULT'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'DEFAULT'), 'DEFAULT'),
                 null)
       end,
       -- INMEMORY_SERVICE_NAME
       case when (bitand(tsp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       svc.svcname, null),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       svc.svcname, null),
                null)
       end,
       -- CELLMEMORY
       case when (bitand(tsp.flags, 65536) = 65536) then
         -- deferred segment: stgccflags (stgdef.h)
         decode(ccflag_stg,
             8194, 'NO MEMCOMPRESS',
             8196, 'MEMCOMPRESS FOR QUERY',
             8200, 'MEMCOMPRESS FOR CAPACITY',
             16384, 'DISABLED', null)
       else
         -- created segment: ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 4362862139015168),
              281474976710656, 'DISABLED',
              703687441776640, 'NO MEMCOMPRESS',
             1266637395197952, 'MEMCOMPRESS FOR QUERY',
             2392537302040576, 'MEMCOMPRESS FOR CAPACITY', null)
       end,
       -- MEMOPTIMIZE_READ -> KKPACFRAGF_IMOLTP_KV
       decode(bitand(tsp.flags, power(2,30)), power(2,30),
                                'ENABLED', 'DISABLED'),
       -- MEMOPTIMIZE_WRITE -> KKPACFRAGF_IMOLTP_INGEST
       decode(bitand(tsp.flags, power(2,31)), power(2,31),
                                'ENABLED', 'DISABLED')
from   sys.obj$ so, sys.obj$ po, sys.tabcompart$ tcp, sys.tabsubpart$ tsp,
       sys.tab$ t, sys.ts$ ts, sys.seg$ s, sys.deferred_stg$ ds, sys.imsvc$ svc
where  so.obj# = tsp.obj# and po.obj# = tsp.pobj# and tcp.obj# = tsp.pobj# and
       tcp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       tsp.ts# = ts.ts# and tsp.obj# = ds.obj#(+) and
       bitand(tcp.flags, 8388608) = 0 and   /* filter out hidden partitions */
       bitand(tsp.flags, 8388608) = 0 and   /* filter out hidden partitions */
       tsp.file# = s.file#(+) and tsp.block# = s.block#(+)
       and tsp.ts# = s.ts#(+) and
       po.owner# = userenv('SCHEMAID') and so.owner# = userenv('SCHEMAID')
       and po.namespace = 1 and po.remoteowner IS NULL and po.linkname IS NULL
       and so.namespace = 1 and so.remoteowner IS NULL and so.linkname IS NULL
       and tsp.obj# = svc.obj# (+) and svc.subpart#(+) is null
/

