create type       "SYS_YOID0000017376$"              as object( "SYS_NC00001$" NUMBER)
/

