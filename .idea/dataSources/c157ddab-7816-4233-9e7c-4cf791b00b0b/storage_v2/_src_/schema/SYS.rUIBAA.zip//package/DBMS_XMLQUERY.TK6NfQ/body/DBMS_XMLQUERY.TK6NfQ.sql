create PACKAGE BODY DBMS_XMLQUERY AS

  procedure getVersion IS
  begin
    DBMS_OUTPUT.PUT_LINE(CHR(0));
    DBMS_OUTPUT.PUT_LINE(CHR(0));
    DBMS_OUTPUT.PUT_LINE('XSU Version                ' ||
                         'Owner         Timestamp');
    DBMS_OUTPUT.PUT_LINE('-------------------------- ' ||
                         '------------- ----------------');

    FOR i IN (select object_name, owner, timestamp
              from sys.all_objects
              where object_name like '%XSU%VERSION%')
    LOOP
      DBMS_OUTPUT.PUT_LINE(RPAD(i.object_name,27) ||
                           RPAD(i.owner,14) || SUBSTR(i.timestamp,1,16));
    END LOOP;
      DBMS_OUTPUT.NEW_LINE;
  end getVersion;

  FUNCTION newContext(sqlQuery IN VARCHAR2) return ctxType
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.newContext(java.lang.String) return int';

  FUNCTION newContext(sqlQuery IN CLOB) return ctxType
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.newContext(oracle.sql.CLOB) return int';

  PROCEDURE closeContext(ctxHdl IN ctxType)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.closeContext(int)';

  PROCEDURE setRowsetTag(ctxHdl IN ctxType, tag IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRowsetTag(int, java.lang.String)';

  PROCEDURE setRowTag(ctxHdl IN ctxType, tag IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRowTag(int, java.lang.String)';

  PROCEDURE setErrorTag(ctxHdl IN ctxType, tag IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setErrorTag(int, java.lang.String)';

  PROCEDURE setRowIdAttrName(ctxHdl IN ctxType, attrName IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRowIdAttrName(int, java.lang.String)';

  PROCEDURE setRowIdAttrValue(ctxHdl IN ctxType, colName IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRowIdAttrValue(int, java.lang.String)';


  PROCEDURE setCollIdAttrName(ctxHdl IN ctxType, attrName IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setCollIdAttrName(int, java.lang.String)';


  PROCEDURE p_useTypeForCollElemTag(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.useTypeForCollElemTag(int,byte)';

  PROCEDURE useTypeForCollElemTag(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_useTypeForCollElemTag(ctxHdl, 1);
    else
      p_useTypeForCollElemTag(ctxHdl, 0);
    end if;
  end useTypeForCollElemTag;


  PROCEDURE p_useNullAttrInd(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.useNullAttributeIndicator(int, byte)';

  PROCEDURE useNullAttributeIndicator(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_useNullAttrInd(ctxHdl, 1);
    else
      p_useNullAttrInd(ctxHdl, 0);
    end if;
  end useNullAttributeIndicator;

  PROCEDURE p_setSQLToXMLNameEsc(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setSQLToXMLNameEscaping(int, byte)';

  PROCEDURE setSQLToXMLNameEscaping(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_setSQLToXMLNameEsc(ctxHdl, 1);
    else
      p_setSQLToXMLNameEsc(ctxHdl, 0);
    end if;
  end setSQLToXMLNameEscaping;

  PROCEDURE setTagCase(ctxHdl IN ctxType, tCase IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setTagCase(int, byte)';


  PROCEDURE setDateFormat(ctxHdl IN ctxType, mask IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setDateFormat(int, java.lang.String)';


  PROCEDURE setMaxRows (ctxHdl IN ctxType, rows IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setMaxRows(int, int)';


  PROCEDURE setSkipRows(ctxHdl IN ctxType, rows IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setSkipRows(int, int)';


  PROCEDURE p_setStylesheetHeader(ctxHdl IN ctxType, uri IN VARCHAR2, type IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setStylesheetHeader(int, java.lang.String, java.lang.String)';

  PROCEDURE setStylesheetHeader(ctxHdl IN ctxType, uri IN VARCHAR2, type IN VARCHAR2 := 'text/xsl') is
  begin
    p_setStylesheetHeader(ctxHdl, uri, type);
  end setStylesheetHeader;


  PROCEDURE p_setXSLT(ctxHdl IN ctxType, uri IN VARCHAR2, ref IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setXSLT(int, java.lang.String, java.lang.String)';

  PROCEDURE setXSLT(ctxHdl IN ctxType, uri IN VARCHAR2, ref IN VARCHAR2 := null) IS
  begin
    p_setXSLT(ctxHdl, uri, ref);
  end setXSLT;

  PROCEDURE p_setXSLT(ctxHdl IN ctxType, stylesheet IN CLOB, ref IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setXSLT(int, oracle.sql.CLOB, java.lang.String)';

  PROCEDURE setXSLT(ctxHdl IN ctxType, stylesheet IN CLOB, ref IN VARCHAR2 := null) IS
  begin
    p_setXSLT(ctxHdl, stylesheet, ref);
  end setXSLT;

  PROCEDURE setXSLTParam(ctxHdl IN ctxType, name IN VARCHAR2,value IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setXSLTParam(int, java.lang.String, java.lang.String)';

  PROCEDURE removeXSLTParam(ctxHdl IN ctxType, name IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.removeXSLTParam(int, java.lang.String)';

  PROCEDURE p_setEncodingTag(ctxHdl IN ctxType, enc IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setEncodingTag(int, java.lang.String)';

  PROCEDURE setEncodingTag(ctxHdl IN ctxType,enc IN VARCHAR2 := DB_ENCODING) is
  begin
    p_setEncodingTag(ctxHdl, enc);
  end setEncodingTag;

  PROCEDURE setBindValue(ctxHdl IN ctxType, bindName IN VARCHAR2, bindValue IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setBindValue(int, java.lang.String, java.lang.String)';


  PROCEDURE clearBindValues(ctxHdl IN ctxType)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.clearBindValues(int)';

  PROCEDURE p_setMetaHeader(ctxHdl IN ctxType, header IN CLOB)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setMetaHeader(int, oracle.sql.CLOB)';

  PROCEDURE setMetaHeader(ctxHdl IN ctxType, header IN CLOB := null) IS
  begin
    p_setMetaHeader(ctxHdl, header);
  end setMetaHeader;

  PROCEDURE p_setDataHeader(ctxHdl IN ctxType, header IN CLOB, tag IN VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setDataHeader(int, oracle.sql.CLOB, java.lang.String)';

  PROCEDURE setDataHeader(ctxHdl IN ctxType, header IN CLOB := null, tag IN VARCHAR2 := null) is
  begin
    p_setDataHeader(ctxHdl, header, tag);
  end setDataHeader;


  PROCEDURE p_setRaiseException(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRaiseException(int, byte)';

  PROCEDURE setRaiseException(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_setRaiseException(ctxHdl, 1);
    else
      p_setRaiseException(ctxHdl, 0);
    end if;
  end setRaiseException;

  PROCEDURE p_setRaiseNoRowsExc(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setRaiseNoRowsException(int, byte)';

  PROCEDURE setRaiseNoRowsException(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_setRaiseNoRowsExc(ctxHdl, 1);
    else
      p_setRaiseNoRowsExc(ctxHdl, 0);
    end if;
  end setRaiseNoRowsException;

  PROCEDURE p_propOrigExc(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.propagateOriginalException(int, byte)';

  PROCEDURE propagateOriginalException(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_propOrigExc(ctxHdl, 1);
    else
      p_propOrigExc(ctxHdl, 0);
    end if;
  end propagateOriginalException;

  PROCEDURE getExceptionContent(ctxHdl IN ctxType, errNo OUT NUMBER, errMsg OUT VARCHAR2)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.getExceptionContent(int, int[], java.lang.String[])';

  PROCEDURE p_setStrictLegalXMLCharCheck(ctxHdl IN ctxType, flag IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.setStrictLegalXMLCharCheck(int, byte)';

  PROCEDURE setStrictLegalXMLCharCheck(ctxHdl IN ctxType, flag IN BOOLEAN := true) is
  begin
    if flag = true then
      p_setStrictLegalXMLCharCheck(ctxHdl, 1);
    else
      p_setStrictLegalXMLCharCheck(ctxHdl, 0);
    end if;
  end setStrictLegalXMLCharCheck;

  ------------------- generation ----------------------------------------------
  FUNCTION getDTD(ctxHdl IN ctxType, withVer IN BOOLEAN := false) RETURN CLOB IS
    clb CLOB;
  begin
    dbms_lob.createtemporary(clb, true, DBMS_LOB.SESSION);
    getDTD(ctxHdl, clb, withVer);
    return clb;
  end getDTD;

  PROCEDURE p_getDTD(ctxHdl IN ctxType, xDoc IN CLOB, withVer IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.getDTD(int, oracle.sql.CLOB, byte)';

  PROCEDURE getDTD(ctxHdl IN ctxType, xDoc IN CLOB, withVer IN BOOLEAN := false) IS
  begin
    if withVer = true then
      p_getDTD(ctxHdl, xDoc, 1);
    else
      p_getDTD(ctxHdl, xDoc, 0);
    end if;
  end getDTD;


  FUNCTION getXML(ctxHdl IN ctxType, metaType IN NUMBER := NONE) RETURN CLOB IS
    clb CLOB;
  begin
    dbms_lob.createtemporary(clb, true, DBMS_LOB.SESSION);
    getXML(ctxHdl, clb, metaType);
    return clb;
  end getXML;

  PROCEDURE p_getXML(ctxHdl IN ctxType, xDoc IN CLOB, metaType IN NUMBER)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.getXML(int, oracle.sql.CLOB, byte)';

  PROCEDURE getXML(ctxHdl IN ctxType, xDoc IN CLOB, metaType IN NUMBER := NONE) IS
  begin
    p_getXML(ctxHdl, xDoc, metaType);
  end getXML;

  FUNCTION getXML(sqlQuery IN VARCHAR2, metaType IN NUMBER := NONE) RETURN CLOB IS
    ctx    ctxType;
    clb    CLOB;
  begin
    ctx := newContext(sqlQuery);
    clb := getXML(ctx, metaType);
    closeContext(ctx);
    return clb;
  end getXML;

  FUNCTION getXML(sqlQuery IN CLOB, metaType IN NUMBER := NONE) RETURN CLOB IS
    ctx    ctxType;
    clb    CLOB;
  begin
    ctx := newContext(sqlQuery);
    clb := getXML(ctx, metaType);
    closeContext(ctx);
    return clb;
  end getXML;


  PROCEDURE resetResultSet(ctxHdl IN ctxType)
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.resetResultSet(int)';


  FUNCTION getNumRowsProcessed(ctxHdl IN ctxType) RETURN NUMBER
  as LANGUAGE JAVA NAME
   'oracle.xml.sql.query.OracleXMLStaticQuery.getNumRowsProcessed(int) return long';


END DBMS_XMLQUERY;
/

