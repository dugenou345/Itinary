create PACKAGE tsdp$datapump AS

PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO_WITH_COMMIT);

PROCEDURE INSTANCE_CALLOUT_IMP(
  obj_name         in      varchar2,
  obj_schema       in      varchar2,
  obj_type         in      number,
  prepost          in      pls_integer,
  action           out     varchar2,
  alt_name         out     varchar2);

END tsdp$datapump;
/

