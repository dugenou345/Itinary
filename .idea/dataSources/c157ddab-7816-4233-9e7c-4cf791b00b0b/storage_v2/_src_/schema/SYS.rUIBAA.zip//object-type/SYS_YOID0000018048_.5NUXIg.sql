create type       "SYS_YOID0000018048$"              as object( "SYS_NC00001$" CHARACTER(1 BYTE))
/

