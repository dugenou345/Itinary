create TYPE adr_log_msg_errid_t FORCE AS OBJECT
(
  id         VARCHAR2(100),                             /* error instance id */
  rid        VARCHAR2(100)                              /* error sequence id */
);
/

