create type       "SYS_YOID0000019293$"              as object( "SYS_NC00001$" NUMBER)
/

