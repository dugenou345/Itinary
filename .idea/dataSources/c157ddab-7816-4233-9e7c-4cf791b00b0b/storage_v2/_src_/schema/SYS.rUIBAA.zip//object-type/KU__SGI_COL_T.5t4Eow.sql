create type ku$_sgi_col_t force as object
(
  obj_num           number,                 -- index object number
  con_num           number,                 -- constraint number if constraint
  name              varchar2(128)           -- column name
)
not persistable
/

