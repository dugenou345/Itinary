create PACKAGE dbms_awrhub_source AUTHID CURRENT_USER AS

  -- Support log based replication (proj 17779)
  -- NOTE: Procedures cannot be replicated by LogMiner via regular
  --       DML/DDL apply (replication of SYS schema is not supported)
  --       nor using 'Procedural replication' (re-invoking the procedure
  --       at the logical standby produce different results)
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED);

  UPLOAD_BOUND_CURR_SNID CONSTANT VARCHAR2(128) := 'CURRENT_SNAP_ID';
  UPLOAD_BOUND_MAX_SNID  CONSTANT VARCHAR2(128) := 'MAX_SNAP_ID';

  --
  -- register_source
  --   Routine to configure the database where it runs as an AWRHub
  --   source of the specified hub.
  --
  --  Input Parameters:
  --    hub_name     - Name of the hub for source to register.
  --    source_name  - Name used to register the source in the hub. Maximum
  --                   name length is 128.
  --    source_id    - Unique source identifier.
  --    hub_mailbox  - Directory object used to store AWRHub Mail packages
  --                   for the hub.
  --    mailbox_type - Mailbox type, following are two supported types:
  --                   'FILE_SYSTEM' : Local file system
  --                   'OBJECT_STORE': Oracle Object Store in cloud
  --    mailbox_cred - Credential for Oracle Wallet, must be provided if
  --                   mailbox_type is 'OBJECT_STORE'
  --    cred_owner   - The owner who created the credential. If NULL is provided
  --                   the credential is assumed to be owned by the current
  --                   user who invokes this API.
  PROCEDURE register_source(hub_name      IN VARCHAR2,
                            source_name   IN VARCHAR2 DEFAULT NULL,
                            hub_mailbox   IN VARCHAR2,
                            mailbox_type  IN VARCHAR2 DEFAULT 'FILE_SYSTEM',
                            mailbox_cred  IN VARCHAR2 DEFAULT NULL,
                            cred_owner    IN VARCHAR2 DEFAULT NULL);

  --
  -- setup_source_cache_mailbox
  --   Routine to setup a cache mailbox for AWRHub source. A source cache
  --   mailbox is a temporary location for mailpkgs to be put in before
  --   exported to the hub mailbox. The purpose of setting up a source
  --   mailbox is to improve export performance.
  --
  --  Input parameters
  --    hub_name      - Name of the hub where the source is registered.
  --    source_name   - Name used to register the source in the hub.
  --    cache_mailbox - Mailbox location for caching purpose.
  --                    If NULL is provided, using DATA_PUMP_DIR
  --
  PROCEDURE setup_source_cache_mailbox(hub_name      IN VARCHAR2,
                                       source_name   IN VARCHAR2 DEFAULT NULL,
                                       cache_mailbox IN VARCHAR2 DEFAULT NULL);

  --
  -- get_hub_account
  --   Routine to obtain the hub_account for given source_name and source_id
  --
  --  Input parameters
  --    hub_name    - Name of the hub where the source is registered.
  --    source_name - Name used to register the source in the hub
  --    source_id   - Unique source identifier.
  --
  --  Returns:
  --    If the source is successfully registered with a hub, it will return
  --    the hub_account associated with the source registration.
  --    Otherwise, it will throw errors to indicate either the registration
  --    is still pending or source_name/source_id pair not exists.
  --
  FUNCTION get_hub_account(hub_name    IN VARCHAR2,
                           source_name IN VARCHAR2,
                           source_id   IN NUMBER)
  RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(GET_HUB_ACCOUNT, READ_ONLY);

  --
  -- unregister_source
  --   Routine to unregister a source from AWRHub
  --
  --  Input parameters
  --    hub_name    - Name of the hub where the source is registered.
  --    source_name - Name of the source to be unregistered.
  --
  PROCEDURE unregister_source(hub_name    IN VARCHAR2 DEFAULT NULL,
                              source_name IN VARCHAR2 DEFAULT NULL);

  --
  -- modify_source_settings
  --   Routine to modify the settings of the source.
  --
  --  Input Parameters:
  --    hub_name        - Name of the hub where the source is registered.
  --    source_name     - Name of the source
  --    upload_interval - The time frequency in which the source will
  --                      attempt to export new packages to the mailbox, in
  --                      unit of seconds.
  --
  --                      Default value is 86400 (24 hours).
  --
  --                      Minimum value is 60 (1 minute).
  --
  --                      If NULL is specified, the current value is preserved.
  --    upload_lo_bound - Minimum value of the snapshot to upload
  --                      If NULL is specified, the current value is preserved.
  --                      Possible non-NULLable values:
  --                         1) UPLOAD_BOUND_CURR_SNID, or
  --                         2) UPLOAD_BOUND_MAX_SNID, or
  --                         3) A valid snapid in string format.
  --
  --    upload_hi_bound - Maxinum value of the snapshot to upload
  --                      If NULL is specified, the current value is preserved.
  --                      Possible values: same as upload_lo_bound
  --
  PROCEDURE modify_source_settings(hub_name        IN VARCHAR2 DEFAULT NULL,
                                   source_name     IN VARCHAR2 DEFAULT NULL,
                                   upload_interval IN NUMBER DEFAULT NULL,
                                   upload_lo_bound IN VARCHAR2 DEFAULT NULL,
                                   upload_hi_bound IN VARCHAR2 DEFAULT NULL);

  --
  -- check_registration_status
  --   Function to check the registration status. It will wait until the
  --   registration completes (either SUCCESS or FAILED) within the maximum
  --   specified wait time.
  --
  --   If NULL is specified, use the the default wait time (15minutes).
  --
  --  Input parameters
  --    wait_time - Wait time (in seconds)
  --
  FUNCTION  check_registration_status(wait_time IN NUMBER DEFAULT NULL)
  RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(CHECK_REGISTRATION_STATUS, READ_ONLY);

  --
  -- upload snapshot
  --   Routine to manually upload snapshot in the specified range into
  --   AWRHub server
  --
  --  Input parameters
  --   beg_snap_id    - (IN) Begin snap ID.
  --                         If NULL is specified, use the the begin snap ID
  --                         that Auto-upload determines
  --   end_snap_id    - (IN) End snap ID
  --                         If NULL is specified, use the the end snap ID
  --                         that Auto-upload determines
  PROCEDURE upload_snapshot(beg_snap_id   IN  NUMBER DEFAULT NULL,
                            end_snap_id   IN  NUMBER DEFAULT NULL);

END dbms_awrhub_source;
/

