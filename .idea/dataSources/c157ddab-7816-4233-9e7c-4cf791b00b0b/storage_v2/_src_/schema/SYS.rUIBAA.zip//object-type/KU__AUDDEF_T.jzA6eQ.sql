create TYPE     ku$_auddef_t FORCE AS OBJECT
(
  name          VARCHAR2(31),   -- operation to be audited, e.g., ALTER
  value         CHAR(1),        -- 'S' = by session
                                -- 'A' = by access
                                -- '-' = no auditing
  type          CHAR(1)         -- 'S' = when successful
                                -- 'F' = when not successful
)
NOT PERSISTABLE
/

