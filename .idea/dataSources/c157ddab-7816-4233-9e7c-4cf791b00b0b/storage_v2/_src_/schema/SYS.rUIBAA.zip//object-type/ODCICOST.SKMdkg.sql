create TYPE ODCICost FORCE
                                         AS OBJECT
(
  CPUcost         NUMBER,
  IOcost          NUMBER,
  NetworkCost     NUMBER,
  IndexCostInfo   VARCHAR2(255)
);
/

