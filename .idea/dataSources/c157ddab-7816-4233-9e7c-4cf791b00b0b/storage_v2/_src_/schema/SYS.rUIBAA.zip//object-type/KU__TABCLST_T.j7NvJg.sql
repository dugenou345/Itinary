create type ku$_tabclst_t force as object
(
  base_obj_num  number,                                     /* base object # */
  base_obj      ku$_schemaobj_t,                              /* base object */
  clst          ku$_clst_t                  /* table clustering info, if any */
)
not persistable
/

