create TYPE     ku$_ddl FORCE AS OBJECT
        (       ddltext         CLOB,                   -- The DDL text
                parsedItems     sys.ku$_parsed_items    -- the parsed items
        )
NOT PERSISTABLE
/

