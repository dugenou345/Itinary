create type       "SYS_YOID0000018154$"              as object( "SYS_NC00001$" NUMBER)
/

