create function dbms_pdb_check_lockdown (rule_type      number,
                                                    rule_id        number,
                                                    raise_error    boolean,
                                                    init_parameter number,
                                                    events         boolean)
  return boolean authid current_user is
begin
  return dbms_pdb.check_lockdown(rule_type, rule_id, raise_error,
                                 init_parameter, events);
end;
/

