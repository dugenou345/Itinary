create view "_DBA_STREAMS_COMPONENT_PROP"
            (COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, PROP_NAME, PROP_VALUE, SPARE1, SPARE2, SPARE3, SPARE4) as
SELECT  v.COMPONENT_NAME,
        global_name                   as COMPONENT_DB,
        v.COMPONENT_TYPE,
        v.PROP_NAME,
        v.PROP_VALUE,
        0, 0, NULL, to_date(NULL, '')
FROM ( -- Capture property: SOURCE_DATABASE
       SELECT c.capture_name          as COMPONENT_NAME,
              1                       as COMPONENT_TYPE,
              'SOURCE_DATABASE'       as PROP_NAME,
              c.source_dbname         as PROP_VALUE
       -- OPTIMIZE: Replace dba_capture with sys.streams$_capture_process
       FROM sys.streams$_capture_process c
       UNION
       -- CAPTURE property: PARALLELISM
       SELECT c.capture_name          as COMPONENT_NAME,
              1                       as COMPONENT_TYPE,
              'PARALLELISM'           as PROP_NAME,
              p.value                 as PROP_VALUE
       FROM sys.streams$_capture_process c,
            sys.streams$_process_params p
       WHERE c.capture# = p.process# AND
             p.name = 'PARALLELISM' AND
             p.process_type = 2       -- type 2 indicates capture process
       UNION
       -- Capture property: OPTIMIZATION_MODE
       SELECT c.capture_name          as COMPONENT_NAME,
              1                       as COMPONENT_TYPE,
              'OPTIMIZATION_MODE'     as PROP_NAME,
              decode(c.optimization, 1, '1', 2, '2', '0')
                                      as PROP_VALUE
       FROM SYS."_GV$SXGG_CAPTURE" c
       UNION
       -- Apply - property: PARALLELISM
       SELECT apply_name                as COMPONENT_NAME,
              4                         as COMPONENT_TYPE,
              'PARALLELISM'             as PROP_NAME,
              to_char(count(server_id)) as PROP_VALUE
       FROM  SYS."_GV$SXGG_APPLY_SERVER"
       GROUP BY apply_name
       UNION
      -- Replicat - property: PARALLELISM
       SELECT ltrim(apply_name, 'OGG$') as COMPONENT_NAME,
              7                         as COMPONENT_TYPE,
              'PARALLELISM'             as PROP_NAME,
              to_char(count(server_id)) as PROP_VALUE
       FROM  gv$gg_apply_server
       GROUP BY apply_name
       UNION
       -- Extract property: PARALLELISM - always 1
       SELECT e.extract_name              as COMPONENT_NAME,
              6                         as COMPONENT_TYPE,
              'PARALLELISM'             as PROP_NAME,
              '1'                         as PROP_VALUE
       FROM gv$goldengate_capture e
       UNION
       -- Apply/Extract property: SOURCE_DATABASE
       SELECT decode(da.purpose, 'GoldenGate Capture',
                     ltrim(ap.apply_name, 'OGG$'),
                     ap.apply_name)   as COMPONENT_NAME,
              decode(da.purpose, 'GoldenGate Capture', 6, 4)
                                      as COMPONENT_TYPE,
              'SOURCE_DATABASE'       as PROP_NAME,
              am.source_db_name       as PROP_VALUE
       -- OPTIMIZE: Replace dba_apply_progress with
       -- sys.streams$_apply_process and sys.streams$_apply_milestone
       FROM sys.streams$_apply_process ap,
            dba_apply da,
            sys.streams$_apply_milestone am
       WHERE ap.apply# = am.apply# (+) AND
             da.apply_name = ap.apply_name
       UNION
       -- Apply/Extract property: APPLY_CAPTURED
       SELECT decode(da.purpose,
                     'GoldenGate Capture', ltrim(a.apply_name, 'OGG$'),
                     a.apply_name)   as COMPONENT_NAME,
              decode(da.purpose, 'GoldenGate Capture', 6, 4)
                                      as COMPONENT_TYPE,
              'APPLY_CAPTURED'        as PROP_NAME,
              decode(bitand(a.flags, 1), 1, 'YES', 0, 'NO')
                                      as PROP_VALUE
       FROM sys.streams$_apply_process a,
            dba_apply da
       WHERE a.apply_name = da.apply_name
       UNION
       -- Apply/Extract property: MESSAGE_DELIVERY_MODE
       SELECT decode(da.purpose,
                     'GoldenGate Capture', ltrim(a.apply_name, 'OGG$'),
                     a.apply_name)    as COMPONENT_NAME,
              decode(da.purpose, 'GoldenGate Capture', 6, 4)
                                      as COMPONENT_TYPE,
              'MESSAGE_DELIVERY_MODE' as PROP_NAME,
              decode(bitand(a.flags, 1), 1, 'CAPTURED',
                     decode(bitand(a.flags, 128),
                            128, 'CAPTURED', 0, 'PERSISTENT'))
                                      as PROP_VALUE
       FROM sys.streams$_apply_process a,
            dba_apply da
       WHERE a.apply_name = da.apply_name
     ) v, global_name
/

comment on table "_DBA_STREAMS_COMPONENT_PROP" is 'DBA Streams Component Properties'
/

comment on column "_DBA_STREAMS_COMPONENT_PROP".COMPONENT_NAME is 'Name of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_PROP".COMPONENT_DB is 'Database on which the streams component resides'
/

comment on column "_DBA_STREAMS_COMPONENT_PROP".COMPONENT_TYPE is 'Type of the streams component'
/

comment on column "_DBA_STREAMS_COMPONENT_PROP".PROP_NAME is 'Name of the property'
/

comment on column "_DBA_STREAMS_COMPONENT_PROP".PROP_VALUE is 'Value of the property'
/

