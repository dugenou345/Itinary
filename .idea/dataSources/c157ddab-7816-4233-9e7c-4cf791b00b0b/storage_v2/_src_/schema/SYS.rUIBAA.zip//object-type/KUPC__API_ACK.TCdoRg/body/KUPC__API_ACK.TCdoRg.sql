create TYPE BODY kupc$_api_ack wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
4eb 13c
zoxgzRFFac/eep1zEK0eyJZPp6Qwgz0JLcsVyi8yM9VIfQ70f/+rWxiAXm2Ax92Pol+3KSWV
tR/yhuB3lWtlyJjG2VWGQ77HbWnsaohFEqpiFWOdAtkNHTjBpiXIMopjgnSXt/UNqBHP1W3K
g3vnMVZmHk414Zuw0zrVx71f/4I36TtRqbSjZEynCeBc63wGkdWcoiD+1o6+HGNGCDh4S8it
4i4UGknTnfP7m6MXWt7MMTZ5wE/+sKspSxO1/zezrD2/0U5X+RGX7IlYX/YtdeXe8uqqyC1N
wMI++AzQD7Y6PAb1chwYYTa4
/

