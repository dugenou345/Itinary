create function
  SYS_XMLAGG(input sys.xmltype, format sys.XMLGenFormatType := null)
  return sys.xmltype as
 begin
   null;
 end;
/

