create view DBA_USERS
            (USERNAME, USER_ID, PASSWORD, ACCOUNT_STATUS, LOCK_DATE, EXPIRY_DATE, DEFAULT_TABLESPACE,
             TEMPORARY_TABLESPACE, LOCAL_TEMP_TABLESPACE, CREATED, PROFILE, INITIAL_RSRC_CONSUMER_GROUP, EXTERNAL_NAME,
             PASSWORD_VERSIONS, EDITIONS_ENABLED, AUTHENTICATION_TYPE, PROXY_ONLY_CONNECT, COMMON, LAST_LOGIN,
             ORACLE_MAINTAINED, INHERITED, DEFAULT_COLLATION, IMPLICIT, ALL_SHARD, EXTERNAL_SHARD, PASSWORD_CHANGE_DATE,
             MANDATORY_PROFILE_VIOLATION)
as
select u.name, u.user#,
     decode(u.password, 'GLOBAL', u.password,
                        'EXTERNAL', u.password,
                        NULL),
     m.status,
     decode(mod(u.astatus, 16), 4, u.ltime,
                                5, u.ltime,
                                6, u.ltime,
                                8, u.ltime,
                                9, u.ltime,
                                10, u.ltime, to_date(NULL)),
     decode(mod(u.astatus, 16),
            1, u.exptime,
            2, u.exptime,
            5, u.exptime,
            6, u.exptime,
            9, u.exptime,
            10, u.exptime,
            decode(bitand(u.spare1,65536), 65536, to_date(NULL),
              decode(u.password, 'GLOBAL', to_date(NULL),
                               'EXTERNAL', to_date(NULL),
                decode(u.ptime, '', to_date(NULL),
                  decode(pr.limit#, 2147483647, to_date(NULL),
                   decode(pr.limit#, 0,
                     decode(dp.limit#, 2147483647, to_date(NULL), u.ptime +
                       dp.limit#/86400),
                     u.ptime + pr.limit#/86400)))))),
     dts.name, tts.name, ltts.name, 
     u.ctime, p.name,
     nvl(cgm.consumer_group, 'DEFAULT_CONSUMER_GROUP'),
     u.ext_username,
     decode(bitand(u.spare1, 65536), 65536, NULL, decode(
       REGEXP_INSTR(
         NVL2(u.password, u.password, ' '),
         '^                $'
       ),
       0,
       decode(length(u.password), 16, '10G ', NULL),
       ''
     ) ||
     decode(
       REGEXP_INSTR(
         REGEXP_REPLACE(
           NVL2(u.spare4, u.spare4, ' '),
           'S:000000000000000000000000000000000000000000000000000000000000',
           'not_a_verifier'
         ),
         'S:'
       ),
       0, '', '11G '
     ) ||
     decode(
       REGEXP_INSTR(
         NVL2(u.spare4, u.spare4, ' '),
         'T:'
       ),
       0, '', '12C '
     ) ||
     decode(
       REGEXP_INSTR(
         REGEXP_REPLACE(
           NVL2(u.spare4, u.spare4, ' '),
           'H:00000000000000000000000000000000',
           'not_a_verifier'
         ),
         'H:'
       ),
       0, '', 'HTTP '
     )),
     decode(bitand(u.spare1, 16),
            16, 'Y',
                'N'),
     decode(bitand(u.spare1,65536), 65536, 'NONE',
                   decode(u.password, 'GLOBAL',   'GLOBAL',
                                      'EXTERNAL', 'EXTERNAL',
                                      'PASSWORD')),
     decode(bitand(u.spare1, 10272),
            32, 'Y', 2048, 'Y',  2080, 'Y',
          8192, 'Y', 8224, 'Y', 10240, 'Y',
         10272, 'Y',
                'N'),
     decode(bitand(u.spare1, 128), 0, 'NO', 'YES'),
    from_tz(to_timestamp(to_char(u.spare6, 'DD-MON-YYYY HH24:MI:SS'),
                          'DD-MON-YYYY HH24:MI:SS'), '0:00')
     at time zone sessiontimezone,
     decode(bitand(u.spare1, 256), 256, 'Y', 'N'),
     decode(bitand(u.spare1, 4224),
            128, decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES'),
            4224, decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'),
                         'YES', 'YES', 'NO'),
            'NO'),
     nls_collation_name(nvl(u.spare3, 16382)),
     -- IMPLICIT
     decode(bitand(u.spare1, 32768), 32768, 'YES', 'NO'),
     -- ALL_SHARD
     decode(bitand(u.spare1, 16384), 16384, 'YES', 'NO'),
     -- EXTERNAL_SHARD
     decode(bitand(u.spare1, 262144), 262144, 'YES', 'NO'),
     -- PASSWORD_CHANGE_DATE
     u.ptime,
     -- MANDATORY_PROFILE_VIOLATION
     decode(bitand(u.astatus, 64), 64, 'YES', 'NO')
     from sys.user$ u
          left outer join sys.resource_group_mapping$ cgm
          on (cgm.attribute = 'ORACLE_USER' and cgm.status = 'ACTIVE' and
              cgm.value = u.name) left outer join sys.ts$ ltts
                                       on (u.spare9 = ltts.ts#),
          sys.ts$ dts, sys.ts$ tts, sys.profname$ p,
          sys.user_astatus_map m, sys.profile$ pr, sys.profile$ dp
    where u.datats# = dts.ts#
     and u.resource$ = p.profile#
     and u.tempts# = tts.ts#
     and ((u.astatus = m.status#) or
          (u.astatus = (m.status# + 16 - BITAND(m.status#, 16))) or
          (u.astatus = (m.status# + 64 - BITAND(m.status#, 64))))
     and u.type# = 1
     and u.resource$ = pr.profile#
     and dp.profile# = 0
     and dp.type#=1
     and dp.resource#=1
     and pr.type# = 1
     and pr.resource# = 1
/

comment on table DBA_USERS is 'Information about all users of the database'
/

comment on column DBA_USERS.USERNAME is 'Name of the user'
/

comment on column DBA_USERS.USER_ID is 'ID number of the user'
/

comment on column DBA_USERS.PASSWORD is 'Deprecated from 11.2 -- use AUTHENTICATION_TYPE instead'
/

comment on column DBA_USERS.ACCOUNT_STATUS is 'Status of user account like OPEN, LOCKED, EXPIRED etc.'
/

comment on column DBA_USERS.LOCK_DATE is 'Date on which the user account was locked if account status was locked'
/

comment on column DBA_USERS.EXPIRY_DATE is 'Date on which the user account''s password was expired if account status was EXPIRED, or will expire, if account status was OPEN (valid only for password authenticated users)'
/

comment on column DBA_USERS.DEFAULT_TABLESPACE is 'Default tablespace for data'
/

comment on column DBA_USERS.TEMPORARY_TABLESPACE is 'Default tablespace for temporary tables'
/

comment on column DBA_USERS.CREATED is 'User creation date'
/

comment on column DBA_USERS.PROFILE is 'User resource profile name'
/

comment on column DBA_USERS.INITIAL_RSRC_CONSUMER_GROUP is 'User''s initial consumer group'
/

comment on column DBA_USERS.EXTERNAL_NAME is 'User external name'
/

comment on column DBA_USERS.PASSWORD_VERSIONS is 'List of versions of password hashes (e.g. 11G for SHA-1, 12C for SHA-512)'
/

comment on column DBA_USERS.EDITIONS_ENABLED is 'Whether editions are enabled for this user'
/

comment on column DBA_USERS.AUTHENTICATION_TYPE is 'Authentication mechanism for the user'
/

comment on column DBA_USERS.PROXY_ONLY_CONNECT is 'Whether this user can connect only through a proxy'
/

comment on column DBA_USERS.COMMON is 'Indicates whether this user is Common'
/

comment on column DBA_USERS.ORACLE_MAINTAINED is 'Denotes whether the user was created, and is maintained, by Oracle-supplied scripts. A user for which this has the value Y must not be changed in any way except by running an Oracle-supplied script.'
/

comment on column DBA_USERS.INHERITED is 'Was user definition inherited from another container'
/

comment on column DBA_USERS.DEFAULT_COLLATION is 'User default collation'
/

comment on column DBA_USERS.IMPLICIT is 'Is this user a common user created by an implicit application'
/

comment on column DBA_USERS.ALL_SHARD is 'Is this user an all-shard user'
/

comment on column DBA_USERS.EXTERNAL_SHARD is 'Is this user an external shard user'
/

comment on column DBA_USERS.PASSWORD_CHANGE_DATE is 'Date on which the user account''s password was last changed (valid only for password authenticated users)'
/

comment on column DBA_USERS.MANDATORY_PROFILE_VIOLATION is 'Denotes whether the user account''s password violates mandatory profile''s password complexity requirements. It is valid only for password authenticated users in a multitenant container database (CDB)'
/

