create view REPL_FEATURE_BITMAP (OWNER, TABLE_NAME, OBJNO, FBMAP1, FBMAP2) as
select u.name owner, o.name table_name, o.obj# objno,
  /******************  BEGIN FBMAP1 ************************/
  /*  PERMANENTLY INTERNAL TABLE FEATURES */
  /* This is a category of Internal features that are true at CREATE TABLE time,
   * and should never change via ALTER TABLE, even in future releases.
  /* 0x01 - Internal Schema */
  (case when
    (exists (select 1 from system.logstdby$skip_support s
             where s.name = u.name and action = 0)) then 1 else 0 end) +
  /* 0x02 - Temporary table */
  (case when (bitand(o.flags, 2) != 0)
       then 2 else 0 end) +
  /* 0x04 - Secondary object */
  (case when bitand(o.flags, 16) != 0 then 4 else 0 end) +
  /* 0x08 - Internal (IOT/Rowid) Mapping Table */
  (case when (bitand(t.flags, 536870912) != 0         /* IOT mapping */
          or  bitand(t.property, power(2,57)) != 0) /* rowid mapping */
       then 8 else 0 end) +
  /* 0x10 - IOT Overflow Segment */
  (case when bitand(t.property, 512) != 0 then 16 else 0 end) +
  /* 0x20 - Nested Table Storage */
  (case when bitand(t.property, 8192) != 0 then 32 else 0 end) +
  /* 0x40 - XML/OR Storage Table */
  (case when exists
       (select 1 from sys.opqtype$ opq
          where o.obj# = opq.obj#
            and bitand(opq.flags, 32) = 32)
      then 64 else 0 end) +
  /* 0x80 - unused */
  /* NON PERMANENT INTERNAL TABLE FEATURES */
  /* 0x100 - External, non-Hybrid partitioned, table */
  (case when
      (bitand(t.property, 2147483648) != 0 and
       bitand(t.property, power(2,90)) = 0)
      then 256 else 0 end) +
  /* 0x200 - XML Tokenset */
  (case when bitand(t.property, power(2,65)) != 0
      then 512 else 0 end) +
  /* 0x400 - Internal AQ table */
  (case when
      (bitand(t.property, 131072) != 0 and
       (o.name like 'AQ$\_%\_P' escape '\' or
        o.name like 'AQ$\_%\_C' escape '\' or
        o.name like 'AQ$\_%\_H' escape '\' or
        o.name like 'AQ$\_%\_I' escape '\'))
      then 1024 else 0 end) +
  /* 0x800 - Dropped table */
  (case when bitand(o.flags, 128) != 0 then 2048 else 0 end) +
  /* 0x1000 - Materialized View Table, Read-only MV, container */
  (case when (bitand(t.property, 67108864+33554432) /* mv */ != 0 or
              bitand(t.flags, 262144) != 0 /* summary container */)
      then 4096 else 0 end) +
  /* 0x2000 - MVLOG Table */
  (case when exists (select 1 from sys.mlog$ ml
               where ml.mowner = u.name and ml.log = o.name)
      then 8192 else 0 end) +
  /* 0x4000 - Sub object */
  (case when bitand(t.property, 134217728) != 0
      then 16384 else 0 end) +
  /* 0x8000 - Cube */
  (case when bitand(t.property, 4294967296) != 0
      then 32768 else 0 end) +
  /* 0x10000 - FBA Internal */
  (case when bitand(t.property, 8589934592) != 0
      then 65536 else 0 end) +
  /* TABLE-LEVEL FEATURES */
  /* 0x200000 - Reference Partitioning */
  (case when exists
    (select 1 from partobj$ po
      where po.obj#=o.obj# and
            po.parttype=5)
      then 2097152 else 0 end) +
  /* 0x400000 - System Partitioning */
  (case when exists
    (select 1 from partobj$ po
      where po.obj#=o.obj# and
            po.parttype=3)
      then 4194304 else 0 end) +
  /* 0x800000 - OLAP AW$ Table */
  (case when bitand(t.property, power(2,69)) != 0
      then 8388608 else 0 end) +
  /* 0x1000000 - Hierarchy-enabled Table */
  (case when
        (bitand(t.property, 1) = 1 and
         exists (select 1 from sys.opqtype$ opq
                   where opq.obj# = t.obj# and
                         opq.type=1 and
                         bitand(opq.flags,512) = 512))
        then 16777216 else 0 end)  +
  /* 0x2000000 - AQ queue table */
  (case when bitand(t.property, 131072) != 0
       then 33554432 else 0 end) +
  /* 0x4000000 - Sharded Queue Table */
  (case when bitand(t.property, power(2,73)) != 0
       then 67108864 else 0 end) +
  /* 0x8000000 - Sorted hash cluster table */
  (case when
        (bitand(t.property, 1024) != 0 and
         exists (select 1 from clu$ cl
                  where cl.obj#=t.bobj#
                    and bitand(cl.spare1, 8388608) != 0))
        then 134217728 else 0 end) +
  /* 0x10000000 - Temporal Validity column present in table */
  (case when bitand(t.property, power(2,62)) != 0
        then 268435456 else 0 end) +
  /* 0x20000000 - Blockchain table */
  (case when bitand(t.spare7, 128) != 0
        then 536870912 else 0 end) +
  /* 0x40000000 - Immutable table */
  (case when bitand(t.spare7, 2048) != 0
        then 1073741824 else 0 end)
  as fbmap1,
  /******************  END FBMAP1 ************************/
  /******************  BEGIN FBMAP2 **********************/
  /* 4/5.  INDEX/CONSTRAINT AND COLUMN FEATURES */
  /* 0x8 - PK OID */
  (case when bitand(t.property, 4096) != 0
       then 8 else 0 end) +
  /* begin subquery of col$ */
  nvl((select
    /* 0x01 - Pkey/unique key on ADT attr */
    sum(distinct case when
        (c.type#=121 and
          (bitand(t.property, 1) = 0 and
           exists (select 1
                     from sys.ccol$ ccol, sys.col$ c2, sys.cdef$ cd
                     where o.obj# = c2.obj#
                       and o.obj# = cd.obj#
                       and o.obj# = ccol.obj#
                       and c.col# = c2.col#
                       and ccol.con# = cd.con#
                       and ccol.intcol# = c2.intcol#
                       and bitand(c2.property, 32) = 32   /* Hidden */
                       and cd.type# = 2)))
        then 1 else 0 end) +
    /* 0x2 - Pkey/unique key on long varchar/long raw */
    sum(distinct case when
        (c.type# in (1,23) and bitand(c.property, 128) = 128 and
         /* Note: we do not check length, just "stored as lob" */
         (exists                                  /* Unique index on vc32k */
            (select null
             from ind$ i, icol$ ic
             where i.bo# = t.obj#
               and ic.obj# = i.obj#
               and c.intcol# = ic.intcol#
               and bitand(i.property, 1) = 1                       /* Unique */
            )
           or exists                  /* Primary or unique constraint on 32k */
            (select null
             from cdef$ cd, ccol$ ccol
             where cd.obj# = t.obj#
               and cd.obj# = ccol.obj#
               and cd.con# = ccol.con#
               and cd.type# in (2,3)
               and ccol.intcol# = c.intcol#
            )))
        then 2 else 0 end) +
    /* 0x4 - Table with no scalars */
    sum(distinct case when (
        (c.type# in (8,24,58,112,113,114,115,121,122,123)
           or bitand(c.property, 128) = 128)
         and (bitand(t.property, 1) = 0
         and 0 = (select count(*) from sys.col$ c2
               where o.obj# = c2.obj#
               and bitand(c2.property, 32)  != 32              /* Not hidden */
               and bitand(c2.property, 8)   != 8              /* Not virtual */
               and bitand(c2.property, 128) != 128      /* not stored in lob */
               and (c2.type# in ( 1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  12,                                /* DATE */
                                  23,                                 /* RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  208,                             /* UROWID */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
        ))))
        then 4 else 0 end) +
    /* 0x10 - Bfile attribute of ADT */
    sum(distinct case when
         (bitand(t.property, 1) = 1 and
          c.type#=114 /* BFILE */ and
          exists(select 1
                 from sys.col$ c1
                 where c1.obj#=c.obj# and
                       c1.name = 'SYS_NC_ROWINFO$' and
                       c1.type# = 121)) or
         (bitand(t.property, 1) = 0 and
          c.type# = 114 /* BFILE */ and
          bitand(c.property, 32) = 32 /* hidden */ and
          exists (select 1
                  from sys.col$ c1
                  where c1.obj#=t.obj# and
                        c1.col# = c.col# and
                        c1.type# = 121 and
                        c1.intcol# = (select min(c2.intcol#) from col$ c2
                                      where c2.obj#=t.obj# and c2.col#=c1.col#)))
      then 16 else 0 end) +
    /* 0x20 - Nested table column */
    sum(distinct case when
         (bitand(t.property, 1) = 1 and
          ((c.type# = 122 /* nt */ or c.type# = 123 /* varray */) and
            bitand(c.property, 4) = 4 /* stored as nt */) and
          exists(select 1
                 from sys.col$ c1
                 where c1.obj#=c.obj# and
                       c1.name = 'SYS_NC_ROWINFO$' and
                       c1.type# = 121)) or
         (bitand(t.property, 1) = 0 and
          ((c.type# = 122 /* nt */ or c.type# = 123 /* varray */) and
            bitand(c.property, 4) = 4 /* stored as nt */) and
          (bitand(c.property, 32) = 0 or /* not hidden */
           (bitand(c.property, 32) = 32 /* hidden */ and
            exists (select 1
                    from sys.col$ c1
                    where c1.obj#=t.obj# and
                          c1.col# = c.col# and
                          c1.type# = 121 and
                          c1.intcol# = (select min(c2.intcol#) from col$ c2
                                        where c2.obj#=t.obj# and c2.col#=c1.col#)))))
        then 32 else 0 end) +
    /* 0x40 - Rowid column */
    sum(distinct case when c.type#=69 /* DTYBRI */
        then 64 else 0 end) +
    /* 0x100 - PKREF or virtual REF column */
    sum(distinct case when (c.type#=111 and bitand(c.property,8) != 0)
        then 256 else 0 end) +
    /* 0x200 - Replace Null with Expression */
    sum(distinct case when bitand(c.property, 1099511627776) != 0
        then 512 else 0 end)
    from col$ c
    where c.obj# = o.obj#), 0) +
  /* Column Features - Begin Subquery of coltype$ */
  nvl((select
    /* 0x400 - MDSYS.SDO_TOPO_GEOMETRY */
    sum(distinct case when
        (u2.name='MDSYS' and o2.name = 'SDO_TOPO_GEOMETRY')
        then 1024 else 0 end ) +
    /* 0x800 - MDSYS.SDO_GEORASTER */
    sum(distinct case when
        (u2.name='MDSYS' and o2.name = 'SDO_GEORASTER')
        then 2048  else 0 end ) +
    /* 0x1000 - MDSYS.SDO_RDF_TRIPLE_S */
    sum(distinct case when
        (u2.name='MDSYS' and o2.name = 'SDO_RDF_TRIPLE_S')
        then 4096  else 0 end ) +
    /* 0x2000 - SYS.ANYDATASET */
    sum(distinct case when
        ct2.toid = '00000000000000000000000000020012' /* Anydataset TOID */
        then 8192 else 0 end ) +
    /* 0x80 - Sys.Anydata column with associated Storage Type columns */
    sum(distinct case when
        bitand(ct2.flags, 131072) != 0
        then 128 else 0 end)
    from sys.obj$ o2, sys.coltype$ ct2, sys.user$ u2
    where o.obj# = ct2.obj# and
          u2.user# = o2.owner# and
          ct2.toid = o2.oid$), 0) +
  /* 0x80000000 - DEFAULT - every table has this feature, so that every
   *   table gets a non-zero bitmap value, and we can join this view with
   *   the support matrix.
   */
  (2147483648)
  as fbmap2
  /****************** END FBMAP2 **********************/
  from sys.obj$ o, sys.user$ u, sys.tab$ t
  where o.owner# = u.user#
  and o.obj# = t.obj#
/

