create view DBA_SCHEDULER_JOB_DESTS
            (OWNER, JOB_NAME, JOB_SUBNAME, CREDENTIAL_OWNER, CREDENTIAL_NAME, DESTINATION_OWNER, DESTINATION,
             JOB_DEST_ID, ENABLED, REFS_ENABLED, STATE, NEXT_START_DATE, RUN_COUNT, RETRY_COUNT, FAILURE_COUNT,
             LAST_START_DATE, LAST_END_DATE)
as
SELECT  dd.OWNER, dd.JOB_NAME,
        dd.JOB_SUBNAME,
        decode(dd.local, 'X', null, CREDENTIAL_OWNER),
        decode(dd.local, 'X', null,dd.CREDENTIAL_NAME),
        decode(dd.local, 'N', dd.DESTINATION_OWNER, null),
        decode(dd.local, 'N', dd.DESTINATION_NAME, 'LOCAL'),
        lj.JOB_DEST_ID,
        decode(dd.pj_enbl, 1, 'TRUE', 'FALSE'),
        dd.ENABLED,
        (CASE WHEN (bitand(dd.pj_status,4+8+16+32+8192+524288) > 0 OR
                    (lj.STATE <> 'RUNNING' AND bitand(dd.pj_status, 1) = 0))
                 THEN  'DISABLED'
                 ELSE  coalesce(lj.STATE, 'SCHEDULED') END),
        dd.next_run_date NEXT_START_DATE,
        coalesce(lj.RUN_COUNT,0),
        coalesce(lj.RETRY_COUNT,0),
        coalesce(lj.FAILURE_COUNT,0),
        lj.LAST_START_DATE, lj.LAST_END_DATE
FROM
(SELECT
  d.job_dest_id JOB_DEST_ID,
  DECODE(BITAND(d.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
    DECODE(BITAND(d.job_status,1+4+8+16+32+128+8192),0,'SCHEDULED',1,
      (CASE WHEN d.retry_count>0 THEN 'RETRY SCHEDULED'
            WHEN (bitand(d.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)) STATE,
    d.run_count, d.retry_count, d.failure_count,
    d.last_start_date, d.last_end_date, d.program_oid parent_job_id, d.dest_oid
  FROM  scheduler$_comb_lw_job d) lj,
(SELECT
     j0.OWNER, j0.JOB_NAME,
     'SCHED$_MD_'
     || TO_CHAR(coalesce(d0.dest_oid,j0.dest_oid), 'FMXXXXXXXXX') || '_'
     || TO_CHAR(decode(d0.local, 'X', 0,
                  coalesce(d0.cred_oid,j0.cred_oid)), 'FMXXXXXXXXX') JOB_SUBNAME,
     coalesce(d0.credential_owner,j0.credential_owner) credential_owner,
     coalesce(d0.credential_name,j0.credential_name) credential_name,
     d0.destination_owner,
     d0.destination_name,
     decode(d0.en_flag+j0.en_flag,2, 'TRUE', 'FALSE') enabled,
     j0.en_flag pj_enbl,
     j0.pj_status,
     j0.next_run_date, j0.parent_job_id, d0.dest_oid, d0.local
FROM
( SELECT cmu.name credential_owner,  cmo.name credential_name,
      wmu.name destination_owner, wmo.name destination_name,
      bitand(d.flags, bitand(w.flags,bitand(coalesce(ad.flags,1),1))) en_flag,
      w.obj# dest_grp_id,
      wg.member_oid2 cred_oid,
      wg.member_oid dest_oid,
      decode(bitand(d.flags, 12),12, 'X',8, 'Y','N') local
  FROM  scheduler$_window_group w, scheduler$_wingrp_member wg,
        scheduler$_destinations d, scheduler$_destinations ad,
         user$ wmu, obj$ wmo, user$ cmu, obj$ cmo
  WHERE w.obj# = wg.oid
       AND wg.member_oid = wmo.obj#
       AND wmo.owner# = wmu.user#
       AND wg.member_oid = d.obj#
       AND cmo.obj#(+) = wg.member_oid2
       AND d.agtdestoid = ad.obj#(+)
       AND cmo.owner# = cmu.user#(+)) d0,
(SELECT  j1.credential_owner, j1.credential_name,
    substr(j1.destination, 1, instr(j1.destination, '"')-1) destination_owner,
    substr(j1.destination, instr(j1.destination, '"')+1,
        length(j1.destination) - instr(j1.destination, '"')) destination_name,
    bitand(j1.job_status, 1) en_flag,
    j1.dest_oid,
    j1.next_run_date,
    u.name OWNER, o.name JOB_NAME, o.subname JOB_SUBNAME,
    j1.obj# parent_job_id,
    j1.job_status pj_status,
    j1.credential_oid cred_oid
    FROM scheduler$_job j1, user$ u, obj$ o
              WHERE j1.obj# = o.obj# AND o.owner# = u.user# ) j0
  WHERE j0.dest_oid = d0.dest_grp_id
    and (j0.cred_oid is null or j0.cred_oid != coalesce(d0.cred_oid, 0)
        or not exists (select 1 from scheduler$_wingrp_member wm
                where  wm.oid = d0.dest_grp_id
                and wm.member_oid2 is null
                and wm.member_oid = d0.dest_oid))) dd
WHERE
   lj.parent_job_id (+) = dd.parent_job_id  and
   lj.dest_oid (+) = dd.dest_oid and
   (dd.pj_enbl = 1 or lj.dest_oid is not null)
UNION ALL
 SELECT u1.name, o1.name, o1.subname, j1.credential_owner, j1.credential_name,
    j1.destination_owner, j1.destination,
    j1.job_dest_id, DECODE(BITAND(j1.job_status,1),0,'FALSE','TRUE'),
    decode(jd1.enabled, 'TRUE', 'TRUE',
           decode(bitand(j1.flags, 274877906944), 0, 'TRUE', 'FALSE')),
    DECODE(BITAND(j1.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
       DECODE(BITAND(j1.job_status,1+4+8+16+32+128+8192),0,'DISABLED',1,
        (CASE WHEN j1.retry_count>0 AND bitand(j1.flags, 549755813888) = 0
            THEN 'RETRY SCHEDULED'
            WHEN (bitand(j1.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
        4,'COMPLETED',8,'BROKEN',16,'FAILED',
        32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)),
    j1.next_run_date, j1.run_count,
    decode(bitand(j1.flags, 549755813888), 0, j1.retry_count, 0),
    j1.failure_count, j1.last_start_date,
    (CASE WHEN j1.last_end_date>j1.last_start_date THEN j1.last_end_date
     ELSE NULL END)
  FROM
   (select rj1.obj# obj#, rj1.credential_owner credential_owner,
           rj1.credential_name credential_name,
           decode(bitand(rj1.flags, 274877906944), 0, NULL,
             substr(rj1.destination, 1, instr(rj1.destination, '"')-1))
               destination_owner,
           decode(bitand(rj1.flags, 274877906944), 0,
              decode(rj1.destination, NULL, 'LOCAL', rj1.destination),
                 substr(rj1.destination, instr(rj1.destination, '"')+1,
                    length(rj1.destination) - instr(rj1.destination, '"')))
                destination,
           rj1.job_status job_status, rj1.flags flags,
           rj1.next_run_date next_run_date, rj1.run_count run_count,
           rj1.retry_count retry_count, rj1.failure_count failure_count,
           rj1.last_start_date last_start_date, rj1.last_end_date last_end_date,
           rj1.job_dest_id job_dest_id
      from scheduler$_job rj1
    union all
    select lj1.obj#, lj1.credential_owner, lj1.credential_name,
           decode(bitand(lj1.flags, 274877906944), 0, NULL,
             substr(lj1.destination, 1, instr(lj1.destination, '"')-1)),
           decode(bitand(lj1.flags, 274877906944), 0,
              decode(lj1.destination, NULL, 'LOCAL', lj1.destination),
                 substr(lj1.destination, instr(lj1.destination, '"')+1,
                    length(lj1.destination) - instr(lj1.destination, '"'))),
           lj1.job_status, lj1.flags,
           lj1.next_run_date, lj1.run_count, lj1.retry_count,
           lj1.failure_count, lj1.last_start_date, lj1.last_end_date,
           lj1.job_dest_id
      from scheduler$_comb_lw_job lj1) j1,
    (select ro1.obj# obj#, ro1.owner# owner#, ro1.name name, ro1.subname subname
       from obj$ ro1
     union all
     select lo1.obj#, lo1.userid, lo1.name, lo1.subname
       from scheduler$_lwjob_obj lo1) o1,
    user$ u1,
    (select dd.owner owner, dd.destination_name dest_name,
            decode(dd.enabled, 'FALSE', 'FALSE', dd.refs_enabled) enabled
     from dba_scheduler_db_dests dd
     union all
     select 'SYS', ed.destination_name, ed.enabled
     from dba_scheduler_external_dests ed) jd1
  WHERE j1.obj# = o1.obj# AND o1.owner# = u1.user#
    AND bitand(j1.flags, 137438953472) = 0
    AND bitand(j1.flags, 549755813888) = 0
    AND (jd1.owner(+) = j1.destination_owner)
    AND (jd1.dest_name(+) = j1.destination)
UNION ALL
  SELECT du.name, do.name, do.subname,
    d.credential_owner, d.credential_name,
    substr(d.destination, 1, instr(d.destination, '"')-1),
    substr(d.destination, instr(d.destination, '"')+1,
        length(d.destination) - instr(d.destination, '"')),
    d.job_dest_id, 'FALSE', 'FALSE', 'RUNNING', NULL, d.run_count,
    d.retry_count, d.failure_count, d.last_start_date, d.last_end_date
  FROM  scheduler$_comb_lw_job d, user$ du, scheduler$_lwjob_obj do,
        scheduler$_job pj
  WHERE d.obj# = do.obj# and do.userid = du.user# and d.program_oid = pj.obj#
    and bitand(d.flags, 8589934592) <> 0
    and bitand(d.job_status, 2) = 2
    and (d.dest_oid is null or
         d.dest_oid not in
           (select so.obj# from obj$ so where so.owner# = 0 and so.namespace = 1
            and so.name = 'SCHED$_LOCAL_PSEUDO_DB'))
    and (nvl(d.dest_oid,0), nvl(d.credential_oid,0)) not in
          (select nvl(wg.member_oid,0),
             nvl(decode(wg.member_oid2, null, pj.credential_oid, wg.member_oid2), 0)
           from scheduler$_wingrp_member wg
           where wg.oid = pj.dest_oid)
/

comment on table DBA_SCHEDULER_JOB_DESTS is 'State of all jobs at each of their destinations'
/

comment on column DBA_SCHEDULER_JOB_DESTS.OWNER is 'Owner of the scheduler job'
/

comment on column DBA_SCHEDULER_JOB_DESTS.JOB_NAME is 'Name of scheduler job'
/

comment on column DBA_SCHEDULER_JOB_DESTS.JOB_SUBNAME is 'Subname of scheduler job'
/

comment on column DBA_SCHEDULER_JOB_DESTS.CREDENTIAL_OWNER is 'Owner of credential used for remote destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.CREDENTIAL_NAME is 'Name of credential used for remote destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.DESTINATION_OWNER is 'Owner of destination object that points to destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.DESTINATION is 'Name of destination object or name of destination itself'
/

comment on column DBA_SCHEDULER_JOB_DESTS.JOB_DEST_ID is 'Numerical ID assigned to job at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.ENABLED is 'Is this job enabled at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.STATE is 'State of this job at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.NEXT_START_DATE is 'Next start time of this job at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.RUN_COUNT is 'Number of times this job has run at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.RETRY_COUNT is 'Number of times this job has been retried at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.FAILURE_COUNT is 'Number of times this job has failed at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.LAST_START_DATE is 'Last time this job started at this destination'
/

comment on column DBA_SCHEDULER_JOB_DESTS.LAST_END_DATE is 'Last time this job ended at this destination'
/

