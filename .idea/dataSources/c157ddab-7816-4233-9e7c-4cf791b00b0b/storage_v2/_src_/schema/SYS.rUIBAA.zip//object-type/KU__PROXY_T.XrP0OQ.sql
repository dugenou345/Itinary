create type ku$_proxy_t force as object
(
  user_id       number,                                           /* role id */
  client_name   varchar2(128),                                /* client name */
  proxy_name    varchar2(128),                                 /* proxy name */
  flags         number,               /* Mask flags of associated with entry */
  cred_type     number,                /* Type of credential passed by proxy */
  proxy_role_list  ku$_proxy_role_list_t                  /* proxy role list */
)
not persistable
/

