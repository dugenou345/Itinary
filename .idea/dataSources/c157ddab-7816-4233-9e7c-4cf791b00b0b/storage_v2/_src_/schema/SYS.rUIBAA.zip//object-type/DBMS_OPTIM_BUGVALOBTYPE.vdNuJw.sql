create TYPE
  dbms_optim_bugValObType FORCE as object(fix number, val number) NOT PERSISTABLE;
/

