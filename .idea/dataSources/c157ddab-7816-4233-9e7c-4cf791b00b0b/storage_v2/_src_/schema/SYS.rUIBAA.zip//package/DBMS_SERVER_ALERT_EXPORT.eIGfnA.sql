create PACKAGE dbms_server_alert_export AUTHID CURRENT_USER AS

-- Support log based replication (proj 17779)
  -- NOTE: Procedures cannot be replicated by LogMiner via regular
  --       DML/DDL apply (replication of SYS schema is not supported)
  --       nor using 'Procedural replication' (re-invoking the procedure
  --       at the logical standby produce different results)
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED);

-- Generate PL/SQL for procedural actions
 FUNCTION system_info_exp(prepost IN PLS_INTEGER,
                          connectstring OUT VARCHAR2,
                          version IN VARCHAR2,
                          new_block OUT PLS_INTEGER)
 RETURN VARCHAR2;

END dbms_server_alert_export;
/

