create view DBA_OBJECTS_AE
            (OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE, CREATED, LAST_DDL_TIME,
             TIMESTAMP, STATUS, TEMPORARY, GENERATED, SECONDARY, NAMESPACE, EDITION_NAME, SHARING, EDITIONABLE,
             ORACLE_MAINTAINED, APPLICATION, DEFAULT_COLLATION, DUPLICATED, SHARDED, IMPORTED_OBJECT, CREATED_APPID,
             CREATED_VSNID, MODIFIED_APPID, MODIFIED_VSNID)
as
select u.name, o.name, o.subname, o.obj#, o.dataobj#,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE',
                      7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                      10, 'NON-EXISTENT',
                      11, 'PACKAGE BODY', 12, 'TRIGGER',
                      13, 'TYPE', 14, 'TYPE BODY',
                      19, 'TABLE PARTITION', 20, 'INDEX PARTITION', 21, 'LOB',
                      22, 'LIBRARY', 23, 'DIRECTORY', 24, 'QUEUE',
                      28, 'JAVA SOURCE', 29, 'JAVA CLASS', 30, 'JAVA RESOURCE',
                      32, 'INDEXTYPE', 33, 'OPERATOR',
                      34, 'TABLE SUBPARTITION', 35, 'INDEX SUBPARTITION',
                      40, 'LOB PARTITION', 41, 'LOB SUBPARTITION',
                      42, CASE (SELECT BITAND(s.xpflags, 8388608 + 34359738368)
                                FROM sum$ s
                                WHERE s.obj#=o.obj#)
                          WHEN 8388608 THEN 'REWRITE EQUIVALENCE'
                          WHEN 34359738368 THEN 'MATERIALIZED ZONEMAP'
                          ELSE 'MATERIALIZED VIEW'
                          END,
                      43, 'DIMENSION',
                      44, 'CONTEXT', 46, 'RULE SET', 47, 'RESOURCE PLAN',
                      48, 'CONSUMER GROUP',
                      51, 'SUBSCRIPTION', 52, 'LOCATION',
                      55, 'XML SCHEMA', 56, 'JAVA DATA',
                      57, 'EDITION', 59, 'RULE',
                      60, 'CAPTURE', 61, 'APPLY',
                      62, 'EVALUATION CONTEXT',
                      66, 'JOB', 67, 'PROGRAM', 68, 'JOB CLASS', 69, 'WINDOW',
                      72, 'SCHEDULER GROUP', 74, 'SCHEDULE', 79, 'CHAIN',
                      81, 'FILE GROUP', 82, 'MINING MODEL', 87, 'ASSEMBLY',
                      90, 'CREDENTIAL', 92, 'CUBE DIMENSION', 93, 'CUBE',
                      94, 'MEASURE FOLDER', 95, 'CUBE BUILD PROCESS',
                      100, 'FILE WATCHER', 101, 'DESTINATION',
                      111, 'CONTAINER',
                      114, 'SQL TRANSLATION PROFILE',
                      115, 'UNIFIED AUDIT POLICY',
                      144, 'MINING MODEL PARTITION',
                      148, 'LOCKDOWN PROFILE',
                      150, 'HIERARCHY',
                      151, 'ATTRIBUTE DIMENSION',
                      152, 'ANALYTIC VIEW',
                      163, 'MLE LANGUAGE',
                     'UNDEFINED'),
       o.ctime, o.mtime,
       to_char(o.stime, 'YYYY-MM-DD:HH24:MI:SS'),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 4), 0, 'N', 4, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       o.namespace,
       o.defining_edition,
       decode(bitand(o.flags, (65536+131072+4294967296)),
              4294967296+65536, 'EXTENDED DATA LINK', 65536, 'METADATA LINK',
              131072, 'DATA LINK', 'NONE'),
       case when o.type# in (4,5,7,8,9,11,12,13,14,22,87,114) then
           decode(bitand(o.flags, 1048576), 0, 'Y', 1048576, 'N', 'Y')
         else null end,
       decode(bitand(o.flags, 4194304), 4194304, 'Y', 'N'),
       decode(bitand(o.flags, 134217728), 134217728, 'Y', 'N'),
       case when o.type# in (2,4,7,8,9,12,13) then
           nls_collation_name(nvl(o.dflcollid, 16382))
         when (o.type# = 42
               and exists
               (SELECT 1
                FROM sum$ s
                WHERE s.obj#=o.obj#
                -- not rewrite equivalence or zone map
                and bitand(s.xpflags, 8388608 + 34359738368) = 0)) then
           nls_collation_name(nvl(o.dflcollid, 16382))
         else null end,
       -- DUPLICATED
       decode(bitand(o.flags, 2684354560),
                     0, 'N',
                     2147483648, 'Y', /* KQDOBREF set */
                     2684354560, 'Y', /* both KQDOBREF and KQDOBOAS set */
                     'N'),
       -- SHARDED
       decode(bitand(o.flags, 1073741824), 0, 'N', 1073741824, 'Y', 'N'),
       -- EXTERNAL SHARDING (for federated database)
       decode(bitand(o.flags, 34359738368), 0, 'N', 34359738368, 'Y', 'N'),
       -- CREATED_APPID
       o.CREAPPID,
       -- CREATED_VSNID
       o.CREVERID,
       -- MODIFIED_APPID,
       o.MODAPPID,
       -- MODIFIED_VSNID,
       o.MODVERID
from sys."_ACTUAL_EDITION_OBJ" o, sys.user$ u 
where o.owner# = u.user#
  and o.linkname is null
  
  and o.name != '_NEXT_OBJECT'
  and o.name != '_default_auditing_options_'
  and bitand(o.flags, 128) = 0
  -- Exclude XML Token set objects */
  and (o.type# not in (1 /* INDEXES */,
                       2 /* TABLES */,
                       6 /* SEQUENCE */)
      or
      (o.type# = 1 and not exists (select 1
                from sys.ind$ i, sys.tab$ t, sys.obj$ io
                where i.obj# = o.obj#
                  and io.obj# = i.bo#
                  and io.type# = 2
                  and i.bo# = t.obj#
                  and bitand(t.property, power(2,65)) =  power(2,65)))
      or
      (o.type# = 2 and 1 = (select 1
                from sys.tab$ t
                where t.obj# = o.obj#
                  and (bitand(t.property, power(2,65)) = 0
                        or t.property is null)))
      or
      (o.type# = 6 and 1 = (select 1
                from sys.seq$ s
                where s.obj# = o.obj#
                  and (bitand(s.flags, 1024) = 0 or s.flags is null))))
union all
select u.name, l.name, NULL, to_number(null), to_number(null),
       'DATABASE LINK',
       l.ctime, to_date(null), NULL, 'VALID','N','N', 'N', NULL, NULL,
       'NONE', NULL, 'N', 'N', NULL, 'N', 'N', 'N',
       -- CREATED_APPID
       NULL,
       -- CREATED_VSNID
       NULL,
       -- MODIFIED_APPID
       NULL,
       -- MODIFIED_VSNID
       NULL
from sys.link$ l, sys.user$ u
where l.owner# = u.user#
/

comment on table DBA_OBJECTS_AE is 'All objects in the database'
/

comment on column DBA_OBJECTS_AE.OWNER is 'Username of the owner of the object'
/

comment on column DBA_OBJECTS_AE.OBJECT_NAME is 'Name of the object'
/

comment on column DBA_OBJECTS_AE.SUBOBJECT_NAME is 'Name of the sub-object (for example, partititon)'
/

comment on column DBA_OBJECTS_AE.OBJECT_ID is 'Object number of the object'
/

comment on column DBA_OBJECTS_AE.DATA_OBJECT_ID is 'Object number of the segment which contains the object'
/

comment on column DBA_OBJECTS_AE.OBJECT_TYPE is 'Type of the object'
/

comment on column DBA_OBJECTS_AE.CREATED is 'Timestamp for the creation of the object'
/

comment on column DBA_OBJECTS_AE.LAST_DDL_TIME is 'Timestamp for the last DDL change (including GRANT and REVOKE) to the object'
/

comment on column DBA_OBJECTS_AE.TIMESTAMP is 'Timestamp for the specification of the object'
/

comment on column DBA_OBJECTS_AE.STATUS is 'Status of the object'
/

comment on column DBA_OBJECTS_AE.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column DBA_OBJECTS_AE.GENERATED is 'Was the name of this object system generated?'
/

comment on column DBA_OBJECTS_AE.SECONDARY is 'Is this a secondary object created as part of icreate for domain indexes?'
/

comment on column DBA_OBJECTS_AE.NAMESPACE is 'Namespace for the object'
/

comment on column DBA_OBJECTS_AE.EDITION_NAME is 'Name of the edition in which the object is actual'
/

comment on column DBA_OBJECTS_AE.SHARING is 'Is this a Metadata Link, an Object Link or neither?'
/

comment on column DBA_OBJECTS_AE.EDITIONABLE is 'Object is considered editionable'
/

comment on column DBA_OBJECTS_AE.ORACLE_MAINTAINED is 'Denotes whether the object was created, and is maintained, by Oracle-supplied scripts. An object for which this has the value Y must not be changed in any way except by running an Oracle-supplied script.'
/

comment on column DBA_OBJECTS_AE.APPLICATION is 'Denotes whether the object is part of an Application Container.'
/

comment on column DBA_OBJECTS_AE.DEFAULT_COLLATION is 'Default collation for the object'
/

comment on column DBA_OBJECTS_AE.CREATED_APPID is 'ID of Application that created object'
/

comment on column DBA_OBJECTS_AE.CREATED_VSNID is 'ID of Application Version that created object'
/

comment on column DBA_OBJECTS_AE.MODIFIED_APPID is 'ID of Application that last modified object'
/

comment on column DBA_OBJECTS_AE.MODIFIED_VSNID is 'ID of Application Version that last modified object'
/

