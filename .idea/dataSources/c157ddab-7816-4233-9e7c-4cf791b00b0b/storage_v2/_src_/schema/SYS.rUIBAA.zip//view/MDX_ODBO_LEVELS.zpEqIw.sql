create view MDX_ODBO_LEVELS
            (CATALOG_NAME, SCHEMA_NAME, CUBE_NAME, DIMENSION_UNIQUE_NAME, HIERARCHY_UNIQUE_NAME, LEVEL_NAME,
             LEVEL_UNIQUE_NAME, LEVEL_GUID, LEVEL_CAPTION, LEVEL_NUMBER, LEVEL_CARDINALITY, LEVEL_TYPE, DESCRIPTION,
             CUSTOM_ROLLUP_SETTINGS, LEVEL_UNIQUE_SETTINGS, LEVEL_IS_VISIBLE, LEVEL_ORDERING_PROPERTY, LEVEL_DBTYPE,
             LEVEL_MASTER_UNIQUE_NAME, LEVEL_NAME_SQL_COLUMN_NAME, LEVEL_KEY_SQL_COLUMN_NAME,
             LEVEL_UNIQUE_NAME_SQL_COL_NAME, LEVEL_ATTRIBUTE_HIERARCHY_NAME, LEVEL_KEY_CARDINALITY, LEVEL_ORIGIN)
as
(
SELECT
  schema_name CATALOG_NAME,
  SCHEMA_NAME,
  CUBE_NAME,
  CAST(DIMENSION_UNIQUE_NAME AS VARCHAR2(4000)) DIMENSION_UNIQUE_NAME,
  CAST(HIERARCHY_UNIQUE_NAME AS VARCHAR2(4000)) HIERARCHY_UNIQUE_NAME,
  CAST(LEVEL_NAME AS VARCHAR2(4000)) LEVEL_NAME,
  CAST(LEVEL_UNIQUE_NAME AS VARCHAR2(4000)) LEVEL_UNIQUE_NAME,
  NULL LEVEL_GUID,       /* not supported by this schema rowset, set to NULL */
  LEVEL_CAPTION,
  LEVEL_NUMBER,
  LEVEL_CARDINALITY,
  LEVEL_TYPE,
  DESCRIPTION,
  NULL CUSTOM_ROLLUP_SETTINGS,   /* not supported by schema rowset, set NULL */
  LEVEL_UNIQUE_SETTINGS,
  LEVEL_IS_VISIBLE,
  LEVEL_ORDERING_PROPERTY,
  NULL LEVEL_DBTYPE,     /* not supported by this schema rowset, set to NULL */
  NULL LEVEL_MASTER_UNIQUE_NAME, /* not supported by schema rowset, set NULL */
  NULL LEVEL_NAME_SQL_COLUMN_NAME,/* not supported by schema rowset, set NULL*/
  NULL LEVEL_KEY_SQL_COLUMN_NAME,/* not supported by schema rowset, set NULL */
  NULL LEVEL_UNIQUE_NAME_SQL_COL_NAME,/*not supported by schema rowset,  NULL*/
  NULL LEVEL_ATTRIBUTE_HIERARCHY_NAME,/* not supported by schema rowset, NULL*/
  LEVEL_KEY_CARDINALITY,
  LEVEL_ORIGIN
FROM (
SELECT
  SCHEMA_NAME,
  CUBE_NAME,
  DIMENSION_UNIQUE_NAME,
  HIERARCHY_UNIQUE_NAME,
  LEVEL_NAME,
  LEVEL_UNIQUE_NAME,
  NVL(level_caption_raw, level_name) LEVEL_CAPTION,
  LEVEL_NUMBER,
  LEVEL_CARDINALITY,
  LEVEL_TYPE,
  NVL(description_raw, NVL(level_caption_raw, level_name)) DESCRIPTION,
  LEVEL_UNIQUE_SETTINGS,
  LEVEL_IS_VISIBLE,
  LEVEL_ORDERING_PROPERTY,
  LEVEL_KEY_CARDINALITY,
  LEVEL_ORIGIN
FROM (
SELECT /* Single level in the Measure dimension */
  av.owner SCHEMA_NAME,
  av.analytic_view_name CUBE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(mdname.value, 'MEASURES')) DIMENSION_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(mdname.value, 'MEASURES'), NVL(mdhiername.value, 'MEASURES')) HIERARCHY_UNIQUE_NAME,
  to_char(NVL(mdhierlvlname.value, 'MEASURES')) LEVEL_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(mdname.value, 'MEASURES'), NVL(mdhiername.value, 'MEASURES'), NVL(mdhierlvlname.value, 'MEASURES')) LEVEL_UNIQUE_NAME,
  NULL LEVEL_CAPTION_RAW,
  0 LEVEL_NUMBER,
  dbms_mdx_odbo.mdx_get_measure_cardinality(av.owner, av.analytic_view_name) LEVEL_CARDINALITY,
  /*  Set LEVEL_TYPE to MDLEVEL_TYPE_REGULAR (0) for measures  */
  0 LEVEL_TYPE,
  NULL DESCRIPTION_RAW,
  /*  Set LEVEL_UNIQUE_SETTINGS to MDDIMENSIONS_MEMBER_KEY_UNIQUE and
      MDDIMENSIONS_MEMBER_NAME_UNIQUE for Measures level */
  dbms_mdx_odbo.mdx_level_unique_settings('MDDIMENSIONS_MEMBER_KEY_UNIQUE') +
    dbms_mdx_odbo.mdx_level_unique_settings('MDDIMENSIONS_MEMBER_NAME_UNIQUE') LEVEL_UNIQUE_SETTINGS,
  /* Set LEVEL_IS_VISIBLE to TRUE as a default               */
  1 LEVEL_IS_VISIBLE,
  NULL LEVEL_ORDERING_PROPERTY,
  1 LEVEL_KEY_CARDINALITY,
  /* Set LEVEL_ORIGIN to user-defined as a default           */
  dbms_mdx_odbo.mdx_origin('MD_ORIGIN_USER_DEFINED') LEVEL_ORIGIN
FROM all_analytic_views av,
     all_analytic_view_class mdname,
     all_analytic_view_class mdhiername,
     all_analytic_view_class mdhierlvlname,
     all_objects ao
WHERE mdname.owner (+)= av.owner AND
      mdname.analytic_view_name (+)= av.analytic_view_name AND
      mdname.classification (+)= 'MEAS_DIM_NAME' AND
      mdhiername.owner (+)= av.owner AND
      mdhiername.analytic_view_name (+)= av.analytic_view_name AND
      mdhiername.classification (+)= 'MEAS_DIM_HIER_NAME' AND
      mdhierlvlname.owner (+)= av.owner AND
      mdhierlvlname.analytic_view_name (+)= av.analytic_view_name AND
      mdhierlvlname.classification (+)= 'MEAS_DIM_HIER_LVL_NAME' AND
      ao.owner = av.owner AND
      ao.object_name = av.analytic_view_name AND
      ao.object_type = 'ANALYTIC VIEW' AND
      ao.status = 'VALID'
UNION ALL
SELECT /* ALL level in level hiers in DIMENSION BY */
  avh.owner SCHEMA_NAME,
  avh.analytic_view_name CUBE_NAME,
  dbms_mdx_odbo.mdx_component_id(avh.dimension_alias) DIMENSION_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_component_id(avh.dimension_alias, avh.hier_alias) HIERARCHY_UNIQUE_NAME,
  'ALL' LEVEL_NAME,
  dbms_mdx_odbo.mdx_component_id(avh.dimension_alias, avh.hier_alias, 'ALL') LEVEL_UNIQUE_NAME,
  NULL LEVEL_CAPTION_RAW,
  0 LEVEL_NUMBER,
  1 LEVEL_CARDINALITY,
  /*  Set LEVEL_TYPE to MDLEVEL_TYPE_ALL (1) for All Level   */
  1 LEVEL_TYPE,
  NULL DESCRIPTION_RAW,
  /*  Set LEVEL_UNIQUE_SETTINGS to MDDIMENSIONS_MEMBER_KEY_UNIQUE and
      MDDIMENSIONS_MEMBER_NAME_UNIQUE for All level */
  dbms_mdx_odbo.mdx_level_unique_settings('MDDIMENSIONS_MEMBER_KEY_UNIQUE') +
    dbms_mdx_odbo.mdx_level_unique_settings('MDDIMENSIONS_MEMBER_NAME_UNIQUE') LEVEL_UNIQUE_SETTINGS,
  /* Set LEVEL_IS_VISIBLE to TRUE as a default               */
  1 LEVEL_IS_VISIBLE,
  NULL LEVEL_ORDERING_PROPERTY,
  1 LEVEL_KEY_CARDINALITY,
  /* Set LEVEL_ORIGIN to user-defined as a default           */
  dbms_mdx_odbo.mdx_origin('MD_ORIGIN_USER_DEFINED') LEVEL_ORIGIN
FROM all_analytic_view_hiers avh,
     all_objects ao
/*  Used to check parent-child hierarchies, currently not supported. */
--     all_analytic_view_columns avc
WHERE ao.owner = avh.owner AND
      ao.object_name = avh.analytic_view_name AND
      ao.object_type = 'ANALYTIC VIEW' AND
      ao.status = 'VALID'
/*  Parent-child hierarchies are currently not supported.  Remove WHERE
    block logic temporarily  */
/* Eliminate parent-child hierarchies */
--      avc.role = 'PAR' AND
--      NOT (avh.owner = avc.owner AND
--           avh.analytic_view_name = avc.analytic_view_name AND
--           avh.dimension_alias = avc.dimension_name AND
--           avh.hier_alias = avc.hier_name)
UNION ALL
SELECT /* Explicit levels in level hiers in DIMENSION BY */
  avl.owner SCHEMA_NAME,
  avl.analytic_view_name CUBE_NAME,
  dbms_mdx_odbo.mdx_component_id(avl.dimension_alias) DIMENSION_UNIQUE_NAME,
  dbms_mdx_odbo.mdx_component_id(avl.dimension_alias, avl.hier_alias) HIERARCHY_UNIQUE_NAME,
  avl.level_name LEVEL_NAME,
  dbms_mdx_odbo.mdx_component_id(avl.dimension_alias, avl.hier_alias, avl.level_name) LEVEL_UNIQUE_NAME,
  NVL(avlc_cap_l.value, avlc_cap_n.value) LEVEL_CAPTION_RAW,
  avl.order_num+1 LEVEL_NUMBER,
  dbms_mdx_odbo.mdx_get_level_cardinality(avl.owner, avl.analytic_view_name, avl.dimension_alias, avl.hier_alias, avl.level_name) LEVEL_CARDINALITY,
  /*  Set LEVEL_TYPE to MDLEVEL_TYPE_REGULAR (0) for every Level   */
  0 LEVEL_TYPE,
  NVL(avlc_desc_l.value, avlc_desc_n.value) DESCRIPTION_RAW,
  /*  Set LEVEL_UNIQUE_SETTINGS to MDDIMENSIONS_MEMBER_KEY_UNIQUE as
      a default */
  dbms_mdx_odbo.mdx_level_unique_settings('MDDIMENSIONS_MEMBER_KEY_UNIQUE') LEVEL_UNIQUE_SETTINGS,
  /* Set LEVEL_IS_VISIBLE to TRUE as a default               */
  1 LEVEL_IS_VISIBLE,
  NULL LEVEL_ORDERING_PROPERTY,
  1 LEVEL_KEY_CARDINALITY,
  /* Set LEVEL_ORIGIN to user-defined as a default           */
  dbms_mdx_odbo.mdx_origin('MD_ORIGIN_USER_DEFINED') LEVEL_ORIGIN
FROM all_analytic_view_levels avl,
     v$nls_parameters nls,
     all_analytic_view_level_class avlc_cap_l,
     all_analytic_view_level_class avlc_cap_n,
     all_analytic_view_level_class avlc_desc_l,
     all_analytic_view_level_class avlc_desc_n,
     all_objects ao
WHERE nls.parameter = 'NLS_LANGUAGE' AND
      avlc_cap_l.owner (+)= avl.owner AND
      avlc_cap_l.analytic_view_name (+)= avl.analytic_view_name AND
      avlc_cap_l.dimension_alias (+)= avl.dimension_alias AND
      avlc_cap_l.hier_alias (+)= avl.hier_alias AND
      avlc_cap_l.level_name (+)= avl.level_name AND
      avlc_cap_l.classification (+)= 'CAPTION' AND
      avlc_cap_l.language (+)= nls.value AND
      avlc_cap_n.owner (+)= avl.owner AND
      avlc_cap_n.analytic_view_name (+)= avl.analytic_view_name AND
      avlc_cap_n.dimension_alias (+)= avl.dimension_alias AND
      avlc_cap_n.hier_alias (+)= avl.hier_alias AND
      avlc_cap_n.level_name (+)= avl.level_name AND
      avlc_cap_n.classification (+)= 'CAPTION' AND
      avlc_cap_n.language (+) IS NULL AND
      avlc_desc_l.owner (+)= avl.owner AND
      avlc_desc_l.analytic_view_name (+)= avl.analytic_view_name AND
      avlc_desc_l.dimension_alias (+)= avl.dimension_alias AND
      avlc_desc_l.hier_alias (+)= avl.hier_alias AND
      avlc_desc_l.level_name (+)= avl.level_name AND
      avlc_desc_l.classification (+)= 'DESCRIPTION' AND
      avlc_desc_l.language (+)= nls.value AND
      avlc_desc_n.owner (+)= avl.owner AND
      avlc_desc_n.analytic_view_name (+)= avl.analytic_view_name AND
      avlc_desc_n.dimension_alias (+)= avl.dimension_alias AND
      avlc_desc_n.hier_alias (+)= avl.hier_alias AND
      avlc_desc_n.level_name (+)= avl.level_name AND
      avlc_desc_n.classification (+)= 'DESCRIPTION' AND
      avlc_desc_n.language (+) IS NULL AND
      ao.owner = avl.owner AND
      ao.object_name = avl.analytic_view_name AND
      ao.object_type = 'ANALYTIC VIEW' AND
      ao.status = 'VALID'
)))
/

