create type ku$_rls_policy_objnum_t force as object
(
  obj_num       number,                              /* parent object number */
  name          varchar2(128),                             /* name of policy */
  pfschma       varchar2(128),             /* name of policy function schema */
  ppname        varchar2(128),                     /* name of policy package */
  pfname        varchar2(128),               /* name of policy function name */
  base_obj      ku$_schemaobj_t                        /* base schema object */
)
not persistable
/

