create type       "SYS_YOID0000018384$"              as object( "SYS_NC00001$" NUMBER)
/

