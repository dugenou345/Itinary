create type       "SYS_YOID0000017441$"              as object( "SYS_NC00001$" NUMBER)
/

