create type dm_em_projection
                                       as object
  (feature_name          VARCHAR2(4000)
  ,attribute_name        VARCHAR2(4000)
  ,attribute_subname     VARCHAR2(4000)
  ,attribute_value       VARCHAR2(4000)
  ,coefficient           NUMBER
  )
/

