create view KU$_SP2TPARTCOL_VIEW
            (OBJ_NUM, COL_NUM, INTCOL_NUM, SEGCOL_NUM, SEGCOLLENGTH, OFFSET, PROPERTY, PROPERTY2, NAME, TYPE_NUM,
             LENGTH, FIXEDSTORAGE, PRECISION_NUM, SCALE, NOT_NULL, DEFLENGTH, DEFAULT_VAL, DEFAULT_VALC, PARSED_DEF,
             BINARYDEFVAL, GUARD_ID, CHARSETID, CHARSETFORM, CON, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6,
             IDENTITY_COL, EVALEDITION_NUM, UNUSABLEBEF_NUM, UNUSABLEBEG_NUM, ATTRNAME2, COL_SORTKEY, COLLNAME,
             COLLINTCOL_NUM, ATTRNAME, FULLATTRNAME, BASE_INTCOL_NUM, BASE_COL_TYPE, BASE_COL_NAME, TYPEMD, OIDINDEX,
             LOBMD, OPQMD, PLOBMD, PART_OBJNUM)
as
select c.obj#, c.col#, c.intcol#, c.segcol#,
         c.segcollength, c.offset,
         bitand(c.property, (power(2, 32)-1)),
         bitand(trunc(c.property / power(2, 32)), (power(2, 32)-1)),
         c.name,
      -- type, length ... charsetid, charsetform
         c.type#, c.length, c.fixedstorage,
         c.precision#, c.scale, c.null$, c.deflength,
         case
           when c.deflength > 4000
           then null
           else
             sys.dbms_metadata_util.long2varchar(c.deflength,
                                                 'SYS.COL$',
                                                 'DEFAULT$',
                                                  c.rowid)
         end,
         case
           when c.deflength <= 4000
           then null
           else
             sys.dbms_metadata_util.long2clob(c.deflength,
                                              'SYS.COL$',
                                              'DEFAULT$',
                                              c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
           then null
           else
             (select sys.dbms_metadata.parse_default
                        (SYS_CONTEXT('USERENV','CURRENT_USERID'),u.name,o.name,
                                     c.deflength, c.rowid)
              from obj$ o, user$ u
              where o.obj#=c.obj# and o.owner#=u.user#)
         end,
         sys.dbms_metadata_util.blob2clob(c.obj#,c.intcol#, c.property),
         (select e.guard_id from ecol$ e where e.tabobj#=c.obj# and e.colnum=c.intcol#),
         c.charsetid, c.charsetform,
       -- column constraints
         ( select value(cv)
             from ku$_constraint_col_view ccv, ku$_constraint0_view cv
             where c.intcol# = ccv.intcol_num
             and c.obj# = ccv.obj_num
             and ccv.con_num = cv.con_num
             and cv.contype in (7,11)
         ),
      -- spare1-6, identity_col, edition numbers, attrname2, col_sortkey
         c.spare1, c.spare2, c.spare3, c.spare4, c.spare5,
         to_char(c.spare6,'YYYY/MM/DD HH24:MI:SS'),
         case when (bitand(c.property,137438953472+274877906944)!=0) then
             (select value(i) from ku$_identity_col_view i
                              where i.obj_num = c.obj#)
         else null end, nvl(evaledition#,0),
            nvl(unusablebefore#,0),
            nvl(unusablebeginning#,0),
         -- If column has the properties ((ADT attribute, hidden, system
         -- generated) or (type id, ADT attribute, hidden)), then
         -- this column may be part of an unpacked anydata type.
         case when (bitand(c.property,289) = 289  or
                    bitand(c.property,33554465) = 33554465) then
            sys.dbms_metadata_util.get_attrname2(c.obj#, c.intcol#, c.col#)
          else
            NULL
         end,
         -- Column sortkey: in principle we want to sort by segcol#, but
         -- segcol# for xmltype is 0 so replace it with the segcol# of its
         -- underlying lob or object rel column that contains the actual
         -- data.  This query needs to be identical to the one for the
         -- col_sorkey column in ku$_strmtable_view in order to ensure that
         -- lob columns are ordered identically when writing to and reading
         -- from dump files (bug# 12998987, 17627666).
         case when (c.segcol# = 0 and c.type# = 58) then
          NVL((select cc.segcol# from col$ cc, opqtype$ opq
              where opq.obj#=c.obj#
                and opq.intcol#=c.intcol#
                and opq.type=1
                and cc.intcol#=opq.lobcol    -- xmltype stored as lob
                and cc.obj#=c.obj#),
                (NVL((select cc.segcol# from col$ cc, opqtype$ opq
                      where opq.obj#=c.obj#
                        and opq.intcol#=c.intcol#
                        and opq.type=1
                        and cc.intcol#=opq.objcol  -- xmltype stored obj rel
                        and bitand(opq.flags,1)=1
                        and cc.obj#=c.obj#),0)))
         else c.segcol#
         end,
        
           nls_collation_name(nvl(c.collid, 16382)),
           c.collintcol#
        , 
         sys.dbms_metadata_util.get_attrname(
                        c.obj#, c.intcol#),
         sys.dbms_metadata_util.get_fullattrname(
                        c.obj#, c.col#, c.intcol#, c.type#),
      -- base column info - intcol_num, type, name (not for primitive columns)
         case c.col# when c.intcol# then c.intcol#
                     when 0 then c.intcol#
          else sys.dbms_metadata_util.get_base_intcol_num(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
         case c.col# when 0 then 0
          else
            sys.dbms_metadata_util.get_base_col_type(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
         case c.col#
          when c.intcol# then NULL
          when 0 then NULL
          else
            sys.dbms_metadata_util.get_base_col_name(c.obj#,c.col#,
                                                          c.intcol#,c.type#)
         end,
       -- typemd, lobmd, opqmd, oidindex (not for primitive)
         ( select value(ctv)
             from ku$_coltype_view ctv
             where c.type# in ( 121,    -- DTYADT  (user-defined type)
                                122,    -- DTYNTB  (nested table)
                                123,    -- DTYNAR  (varray)
                                111,    -- DTYIREF (REF)
                                 58)    -- DTYOPQ  (opaque type)
             and   c.obj#  = ctv.obj_num
             and   c.intcol# = ctv.intcol_num
         ),
         ( select value(oi)
             from ku$_oidindex_view oi
             where bitand(c.property, 2) = 2
             and   c.obj# = oi.obj_num
             and   c.intcol# = oi.intcol_num
         ),
       -- lobmd, opqmd
         value(lv),
         ( select value(opq) from sys.ku$_opqtype_view opq
             where c.type# = 58        -- DTYOPQ (opaque type)
             and   c.obj# = opq.obj_num
             and   c.intcol# = opq.intcol_num
         ),
         NULL, NULL
  from col$ c, ku$_sp2tlob_view lv 
 where
    c.obj#  = lv.base_obj_num and
    ((c.type# in (1,23,58,112,113) and c.intcol# = lv.intcol_num) or
     (c.type# = 58 and
      lv.intcol_num = ( select opq.lobcol
                        from sys.ku$_opqtype_view opq
                        where c.obj# = opq.obj_num
                          and c.intcol# = opq.intcol_num ))) and (((
     case
         when  nvl(unusablebefore#,0) = 0 then (0)
         else  dbms_editions_utilities.compare_edition(
               dbms_metadata.get_edition_id, unusablebefore#)
         end) in (0,2) )
      and((
      case
           when nvl(unusablebeginning#,0) = 0 then (1)
           else dbms_editions_utilities.compare_edition(
                dbms_metadata.get_edition_id, unusablebeginning#)
      end) = 1  ))
/

