create PACKAGE dbms_disrupt AUTHID DEFINER IS

  ---------------------------
  -- PROCEDURES AND FUNCTIONS
  --
  PROCEDURE disrupt_sessions(
              job_name       IN VARCHAR2,
              user_names     IN VARCHAR2 := '?',
              service_names  IN VARCHAR2 := '*',
              instance_names IN VARCHAR2 := '?',
              module_names   IN VARCHAR2 := '*',
              percentage     IN NUMBER,
              sleep_interval IN NUMBER,
              duration       IN NUMBER   := 0,
              output_file    IN VARCHAR2 := NULL
            );

  PROCEDURE disrupt_sessions_immediate(
              user_names     IN VARCHAR2 := '*',
              service_names  IN VARCHAR2 := '*',
              instance_names IN VARCHAR2 := '?',
              module_names   IN VARCHAR2 := '*',
              percentage     IN NUMBER,
              output_file    IN VARCHAR2 := NULL);

  PROCEDURE disrupt_sessions_cancel(
              job_name       IN VARCHAR2 := '*'
            );

  PROCEDURE disrupt_services(
              job_name       IN VARCHAR2,
              service_names  IN VARCHAR2 := '*',
              instance_names IN VARCHAR2 := '?',
              percentage     IN NUMBER,
              sleep_interval IN NUMBER,
              stop_interval  IN NUMBER   := 0,
              duration       IN NUMBER   := 0,
              output_file    IN VARCHAR2 := NULL
            );

  PROCEDURE disrupt_services_immediate(
              job_name       IN VARCHAR2,
              service_names  IN VARCHAR2 := '*',
              instance_names IN VARCHAR2 := '?',
              percentage     IN NUMBER,
              stop_interval  IN NUMBER,
              output_file    IN VARCHAR2 := NULL);

  PROCEDURE disrupt_services_cancel(
              job_name       IN VARCHAR2 := '*'
            );

  PROCEDURE wake_up_service(
              service_name   IN VARCHAR2,
              instance_name  IN VARCHAR2,
              output_file    IN VARCHAR2 := NULL);

  -------------
  -- CONSTANTS
  --
  all_users       CONSTANT VARCHAR2(2) := '*';
  cur_user        CONSTANT VARCHAR2(2) := '?';
  all_instances   CONSTANT VARCHAR2(2) := '*';
  cur_instance    CONSTANT VARCHAR2(2) := '?';
  all_services    CONSTANT VARCHAR2(2) := '*';
  all_modules     CONSTANT VARCHAR2(2) := '*';

END;
/

