create view "_user_stat"
            (TYPE, VERSION, FLAGS, C1, C2, C3, C4, C5, C6, N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12, N13, D1,
             T1, R1, R2, R3, CH1, CL1, BL1, MIN_SC, MAX_SC)
as
select
  type,
  version,
  flags,
  c1, c2, c3, c4, c5, c6,
  n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13,
  d1,
  t1,
  r1, r2, r3,
  ch1,
  cl1,
  bl1,
  min_sc,
  max_sc
from (
  --
  -- Type T, table, (sub)partition  statistics.
  -- The queries are similar to open_tab_stats_dict_cur, open_fxt_stats_dict_cur
  --
  -- T.1 Non partitioned tables
  select
    'T' type,
    dbms_stats.get_stat_tab_version version,
    decode(bitand(t.flags, 512),512,2,0) + -- DSC_GLOBAL_STAT
    decode(bitand(t.flags, 256),256,1,0) flags,  -- DSC_USER_STAT
    o.name c1, null c2, null c3, null c4, u.name c5, null c6,
    t.rowcnt n1,
    case  bitand(t.property, 128)
      when 128 then    --  iot with overflow
        (select tov.blkcnt from sys.tab$ tov
           where tov.obj# = t.bobj#)
      else
        t.blkcnt
    end n2,
    t.avgrln n3, t.samplesize n4,
    -- Note that im_imcu_count, im_block_count, scanrate are new in 12.2,
    -- However the view will return this even if DSC_COMPATIBLE_1201. This
    -- should not cause any issue when importing into 12.1 as it will just
    -- get ignored.
    null n5, tst.im_imcu_count n6, tst.im_block_count n7, tst.scanrate n8,
    t.chncnt n9,
    tst.cachedblk n10, tst.cachehit n11, tst.logicalread n12, null n13,
    t.analyzetime d1,
    null t1, null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
    from sys.tab$ t,
         sys.tab_stats$ tst,
         sys.obj$ o,
         sys.user$ u
  where
    SYS_OP_DV_CHECK(o.name, o.owner#) = 1 and
    t.obj# = tst.obj# (+) and
    t.obj# = o.obj# and
    o.owner# = u.user# and
    bitand(t.property, 512) != 512 and          -- not an iot overflow
    bitand(t.flags, 536870912) != 536870912 and -- not an iot mapping table
    (bitand(t.flags,16) = 16 or                 -- has data stats
     tst.obj# is not null)                      -- has cache stats
  union all
  -- T.2 Partitioned tables
  select
    'T',
    dbms_stats.get_stat_tab_version,
    decode(bitand(tp.flags, 16),16,2,0)+
    decode(bitand(tp.flags, 8),8,1,0),
    op.name, op.subname, null, null, u.name, null,
    tp.rowcnt,
    case  bitand(t.property, 128)
      when 128 then    --  iot with overflow
        (select tov.blkcnt from sys.tabpart$ tov
           where tov.bo# = t.bobj# and tov.part# = tp.part#)
      else
        tp.blkcnt
    end blkcnt,
    tp.avgrln,  tp.samplesize,
    null, tst.im_imcu_count, tst.im_block_count, tst.scanrate,
    tp.chncnt,
    tst.cachedblk, tst.cachehit, tst.logicalread, tp.part#,
    tp.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.tabpartv$ tp, sys.obj$ op,
       sys.tab_stats$ tst, sys.tab$ t,
       sys.user$ u
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    op.obj# = tp.obj# and
    tp.bo# = t.obj# and
    tp.obj# = tst.obj# (+) and
    op.owner# = u.user# and
    bitand(t.property, 512) != 512 and          -- not an iot overflow
    bitand(t.flags, 536870912) != 536870912 and -- not an iot mapping table
    (bitand(tp.flags,2) = 2 or tst.obj# is not null) -- has data/cache stats
  union all
  -- T.3 Partitions of composite partitioned tables
  select
    'T',
    dbms_stats.get_stat_tab_version,
    decode(bitand(tp.flags, 16),16,2,0) +
    decode(bitand(tp.flags, 8),8,1,0),
    op.name, op.subname, null, null, u.name, null,
    tp.rowcnt, tp.blkcnt, tp.avgrln, tp.samplesize,
    null, tst.im_imcu_count, tst.im_block_count, tst.scanrate,
    tp.chncnt,
    tst.cachedblk, tst.cachehit, tst.logicalread,
    tp.part#,  tp.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.obj$ op, sys.tabcompartv$ tp,
       sys.tab_stats$ tst, sys.user$ u
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    tp.obj# = op.obj# and
    tp.obj# = tst.obj# (+) and
    op.owner# = u.user# and
    (bitand(tp.flags,2) = 2 or tst.obj# is not null) -- has data/cache stats
  union all
  -- T.4 Subpartitions of composite partitioned tables
  select
    'T',
    dbms_stats.get_stat_tab_version,
    decode(bitand(ts.flags, 16),16,2,0) +
    decode(bitand(ts.flags, 8),8,1,0),
    os.name, op.subname, os.subname, null, u.name, null,
    ts.rowcnt, ts.blkcnt, ts.avgrln, ts.samplesize,
    null, tst.im_imcu_count, tst.im_block_count, tst.scanrate,
    ts.chncnt,
    tst.cachedblk, tst.cachehit, tst.logicalread,
    ts.subpart#, ts.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.obj$ op, sys.tabcompart$ tp,
       sys.tabsubpartv$ ts, sys.obj$ os,
       sys.tab_stats$ tst, sys.user$ u
  where
    SYS_OP_DV_CHECK(os.name, os.owner#) = 1 and
    tp.obj# = op.obj# and
    ts.pobj# = tp.obj# and os.obj# = ts.obj# and
    ts.obj# = tst.obj# (+) and
    op.owner# = u.user# and
    (bitand(ts.flags,2) = 2 or tst.obj# is not null)  -- has data/cache stats
  union all
  -- T.5 Session private stats
  -- the cursor below is similar to get table stats for non partitioned
  -- table in shared mode
  select
    'T',
    dbms_stats.get_stat_tab_version,
    decode(bitand(ts.flags_kxttst_ts, 8),8,2,0) +
                                    -- DSC_GLOBAL_STAT (KQLDTVCF_GLS 0x08)
    decode(bitand(ts.flags_kxttst_ts, 4),4,1,0) +
                                    -- DSC_USER_STAT (KQLDTVCF_USS 0x04)
    2048, -- DSC_GTT_SES
    o.name, null, null, null, u.name, null, -- C6
    ts.rowcnt_kxttst_ts, -- N1
    case  bitand(t.property, 128)
      when 128 then    --  iot with overflow
        (select tov.blkcnt from sys.tab$ tov
           where tov.obj# = t.bobj#)
      else
        ts.blkcnt_kxttst_ts
    end blkcnt, -- N2
    ts.avgrln_kxttst_ts, -- N3
    ts.samplesize_kxttst_ts, -- N4
    null, null, null, null,
    ts.chncnt_kxttst_ts, -- N9
    ts.cachedblk_kxttst_ts, ts.cachehit_kxttst_ts, ts.logicread_kxttst_ts,
    null, -- N13
    ts.analyzetime_kxttst_ts, -- D1
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.x$kxttstets ts,
       sys.tab$ t,
       sys.obj$ o,
       sys.user$ u
  where
    SYS_OP_DV_CHECK(o.name, o.owner#) = 1 and
    ts.obj#_kxttst_ts = t.obj# and
    t.obj# = o.obj# and
    o.owner# = u.user# and
    bitand(t.property, 512) != 512 and          -- not an iot overflow
    bitand(t.flags, 536870912) != 536870912 and -- not an iot mapping table
    (bitand(ts.flags_kxttst_ts, 1) = 1 or    -- KQDS_DS set
     bitand(ts.flags_kxttst_ts, 6) <> 0)      -- KQDS_CBK or KQDS_CHR set
  union all
  -- T.6 Fixed tables
  select /*+ ordered use_nl(fobj) use_nl(st) */
    'T',
    dbms_stats.get_stat_tab_version,
    2 + decode(bitand(st.flags, 1),1,1,0),
    t.kqftanam, null, null, null, 'SYS', null,
    st.rowcnt, st.blkcnt, st.avgrln, st.samplesize,
    null, st.im_imcu_count, st.im_block_count, st.scanrate, st.chncnt,
    null, null, null, null,
    st.analyzetime,
    null, null, null, null, null, null, null bl1, 0,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.x$kqfta t, sys.fixed_obj$ fobj, sys.tab_stats$ st
  where -- SYS table not protected by data vault
    t.kqftaobj = st.obj# and
    t.kqftaobj = fobj.obj# and bitand(fobj.flags, 1) = 1
  union all
  --
  -- Type C, column statistics
  -- The queries are similar to export_colstats_direct and
  -- export_fxt_colstats_direct
  --
  -- C.1 Statistics of columns at table level
  select
    'C' type, dbms_stats.get_stat_tab_version,
    bitand(h.spare2, 7) + -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2, 8), 0, 0, 128) +        -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2, 16), 0, 0, 1024) +      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2, 32), 0, 0, 4096) +      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2, 64), 0, 0, 8192) +      -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2, 128), 0, 0, 16384) +    -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2, 256), 0, 0, 65536) +    -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2, 512), 0, 0, 131072) +   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2, 2048), 0, 0, 524288)    -- QOSP_HYBRID_GLOBAL_NDV
                                               flags,
    ot.name c1, null c2, null c3, c.name c4, u.name c5, null c6,
    h.distcnt n1, h.density n2, h.spare1 n3, h.sample_size n4, h.null_cnt n5,
    h.minimum n6, h.maximum n7, h.avgcln n8,
    to_number(decode(h.cache_cnt,0,null,1)) n9,
    hg.bucket n10, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, null t1,
    h.lowval r1, h.hival r2,
    case when hg.epvalue is not null then utl_raw.cast_to_raw(hg.epvalue)
         else hg.epvalue_raw end r3,
    null ch1,
    -- Store the expression of virtual columns for remap purpose
    --   0x00010000 =   65536 = virtual column
    --   0x0100     =     256 = system-generated column
    --   0x0020     =      32 = hidden column
    decode(bitand(c.property, 65536+256+32), 65536+256+32,
           dbms_stats_internal.get_col_expr(c.rowid, c.property), null) cl1,
    null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u,  sys.obj$ ot, sys.col$ c,
       sys.hist_head$ h, sys.histgrm$ hg
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ot.owner# = u.user# and ot.type# = 2 and
    c.obj# = ot.obj# and
    h.obj# = ot.obj# and h.intcol# = c.intcol# and
    hg.obj#(+) = ot.obj# and hg.intcol#(+) = h.intcol#
  union all
  -- C.2 Statistics of columns at partition level
  select
    'C' type,  dbms_stats.get_stat_tab_version,
    bitand(h.spare2, 7) + -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2, 8), 0, 0, 128) +        -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2, 16), 0, 0, 1024) +      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2, 32), 0, 0, 4096) +      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2, 64), 0, 0, 8192) +      -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2, 128), 0, 0, 16384) +    -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2, 256), 0, 0, 65536) +    -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2, 512), 0, 0, 131072) +   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2, 2048), 0, 0, 524288)    -- QOSP_HYBRID_GLOBAL_NDV
                                               flags,
    ot.name c1, op.subname c2, null c3, c.name c4, u.name c5, null c6,
    h.distcnt n1, h.density n2, h.spare1 n3, h.sample_size n4, h.null_cnt n5,
    h.minimum n6, h.maximum n7, h.avgcln n8,
    to_number(decode(h.cache_cnt,0,null,1)) n9,
    hg.bucket n10, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, null t1,
    h.lowval r1, h.hival r2, hg.epvalue_raw r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u,  sys.obj$ ot, sys.col$ c,
       sys.tabpart$ tp, sys.obj$ op,
       sys.hist_head$ h, sys.histgrm$ hg
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    ot.owner# = u.user# and
    ot.type# = 2 and
    c.obj# = ot.obj# and
    tp.bo# = ot.obj# and tp.obj# = op.obj# and
    h.obj# = op.obj# and h.intcol# = c.intcol# and
    hg.obj#(+) = op.obj# and hg.intcol#(+) = h.intcol#
  union all
  -- C.3 Statistics of columns at composite partition level
  select
    'C' type, dbms_stats.get_stat_tab_version,
    bitand(h.spare2, 7) + -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2, 8), 0, 0, 128) +        -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2, 16), 0, 0, 1024) +      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2, 32), 0, 0, 4096) +      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2, 64), 0, 0, 8192) +      -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2, 128), 0, 0, 16384) +    -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2, 256), 0, 0, 65536) +    -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2, 512), 0, 0, 131072) +   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2, 2048), 0, 0, 524288)    -- QOSP_HYBRID_GLOBAL_NDV
                                               flags,
    op.name c1, op.subname c2, null c3, c.name c4, u.name c5, null c6,
    h.distcnt n1, h.density n2, h.spare1 n3, h.sample_size n4, h.null_cnt n5,
    h.minimum n6, h.maximum n7, h.avgcln n8,
    to_number(decode(h.cache_cnt,0,null,1)) n9,
    hg.bucket n10, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, null t1,
    h.lowval r1, h.hival r2,
    case when hg.epvalue is not null then
              utl_raw.cast_to_raw(hg.epvalue)
         else hg.epvalue_raw end r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.col$ c,
       sys.tabcompart$ tp, sys.obj$ op,
       sys.hist_head$ h, sys.histgrm$ hg
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    op.owner# = u.user# and
    op.type# = 19 and
    tp.obj# = op.obj# and c.obj# = tp.bo# and
    h.obj# = op.obj# and h.intcol# = c.intcol# and
    hg.obj#(+) = op.obj# and hg.intcol#(+) = h.intcol#
  union all
  -- C.4 Statistics of columns at sub partition level
  select
    'C' type, dbms_stats.get_stat_tab_version,
    bitand(h.spare2, 7) + -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2, 8), 0, 0, 128) +        -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2, 16), 0, 0, 1024) +      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2, 32), 0, 0, 4096) +      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2, 64), 0, 0, 8192) +      -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2, 128), 0, 0, 16384) +    -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2, 256), 0, 0, 65536) +    -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2, 512), 0, 0, 131072) +   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2, 2048), 0, 0, 524288)    -- QOSP_HYBRID_GLOBAL_NDV
                                               flags,
    op.name c1, op.subname c2, os.subname c3, c.name c4, u.name c5, null c6,
    h.distcnt n1, h.density n2, h.spare1 n3, h.sample_size n4, h.null_cnt n5,
    h.minimum n6, h.maximum n7, h.avgcln n8,
    to_number(decode(h.cache_cnt,0,null,1)) n9,
    hg.bucket n10, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, null t1,
    h.lowval r1, h.hival r2,
    case when hg.epvalue is not null then
              utl_raw.cast_to_raw(hg.epvalue)
         else hg.epvalue_raw end r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.col$ c,
       sys.tabcompart$ tp, sys.obj$ op,
       sys.tabsubpart$ ts, sys.obj$ os,
       sys.hist_head$ h, sys.histgrm$ hg
  where
    SYS_OP_DV_CHECK(os.name, os.owner#) = 1 and
    op.owner# = u.user# and
    op.type# = 19 and
    tp.obj# = op.obj# and c.obj# = tp.bo# and
    ts.pobj# = tp.obj# and ts.obj# = os.obj# and
    h.obj# = os.obj# and h.intcol# = c.intcol# and
    hg.obj#(+) = os.obj# and hg.intcol#(+) = h.intcol#
  union all
  -- C.5 Statistics of columns (session private stats)
  select 'C' type,  dbms_stats.get_stat_tab_version,
    bitand(h.spare2_kxttst_cs,7) +
                       -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2_kxttst_cs, 8), 0, 0, 128) +
                                              -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2_kxttst_cs, 16), 0, 0, 1024) +
                                                      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2_kxttst_cs, 32), 0, 0, 4096) +
                                                      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2_kxttst_cs, 64), 0, 0, 8192) +
                                                   -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2_kxttst_cs, 128), 0, 0, 16384) +
                                                   -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2_kxttst_cs, 256), 0, 0, 65536) +
                                                   -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2_kxttst_cs, 512), 0, 0, 131072) +
                                                   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2_kxttst_cs, 2048), 0, 0, 524288) +
                                                   -- QOSP_HYBRID_GLOBAL_NDV
    2048 flags,                                          -- DSC_GTT_SES
    o.name c1, null c2, null c3, c.name c4, u.name c5, null c6,
    h.distcnt_kxttst_cs n1, h.density_kxttst_cs n2, h.spare1_kxttst_cs n3,
    h.sample_size_kxttst_cs n4, h.null_cnt_kxttst_cs n5,
    h.minimum_kxttst_cs n6, h.maximum_kxttst_cs n7, h.avgcln_kxttst_cs n8,
    to_number(decode(h.cache_cnt_kxttst_cs,0,null,1)) n9,
    hg.bucket_kxttst_hs n10, hg.endpoint_kxttst_hs n11,
    hg.ep_repeat_count_kxttst_hs n12, null n13,
    h.timestamp#_kxttst_cs d1, null t1,
    h.lowval_kxttst_cs r1, h.hival_kxttst_cs r2,
    hg.epvalue_raw_kxttst_hs r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.col$ c,
       sys.x$kxttstecs h, sys.x$kxttstehs hg,
       sys.obj$ o, sys.user$ u
  where
    SYS_OP_DV_CHECK(o.name, o.owner#) = 1 and
    o.obj# = c.obj# and
    o.owner# = u.user# and
    h.obj#_kxttst_cs = c.obj# and h.intcol#_kxttst_cs = c.intcol# and
    hg.obj#_kxttst_hs(+) = h.obj#_kxttst_cs and
    hg.intcol#_kxttst_hs(+) = h.intcol#_kxttst_cs
  union all
  -- C.6 Statistics of columns of fixed tables
  select /*+ ordered */
    'C' type, dbms_stats.get_stat_tab_version,
    bitand(h.spare2, 7) + -- QOSP_USER_STAT + QOSP_GLOBAL_STAT + QOSP_EAVS
    decode(bitand(h.spare2, 8), 0, 0, 128) + -- QOSP_GLOBAL_SYNOP_STAT
    decode(bitand(h.spare2, 16), 0, 0, 1024) +      -- QOSP_HIST_SKIP
    decode(bitand(h.spare2, 32), 0, 0, 4096) +      -- QOSP_HIST_FREQ
    decode(bitand(h.spare2, 64), 0, 0, 8192) +      -- QOSP_HIST_TOPFREQ
    decode(bitand(h.spare2, 128), 0, 0, 16384) +    -- QOSP_HIST_IGNORE
    decode(bitand(h.spare2, 256), 0, 0, 65536) +    -- QOSP_HISTGRM_ONLY
    decode(bitand(h.spare2, 512), 0, 0, 131072) +   -- QOSP_STATS_ON_LOAD
    decode(bitand(h.spare2, 2048), 0, 0, 524288)    -- QOSP_HYBRID_GLOBAL_NDV
                                               flags,
    ot.kqftanam c1, null c2, null c3, c.kqfconam c4, 'SYS' c5, null c6,
    h.distcnt n1, h.density n2, h.spare1 n3, h.sample_size n4, h.null_cnt n5,
    h.minimum n6, h.maximum n7, h.avgcln n8,
    to_number(decode(h.cache_cnt,0,null,1)) n9,
    hg.bucket n10, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, null t1,
    h.lowval r1, h.hival r2,
    case when hg.epvalue is not null then
              utl_raw.cast_to_raw(hg.epvalue)
         else hg.epvalue_raw end r3, null ch1, null cl1, null bl1, 0,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.x$kqfta ot, sys.x$kqfco c,
       sys.hist_head$ h, sys.histgrm$ hg
  where  -- SYS objects not protected by data vault
    c.kqfcotob = ot.kqftaobj and
    h.obj# = ot.kqftaobj and h.intcol# = c.kqfcocno and
    hg.obj#(+) = ot.kqftaobj and hg.intcol#(+) = h.intcol#
  union all
  --
  -- Type E, extensions
  --
  select
    'E', dbms_stats.get_stat_tab_version,
    256,
    ot.name c1, null, null, c.name c4, u.name c5, null c6,
    null n1, null n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1, null r1, null r2, null r3, null ch1,
    dbms_stats_internal.get_default$(c.rowid) cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot, sys.col$ c
  where
    ot.owner# = u.user# and
    ot.type# = 2 and
    c.obj# = ot.obj# and
    bitand(c.property, 32) = 32 and
    bitand(c.property, 65536) =  65536 and
    substr(c.name, 1, 6) = 'SYS_ST'
  union all
  --
  -- Type P, table level preferences
  --
  select
    'P', dbms_stats.get_stat_tab_version,
    null,
    o.name, p.pname, null, null, u.name, null c6,
    p.valnum, p.spare1 n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    p.chgtime d1, null t1, null r1, null r2, null r3, null ch1,
    to_clob(p.valchar) cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from optstat_user_prefs$ p, obj$ o, user$ u
  where p.obj#=o.obj# and o.owner#=u.user#
  union all
  --
  -- Type H, synopses head
  --
  select /*+ ordered */
    'H', dbms_stats.get_stat_tab_version,
    null,
    ot.name, op.subname, null, c.name, u.name, null,
    h.split n1, h.spare1 n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    h.analyzetime d1, null t1, null r1, null r2, null r3, null ch1,
    null cl1, h.spare2 bl1,
    u.user# owner#,
    -- #(22182203) HLL synopses are stored in spare2 and is supported from
    -- 12.2 onwards. The type of synopses will be set to 1 for HLL in spare1.
    -- Mark them as supported from 12.2.
    decode(h.spare1, 1,
           dbms_stats_internal.get_sc_1202,
           dbms_stats_internal.get_sc_1201) min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from
    sys.user$ u,
    sys.obj$ ot,
    sys.wri$_optstat_synopsis_head$ h,
    sys.obj$ op,
    sys.col$ c
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    u.user# = ot.owner# and
    ot.obj# = h.bo# and
    h.group#/2 = op.obj#(+)  and
    h.bo# = c.obj# and
    h.intcol# = c.intcol#
  union all
  --
  -- Type B, synopses
  --
  select /*+ ordered */
    'B', dbms_stats.get_stat_tab_version,
    null,
    ot.name c1, op.subname c2, null c3, c.name c4, u.name c5, null c6,
    null n1, null n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1, null r1, null r2, null r3, null ch1, s.hashVal cl1,
    null bl1, u.user# owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from
    sys.user$ u,
    sys.obj$ ot,
    sys.wri$_optstat_synopsis_head$ h,
    sys.obj$ op,
    table(dbms_stats_internal.compose_hashval_clob_rec(
            h.bo#, h.group#/2, h.group#)) s,
    sys.col$ c
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    u.user# = ot.owner# and
    ot.obj# = h.bo# and
    h.group#/2 = op.obj#(+)  and
    h.intcol# = s.intcol# and
    h.bo# = c.obj# and
    h.intcol# = c.intcol#
  union all
  --
  -- Type I, index, (sub)partition  statistics.
  -- The queries are similar to get_indstats_dict
  --
  -- I.1 Non partitioned indexes
  select
    'I',  dbms_stats.get_stat_tab_version,
    decode(bitand(i.flags, 2048),2048,2,0) +
    decode(bitand(i.flags, 64),64,1,0),
    o.name, null, null, ot.name, u.name, ut.name,
    i.rowcnt, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac,
    i.blevel,  i.samplesize,
    decode(bitand(i.flags, 128), 128, mod(trunc(i.pctthres$/256),256),
           decode(i.type#, 4, mod(trunc(i.pctthres$/256),256), NULL)),
    ist.cachedblk, ist.cachehit, ist.logicalread, null, i.analyzetime,
    null, null, null, null, null, dbms_stats_internal.get_ind_cols(i.obj#),
    null bl1, u.user# owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.ind$ i, sys.ind_stats$ ist, sys.obj$ o, sys.user$ u,
       sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    i.obj# = o.obj# and
    o.owner# = u.user# and
    i.bo# = ot.obj# and
    ot.owner# = ut.user# and
    i.obj# = ist.obj# (+) and
    (bitand(i.flags,2) = 2 or ist.obj# is not null)
  union all
  -- I.2 Partitions
  select
    'I',  dbms_stats.get_stat_tab_version,
    decode(bitand(ip.flags, 16),16,2,0) +
    decode(bitand(ip.flags, 8),8,1,0),
    op.name, op.subname, null, ot.name, u.name, ut.name,
    ip.rowcnt, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey, ip.clufac,
    ip.blevel,  ip.samplesize, ip.pctthres$,
    ist.cachedblk, ist.cachehit, ist.logicalread, ip.part#, ip.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
     dbms_stats_internal.get_sc_max max_sc
  from sys.indpartv$ ip, sys.obj$ op,
       sys.ind_stats$ ist, sys.user$ u,
       sys.ind$ i, obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    op.obj# = ip.obj# and
    op.owner# = u.user# and
    ip.bo# = i.obj# and i.bo# = ot.obj# and ot.owner# = ut.user# and
    ip.obj# = ist.obj# (+) and
    (bitand(ip.flags,2) = 2 or ist.obj# is not null)
  union all
  -- I.3 Composite partitions
  select
    'I',  dbms_stats.get_stat_tab_version,
    decode(bitand(ip.flags, 16),16,2,0) +
    decode(bitand(ip.flags, 8),8,1,0),
    op.name, op.subname, null, ot.name, u.name, ut.name,
    ip.rowcnt, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey, ip.clufac,
    ip.blevel,  ip.samplesize, null,
    ist.cachedblk, ist.cachehit, ist.logicalread, ip.part#, ip.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.obj$ op, sys.indcompartv$ ip,
       sys.ind_stats$ ist, sys.user$ u,
       sys.ind$ i, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ip.obj# = op.obj# and
    op.owner# = u.user# and
    ip.bo# = i.obj# and i.bo# = ot.obj# and ot.owner# = ut.user# and
    ip.obj# = ist.obj# (+) and
    (bitand(ip.flags,2) = 2 or ist.obj# is not null)
  union all
  -- I.4 Sub partitions
  select
    'I',  dbms_stats.get_stat_tab_version,
    decode(bitand(isp.flags, 16),16,2,0) +
    decode(bitand(isp.flags, 8),8,1,0),
    op.name, op.subname, os.subname, ot.name, u.name, ut.name,
    isp.rowcnt, isp.leafcnt, isp.distkey, isp.lblkkey,
    isp.dblkkey, isp.clufac,
    isp.blevel,  isp.samplesize, null,
    ist.cachedblk, ist.cachehit, ist.logicalread, isp.subpart#,
    isp.analyzetime,
    null, null, null, null, null, null, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.obj$ op, sys.indcompart$ ip,
       sys.indsubpartv$ isp, sys.obj$ os,
       sys.ind_stats$ ist, sys.user$ u,
       sys.ind$ i, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ip.obj# = op.obj# and
    isp.pobj# = ip.obj# and os.obj# = isp.obj# and
    os.owner# = u.user# and
    ip.bo# = i.obj# and i.bo# = ot.obj# and ot.owner# = ut.user# and
    isp.obj# = ist.obj# (+) and
    (bitand(isp.flags,2) = 2 or ist.obj# is not null)
  union all
  -- I.5 Session private index stats
  select
    'I',  dbms_stats.get_stat_tab_version,
    decode(bitand(ist.flags_kxttst_is, 2048),2048,2,0)+  -- KQLDINF_GLS
    decode(bitand(ist.flags_kxttst_is, 64),64,1,0)+      -- KQLDINF_USS
    2048, -- DSC_GTT_SES
    o.name, null, null, ot.name, u.name, ut.name,
    ist.rowcnt_kxttst_is, ist.leafcnt_kxttst_is,
    ist.distkey_kxttst_is, ist.lblkkey_kxttst_is,
    ist.dblkkey_kxttst_is, ist.clufac_kxttst_is,
    ist.blevel_kxttst_is,
    ist.samplesize_kxttst_is,
    decode(bitand(i.flags, 128), 128, mod(trunc(i.pctthres$/256),256),
           decode(i.type#, 4, mod(trunc(i.pctthres$/256),256), NULL)),
    ist.cachedblk_kxttst_is, ist.cachehit_kxttst_is,
    ist.logicalread_kxttst_is, null, ist.analyzetime_kxttst_is,
    null, null, null, null, null, dbms_stats_internal.get_ind_cols(i.obj#),
    null bl1, u.user# owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.ind$ i, sys.x$kxttsteis ist,
       sys.obj$ o, sys.user$ u,
       sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ist.obj#_kxttst_is = i.obj# and
    i.obj# = o.obj# and
    o.owner# = u.user# and
    i.bo# = ot.obj# and
    ot.owner# = ut.user# and
    (bitand(ist.flags_kxttst_is, 1) = 1 or  -- KQDS_DS set
     bitand(ist.flags_kxttst_is, 6) <> 0)   -- KQDS_CBK or KQDS_CHR set
  --
  -- Type t, table, (sub)partition  statistics history.
  -- The queries are similar to open_tab_stats_hist_cur
  --
  union all
  -- t.1 tables and partitions
  select
    't' type,
    dbms_stats.get_stat_tab_version version,
    t.flags flags,
    ot.name c1, ot.subname, null, null, u.name, null c6,
    t.rowcnt n1, t.blkcnt, t.avgrln,  t.samplesize n4,
    null n5, t.im_imcu_count n6, t.im_block_count n7, t.scanrate n8,
    t.spare1 n9, t.cachedblk, t.cachehit, t.logicalread n12, null n13,
    t.analyzetime d1, t.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201
    min_sc, dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot, sys.wri$_optstat_tab_history t
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ot.owner# = u.user# and
    ot.type# in (2,19) and -- TABLE, [COMPOSITE] PARTITION
    ot.obj# = t.obj#
  union all
  -- t.2 subpartitions of tables
  select
    't' type,
    dbms_stats.get_stat_tab_version version,
    t.flags flags,
    op.name c1, op.subname, os.subname, null, u.name c5, null c6,
    t.rowcnt n1, t.blkcnt, t.avgrln,  t.samplesize n4,
    null n5, t.im_imcu_count n6, t.im_block_count n7, t.scanrate n8,
    t.spare1 n9, t.cachedblk, t.cachehit, t.logicalread n12, null n13,
    t.analyzetime d1, t.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ os,
       sys.tabsubpart$ ts,  sys.obj$ op, sys.wri$_optstat_tab_history t
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    os.owner# = u.user# and
    os.type# = 34 and -- SUB PARTITION
    os.obj# = ts.obj# and ts.pobj# = op.obj# and op.type# = 19 and
    ts.obj# = t.obj#
  union all
  -- t.3 fixed tables
  select
    't' type,
    dbms_stats.get_stat_tab_version version,
    t.flags flags,
    ot.kqftanam c1, null, null, null, 'SYS' c5, null c6,
    t.rowcnt n1, t.blkcnt, t.avgrln, t.samplesize n4,
    null n5, t.im_imcu_count n6, t.im_block_count n7, t.scanrate n8,
    t.spare1 n9, t.cachedblk, t.cachehit, t.logicalread n12, null n13,
    t.analyzetime d1, t.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1, 0 owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  -- data vault not enabled on SYS objects
  from sys.x$kqfta ot, sys.wri$_optstat_tab_history t
  where ot.kqftaobj = t.obj#
  --
  -- Type i, index, (sub)partition  statistics history.
  -- The queries are similar to get_indstats_hist
  --
  union all
  -- i.1 INDEX
  select
    'i' type,  dbms_stats.get_stat_tab_version version,
    i.flags flags,
    oi.name c1, oi.subname, null, ot.name, u.name, ut.name c6,
    i.rowcnt n1, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac n6,
    i.blevel n7,  i.samplesize, i.guessq n9,
    i.cachedblk n10, i.cachehit, i.logicalread, null n13,
    i.analyzetime d1, i.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ oi, sys.wri$_optstat_ind_history i,
       sys.ind$ ind, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    oi.obj# = ind.obj# and
    ind.bo# = ot.obj# and ot.owner# = ut.user# and
    oi.owner# = u.user# and
    oi.type# = 1 and -- INDEX
    oi.obj# = i.obj#
  union all  -- INDEX PARTITION
  select
    'i' type,  dbms_stats.get_stat_tab_version version,
    i.flags flags,
    oi.name c1, oi.subname, null, ot.name, u.name, ut.name c6,
    i.rowcnt n1, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac n6,
    i.blevel n7,  i.samplesize, i.guessq n9,
    i.cachedblk n10, i.cachehit, i.logicalread, null n13,
    i.analyzetime d1, i.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ oi, sys.wri$_optstat_ind_history i,
       sys.indpart$ ip, sys.ind$ ind, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ip.obj# = i.obj# and ip.bo# = ind.obj# and
    ind.bo# = ot.obj# and ot.owner# = ut.user# and
    oi.owner# = u.user# and
    oi.type# = 20 and -- [COMPOSITE] PARTITION
    oi.obj# = i.obj#
  union all  -- INDEX COMPOSITE PARTITION
  select
    'i' type,  dbms_stats.get_stat_tab_version version,
    i.flags flags,
    oi.name c1, oi.subname, null, ot.name, u.name, ut.name c6,
    i.rowcnt n1, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac n6,
    i.blevel n7,  i.samplesize, i.guessq n9,
    i.cachedblk n10, i.cachehit, i.logicalread, null n13,
    i.analyzetime d1, i.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ oi, sys.wri$_optstat_ind_history i,
       sys.indcompart$ ip, sys.ind$ ind, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ip.obj# = i.obj# and ip.bo# = ind.obj# and
    ind.bo# = ot.obj# and ot.owner# = ut.user# and
    oi.owner# = u.user# and
    oi.type# = 20 and -- [COMPOSITE] PARTITION
    oi.obj# = i.obj#
  union all
  -- i.2 INDEX SUB PARTITION
  select
    'i' type,  dbms_stats.get_stat_tab_version version,
    i.flags flags,
    op.name c1, op.subname, os.subname, ot.name, u.name, ut.name c6,
    i.rowcnt n1, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac n6,
    i.blevel n7,  i.samplesize, i.guessq n9,
    i.cachedblk n10, i.cachehit, i.logicalread, null n13,
    i.analyzetime d1, i.savtime t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ os,
       sys.indsubpart$ isp, sys.obj$ op,
       sys.wri$_optstat_ind_history i,
       sys.indcompart$ ip, sys.ind$ ind, sys.obj$ ot, sys.user$ ut
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    os.owner# = u.user# and
    os.type# = 35 and -- SUB PARTITION
    os.obj# = isp.obj# and
    isp.pobj# = op.obj# and op.type# = 20 and
    isp.pobj# = ip.obj# and ip.bo# = ind.obj# and
    ind.bo# = ot.obj# and ot.owner# = ut.user# and
    isp.obj# = i.obj#
  --
  -- Type c, column statistics history.
  -- The queries are similar to open_colstats_hist_cur
  -- Note that if extensions are dropped when exporting
  -- stats, the entries in history will have intcol# = 0.
  -- These entries does not join with col$ and hence we
  -- directly get the column name from history for these
  -- cases. We don't need this for fixed tables as
  -- extensions are not supported for them.
  --
  union all
  -- c.1 -- Columns of Tables and Partitions
  select
    'c' type, dbms_stats.get_stat_tab_version version,
    h.flags flags,
    ot.name c1, ot.subname c2, null c3,
    nvl(h.colname, -- h.colname not null only when an extension
        (select name from sys.col$ c
         where c.obj# = tab.bo# and
               h.intcol# = c.intcol#)) c4,
    u.name c5, null c6,
    h.distcnt n1, h.density, h.sample_distcnt, h.sample_size n4,
    h.null_cnt n5, h.minimum, h.maximum, h.avgcln n8,
    null n9, hg.bucket, hg.endpoint n11,
    hg.ep_repeat_count n12, h.spare1 n13,
    h.timestamp# d1, h.savtime t1,
    h.lowval r1, h.hival r2, case when hg.epvalue is not null
                                  then utl_raw.cast_to_raw(hg.epvalue)
                                  else hg.epvalue_raw end r3, null ch1,
    expression cl1, null bl1, u.user# owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u,  sys.obj$ ot,
       sys.wri$_optstat_histhead_history h,
       sys.wri$_optstat_histgrm_history hg,
       (select 2 type#, t.obj# obj#, t.obj# bo#
        from sys.tab$ t
        union all
        select 19 type#,  t.obj# obj#, t.bo# bo#
        from sys.tabpart$ t
        union all
        select 19 type#, t.obj# obj#, t.bo# bo#
        from sys.tabcompart$ t) tab
  where
    SYS_OP_DV_CHECK(ot.name, ot.owner#) = 1 and
    ot.owner# = u.user# and ot.type# in (2,19) and
    h.obj# = ot.obj# and
    ot.obj# = tab.obj# and
    ot.type# = tab.type# and
    hg.obj#(+) = ot.obj# and hg.intcol#(+) = h.intcol# and
    hg.savtime(+) = h.savtime
  union all
  -- c.2 -- Columns of Sub Partitions
  select
    'c' type, dbms_stats.get_stat_tab_version version,
    h.flags flags,
    op.name c1, op.subname c2, os.subname c3,
    nvl(h.colname, -- h.colname not null only when an extension
        (select name from sys.col$ c
         where c.obj# = tcp.bo# and
               h.intcol# = c.intcol#)) c4,
    u.name c5, null c6,
    h.distcnt n1, h.density, h.sample_distcnt, h.sample_size n4,
    h.null_cnt n5, h.minimum, h.maximum, h.avgcln n8,
    null n9, hg.bucket, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, h.savtime t1,
    h.lowval r1, h.hival r2, case when hg.epvalue is not null then
                                       utl_raw.cast_to_raw(hg.epvalue)
                             else hg.epvalue_raw end r3, null ch1,
    expression cl1, null bl1, u.user# owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ op, sys.obj$ os,
       sys.tabsubpart$ ts, sys.tabcompart$ tcp,
       sys.wri$_optstat_histhead_history h,
       sys.wri$_optstat_histgrm_history hg
  where
    SYS_OP_DV_CHECK(op.name, op.owner#) = 1 and
    os.owner# = u.user# and
    os.type# = 34 and -- SUB PARTITION
    os.obj# = ts.obj# and ts.pobj# = op.obj# and op.type# = 19 and
    ts.pobj# = tcp.obj# and
    os.obj# = h.obj# and
    hg.obj#(+) = os.obj# and hg.intcol#(+) = h.intcol# and
    hg.savtime(+) = h.savtime
  union all
  -- c.3 -- Columns of fixed tables
  select
    'c' type, dbms_stats.get_stat_tab_version version,
    h.flags flags,
    ot.kqftanam c1, null c2, null c3, null c4, 'SYS' c5, null c6,
    h.distcnt n1, h.density, h.sample_distcnt, h.sample_size n4,
    h.null_cnt n5, h.minimum, h.maximum, h.avgcln n8,
    null n9, hg.bucket, hg.endpoint n11,
    hg.ep_repeat_count n12, null n13,
    h.timestamp# d1, h.savtime t1,
    h.lowval r1, h.hival r2, case when hg.epvalue is not null then
                                       utl_raw.cast_to_raw(hg.epvalue)
                             else hg.epvalue_raw end r3, null ch1,
    expression cl1, null bl1, 0 owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
    from sys.x$kqfta ot, sys.x$kqfco c,
         sys.wri$_optstat_histhead_history h,
         sys.wri$_optstat_histgrm_history hg
    where -- SYS objects not protected by data vault
      SYS_OP_DV_CHECK(ot.kqftanam, 0) = 1 and
      c.kqfcotob = ot.kqftaobj and
      h.obj# = ot.kqftaobj and h.intcol# = c.kqfcocno and
      hg.obj#(+) = ot.kqftaobj and hg.intcol#(+) = h.intcol# and
      hg.savtime(+) = h.savtime
  union all
  --
  -- Type M, DML Modification monitoring information
  --
  -- M.1 Modifications for tables and [composite] partitions
  select
    'M' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    ot.name c1, ot.subname, null, null, u.name, null c6,
    m.inserts n1, m.updates n2, m.deletes n3, m.flags n4,
    m.drop_segments n5, null, null, null n8,
    null n9, null, null, null n12, null n13,
    m.timestamp d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot, sys.mon_mods_all$ m
  where
    ot.owner# = u.user# and
    ot.type# in (2,19) and -- TABLE, [COMPOSITE] PARTITION
    ot.obj# = m.obj#
  union all
  -- M.2 Modifications for subpartitions of tables
  select
    'M' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    op.name c1, op.subname, os.subname, null, u.name c5, null c6,
    m.inserts n1, m.updates n2, m.deletes n3, m.flags n4,
    m.drop_segments n5, null, null, null n8,
    null n9, null, null, null n12, null n13,
    m.timestamp d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ os,
       sys.tabsubpart$ ts,  sys.obj$ op, sys.mon_mods_all$ m
  where
    os.owner# = u.user# and
    os.type# = 34 and -- SUB PARTITION
    os.obj# = ts.obj# and ts.pobj# = op.obj# and op.type# = 19 and
    ts.obj# = m.obj#
  union all
  --
  -- Type U, column Usage information
  --
  -- U.1 Column Usage of regular tables
  select
    'U' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    ot.name c1, null, null, c.name, u.name, null c6,
    u.equality_preds n1, u.equijoin_preds n2, u.nonequijoin_preds n3,
    u.range_preds n4, u.like_preds n5, u.null_preds n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    u.timestamp d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot, sys.col$ c, sys.col_usage$ u
  where
    ot.owner# = u.user# and
    ot.type# = 2 and -- TABLE
    ot.obj# = c.obj# and
    u.obj# = c.obj# and u.intcol# = c.intcol#
  union all
  -- U.2 Column Usage of fixed tables
  select
    'U' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    ot.kqftanam c1, null c2, null c3, null c4, 'SYS' c5, null c6,
    u.equality_preds n1, u.equijoin_preds n2, u.nonequijoin_preds n3,
    u.range_preds n4, u.like_preds n5, u.null_preds n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    u.timestamp d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1, 0 owner#,
    dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
    from sys.x$kqfta ot, sys.x$kqfco c, sys.col_usage$ u
    where
      c.kqfcotob = ot.kqftaobj and
      u.obj# = c.kqfcotob and u.intcol# = c.kqfcocno
  --
  -- Type G, column group Usage information
  --
  union all
  select
    'G' type,
    dbms_stats.get_stat_tab_version version,
    g.flags flags,
    ot.name c1, null, null, null, u.name, null c6,
    null n1, null n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    g.timestamp d1, null t1,
    null r1, null r2, null r3, null ch1,
    -- proj 82820: combine cols and cols_range with '|'
    to_clob(g.cols || '|' || g.cols_range) cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot, sys.col_group_usage$ g
  where
    ot.owner# = u.user# and
    ot.type# = 2 and -- TABLE
    ot.obj# = g.obj#
  --
  -- Type L, statistics lock (and can store other metadata as well?)
  -- Lock bits are not stored in subpartitions, hence no query on tabsubpart$
  --
  union all
  select
    'L' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    ot.name c1, ot.subname c2, null, null, u.name, null c6,
    o.lckflag n1, null n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    u.user# owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from sys.user$ u, sys.obj$ ot,
       (select obj#,
               decode(bitand(t.trigflag, 67108864), 0, 0, 1) +
               decode(bitand(t.trigflag, 134217728), 0, 0, 2) lckflag
        from tab$ t
        where
          (bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728)) != 0
        union all
        select obj#,
               decode(bitand(t.flags, 32), 0, 0, 1) +
               decode(bitand(t.flags, 64), 0, 0, 2) lckflag
        from tabpart$ t
        where (bitand(t.flags, 32) + bitand(t.flags, 64)) != 0
        union all
        select obj#,
               decode(bitand(t.flags, 32), 0, 0, 1) +
               decode(bitand(t.flags, 64), 0, 0, 2) lckflag
        from tabcompart$ t
        where (bitand(t.flags, 32) + bitand(t.flags, 64)) != 0) o
  where
    ot.owner# = u.user# and
    ot.obj# = o.obj#
  --
  -- Type D, Sql Plan Directives
  --
  -- #(22182203) Dynamic sampling result directive is supported only from
  -- 12.2. These type of directives and its objects are marked with
  -- correct DSC_COMPATIBLE values based on d.type.
  --
  -- We have 2 types of directives today
  --   DYNAMIC_SAMPLING (d.type is 1, supported since 12.1)
  --   DYNAMIC_SAMPLING_RESULT (d.type is 2, supported since 12.2)
  --
  union all
  select
    'D' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    null c1, null c2, null, null, to_char(d.dir_id) c5, null c6,
    d.type n1, d.state n2, d.flags n3, f.type n4, f.reason n5, f.tab_cnt n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1, to_clob(d.vc_one) cl1, null bl1,
    0 owner#,
    case when d.type = 1 then dbms_stats_internal.get_sc_1201
         else dbms_stats_internal.get_sc_1202 end min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from  opt_directive$ d, opt_finding$ f
  where d.f_id = f.f_id
  --
  -- Type O, Sql Plan Directive Objects
  -- This branch gives 12.1 version of SPD objects which does not
  -- get dynamic sampling result directive (see d.type = 1 predicate)
  --
  union all
  select
    'O' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    u.name c1, o.name c2, null, null, to_char(d.dir_id) c5, null c6,
    o.type# n1, fo.flags n2, fo.nrows  n3, fo.obj_type  n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    0 owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_1202 max_sc
  from  sys.opt_directive$ d, opt_finding_obj$ fo,
        (select obj#, owner#, type#, name from sys.obj$
         union all
         select object_id obj#, 0 owner#, 2 type#, name from  v$fixed_table) o,
        user$ u
  where d.f_id = fo.f_id and fo.f_obj# = o.obj# and o.owner# = u.user# and
  fo.obj_type = 1 and d.type = 1
  union all
  -- This branch gives 12.2 and above version of SPD objects
  select
    'O' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    u.name c1, o.name c2, null, null, to_char(d.dir_id) c5, null c6,
    o.type# n1, fo.flags n2, fo.nrows  n3, fo.obj_type  n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    0 owner#, dbms_stats_internal.get_sc_1202 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from  sys.opt_directive$ d, opt_finding_obj$ fo,
        (select obj#, owner#, type#, name from sys.obj$
         union all
         select object_id obj#, 0 owner#, 2 type#, name from  v$fixed_table) o,
        user$ u
  where d.f_id = fo.f_id and fo.f_obj# = o.obj# and o.owner# = u.user# and
  fo.obj_type = 1
  --
  -- Type O, Sql Plan Directive Objects - SQLID and SQLENV
  -- Applicable only for 12.2 and above
  --
  union all
  select
    'O' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    to_char(fo.f_obj#) c1, null c2, null,
    null, to_char(d.dir_id) c5, null c6,
    null n1, fo.flags n2, null  n3, fo.obj_type n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1, null cl1, null bl1,
    0 owner#, dbms_stats_internal.get_sc_1202 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from  opt_directive$ d, opt_finding_obj$ fo
  where d.f_id = fo.f_id and
    fo.obj_type in (4,5)
  --
  -- Type V, Sql Plan Directive Object columns
  --
  union all
  select
    'V' type,
    dbms_stats.get_stat_tab_version version,
    null flags,
    u.name c1, o.name c2, c.name c3, null, to_char(d.dir_id) c5, null c6,
    o.type# n1, null n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    null d1, null t1,
    null r1, null r2, null r3, null ch1,
    -- Store the expression of virtual columns for remap purpose
    --   0x00010000 =   65536 = virtual column
    --   0x0100     =     256 = system-generated column
    --   0x0020     =      32 = hidden column
    decode(bitand(c.property, 65536+256+32), 65536+256+32,
           dbms_stats_internal.get_col_expr(c.rowidn, c.property), null) cl1,
    null bl1, 0 owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from opt_directive$ d,  "_BASE_OPT_FINDING_OBJ_COL" ft,
       (select obj#, owner#, type#, name from sys.obj$
         union all
         select object_id obj#, 0 owner#, 2 type#, name from  v$fixed_table) o,
       (select obj#, intcol#, name, rowid rowidn, property
        from sys.col$
        union all
        -- Virtual columns not allowed on fixed tables. So using null for
        -- rowid and property
        select kqfcotob obj#, kqfcocno intcol#, kqfconam name, null rowidn,
               null property
        from sys.x$kqfco) c,
       user$ u
  where d.f_id = ft.f_id and ft.f_obj# = o.obj# and
        o.owner# = u.user# and o.obj# = c.obj# and
        ft.intcol# = c.intcol#
  --
  -- Type A, Global Preferences
  --
  union all
  select
    'A', dbms_stats.get_stat_tab_version,
    null flags,
    null c1, p.sname c2, null, null, null, null c6,
    p.sval1 n1, p.spare1 n2, null n3, null n4, null n5, null n6,
    null n7, null n8, null n9, null n10, null n11, null n12, null n13,
    p.sval2 d1, null t1, null r1, null r2, null r3, null ch1,
    to_clob(p.spare4) cl1, null bl1,
    0 owner#, dbms_stats_internal.get_sc_1201 min_sc,
    dbms_stats_internal.get_sc_max max_sc
  from optstat_hist_control$ p
) v
where -- current user is owner
      v.owner# = SYS_CONTEXT('USERENV','CURRENT_USERID') or
      -- Display Sql Plan Directives only if user has
      -- Administer SQL Management Object privilege
      (type in ('D', 'O', 'V') and
       exists (select null from v$enabledprivs where priv_number = -327)) or
      -- object is owned by SYS and current user has ANALYZE ANY DICTIONARY
      -- privilege
      (type not in ('D', 'O', 'V') and v.owner# = 0 and
       exists (select null from v$enabledprivs where priv_number = -262)) or
      -- object is NOT owned by SYS and current user has ANALYZE ANY
      (type not in ('D', 'O', 'V') and v.owner# != 0 and  -- ANALYZE ANY
       exists (select null from v$enabledprivs where priv_number = -165))
/

