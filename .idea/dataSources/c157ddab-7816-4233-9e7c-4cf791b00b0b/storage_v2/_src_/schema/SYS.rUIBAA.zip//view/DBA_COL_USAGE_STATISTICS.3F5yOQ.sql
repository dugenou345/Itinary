create view DBA_COL_USAGE_STATISTICS
            (SEGMENT_NAME, SUBOBJECT_NAME, TABLE_OWNER, TABLESPACE_NAME, COLUMN_NAME, COLUMN_ID, STATISTIC_NAME,
             BEGIN_TRACK_TIME, END_TRACK_TIME, STATISTIC_VALUE_INT, STATISTIC_VALUE_STR)
as
select o.name, p.subname, u.name, ts.name, c.name, s.colid,
       (case s.stat_type
           when 0  then 'In Memory'
           when 1  then 'Is Scanned'
           when 2  then 'Is Projected'
           when 3  then 'Is Modified'
           when 4  then 'Num Scans'
           when 5  then 'Num Projects'
           when 6  then 'Num Updates'
           when 7  then 'Used in Predicate'
           when 8  then 'Num Queries'
           when 9  then 'Num Queries Predicate'
           when 10 then 'Num Queries Project'
        end) as stat_name,
       s.track_time, i.track_time,
       (case s.stat_type
           when 1 then (case when (s.stat_val_int=1) then 1
              else (case when (i.stat_val_int=1) then 1 else 0 end) end)
           when 2 then (case when (s.stat_val_int=1) then 1
              else (case when (i.stat_val_int=1) then 1 else 0 end) end)
           when 3 then (case when (s.stat_val_int=1) then 1
              else (case when (i.stat_val_int=1) then 1 else 0 end) end)
           when 4 then (s.stat_val_int + i.stat_val_int)
           when 5 then (s.stat_val_int + i.stat_val_int)
           when 6 then (s.stat_val_int + i.stat_val_int)
           when 7 then (case when (s.stat_val_int=1) then 1
          else (case when (i.stat_val_int=1) then 1 else 0 end) end)
           when 8 then (s.stat_val_int + i.stat_val_int)
           when 9 then (s.stat_val_int + i.stat_val_int)
           when 10 then (s.stat_val_int + i.stat_val_int)
        end) as stat_val_int, s.stat_val_str
from COLUMN_STAT$ s, GV$COLUMN_STATISTICS i, USER$ u,
(select obj#, name, subname, owner# from obj$ where name in (select distinct (o.name) from
 obj$ o, COLUMN_STAT$ s where s.obj#=o.obj#) and type#=2) o, obj$ p,
COL$ c, TS$ ts
where s.obj#=i.obj# and
o.owner#=u.user# and
o.owner#=p.owner# and
p.obj# = s.obj# and
p.name = o.name and
c.obj#=o.obj# and
c.col#=s.colid and
s.ts#=ts.ts# and
s.colid=i.colid and
s.stat_type = i.stat_type and
s.stat_type in (0,1,2,3,4,5,6,7,8,9,10)
union
select o.name, p.subname, u.name, ts.name, c.name, s.colid,
        (case s.stat_type
           when 0  then 'In Memory'
           when 1  then 'Is Scanned'
           when 2  then 'Is Projected'
           when 3  then 'Is Modified'
           when 4  then 'Num Scans'
           when 5  then 'Num Projects'
           when 6  then 'Num Updates'
           when 7  then 'Used in Predicate'
           when 8  then 'Num Queries'
           when 9  then 'Num Queries Predicate'
           when 10 then 'Num Queries Project'
        end) as stat_name,
       s.track_time, s.track_time, s.stat_val_int,s.stat_val_str
from COLUMN_STAT$ s,
(select obj#, name, subname, owner# from obj$ where name in (select distinct (o.name) from
 obj$ o, COLUMN_STAT$ s where s.obj#=o.obj#) and type#=2) o, obj$ p,
user$ u, ts$ ts, col$ c
where o.owner#=u.user# and
o.owner#=p.owner# and
p.obj# = s.obj# and
p.name = o.name and
c.obj#=o.obj# and
c.col#=s.colid and
s.ts#=ts.ts# and
s.stat_type in (0,1,2,3,4,5,6,7,8,9,10) and
(s.obj#, s.colid, s.stat_type) not in
          (select obj#, colid, stat_type from GV$COLUMN_STATISTICS)
union
select o.name, p.subname, u.name, ts.name, c.name, s.colid,
        (case s.stat_type
           when 0  then 'In Memory'
           when 1  then 'Is Scanned'
           when 2  then 'Is Projected'
           when 3  then 'Is Modified'
           when 4  then 'Num Scans'
           when 5  then 'Num Projects'
           when 6  then 'Num Updates'
           when 7  then 'Used in Predicate'
           when 8  then 'Num Queries'
           when 9  then 'Num Queries Predicate'
           when 10 then 'Num Queries Project'
        end) as stat_name,
       s.track_time, s.track_time, s.stat_val_int,s.stat_val_str
from GV$COLUMN_STATISTICS s,
(select obj#, name, owner# from obj$ where name in (select distinct (o.name) from
 obj$ o, gv$column_statistics s where s.obj#=o.obj#) and type#=2) o, obj$ p,
user$ u, ts$ ts, col$ c
where o.owner#=u.user# and
o.owner#=p.owner# and
p.obj# = s.obj# and
p.name = o.name and
c.obj#=o.obj# and
c.col#=s.colid and
s.ts#=ts.ts# and
s.stat_type in (0,1,2,3,4,5,6,7,8,9,10) and
(s.obj#, s.colid, s.stat_type) not in
          (select obj#, colid, stat_type from COLUMN_STAT$)
/

