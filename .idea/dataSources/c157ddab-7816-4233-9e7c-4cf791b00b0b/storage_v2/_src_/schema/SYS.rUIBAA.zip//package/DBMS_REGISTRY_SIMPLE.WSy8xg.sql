create PACKAGE dbms_registry_simple AS

-- inline PRAGMA declarations to handle PL/SQL packages rolling upgrade
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

FUNCTION  is_db_consolidated RETURN BOOLEAN;

FUNCTION  is_db_root         RETURN BOOLEAN;

FUNCTION  is_db_pdb          RETURN BOOLEAN;

FUNCTION  is_db_pdb_seed     RETURN BOOLEAN;

END dbms_registry_simple;
/

