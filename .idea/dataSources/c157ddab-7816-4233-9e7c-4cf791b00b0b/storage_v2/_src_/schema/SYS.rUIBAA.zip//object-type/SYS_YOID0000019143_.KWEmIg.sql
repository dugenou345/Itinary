create type       "SYS_YOID0000019143$"              as object( "SYS_NC00001$" NUMBER)
/

