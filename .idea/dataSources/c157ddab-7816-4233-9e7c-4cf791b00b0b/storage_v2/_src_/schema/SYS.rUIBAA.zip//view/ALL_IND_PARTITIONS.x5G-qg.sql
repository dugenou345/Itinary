create view ALL_IND_PARTITIONS
            (INDEX_OWNER, INDEX_NAME, COMPOSITE, PARTITION_NAME, SUBPARTITION_COUNT, HIGH_VALUE, HIGH_VALUE_LENGTH,
             PARTITION_POSITION, STATUS, TABLESPACE_NAME, PCT_FREE, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT,
             MIN_EXTENT, MAX_EXTENT, MAX_SIZE, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, COMPRESSION, BLEVEL,
             LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS,
             SAMPLE_SIZE, LAST_ANALYZED, BUFFER_POOL, FLASH_CACHE, CELL_FLASH_CACHE, USER_STATS, PCT_DIRECT_ACCESS,
             GLOBAL_STATS, DOMIDX_OPSTATUS, PARAMETERS, INTERVAL, SEGMENT_CREATED, ORPHANED_ENTRIES)
as
select u.name, io.name, 'NO', io.subname, 0,
       ip.hiboundval, ip.hiboundlen,
       row_number() over (partition by u.name, io.name order by ip.part#),
       decode(bitand(ip.flags, 1), 1, 'UNUSABLE', 'USABLE'),ts.name,
       ip.pctfree$, ip.initrans, ip.maxtrans,
       decode(bitand(ip.flags, 65536), 65536,
              ds.initial_stg * ts.blocksize, s.iniexts * ts.blocksize),
       decode(bitand(ip.flags, 65536), 65536,
              ds.next_stg * ts.blocksize, s.extsize * ts.blocksize),
       decode(bitand(ip.flags, 65536), 65536, ds.minext_stg, s.minexts),
       decode(bitand(ip.flags, 65536), 65536, ds.maxext_stg, s.maxexts),
       decode(bitand(ip.flags, 65536), 65536,
              ds.maxsiz_stg * ts.blocksize,
              decode(bitand(s.spare1, 4194304), 4194304, bitmapranges, NULL)),
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
              decode(bitand(ip.flags, 65536), 65536, ds.pctinc_stg, s.extpct)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(ip.flags, 65536), 65536,
                     decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                     decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(ip.flags, 65536), 65536,
                     decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                     decode(s.groups, 0, 1, s.groups))),
       decode(mod(trunc(ip.flags / 4), 2), 0, 'YES', 'NO'),
       case
         when bitand(ip.flags, 1024) = 1024 then 'ENABLED'
       else
         case when (bitand(ip.flags, 65536) = 65536) then
           decode(bitand(ds.flags_stg, 4), 4,
                  decode(bitand(ds.cmpflag_stg, 6),
                         4, 'ADVANCED LOW',
                         2, 'ADVANCED HIGH',
                         NULL),
                  'DISABLED')
         else
           decode(bitand(s.spare1, 2048), 2048,
                  decode(bitand(s.spare1, 16777216 + 1048576),
                         16777216, 'ADVANCED HIGH',
                         1048576, 'ADVANCED LOW',
                         NULL),
                  'DISABLED')
         end
       end,
       ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey,
       ip.clufac, ip.rowcnt, ip.samplesize, ip.analyzetime,
       decode(bitand(decode(bitand(ip.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 3),
              1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(decode(bitand(ip.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 12)/4,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(decode(bitand(ip.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 48)/16,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(ip.flags, 8), 0, 'NO', 'YES'), ip.pctthres$,
       decode(bitand(ip.flags, 16), 0, 'NO', 'YES'), '','',
       decode(bitand(ip.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(ip.flags, 65536), 65536, 'NO', 'YES'),
       decode(bitand(ip.flags, 262144), 262144, 'YES', 'NO')
from obj$ io, indpart$ ip, ts$ ts, sys.seg$ s, ind$ i, sys.user$ u, tab$ t,
     sys.deferred_stg$ ds
where io.obj# = ip.obj# and ts.ts# = ip.ts# and ip.file#=s.file#(+) and
      ip.block#=s.block#(+) and ip.ts#=s.ts#(+) and io.owner# = u.user# and
      i.obj# = ip.bo# and i.bo# = t.obj# and ip.obj# = ds.obj#(+) and
      bitand(ip.flags, 8388608) = 0 and    /* filter out hidden partitions */
      bitand(t.trigflag, 1073741824) != 1073741824 and
      i.type# != 8 and      /* not LOB index */
      i.type# != 9 and      /* not DOMAIN index */
      io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL and
        (io.owner# = userenv('SCHEMAID')
        or
        i.bo# in (select obj#
                    from objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
union all
select u.name, io.name, 'YES', io.subname, icp.subpartcnt,
       icp.hiboundval, icp.hiboundlen,
       row_number() over (partition by u.name, io.name order by icp.part#) ,
       'N/A', ts.name,
       icp.defpctfree, icp.definitrans, icp.defmaxtrans,
       icp.definiexts, icp.defextsize, icp.defminexts, icp.defmaxexts,
       icp.defmaxsize, icp.defextpct, icp.deflists, icp.defgroups,
       decode(icp.deflogging, 0, 'NONE', 1, 'YES', 2, 'NO', 'UNKNOWN'),
       case
         when bitand(icp.spare3, 8) = 8 then 'ADVANCED LOW'
         when bitand(icp.spare3, 4) = 4 then 'ADVANCED HIGH'
       else
         decode(bitand(icp.flags, 1024), 1024, 'ENABLED', 'DISABLED')
       end,
       icp.blevel, icp.leafcnt, icp.distkey, icp.lblkkey, icp.dblkkey,
       icp.clufac, icp.rowcnt, icp.samplesize, icp.analyzetime,
       decode(bitand(icp.defbufpool, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(icp.defbufpool, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(icp.defbufpool, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(icp.flags, 8), 0, 'NO', 'YES'), TO_NUMBER(NULL),
       decode(bitand(icp.flags, 16), 0, 'NO', 'YES'), '','',
       decode(bitand(icp.flags, 32768), 32768, 'YES', 'NO'), 'N/A', 'N/A'
from   obj$ io, indcompart$ icp, ts$ ts, ind$ i, user$ u, tab$ t
where  io.obj# = icp.obj# and icp.defts# = ts.ts# (+) and io.owner# = u.user# and
       i.obj# = icp.bo# and i.bo# = t.obj# and
       bitand(t.trigflag, 1073741824) != 1073741824 and
       bitand(icp.flags, 8388608) = 0 and    /* filter out hidden partitions */
       i.type# != 8 and      /* not LOB index */
       i.type# != 9 and      /* not DOMAIN index */
       io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL and
       (io.owner# = userenv('SCHEMAID')
        or
        i.bo# in (select oa.obj#
                 from sys.objauth$ oa
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
        or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
union all
select u.name, io.name, 'NO', io.subname, 0,
       ip.hiboundval, ip.hiboundlen,
       row_number() over (partition by u.name, io.name order by ip.part#),
       decode(bitand(ip.flags, 1), 1, 'UNUSABLE',
               decode(bitand(ip.flags, 4096), 4096, 'INPROGRS', 'USABLE')),
       null, ip.pctfree$, ip.initrans, ip.maxtrans,
       0, 0, 0, 0, 0, 0, 0, 0,
       decode(mod(trunc(ip.flags / 4), 2), 0, 'YES', 'NO'),
       'N/A',
       ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey,
       ip.clufac, ip.rowcnt, ip.samplesize, ip.analyzetime,
       'DEFAULT', 'DEFAULT', 'DEFAULT',
       decode(bitand(ip.flags, 8), 0, 'NO', 'YES'), ip.pctthres$,
       decode(bitand(ip.flags, 16), 0, 'NO', 'YES'),
       decode(i.type#,
             9, decode(bitand(ip.flags, 8192), 8192, 'FAILED', 'VALID'),
             ''),
       ipp.parameters,
       decode(bitand(ip.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(ip.flags, 65536), 65536, 'NO', 'YES'),
       decode(bitand(ip.flags, 262144), 262144, 'YES', 'NO')
from obj$ io, indpart$ ip, ind$ i, sys.user$ u, indpart_param$ ipp, tab$ t
where io.obj# = ip.obj# and io.owner# = u.user# and
      i.obj# = ip.bo# and ip.obj# = ipp.obj# and
      i.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
      io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL and
        (io.owner# = userenv('SCHEMAID')
        or
        i.bo# in (select obj#
                    from objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
union all
select u.name, io.name, 'YES', io.subname, icp.subpartcnt,
       icp.hiboundval, icp.hiboundlen,
       row_number() over (partition by u.name, io.name order by icp.part#),
       'N/A', null,
       icp.defpctfree, icp.definitrans, icp.defmaxtrans,
       0, 0, 0, 0, 0, 0, 0, 0,
       decode(icp.deflogging, 0, 'NONE', 1, 'YES', 2, 'NO', 'UNKNOWN'),
       'N/A',
       icp.blevel, icp.leafcnt, icp.distkey, icp.lblkkey, icp.dblkkey,
       icp.clufac, icp.rowcnt, icp.samplesize, icp.analyzetime,
       'DEFAULT', 'DEFAULT', 'DEFAULT',
       decode(bitand(icp.flags, 8), 0, 'NO', 'YES'), TO_NUMBER(NULL),
       decode(bitand(icp.flags, 16), 0, 'NO', 'YES'),
       decode(i.type#,
             9, decode(bitand(icp.flags, 8192), 8192, 'FAILED', 'VALID'),
             ''),
       ipp.parameters,
       decode(bitand(icp.flags, 32768), 32768, 'YES', 'NO'), 'N/A', 'N/A'
from obj$ io, indcompart$ icp, ind$ i, sys.user$ u, indpart_param$ ipp, tab$ t
where io.obj# = icp.obj# and io.owner# = u.user# and
      i.obj# = icp.bo# and icp.obj# = ipp.obj# and
      i.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
      io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL and
        (io.owner# = userenv('SCHEMAID')
        or
        i.bo# in (select obj#
                    from objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/

