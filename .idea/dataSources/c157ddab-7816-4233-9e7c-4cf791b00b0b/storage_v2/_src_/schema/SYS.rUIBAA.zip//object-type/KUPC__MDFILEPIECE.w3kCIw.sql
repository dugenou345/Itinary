create TYPE     kupc$_mdFilePiece FORCE AS OBJECT
(
   dump_fileid     NUMBER,
   dump_pos        NUMBER,
   dump_len        NUMBER,
   dump_alloc      NUMBER,
   dump_off        NUMBER,
   dump_name       VARCHAR2(4000),
   dump_cred       VARCHAR2(4000),
   CONSTRUCTOR FUNCTION kupc$_mdFilePiece RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION kupc$_mdFilePiece (
                                fid      NUMBER,
                                pos      NUMBER,
                                len      NUMBER,
                                alc      NUMBER
                               ) RETURN SELF AS RESULT
)
NOT PERSISTABLE
/

