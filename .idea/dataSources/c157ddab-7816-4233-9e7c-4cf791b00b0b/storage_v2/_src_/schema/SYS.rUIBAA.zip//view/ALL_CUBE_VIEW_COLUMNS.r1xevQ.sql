create view ALL_CUBE_VIEW_COLUMNS (OWNER, CUBE_NAME, VIEW_NAME, COLUMN_NAME, COLUMN_TYPE, OBJECT_NAME) as
SELECT OWNER, CUBE_NAME, VIEW_NAME, COLUMN_NAME, COLUMN_TYPE, OBJECT_NAME
FROM
(SELECT
  co.obj# obj#,
  co.owner# owner#,
  co.type# type#,
  cu.name OWNER,
  co.name CUBE_NAME,
  vo.name VIEW_NAME,
  col.name COLUMN_NAME,
  'MEASURE' COLUMN_TYPE,
  m.measure_name OBJECT_NAME -- name of measure
FROM
  olap_aw_view_columns$ avc,
  olap_aw_views$ av,
  olap_measures$ m,
  col$ col,
  obj$ co,
  user$ cu,
  obj$ vo
WHERE
  av.olap_object_type = 1 -- CUBE
  AND av.olap_object_id = co.obj#
  AND av.view_type = 1 -- ET
  AND co.owner# = cu.user#
  AND av.view_obj# = avc.view_obj#
  AND avc.column_type = 1 -- OBJECT
  AND avc.referenced_object_type = 2 -- MEASURE
  AND avc.referenced_object_id = m.measure_id
  AND avc.view_obj# = col.obj#
  AND avc.column_obj# = col.col#
  AND avc.view_obj#=vo.obj#
  AND vo.type# != 10 -- not NON-EXISTENT
  AND vo.owner#=co.owner#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privilages
              ora_check_SYS_privilege (co.owner#, co.type#) = 1
            )
UNION ALL
SELECT -- dimensioned by dimension
  co.obj# obj#,
  co.owner# owner#,
  co.type# type#,
  cu.name OWNER,
  co.name CUBE_NAME,
  vo.name VIEW_NAME,
  col.name COLUMN_NAME,
  'KEY' COLUMN_TYPE,
  do.name OBJECT_NAME -- name of dimension
FROM
  olap_aw_view_columns$ avc,
  olap_aw_views$ av,
  col$ col,
  obj$ co,
  user$ cu,
  obj$ vo,
  obj$ do,
  olap_dimensionality$ d
WHERE
  av.olap_object_type = 1 -- CUBE
  AND av.olap_object_id = co.obj#
  AND av.view_type = 1 -- ET
  AND co.owner# = cu.user#
  AND av.view_obj# = avc.view_obj#
  AND avc.column_type = 2 -- KEY
  AND avc.referenced_object_type = 16 -- DIMENSIONALITY
  AND avc.referenced_object_id = d.dimensionality_id
  AND d.dimension_type = 11 -- DIMENSION
  AND d.dimension_id = do.obj#
  AND avc.view_obj# = col.obj#
  AND avc.column_obj# = col.col#
  AND avc.view_obj#=vo.obj#
  AND vo.type# != 10 -- not NON-EXISTENT
  AND vo.owner#=co.owner#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privilages
              ora_check_SYS_privilege (co.owner#, co.type#) = 1
            )
UNION ALL
SELECT -- dimensioned by dimension level
  co.obj# obj#,
  co.owner# owner#,
  co.type# type#,
  cu.name OWNER,
  co.name CUBE_NAME,
  vo.name VIEW_NAME,
  col.name COLUMN_NAME,
  'KEY' COLUMN_TYPE,
  do.name OBJECT_NAME -- name of dimension
FROM
  olap_aw_view_columns$ avc,
  olap_aw_views$ av,
  col$ col,
  obj$ co,
  user$ cu,
  obj$ vo,
  obj$ do,
  olap_dimensionality$ d,
  olap_dim_levels$ dl
WHERE
  av.olap_object_type = 1 -- CUBE
  AND av.olap_object_id = co.obj#
  AND av.view_type = 1 -- ET
  AND co.owner# = cu.user#
  AND av.view_obj# = avc.view_obj#
  AND avc.column_type = 2 -- KEY
  AND avc.referenced_object_type = 16 -- DIMENSIONALITY
  AND avc.referenced_object_id = d.dimensionality_id
  AND d.dimension_type = 12 -- DIM_LEVEL
  AND d.dimension_id = dl.level_id
  AND dl.dim_obj# = do.obj#
  AND avc.view_obj# = col.obj#
  AND avc.column_obj# = col.col#
  AND avc.view_obj#=vo.obj#
  AND vo.type# != 10 -- not NON-EXISTENT
  AND vo.owner#=co.owner#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privilages
              ora_check_SYS_privilege (co.owner#, co.type#) = 1
            )
UNION ALL
SELECT -- dimensioned by hierarchy
  co.obj# obj#,
  co.owner# owner#,
  co.type# type#,
  cu.name OWNER,
  co.name CUBE_NAME,
  vo.name VIEW_NAME,
  col.name COLUMN_NAME,
  'KEY' COLUMN_TYPE,
  do.name OBJECT_NAME -- name of dimension
FROM
  olap_aw_view_columns$ avc,
  olap_aw_views$ av,
  col$ col,
  obj$ co,
  user$ cu,
  obj$ vo,
  obj$ do,
  olap_dimensionality$ d,
  olap_hierarchies$ h
WHERE
  av.olap_object_type = 1 -- CUBE
  AND av.olap_object_id = co.obj#
  AND av.view_type = 1 -- ET
  AND co.owner# = cu.user#
  AND av.view_obj# = avc.view_obj#
  AND avc.column_type = 2 -- KEY
  AND avc.referenced_object_type = 16 -- DIMENSIONALITY
  AND avc.referenced_object_id = d.dimensionality_id
  AND d.dimension_type = 13 -- HIERARCHY
  AND d.dimension_id = h.hierarchy_id
  AND h.dim_obj# = do.obj#
  AND avc.view_obj# = col.obj#
  AND avc.column_obj# = col.col#
  AND avc.view_obj#=vo.obj#
  AND vo.type# != 10 -- not NON-EXISTENT
  AND vo.owner#=co.owner#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privilages
              ora_check_SYS_privilege (co.owner#, co.type#) = 1
            )
UNION ALL
SELECT -- dimensioned by hierarchy level
  co.obj# obj#,
  co.owner# owner#,
  co.type# type#,
  cu.name OWNER,
  co.name CUBE_NAME,
  vo.name VIEW_NAME,
  col.name COLUMN_NAME,
  'KEY' COLUMN_TYPE,
  do.name OBJECT_NAME -- name of dimension
FROM
  olap_aw_view_columns$ avc,
  olap_aw_views$ av,
  col$ col,
  obj$ co,
  user$ cu,
  obj$ vo,
  obj$ do,
  olap_dimensionality$ d,
  olap_hierarchies$ h,
  olap_hier_levels$ hl
WHERE
  av.olap_object_type = 1 -- CUBE
  AND av.olap_object_id = co.obj#
  AND av.view_type = 1 -- ET
  AND co.owner# = cu.user#
  AND av.view_obj# = avc.view_obj#
  AND avc.column_type = 2 -- KEY
  AND avc.referenced_object_type = 16 -- DIMENSIONALITY
  AND avc.referenced_object_id = d.dimensionality_id
  AND d.dimension_type = 14 -- HIER_LEVEL
  AND d.dimension_id = hl.hierarchy_level_id
  AND hl.hierarchy_id = h.hierarchy_id
  AND h.dim_obj# = do.obj#
  AND avc.view_obj# = col.obj#
  AND avc.column_obj# = col.col#
  AND avc.view_obj#=vo.obj#
  AND vo.type# != 10 -- not NON-EXISTENT
  AND vo.owner#=co.owner#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privilages
              ora_check_SYS_privilege (co.owner#, co.type#) = 1
            )
) u,
 (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      dependency$ d,
      obj$ do
    WHERE
      do.obj# = d.p_obj#
      AND do.type# = 92 -- CUBE DIMENSION
      AND c.obj# = d.d_obj#
    )
    GROUP BY obj# ) da
WHERE u.obj#=da.obj#(+)
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL)
         or   -- user has system privileges
                ora_check_SYS_privilege (owner#, type#) = 1
  )
/

comment on table ALL_CUBE_VIEW_COLUMNS is 'OLAP Cube View Columns in the database accessible by the user'
/

comment on column ALL_CUBE_VIEW_COLUMNS.OWNER is 'Owner of the OLAP Cube View Column'
/

comment on column ALL_CUBE_VIEW_COLUMNS.CUBE_NAME is 'Name of owning cube of the OLAP Cube View Column'
/

comment on column ALL_CUBE_VIEW_COLUMNS.VIEW_NAME is 'View Name of the OLAP Cube View Column'
/

comment on column ALL_CUBE_VIEW_COLUMNS.COLUMN_NAME is 'Name of the OLAP Cube View Column'
/

comment on column ALL_CUBE_VIEW_COLUMNS.COLUMN_TYPE is 'View Type of the OLAP Cube View Column'
/

comment on column ALL_CUBE_VIEW_COLUMNS.OBJECT_NAME is 'Name of Measure of the OLAP Cube View Column'
/

