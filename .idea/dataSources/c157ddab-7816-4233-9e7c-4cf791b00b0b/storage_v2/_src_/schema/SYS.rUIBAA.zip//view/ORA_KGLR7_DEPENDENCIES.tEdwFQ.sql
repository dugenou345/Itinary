create view ORA_KGLR7_DEPENDENCIES
            (OWNER, NAME, TYPE, PARENT_OWNER, PARENT_NAME, PARENT_TYPE, PARENT_LINK_NAME, PARENT_TIMESTAMP,
             ORDER_NUMBER, OBJ#, PROPERTY)
as
select u.name, o.name, o.type#,
    decode(o2.linkname, null, u2.name, o2.remoteowner), o2.name, o2.type#,
         o2.linkname, d.p_timestamp, d.order#, o.obj#, d.property
from sys.obj$ o, sys.dependency$ d,
     sys.user$ u, sys.obj$ o2, sys.user$ u2
where o.obj# = d.d_obj#
  and o.owner# = u.user#
  and o.status = 1 /* VALID/AUTHORIZED WITHOUT ERRORS */
  and (o2.obj# = d.p_obj# and o2.owner# = u2.user# and
       (o2.namespace = 1 /* TABLE/PROCEDURE */
       or
       o2.namespace = 2 /* BODY */))
  and (o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
       or (o.namespace in (1 /* TABLE/PROCEDURE */,
                           2 /* PACKAGE BODY */)
           and (o.type# in (2 /* TABLE */, 4 /* VIEW */, 9 /* PACKAGE */,
                           13 /* TYPE */)
                or
                o.obj# in (select obj# from sys.objauth$
                           where grantee# in (select kzsrorol
                                              from x$kzsro)
                             and privilege# = 12 /* EXECUTE */)
                or
                exists (select null from sys.sysauth$
                        where grantee# in (select kzsrorol
                                           from x$kzsro)
                             and (o.type# in (7 /* PROCEDURE */,
                                             8 /* FUNCTION */,
                                             11 /* PACKAGE BODY */) and
                                  privilege# = -144 /* EXECUTE ANY PROCEDURE */
                                  )))))
union
select u.name, o.name, o.type#, 'SYS', po.name,
      decode(po.type, 'TABLE', 2, 'VIEW', 4, 2),
         null, d.p_timestamp, d.order#, o.obj#, d.property
from sys.obj$ o, sys.v$fixed_table po, sys.dependency$ d,
     sys.user$ u
where o.obj# = d.d_obj#
  and o.owner# = u.user#
  and o.status = 1 /* VALID/AUTHORIZED WITHOUT ERRORS */
  and po.object_id = d.p_obj#
  and (o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
       or (o.namespace in (1 /* TABLE/PROCEDURE */,
                           2 /* PACKAGE BODY */)
           and (o.type# in (2 /* TABLE */, 4 /* VIEW */, 9 /* PACKAGE */,
                           13 /* TYPE */)
                or
                o.obj# in (select obj# from sys.objauth$
                           where grantee# in (select kzsrorol
                                              from x$kzsro)
                             and privilege# = 12 /* EXECUTE */)
                or
                exists (select null from sys.sysauth$
                        where grantee# in (select kzsrorol
                                           from x$kzsro)
                             and (o.type# in (7 /* PROCEDURE */,
                                             8 /* FUNCTION */,
                                             11 /* PACKAGE BODY */) and
                                  privilege# = -144 /* EXECUTE ANY PROCEDURE */
                                  )))))
union
select u.name, o.name, o.type#, 'SYS', po.name_kqfp,
         po.type_kqfp, /* Note: currently spec=1 and body=2 */
         null, d.p_timestamp, d.order#, o.obj#, d.property
from sys.obj$ o, sys.x$kqfp po, sys.dependency$ d,
     sys.user$ u
where o.obj# = d.d_obj#
  and o.owner# = u.user#
  and o.status = 1 /* VALID/AUTHORIZED WITHOUT ERRORS */
  and po.kobjn_kqfp = d.p_obj#
  and (o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
       or (o.namespace in (1 /* TABLE/PROCEDURE */,
                           2 /* PACKAGE BODY */)
           and (o.type# in (2 /* TABLE */, 4 /* VIEW */, 9 /* PACKAGE */,
                           13 /* TYPE */)
                or
                o.obj# in (select obj# from sys.objauth$
                           where grantee# in (select kzsrorol
                                              from x$kzsro)
                             and privilege# = 12 /* EXECUTE */)
                or
                exists (select null from sys.sysauth$
                        where grantee# in (select kzsrorol
                                           from x$kzsro)
                             and (o.type# in (7 /* PROCEDURE */,
                                             8 /* FUNCTION */,
                                             11 /* PACKAGE BODY */) and
                                  privilege# = -144 /* EXECUTE ANY PROCEDURE */
                                  )))))
/

