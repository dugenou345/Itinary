create TYPE BODY AVTUNE_LOG_LISTAGGCLOBTYPE IS

  static function ODCIAggregateInitialize(
    actx IN OUT avtune_log_listaggclobtype) return number is
  begin
    actx := avtune_log_listaggclobtype('');
    return ODCIConst.Success;
  end;

  member function ODCIAggregateIterate(
    self IN OUT avtune_log_listaggclobtype,
    nxtval CLOB) return number is
  begin
    if self.val is null then
      self.val := nxtval;
    else
      self.val := self.val || nxtval;
    end if;
    return ODCIConst.Success;
  end;

  member function ODCIAggregateMerge(
    self IN OUT avtune_log_listaggclobtype,
    ctx2 IN avtune_log_listaggclobtype) return number is
  begin
    if self.val is null then
      self.val := ctx2.val;
    else
      self.val := self.val || ctx2.val;
    end if;
    return ODCIConst.Success;
  end;

  member function ODCIAggregateTerminate(
    self IN avtune_log_listaggclobtype,
    ReturnValue OUT CLOB,
    flags IN number) return number is
  begin
    ReturnValue := self.val;
    return ODCIConst.Success;
  end;

END;
/

