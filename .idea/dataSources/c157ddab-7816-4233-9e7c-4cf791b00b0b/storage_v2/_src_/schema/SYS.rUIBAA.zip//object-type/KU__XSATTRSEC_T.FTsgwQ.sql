create type ku$_xsattrsec_t force as object
(
  xdsid         number,
  priv_num      number,
  priv_name     varchar2(128),
  priv_owner    varchar2(128),
  name          varchar(128)
)
not persistable
/

