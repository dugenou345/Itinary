create type       "SYS_YOID0000019474$"              as object( "SYS_NC00001$" NUMBER)
/

