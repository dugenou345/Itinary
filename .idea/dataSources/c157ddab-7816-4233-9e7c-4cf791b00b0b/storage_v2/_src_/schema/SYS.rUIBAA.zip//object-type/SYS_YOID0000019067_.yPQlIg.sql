create type       "SYS_YOID0000019067$"              as object( "SYS_NC00001$" NUMBER)
/

