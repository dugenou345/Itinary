create type ku$_auditp_obj_t force as object (
        ACTION        number,
        audit_obj     ku$_schemaobj_t,              /* object being audited */
        NAME          varchar2(128)
  )
not persistable
/

