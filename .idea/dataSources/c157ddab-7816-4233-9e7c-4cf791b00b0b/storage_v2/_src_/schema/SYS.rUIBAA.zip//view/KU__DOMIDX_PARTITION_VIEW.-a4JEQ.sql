create view KU$_DOMIDX_PARTITION_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, SCHEMA_OBJ, COL_LIST, TS_NAME, BLOCKSIZE, STORAGE, DEFERRED_STG,
             DATAOBJ_NUM, BASE_OBJ_NUM, BASE_OBJ, ANC_OBJ, INDMETHOD_NUM, INDTYPE_NAME, INDTYPE_OWNER, SECOBJS,
             PLSQL_CODE, JIJOIN_TABS, JIJOIN, COLS, PCT_FREE, INITRANS, MAXTRANS, PCT_THRES, TYPE_NUM, FLAGS, FLAGS2,
             PROPERTY, BLEVEL, LEAFCNT, DISTKEY, LBLKKEY, DBLKKEY, CLUFAC, ANALYZETIME, SAMPLESIZE, ROWCNT, INTCOLS,
             DEGREE, INSTANCES, TRUNCCNT, NUMCOLSDEP, NUMKEYCOLS, PART_OBJ, SPARE3, SPARE4, SPARE5, SPARE6, FOR_PKOID,
             FOR_REFPAR, OID_OR_SETID, BASE_PROPERTY, BASE_PROPERTY2, BASE_PROPERTY3, IND_PART, IND_SUBPART,
             TABPART_OBJ_NUM, IND_PART_NAME, ILM_POLICIES)
as
select '1','6',
         i.obj#, value(o),
         cast(multiset(select * from ku$_index_col_view ic
                       where ic.obj_num = i.obj#
                        order by ic.pos_num
                      ) as ku$_index_col_list_t
             ),
         ip.ts_name, ip.blocksize,
         ip.storage, ip.deferred_stg,
         ip.dataobj_num, i.bo#,
         (select value(so) from ku$_schemaobj_view so
          where so.obj_num = i.bo#),
         (select value(ao) from ku$_schemaobj_view ao
          where ao.obj_num = dbms_metadata_util.get_anc(i.bo#,0)),
         i.indmethod#,
         (select o2.name from obj$ o2 where i.indmethod# = o2.obj#),
         (select u2.name from user$ u2
                where u2.user# = (select o3.owner# from obj$ o3
                                        where i.indmethod# = o3.obj#)),
         -- include domain index info if type# = 9 (cooperative index method)
         decode(i.type#, 9,
           cast(multiset(select * from ku$_domidx_2ndtab_view so
                        where so.obj_num=i.obj#
                        ) as ku$_domidx_2ndtab_list_t
                ),
           null),
         decode(i.type#, 9,
           ku$_domidx_plsql_t(
            i.obj#,
            /* modification from ku$_domidx_plsql_view, adding partion name */
            (select
                  sys.dbms_metadata.get_domidx_metadata(
                    o.name, o.owner_name,
                    o2.name, o2.owner_name,
                    ip.ts_num, it.interface_version#,
                       /*0x200=iot di*/
                    DECODE(BITAND (i.property, 512), 512, 64,0)+
                       /* 1 = local */
                    DECODE(BITAND(po.flags, 1), 1, 1, 0) +
                       /* 1 = range, 2 = hash */
                    DECODE(po.parttype, 1, 2, 2, 4, 0),
                    onn.name )
             from ku$_schemaobj_view o2, indtypes$ it
             where i.indmethod# = it.obj#
                   AND o2.obj_num = it.implobj#)),
          null),
         -- include bitmap join index info if this is a bji
         decode(bitand(i.property, 1024), 1024,
           cast(multiset(select * from ku$_jijoin_table_view j
                        where j.obj_num = i.obj#
                        ) as ku$_jijoin_table_list_t
                ),
           null),
         decode(bitand(i.property, 1024), 1024,
           cast(multiset(select * from ku$_jijoin_view j
                        where j.obj_num = i.obj#
                        ) as ku$_jijoin_list_t
                ),
           null),
         i.cols, ip.pct_free,
         ip.initrans, ip.maxtrans, ip.pct_thres, i.type#,
         -- flags here are index flags, but we take UNUSABLE and compression from the
         --  [sub]partition. Perhaps more flags need to be carried over?
         -- unusable             0x00000001
         -- compression enabled  0x00000020
         --       advanced high  0x40000000 1073741824
         --        advanced low  0x80000000 2147483648
         -- Note: 'ip' may be ku$_ind_part_view or ku$_ind_subpart_view
         bitand(i.flags,to_number('3FFFFFDE','XXXXXXXX')) +
          bitand(ip.flags,1) +
          decode(bitand(ip.flags,1024),1024,32,
                 decode(bitand(ip.flags,65536),65536,
                        -- if deferred seg create, compression in .deferred_stg.flags_stg
                        decode(bitand(ip.deferred_stg.flags_stg, 4),4,
                               decode(bitand(ip.deferred_stg.flags_stg, 6),
                                      4, 2147483648,
                                      2, 1073741824,
                                      0),
                               0),
                        -- else, compression in storage.flags (aka, spare1)
                        decode(bitand(ip.storage.flags, 2048),2048,
                               decode(bitand(ip.storage.flags, 16777216 + 1048576),
                                      1048576, 2147483648,
                                      16777216, 1073741824,
                                      0),
                               0))),
         bitand(trunc(i.flags / power(2,32)),  (power(2, 32)-1)),
         -- we clear the 'partitioned' property
         i.property-(bitand(i.property,2)),
         i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac,
         to_char(i.analyzetime,'YYYY/MM/DD HH24:MI:SS'), i.samplesize, i.rowcnt, i.intcols, i.degree,
         i.instances, i.trunccnt, i.spare1, i.spare2,
         NULL, -- part_obj (ind_partobj_t) for partitioned indexes
--         (select value(po) from ku$_ind_partobj_view po
--          where i.obj# = po.obj_num),
         i.spare3, replace(i.spare4, chr(0)), i.spare5, to_char(i.spare6,'YYYY/MM/DD HH24:MI:SS'),
         nvl((select 1 from cdef$ c
              where c.enabled = i.obj# and
                    c.type# = 2 and
                    (select 1 from tab$ t
                     where t.obj# = c.obj# and
                     bitand(t.property, 4096) = 4096) = 1) ,0),
         -- For sharding 'chunk move', constraints are always created with
         -- table creation (constraints are not export3ed as separate objects).
         -- So, any index used for a constraint has already been created
         -- (not just PK constraints for ref partitioning).
         nvl((select 1 from dual where
          (exists (select 1 from cdef$ c
              where c.enabled = i.obj# and
                    c.type# in(2, 3) ))),0),
         nvl((select ic.oid_or_setid from ku$_index_col_view ic
              where i.type#=1
              and i.intcols=1
              and ic.obj_num=i.obj#),0),
          nvl((select bitand(t.property, (power(2, 32)-1))
               from tab$ t where t.obj# = i.bo#),0),
          nvl((select bitand(trunc(t.property / power(2, 32)), (power(2, 32)-1))
               from tab$ t where t.obj# = i.bo#),0),
          nvl((select trunc(t.property / power(2, 64))
               from tab$ t where t.obj# = i.bo#),0),
         value(ip), null, ip.obj_num,onn.name
         , cast( multiset(select * from ku$_ilm_policy_view p
                          where p.obj_num = ip.obj_num
                          order by p.policy_num
                        ) as ku$_ilm_policy_list_t
               )
   from  ku$_schemaobj_view o, ind$ i, ts$ ts, ku$_partobj_view po,
         ku$_ind_part_view ip, TABLE(DBMS_METADATA.FETCH_OBJNUMS_NAMES) onn
   where o.obj_num = i.obj#
         AND i.obj#=po.obj_num
         AND i.obj# = onn.obj_num AND ip.schema_obj.subname = onn.name AND ip.base_obj_num = po.obj_num
         AND  i.ts# = ts.ts#
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles WHERE role='SELECT_CATALOG_ROLE'))
/

