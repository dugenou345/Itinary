create view ALL_TAB_STATISTICS
            (OWNER, TABLE_NAME, PARTITION_NAME, PARTITION_POSITION, SUBPARTITION_NAME, SUBPARTITION_POSITION,
             OBJECT_TYPE, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, AVG_SPACE_FREELIST_BLOCKS,
             NUM_FREELIST_BLOCKS, AVG_CACHED_BLOCKS, AVG_CACHE_HIT_RATIO, IM_IMCU_COUNT, IM_BLOCK_COUNT,
             IM_STAT_UPDATE_TIME, SCAN_RATE, SAMPLE_SIZE, LAST_ANALYZED, GLOBAL_STATS, USER_STATS, STATTYPE_LOCKED,
             STALE_STATS, NOTES, SCOPE)
as
WITH stale_pc as
(select spare4 spc from sys.optstat_hist_control$
   where sname ='STALE_PERCENT'
)
  SELECT /* TABLES */ /*+NO_PARALLEL*/
    u.name, o.name, NULL, NULL, NULL, NULL, 'TABLE', t.rowcnt,
    decode(bitand(t.property, 64), 0, t.blkcnt, TO_NUMBER(NULL)),
    decode(bitand(t.property, 64), 0, t.empcnt, TO_NUMBER(NULL)),
    decode(bitand(t.property, 64), 0, t.avgspc, TO_NUMBER(NULL)),
    t.chncnt, t.avgrln, t.avgspc_flb,
    decode(bitand(t.property, 64), 0, t.flbcnt, TO_NUMBER(NULL)),
    ts.cachedblk, ts.cachehit, ts.im_imcu_count, ts.im_block_count,
    ts.im_stat_update_time, ts.scanrate, t.samplesize, t.analyzetime,
    decode(bitand(t.flags, 512), 0, 'NO', 'YES'),
    decode(bitand(t.flags, 256), 0, 'NO', 'YES'),
    decode(bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728),
           0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL'),
    case
      when t.analyzetime is null then null
      -- 1 represents metadata linked table in root
      -- 5 represents sharded Catalog
      -- for metadata linked table in root or sharded table in coordinator
      -- since the PDB/SHARDS will not actively notify the App Root or
      -- coordinator of their status, the staleness of at the App Root for
      -- metadata linked table or the stats for sharded table in coordinator
      -- is unknown.
      when (dbms_stats_internal.get_tab_share_type_view(o.flags, t.property)
        in (1,5)) then 'UNKNOWN'
      when ((m.inserts + m.deletes + m.updates) >
            to_number(decode(p.valchar, null, (select spc from stale_pc),
                             p.valchar)
                     )/100 * t.rowcnt
           )
      then 'YES'
      else  'NO'
    end,
    NULL,
    'SHARED'
  FROM
    sys.user$ u, sys.obj$ o, sys.tab$ t, sys.tab_stats$ ts, sys.mon_mods_v m,
    sys.optstat_user_prefs$ p
  WHERE
        o.owner# = u.user#
    and o.obj# = t.obj#
    and bitand(t.property, 1) = 0 /* not a typed table */
    and o.obj# = ts.obj# (+)
    and t.obj# = m.obj# (+)
    and t.obj# = p.obj#(+)
    and p.pname(+)='STALE_PERCENT'
    and o.subname IS NULL
    and bitand(o.flags, 128) = 0 -- not in recycle bin
    and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
    and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
    and bitand(o.flags, 131072) = 0 -- not a data link table
  UNION ALL
  SELECT /* PARTITIONS,  NOT IOT */ /*+NO_PARALLEL*/
    u.name, o.name, o.subname, tp.part#, NULL, NULL, 'PARTITION',
    tp.rowcnt, tp.blkcnt, tp.empcnt, tp.avgspc,
    tp.chncnt, tp.avgrln, TO_NUMBER(NULL), TO_NUMBER(NULL),
    ts.cachedblk, ts.cachehit, ts.im_imcu_count, ts.im_block_count,
    ts.im_stat_update_time, ts.scanrate, tp.samplesize, tp.analyzetime,
    decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
    decode(
      /*
       * Following decode returns 1 if DATA stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 67108864) + bitand(tp.flags, 32), 0, 0, 1) +
      /*
       * Following decode returns 2 if CACHE stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 134217728) + bitand(tp.flags, 64), 0, 0, 2),
      /* if 0 => not locked, 3 => data and cache stats locked */
      0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL'),
    case
      when tp.analyzetime is null then null
      when ((m.inserts + m.deletes + m.updates) >
            to_number(decode(p.valchar, null, (select spc from stale_pc),
                             p.valchar)
                     )/100 * tp.rowcnt
           )
      then 'YES'
      else  'NO'
    end,
    NULL,
    'SHARED'
  FROM
    sys.user$ u, sys.obj$ o, sys.tabpartv$ tp, sys.tab_stats$ ts, sys.tab$ tab,
    sys.mon_mods_v m, sys.optstat_user_prefs$ p
  WHERE
        o.owner# = u.user#
    and o.obj# = tp.obj#
    and tp.bo# = tab.obj#
    and bitand(tab.property, 64) = 0
    and o.obj# = ts.obj# (+)
    and tp.obj# = m.obj# (+)
    and p.obj#(+)= tab.obj#
    and p.pname(+)='STALE_PERCENT'
    and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
    and bitand(o.flags, 128) = 0 -- not in recycle bin
    and (o.owner# = userenv('SCHEMAID')
        or tp.bo# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  UNION ALL
  SELECT /* IOT Partitions */ /*+NO_PARALLEL*/
    u.name, o.name, o.subname, tp.part#, NULL, NULL, 'PARTITION',
    tp.rowcnt, TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL),
    tp.chncnt, tp.avgrln, TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL),
    TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL),
    TO_TIMESTAMP(NULL), TO_NUMBER(NULL), tp.samplesize, tp.analyzetime,
    decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
    decode(
      /*
       * Following decode returns 1 if DATA stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 67108864) + bitand(tp.flags, 32), 0, 0, 1) +
      /*
       * Following decode returns 2 if CACHE stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 134217728) + bitand(tp.flags, 64), 0, 0, 2),
      /* if 0 => not locked, 3 => data and cache stats locked */
      0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL'),
    case
      when tp.analyzetime is null then null
      when (
            (m.inserts + m.deletes + m.updates) >
            to_number(decode(p.valchar, null, (select spc from stale_pc),
                             p.valchar)
                     )/100 * tp.rowcnt
           )
      then 'YES'
      else 'NO'
    end,
    NULL,
    'SHARED'
  FROM
    sys.user$ u, sys.obj$ o, sys.tabpartv$ tp, sys.tab$ tab, sys.mon_mods_v m,
    sys.optstat_user_prefs$ p
  WHERE
        o.owner# = u.user#
    and o.obj# = tp.obj#
    and tp.bo# = tab.obj#
    and bitand(tab.property, 64) = 64
    and tp.obj# = m.obj# (+)
    and p.obj#(+)= tab.obj#
    and p.pname(+)='STALE_PERCENT'
    and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
    and bitand(o.flags, 128) = 0 -- not in recycle bin
    and (o.owner# = userenv('SCHEMAID')
        or tp.bo# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  UNION ALL
  SELECT /* COMPOSITE PARTITIONS */ /*+NO_PARALLEL*/
    u.name, o.name, o.subname, tcp.part#, NULL, NULL, 'PARTITION',
    tcp.rowcnt, tcp.blkcnt, tcp.empcnt, tcp.avgspc,
    tcp.chncnt, tcp.avgrln, NULL, NULL, ts.cachedblk, ts.cachehit,
    ts.im_imcu_count, ts.im_block_count,
    ts.im_stat_update_time, ts.scanrate, tcp.samplesize, tcp.analyzetime,
    decode(bitand(tcp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(tcp.flags, 8), 0, 'NO', 'YES'),
    decode(
      /*
       * Following decode returns 1 if DATA stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 67108864) + bitand(tcp.flags, 32), 0, 0, 1) +
      /*
       * Following decode returns 2 if CACHE stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 134217728) + bitand(tcp.flags, 64), 0, 0, 2),
      /* if 0 => not locked, 3 => data and cache stats locked */
      0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL'),
    case
      when tcp.analyzetime is null then null
      when (
            (m.inserts + m.deletes + m.updates) >
            to_number(decode(p.valchar, null, (select spc from stale_pc),
                             p.valchar)
                     )/100 * tcp.rowcnt
           )
      then 'YES'
      else 'NO'
    end,
    NULL,
    'SHARED'
  FROM
    sys.user$ u, sys.obj$ o, sys.tabcompartv$ tcp, sys.tab_stats$ ts,
    sys.tab$ tab, sys.mon_mods_v m, sys.optstat_user_prefs$ p
  WHERE
        o.owner# = u.user#
    and o.obj# = tcp.obj#
    and tcp.bo# = tab.obj#
    and o.obj# = ts.obj# (+)
    and tcp.obj# = m.obj# (+)
    and p.obj#(+)= tab.obj#
    and p.pname(+)='STALE_PERCENT'
    and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
    and bitand(o.flags, 128) = 0 -- not in recycle bin
    and (o.owner# = userenv('SCHEMAID')
        or tcp.bo# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  UNION ALL
  SELECT /* SUBPARTITIONS */ /*+NO_PARALLEL*/
    u.name, po.name, po.subname, tcp.part#,  so.subname, tsp.subpart#,
   'SUBPARTITION', tsp.rowcnt,
    tsp.blkcnt, tsp.empcnt, tsp.avgspc,
    tsp.chncnt, tsp.avgrln, NULL, NULL,
    ts.cachedblk, ts.cachehit, ts.im_imcu_count, ts.im_block_count,
    ts.im_stat_update_time, ts.scanrate, tsp.samplesize, tsp.analyzetime,
    decode(bitand(tsp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(tsp.flags, 8), 0, 'NO', 'YES'),
    decode(
      /*
       * Following decode returns 1 if DATA stats locked for partition
       * or at table level.
       * Note that dbms_stats does n't allow locking subpartition stats.
       * If the composite partition is locked, all subpartitions are
       * considered locked. Hence decode checks for tcp entry.
       */
      decode(bitand(tab.trigflag, 67108864) + bitand(tcp.flags, 32), 0, 0, 1) +
      /*
       * Following decode returns 2 if CACHE stats locked for partition
       * or at table level
       */
      decode(bitand(tab.trigflag, 134217728) + bitand(tcp.flags, 64), 0, 0, 2),
      /* if 0 => not locked, 3 => data and cache stats locked */
      0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL'),
    case
      when tsp.analyzetime is null then null
      when (
            (m.inserts + m.deletes + m.updates) >
            to_number(decode(p.valchar, null, (select spc from stale_pc),
                             p.valchar)
                     )/100 * tsp.rowcnt
           )
      then 'YES'
      else  'NO'
    end,
    NULL,
    'SHARED'
  FROM
    sys.user$ u, sys.obj$ po, sys.obj$ so, sys.tabcompartv$ tcp,
    sys.tabsubpartv$ tsp,  sys.tab_stats$ ts, sys.tab$ tab, sys.mon_mods_v m,
    sys.optstat_user_prefs$ p
  WHERE
        so.obj# = tsp.obj#
    and po.obj# = tcp.obj#
    and tcp.obj# = tsp.pobj#
    and tcp.bo# = tab.obj#
    and u.user# = po.owner#
    and bitand(tab.property, 64) = 0
    and so.obj# = ts.obj# (+)
    and tsp.obj# = m.obj# (+)
    and p.obj#(+)= tab.obj#
    and p.pname(+)='STALE_PERCENT'
    and po.namespace = 1 and po.remoteowner IS NULL and po.linkname IS NULL
    and bitand(po.flags, 128) = 0 -- not in recycle bin
    and (po.owner# = userenv('SCHEMAID')
         or tcp.bo# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
        or /* user has system privileges */
          exists (select null FROM v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -397/* READ ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
       )
  UNION ALL
  SELECT /* FIXED TABLES */ /*+NO_PARALLEL*/
    'SYS', t.kqftanam, NULL, NULL, NULL, NULL, 'FIXED TABLE',
    decode(nvl(fobj.obj#, 0), 0, TO_NUMBER(NULL), st.rowcnt),
    TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL),
    decode(nvl(fobj.obj#, 0), 0, TO_NUMBER(NULL), st.avgrln),
    TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL), TO_NUMBER(NULL),
    TO_NUMBER(NULL), TO_NUMBER(NULL), TO_TIMESTAMP(NULL), TO_NUMBER(NULL),
    decode(nvl(fobj.obj#, 0), 0, TO_NUMBER(NULL), st.samplesize),
    decode(nvl(fobj.obj#, 0), 0, TO_DATE(NULL), st.analyzetime),
    decode(nvl(fobj.obj#, 0), 0, NULL,
           decode(nvl(st.obj#, 0), 0, NULL, 'YES')),
    decode(nvl(fobj.obj#, 0), 0, NULL,
           decode(nvl(st.obj#, 0), 0, NULL,
                  decode(bitand(st.flags, 1), 0, 'NO', 'YES'))),
    decode(nvl(fobj.obj#, 0), 0, NULL,
           decode (bitand(fobj.flags, 67108864) +
                     bitand(fobj.flags, 134217728),
                   0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL')),
    NULL,
    NULL,
    'SHARED'
    FROM sys.x$kqfta t, sys.fixed_obj$ fobj, sys.tab_stats$ st
    where
    t.kqftaobj = fobj.obj#(+)
    /*
     * if fobj and st are not in sync (happens when db open read only
     * after upgrade), do not display stats.
     */
    and t.kqftaver = fobj.timestamp (+) - to_date('01-01-1991', 'DD-MM-YYYY')
    and t.kqftaobj = st.obj#(+)
    and (userenv('SCHEMAID') = 0  /* SYS */
         or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-237 /* SELECT ANY DICTIONARY */)
                 )
        )
  UNION ALL
  SELECT /* session private stats for GTT */ /*+NO_PARALLEL*/
    u.name, o.name, NULL, NULL, NULL, NULL, 'TABLE', ses.rowcnt_kxttst_ts,
    decode(bitand(t.property, 64), 0, ses.blkcnt_kxttst_ts, TO_NUMBER(NULL)),
                                         /* property is 64 when IOT */
    decode(bitand(t.property, 64), 0, ses.empcnt_kxttst_ts, TO_NUMBER(NULL)),
    decode(bitand(t.property, 64), 0, ses.avgspc_kxttst_ts, TO_NUMBER(NULL)),
    ses.chncnt_kxttst_ts, ses.avgrln_kxttst_ts, ses.avgspc_flb_kxttst_ts,
    decode(bitand(t.property, 64), 0, ses.flbcnt_kxttst_ts, TO_NUMBER(NULL)),
    ses.cachedblk_kxttst_ts, ses.cachehit_kxttst_ts, null, null, null, null,
    ses.samplesize_kxttst_ts, ses.analyzetime_kxttst_ts,
    /* kketsflg = 8 (KQLDTVCF_GLS) */
    decode(bitand(ses.flags_kxttst_ts, 8), 0, 'NO', 'YES'),
    /* kketsflg = 4 (KQLDTVCF_USS) */
    decode(bitand(ses.flags_kxttst_ts, 4), 0, 'NO', 'YES'),
    null,  /* no lock on session private stats */
    null,  /* session based dml monitoring not available */
    null,  /* notes */
    'SESSION'
  FROM
    sys.x$kxttstets ses,
    sys.user$ u, sys.obj$ o, sys.tab$ t
  WHERE
        o.owner# = u.user#
    and o.obj# = t.obj#
    and t.obj# = ses.obj#_kxttst_ts
    and bitand(t.property, 1) = 0 /* not a typed table */
    and o.subname IS NULL
    and bitand(o.flags, 128) = 0 -- not in recycle bin
    and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
    and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null FROM v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
  UNION ALL
  SELECT /* Data link table statistics */ /*+NO_PARALLEL*/
    owner, table_name, NULL, NULL, NULL,
    NULL, object_type, num_rows, blocks, empty_blocks,
    avg_space, chain_cnt, avg_row_len, avg_space_freelist_blocks,
    num_freelist_blocks, avg_cached_blocks, avg_cache_hit_ratio, im_imcu_count,
    im_block_count, im_stat_update_time, scan_rate, sample_size, last_analyzed,
    global_stats, user_stats, stattype_locked, stale_stats, null, scope
  FROM INT$DATA_LINK_TAB_STATISTICS
  WHERE (owner = sys_context('USERENV', 'CURRENT_USER')
         or OBJ_ID(owner, table_name, object_type#, object_id) in
            (select oa.obj#
             FROM sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 FROM x$kzsro
                               )
            )
         or /* user has system privileges */
         ora_check_sys_privilege (sys_context('USERENV', 'CURRENT_USERID'),
                                  object_type#) = 1
        )
    and (
         (APPLICATION = 1 and
          (SYS_CONTEXT('USERENV','IS_APPLICATION_ROOT') = 'YES' or
           ORIGIN_CON_ID = CON_NAME_TO_ID(SYS_CONTEXT('USERENV',
                                                      'APPLICATION_NAME'))))
         or
         (APPLICATION = 0 and ORIGIN_CON_ID = 1)
        )
  UNION ALL
  SELECT /* real-time table stats */
         /*+ leading(ts) no_merge(v) use_nl(v) no_parallel*/ v."OWNER",v."NAME",v."PARTITION_NAME",v."PARTITION_POSITION",v."SUBPARTITION_NAME",v."SUBPARTITION_POSITION",v."'TABLE'",v."ROWCNT",v."BLKCNT",v."EMPTY_BLOCKS",v."AVG_SPACE",v."CHAIN_CNT",v."AVG_ROW_LEN",v."AVG_SPACE_FREELIST_BLOCKS",v."NUM_FREELIST_BLOCKS",v."AVG_CACHED_BLOCKS",v."AVG_CACHE_HIT_RATIO",v."IM_IMCU_COUNT",v."IM_BLOCK_COUNT",v."IM_STAT_UPDATE_TIME",v."SCAN_RATE",v."SAMPLE_SIZE",v."LAST_ANALYZED",v."GLOBAL_STATS",v."USER_STATS",v."STATTYPE_LOCKED",v."STALE_STATS",v."NOTES",v."SCOPE"
  FROM sys.ts$ ts,
  (select
    u.name owner, o.name, NULL partition_name, NULL partition_position,
    NULL subpartition_name, NULL subpartition_position,
    'TABLE',
    ht.rowcnt + nvl(t.rowcnt, 0) rowcnt, ht.blkcnt,
    NULL empty_blocks, NULL avg_space, NULL chain_cnt,
    NULL avg_row_len, NULL avg_space_freelist_blocks,
    NULL num_freelist_blocks, NULL avg_cached_blocks,
    NULL avg_cache_hit_ratio, NULL im_imcu_count,
    NULL im_block_count, NULL im_stat_update_time,
    NULL scan_rate, NULL sample_size, ht.analyzetime last_analyzed,
    NULL global_stats, NULL user_stats, NULL stattype_locked, NULL stale_stats,
    'STATS_ON_CONVENTIONAL_DML' notes,'SHARED' scope
   from sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history ht, sys.tab$ t
   where o.obj# = ht.obj#
     and t.obj# = ht.obj#
     and t.analyzetime is not null
     and bitand(t.flags, 512) > 0  -- global stats are analyzed
     and ht.savtime = timestamp '4000-12-01 01:00:00 -0:0'
     and o.owner# = u.user# and o.subname is NULL
     and bitand(o.flags, 128) = 0 -- not in recycle bin
     and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
     and (o.owner# = userenv('SCHEMAID')
        or o.obj# in
             (select oa.obj#
              FROM sys.objauth$ oa
              where grantee# in ( select kzsrorol
                                  FROM x$kzsro
                                )
             )
        or /* user has system privileges */
          exists (select null FROM v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -397/* READ ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
       )) v
-- check whether sysaux is online before querying it to avoid
-- ora-00376
where ts.name = 'SYSAUX' and ts.online$ = 1
/

comment on table ALL_TAB_STATISTICS is 'Optimizer statistics for all tables accessible to the user'
/

comment on column ALL_TAB_STATISTICS.OWNER is 'Owner of the object'
/

comment on column ALL_TAB_STATISTICS.TABLE_NAME is 'Name of the table'
/

comment on column ALL_TAB_STATISTICS.PARTITION_NAME is 'Name of the partition'
/

comment on column ALL_TAB_STATISTICS.PARTITION_POSITION is 'Position of the partition within table'
/

comment on column ALL_TAB_STATISTICS.SUBPARTITION_NAME is 'Name of the subpartition'
/

comment on column ALL_TAB_STATISTICS.SUBPARTITION_POSITION is 'Position of the subpartition within partition'
/

comment on column ALL_TAB_STATISTICS.OBJECT_TYPE is 'Type of the object (TABLE, PARTITION, SUBPARTITION)'
/

comment on column ALL_TAB_STATISTICS.NUM_ROWS is 'The number of rows in the object'
/

comment on column ALL_TAB_STATISTICS.BLOCKS is 'The number of used blocks in the object'
/

comment on column ALL_TAB_STATISTICS.EMPTY_BLOCKS is 'The number of empty blocks in the object'
/

comment on column ALL_TAB_STATISTICS.AVG_SPACE is 'The average available free space in the object'
/

comment on column ALL_TAB_STATISTICS.CHAIN_CNT is 'The number of chained rows in the object'
/

comment on column ALL_TAB_STATISTICS.AVG_ROW_LEN is 'The average row length, including row overhead'
/

comment on column ALL_TAB_STATISTICS.AVG_SPACE_FREELIST_BLOCKS is 'The average freespace of all blocks on a freelist'
/

comment on column ALL_TAB_STATISTICS.NUM_FREELIST_BLOCKS is 'The number of blocks on the freelist'
/

comment on column ALL_TAB_STATISTICS.AVG_CACHED_BLOCKS is 'Average number of blocks in buffer cache'
/

comment on column ALL_TAB_STATISTICS.AVG_CACHE_HIT_RATIO is 'Average cache hit ratio for the object'
/

comment on column ALL_TAB_STATISTICS.IM_IMCU_COUNT is 'Number of IMCUs in the object'
/

comment on column ALL_TAB_STATISTICS.IM_BLOCK_COUNT is 'Number of inmemory blocks in the object'
/

comment on column ALL_TAB_STATISTICS.IM_STAT_UPDATE_TIME is 'The timestamp of the most recent update to the inmemory statistics'
/

comment on column ALL_TAB_STATISTICS.SCAN_RATE is 'Scan rate for the object'
/

comment on column ALL_TAB_STATISTICS.SAMPLE_SIZE is 'The sample size used in analyzing this table'
/

comment on column ALL_TAB_STATISTICS.LAST_ANALYZED is 'The date of the most recent time this table was analyzed'
/

comment on column ALL_TAB_STATISTICS.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column ALL_TAB_STATISTICS.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column ALL_TAB_STATISTICS.STATTYPE_LOCKED is 'type of statistics lock'
/

comment on column ALL_TAB_STATISTICS.STALE_STATS is 'Whether statistics for the object is stale or not'
/

comment on column ALL_TAB_STATISTICS.NOTES is 'Notes regarding special properties of the stats'
/

comment on column ALL_TAB_STATISTICS.SCOPE is 'whether statistics for the object is shared or session'
/

