create view USER_XML_TAB_COLS
            (TABLE_NAME, COLUMN_NAME, XMLSCHEMA, SCHEMA_OWNER, ELEMENT_NAME, STORAGE_TYPE, ANYSCHEMA, NONSCHEMA,
             TOKENSETS) as
select o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),null, null, null,
   case when bitand(opq.flags,69) = 1 then 'OBJECT-RELATIONAL'
        when bitand(opq.flags,131140) = 131140 then 'TRANSPORTABLE BINARY'
        when bitand(opq.flags,69) = 68 then 'BINARY'
   else 'CLOB' end,
   case when bitand(opq.flags,69) = 68 then
       case when bitand(opq.flags,128) = 128 then 'YES' else 'NO' end
   else NULL end,
   case when bitand(opq.flags,69) = 68  then
       case when bitand(opq.flags,256) = 256 then 'NO' else 'YES' end
   else NULL end, null
from  sys.opqtype$ opq,
      sys.tab$ t, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr
where o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
  and t.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and bitand(tc.property, 512) = 0
  and bitand(opq.flags,2) = 0
  and (bitand(t.property, power(2,64)) = 0
       or bitand(opq.flags,69) != 68)
  union all
 select o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),
   schm.xmldata.schema_url, schm.xmldata.schema_owner,
decode(xel.xmldata.property.name, null,
        xel.xmldata.property.propref_name.name, xel.xmldata.property.name),
    case when bitand(opq.flags,69) = 1 then 'OBJECT-RELATIONAL'
         when bitand(opq.flags,131140) = 131140 then 'TRANSPORTABLE BINARY'
         when bitand(opq.flags,69) = 68 then 'BINARY'
    else 'CLOB' end,
    case when bitand(opq.flags,69) = 68 then
        case when bitand(opq.flags,128) = 128 then 'YES' else 'NO' end
    else NULL end,
    case when bitand(opq.flags,69) = 68  then
        case when bitand(opq.flags,256) = 256 then 'NO' else 'YES' end
    else NULL end, null
 from xdb.xdb$element xel, xdb.xdb$schema schm, sys.opqtype$ opq,
      sys.tab$ t, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr
 where o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
  and t.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and bitand(tc.property, 512) = 0
  and bitand(opq.flags,2) = 2
  and opq.schemaoid =  schm.sys_nc_oid$
  and opq.elemnum =  xel.xmldata.property.prop_number
  and (bitand(t.property, power(2,64)) = 0
       or bitand(opq.flags,69) != 68)
  union all
 select o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),null, null, null,
   case when bitand(opq.flags,69) = 1 then 'OBJECT-RELATIONAL'
        when bitand(opq.flags,131140) = 131140 then 'TRANSPORTABLE BINARY'
        when bitand(opq.flags,69) = 68 then 'BINARY'
   else 'CLOB' end,
   case when bitand(opq.flags,69) = 68 then
       case when bitand(opq.flags,128) = 128 then 'YES' else 'NO' end
   else NULL end,
   case when bitand(opq.flags,69) = 68  then
       case when bitand(opq.flags,256) = 256 then 'NO' else 'YES' end
   else NULL end, tm.tokensets
from  sys.opqtype$ opq,
      sys.tab$ t, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr, (select tmap.guid as guid,
              LISTAGG(ob.name, ',') within group (order by ob.name)
                as tokensets
        from sys.obj$ ob, xdb.xdb$tsetmap tmap
        where tmap.obj#=ob.obj#
        group by tmap.guid) tm, xdb.xdb$ttset ts
where o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
  and t.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and bitand(tc.property, 512) = 0
  and bitand(opq.flags,2) = 0
  and ts.guid=tm.guid
  and ts.obj#=o.obj#
  and bitand(t.property, power(2,64)) = power(2,64)
  and bitand(opq.flags,69) = 68
  union all
 select o.name,
   decode(bitand(tc.property, 1), 1, attr.name, tc.name),
   schm.xmldata.schema_url, schm.xmldata.schema_owner,
decode(xel.xmldata.property.name, null,
        xel.xmldata.property.propref_name.name, xel.xmldata.property.name),
    case when bitand(opq.flags,69) = 1 then 'OBJECT-RELATIONAL'
         when bitand(opq.flags,131140) = 131140 then 'TRANSPORTABLE BINARY'
         when bitand(opq.flags,69) = 68 then 'BINARY'
    else 'CLOB' end,
    case when bitand(opq.flags,69) = 68 then
        case when bitand(opq.flags,128) = 128 then 'YES' else 'NO' end
    else NULL end,
    case when bitand(opq.flags,69) = 68  then
        case when bitand(opq.flags,256) = 256 then 'NO' else 'YES' end
    else NULL end, tm.tokensets
 from xdb.xdb$element xel, xdb.xdb$schema schm, sys.opqtype$ opq,
      sys.tab$ t, sys.obj$ o, sys.coltype$ ac, sys.col$ tc,
      sys.attrcol$ attr, (select tmap.guid as guid,
              LISTAGG(ob.name, ',') within group (order by ob.name)
                as tokensets
        from sys.obj$ ob, xdb.xdb$tsetmap tmap
        where tmap.obj#=ob.obj#
        group by tmap.guid) tm, xdb.xdb$ttset ts
 where o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
  and t.obj# = tc.obj#
  and tc.obj# = ac.obj#
  and tc.intcol# = ac.intcol#
  and ac.toid = '00000000000000000000000000020100'
  and tc.intcol# =  opq.intcol#
  and tc.obj# =  opq.obj#
  and tc.obj#    = attr.obj#(+)
  and tc.intcol# = attr.intcol#(+)
  and bitand(tc.property, 512) = 0
  and bitand(opq.flags,2) = 2
  and bitand(t.property, power(2,64)) = power(2,64)
  and bitand(opq.flags,69) = 68
  and ts.guid=tm.guid
  and ts.obj#=o.obj#
  and opq.schemaoid =  schm.sys_nc_oid$
  and opq.elemnum =  xel.xmldata.property.prop_number
/

comment on table USER_XML_TAB_COLS is 'Description of the user''s own XMLType tables'
/

comment on column USER_XML_TAB_COLS.TABLE_NAME is 'Name of the XMLType table'
/

comment on column USER_XML_TAB_COLS.XMLSCHEMA is 'Name of the XMLSchema that is used for the table definition'
/

comment on column USER_XML_TAB_COLS.SCHEMA_OWNER is 'Name of the owner of the XMLSchema used for table definition'
/

comment on column USER_XML_TAB_COLS.ELEMENT_NAME is 'Name XMLSChema element that is used for the table'
/

comment on column USER_XML_TAB_COLS.STORAGE_TYPE is 'Type of storage option for the XMLtype data'
/

comment on column USER_XML_TAB_COLS.ANYSCHEMA is 'If storage is BINARY, does this column allow ANYSCHEMA?'
/

comment on column USER_XML_TAB_COLS.NONSCHEMA is 'If storage is BINARY, does this column allow NONSCHEMA?'
/

