create package jvmrjbc as -- this package is definers
function init return VARCHAR2;
procedure putpath(sessid VARCHAR2, pathname VARCHAR2);
function getlob(sessid VARCHAR2) return BLOB;
function getpath(sessid VARCHAR2) return VARCHAR2;
procedure putlob(sessid VARCHAR2, l BLOB);
procedure done(sessid VARCHAR2);
end jvmrjbc;
/

