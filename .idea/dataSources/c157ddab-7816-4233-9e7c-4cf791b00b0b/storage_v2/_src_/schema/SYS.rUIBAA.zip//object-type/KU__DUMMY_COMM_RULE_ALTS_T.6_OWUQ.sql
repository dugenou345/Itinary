create type ku$_dummy_comm_rule_alts_t force as object
(
  vers_major      char(1),                           /* UDT major version # */
  vers_minor      char(1),                           /* UDT minor version # */
  rule_set_name   varchar2(90)                          /* name of Rule Set */
)
not persistable
/

