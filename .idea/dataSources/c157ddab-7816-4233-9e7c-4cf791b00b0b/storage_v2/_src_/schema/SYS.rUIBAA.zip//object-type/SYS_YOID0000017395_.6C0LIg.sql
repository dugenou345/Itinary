create type       "SYS_YOID0000017395$"              as object( "SYS_NC00001$" NUMBER)
/

