create type ku$_indarraytype_t force as object
(
  obj_num       number,                                 /* obj# of indextype */
  type_num      number,                       /* data type of indexed column */
                                           /* for ADT column, type# = DTYADT */
  basetype_obj  ku$_schemaobj_t,                        /* user-defined type */
  arraytype_obj ku$_schemaobj_t                           /* collection type */
)
not persistable
/

