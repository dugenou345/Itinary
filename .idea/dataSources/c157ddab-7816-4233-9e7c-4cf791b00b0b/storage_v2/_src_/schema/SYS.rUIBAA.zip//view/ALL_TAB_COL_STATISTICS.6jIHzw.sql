create view ALL_TAB_COL_STATISTICS
            (OWNER, TABLE_NAME, COLUMN_NAME, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE, DENSITY, NUM_NULLS, NUM_BUCKETS,
             LAST_ANALYZED, SAMPLE_SIZE, GLOBAL_STATS, USER_STATS, NOTES, AVG_COL_LEN, HISTOGRAM, SCOPE)
as
select /*+ leading(ts) no_merge(v) use_nl(v) */v."OWNER",v."TABLE_NAME",v."COLUMN_NAME",v."NUM_DISTINCT",v."LOW_VALUE",v."HIGH_VALUE",v."DENSITY",v."NUM_NULLS",v."NUM_BUCKETS",v."LAST_ANALYZED",v."SAMPLE_SIZE",v."GLOBAL_STATS",v."USER_STATS",v."NOTES",v."AVG_COL_LEN",v."HISTOGRAM",v."'SHARED'"
from sys.ts$ ts,
     (select
       owner, table_name, column_name, num_distinct, low_value, high_value,
       density, num_nulls, num_buckets, last_analyzed, sample_size,
       global_stats,
       user_stats,
       notes || case when (hh.analyzetime is not null) then
                  decode(hh.spare1, null, ' ADAPTIVE_SAMPLING ',
                         ' HYPERLOGLOG ')
                else
                  null
                end notes,
       avg_col_len, HISTOGRAM, 'SHARED'
     from all_tab_cols_v$ v, sys.wri$_optstat_synopsis_head$  hh
     where last_analyzed is not null
       and v.column_int_id = hh.intcol#(+) and v.table_id = hh.bo#(+)
       and hh.group#(+) = 0) v
-- check whether sysaux is online before querying it to avoid
-- ora-00376
where ts.name = 'SYSAUX' and ts.online$ = 1
union all
select /* fixed table column stats */
       'SYS', ft.kqftanam, c.kqfconam,
       h.distcnt, h.lowval, h.hival,
       h.density, h.null_cnt,
       case when nvl(h.distcnt,0) = 0 then h.distcnt
            when h.row_cnt = 0 then 1
	    when exists(select 1 from sys.histgrm$ hg
                        where c.kqfcotob = hg.obj# and c.kqfcocno = hg.intcol#
                          and hg.ep_repeat_count > 0 and rownum < 2) then h.row_cnt
             when (bitand(h.spare2, 32) > 0 or h.bucket_cnt > 2049 or
                   (h.bucket_cnt >= h.distcnt and h.density*h.bucket_cnt < 1))
                then h.row_cnt
            else h.bucket_cnt
       end,
       h.timestamp#, h.sample_size,
       decode(bitand(h.spare2, 2), 2, 'YES', 'NO'),
       decode(bitand(h.spare2, 1), 1, 'YES', 'NO'),
       null,  -- notes
       h.avgcln,
       case when nvl(h.row_cnt,0) = 0 then 'NONE'
            when exists(select 1 from sys.histgrm$ hg
                        where c.kqfcotob = hg.obj# and c.kqfcocno = hg.intcol#
                          and hg.ep_repeat_count > 0 and rownum < 2) then 'HYBRID'
             when (bitand(h.spare2, 32) > 0 or h.bucket_cnt > 2049 or
                   (h.bucket_cnt >= h.distcnt and h.density*h.bucket_cnt < 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end,
       'SHARED'
from   sys.x$kqfta ft, sys.fixed_obj$ fobj,
         sys.x$kqfco c, sys.hist_head$ h
where
       ft.kqftaobj = fobj. obj#
       and c.kqfcotob = ft.kqftaobj
       and h.obj# = ft.kqftaobj
       and h.intcol# = c.kqfcocno
       /*
        * if fobj and st are not in sync (happens when db open read only
        * after upgrade), do not display stats.
        */
       and ft.kqftaver =
             fobj.timestamp - to_date('01-01-1991', 'DD-MM-YYYY')
       and h.timestamp# is not null
       and (userenv('SCHEMAID') = 0  /* SYS */
            or /* user has system privileges */
            exists (select null from v$enabledprivs
                    where priv_number in (-237 /* SELECT ANY DICTIONARY */)
                   )
           )
UNION ALL
select /* session private stats for GTT */
       u.name                  owner,
       o.name                  table_name,
       c.name                  column_name,
       h.distcnt_kxttst_cs     num_distinct,
       case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
            then h.lowval_kxttst_cs
            else null
       end low_value,
       case when SYS_OP_DV_CHECK(o.name, o.owner#) = 1
            then h.hival_kxttst_cs
            else null
       end hi_value,
       h.density_kxttst_cs     density,
       h.null_cnt_kxttst_cs    num_nulls,
       case when nvl(h.distcnt_kxttst_cs,0) = 0 then h.distcnt_kxttst_cs
            when h.row_cnt_kxttst_cs = 0 then 1
            when exists(select 1 from sys.x$kxttstehs hg
                        where c.obj# = hg.obj#_kxttst_hs
                          and c.intcol# = hg.intcol#_kxttst_hs
                          and hg.ep_repeat_count_kxttst_hs > 0
                          and rownum < 2)
                 then h.row_cnt_kxttst_cs
            when bitand(h.spare2_kxttst_cs, 64) > 0
                then h.row_cnt_kxttst_cs
	    when (bitand(h.spare2_kxttst_cs, 32) > 0 or
                  h.bucket_cnt_kxttst_cs > 2049 or
                  (h.bucket_cnt_kxttst_cs > h.distcnt_kxttst_cs
                   and h.row_cnt_kxttst_cs = h.distcnt_kxttst_cs
                   and h.density_kxttst_cs*h.bucket_cnt_kxttst_cs < 1))
                then h.row_cnt_kxttst_cs
            else h.bucket_cnt_kxttst_cs
       end num_buckets,
       h.timestamp#_kxttst_cs  last_analyzed,
       h.sample_size_kxttst_cs sample_size,
       decode(bitand(h.spare2_kxttst_cs, 2), 2, 'YES', 'NO') global_stats,
       decode(bitand(h.spare2_kxttst_cs, 1), 1, 'YES', 'NO') user_stats,
       null, -- notes
       h.avgcln_kxttst_cs      avg_col_len,
       case when nvl(h.row_cnt_kxttst_cs,0) = 0 then 'NONE'
            when exists(select 1 from sys.x$kxttstehs hg
                        where c.obj# = hg.obj#_kxttst_hs
                          and c.intcol# = hg.intcol#_kxttst_hs
                          and hg.ep_repeat_count_kxttst_hs > 0
                          and rownum < 2) then 'HYBRID'
            when bitand(h.spare2_kxttst_cs, 64) > 0
              then 'TOP-FREQUENCY'
            when (bitand(h.spare2_kxttst_cs, 32) > 0 or
                  h.bucket_cnt_kxttst_cs > 2049 or
                  (h.bucket_cnt_kxttst_cs >= h.distcnt_kxttst_cs
                   and h.density_kxttst_cs*h.bucket_cnt_kxttst_cs < 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end,
       'SESSION'               scope
from x$kxttstecs h, obj$ o, col$ c, user$ u, all_tables t
where h.obj#_kxttst_cs = o.obj# and
      o.owner# = u.user# and
      o.name = t.table_name and
      u.name = t.owner and
      c.obj# = o.obj# and
      h.intcol#_kxttst_cs = c.intcol#
UNION ALL
select /*+ leading(ts) no_merge(v) use_nl(v) *//* real-time min, max */ v."OWNER",v."TABLE_NAME",v."COLUMN_NAME",v."NUM_DISTINCT",v."LOW_VALUE",v."HI_VALUE",v."DENSITY",v."NUM_NULLS",v."NUM_BUCKETS",v."LAST_ANAYLZED",v."SAMPLE_SIZE",v."GLOBAL_STATS",v."USER_STATS",v."NOTES",v."AVG_COL_LEN",v."HISTOGRAM",v."'SHARED'"
from sys.ts$ ts,
    (select
       owner, table_name, column_name, ht.distcnt num_distinct,
       case when SYS_OP_DV_CHECK(v.table_name, v.owner_id) = 1
            then least(coalesce(v.low_value, ht.lowval, xs.lowval),
                       coalesce(ht.lowval, xs.lowval, v.low_value),
                       coalesce(xs.lowval, v.low_value, ht.lowval))
            else null
       end low_value,
       case when SYS_OP_DV_CHECK(v.table_name, v.owner_id) = 1
            then greatest(coalesce(v.high_value, ht.hival, xs.hival),
                          coalesce(ht.hival, xs.hival, v.high_value),
                          coalesce(xs.hival, v.high_value, ht.hival))
            else null
       end hi_value,
       null density,
       -- optimizer does not use num_nulls in SGA
       nvl(ht.null_cnt,0) + nvl(v.num_nulls,0) num_nulls, null num_buckets,
       nvl(ht.timestamp#, systimestamp) last_anaylzed,
       nvl(ht.sample_size, 0) + nvl(xs.samplesize, 0) sample_size,
       null global_stats, null user_stats,
       'STATS_ON_CONVENTIONAL_DML' notes,
       -- show the avgcln of conventional DML only
       -- ht.spare1 and xs.scalednonnulcnt store the scaled nonnullcnt
       -- ht.avgcln is sum(opncvl)/ssz, xs.scaledtotcln is sum(opncvl)
       ceil((nvl(ht.avgcln*ht.spare1,0)+nvl(xs.scaledtotcln,0)) /
       greatest(nvl(ht.spare1,0)+nvl(xs.scalednonnulcnt,0), 1)) avg_col_len,
       null HISTOGRAM, 'SHARED'
     from all_tab_cols_v$ v, sys.wri$_optstat_histhead_history ht,
          sys.x$ksxmcolst xs
     where v.column_int_id = ht.intcol#(+) and v.table_id = ht.obj#(+)
       and ht.savtime(+) = timestamp '4000-12-01 01:00:00 -0:0'
       and v.last_analyzed is not null
       and v.global_stats = 'YES'
       and v.column_int_id = xs.icol(+) and v.table_id = xs.objn(+)
       and not (xs.objn is null and ht.obj# is null)) v
-- check whether sysaux is online before querying it to avoid
-- ora-00376
where ts.name = 'SYSAUX' and ts.online$ = 1
/

comment on table ALL_TAB_COL_STATISTICS is 'Columns of user''s tables, views and clusters'
/

comment on column ALL_TAB_COL_STATISTICS.OWNER is 'Table, view or cluster owner'
/

comment on column ALL_TAB_COL_STATISTICS.TABLE_NAME is 'Table, view or cluster name'
/

comment on column ALL_TAB_COL_STATISTICS.COLUMN_NAME is 'Column name'
/

comment on column ALL_TAB_COL_STATISTICS.NUM_DISTINCT is 'The number of distinct values in the column'
/

comment on column ALL_TAB_COL_STATISTICS.LOW_VALUE is 'The low value in the column'
/

comment on column ALL_TAB_COL_STATISTICS.HIGH_VALUE is 'The high value in the column'
/

comment on column ALL_TAB_COL_STATISTICS.DENSITY is 'The density of the column'
/

comment on column ALL_TAB_COL_STATISTICS.NUM_NULLS is 'The number of nulls in the column'
/

comment on column ALL_TAB_COL_STATISTICS.NUM_BUCKETS is 'The number of buckets in histogram for the column'
/

comment on column ALL_TAB_COL_STATISTICS.LAST_ANALYZED is 'The date of the most recent time this column was analyzed'
/

comment on column ALL_TAB_COL_STATISTICS.SAMPLE_SIZE is 'The sample size used in analyzing this column'
/

comment on column ALL_TAB_COL_STATISTICS.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column ALL_TAB_COL_STATISTICS.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column ALL_TAB_COL_STATISTICS.NOTES is 'Notes regarding special properties of the stats'
/

comment on column ALL_TAB_COL_STATISTICS.AVG_COL_LEN is 'The average length of the column in bytes'
/

comment on column ALL_TAB_COL_STATISTICS.SCOPE is 'whether statistics for the object is shared or session'
/

