create TYPE ODCIFuncInfo FORCE
                                         AS OBJECT
(
  ObjectSchema    VARCHAR2(130),
  ObjectName      VARCHAR2(130),
  MethodName      VARCHAR2(130),
  Flags           NUMBER
);
/

