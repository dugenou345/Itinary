create view MDX_ODBO_MEASURES
            (CATALOG_NAME, SCHEMA_NAME, CUBE_NAME, MEASURE_NAME, MEASURE_UNIQUE_NAME, MEASURE_CAPTION, MEASURE_GUID,
             MEASURE_AGGREGATOR, DATA_TYPE, NUMERIC_PRECISION, NUMERIC_SCALE, MEASURE_UNITS, DESCRIPTION, EXPRESSION,
             MEASURE_IS_VISIBLE, LEVELS_LIST, MEASURE_NAME_SQL_COLUMN_NAME, MEASURE_UNQUALIFIED_CAPTION,
             MEASUREGROUP_NAME, MEASURE_DISPLAY_FOLDER, DEFAULT_FORMAT_STRING)
as
(
SELECT
  schema_name CATALOG_NAME,
  SCHEMA_NAME,
  CUBE_NAME,
  MEASURE_NAME,
  CAST(MEASURE_UNIQUE_NAME AS VARCHAR2(4000)) MEASURE_UNIQUE_NAME,
  MEASURE_CAPTION,
  NULL MEASURE_GUID,     /* not supported by this schema rowset, set to NULL */
  MEASURE_AGGREGATOR,
  DATA_TYPE,
  decode(data_type, 139, nvl(numeric_precision, 38), numeric_precision)
    NUMERIC_PRECISION,
  decode(data_type, 139, nvl2(numeric_precision, nvl(numeric_scale, 0), 127),
    numeric_scale) NUMERIC_SCALE,
  NULL MEASURE_UNITS,
  DESCRIPTION,
  NULL EXPRESSION,       /* not supported by this schema rowset, set to NULL */
  MEASURE_IS_VISIBLE,
  NULL LEVELS_LIST,      /* not supported by this schema rowset, set to NULL */
  NULL MEASURE_NAME_SQL_COLUMN_NAME, /* not supported by schema rowset, NULL */
  NULL MEASURE_UNQUALIFIED_CAPTION,  /* not supported by schema rowset, NULL */
  NULL MEASUREGROUP_NAME,    /* not supported by  schema rowset, set to NULL */
  NULL MEASURE_DISPLAY_FOLDER,
  NULL DEFAULT_FORMAT_STRING
FROM (
  SELECT
  av.owner SCHEMA_NAME,
  av.analytic_view_name CUBE_NAME,
  avm.measure_name MEASURE_NAME,
  dbms_mdx_odbo.mdx_component_id(NVL(mdname.value, 'MEASURES'),
    NVL(mdhiername.value, 'MEASURES'), NVL(mdlvlname.value, 'MEASURES'))
    || '.&[' || avm.measure_name || ']' MEASURE_UNIQUE_NAME,
  NVL(avmc_cap_l.value, NVL(avmc_cap_n.value, avm.measure_name)) MEASURE_CAPTION,
  /*  To do: Hard code to MDMEASURE_AGGR_SUM for now    */
  dbms_mdx_odbo.mdx_measure_aggregator('MDMEASURE_AGGR_SUM') MEASURE_AGGREGATOR,
  /*  Get from classifications and then translate to MS format  */
-- Will need to figure out where to get agg method from in the metadata
--CASE avm.agg_method
--  WHEN 'SUM' THEN  sys.dbms_mdx_odbo.mdx_measure_aggregator('MDMEASURE_AGGR_SUM')
--  WHEN 'MAX' THEN sys.dbms_mdx_odbo.mdx_measure_aggregator('MDMEASURE_AGGR_MAX')
--  ...
--  ...
--  ELSE NULL
--END MEASURE_AGGREGATOR,
--
--  MDMEASURE_AGGR_SUM (1) identifies that the measure aggregates from SUM.
--  MDMEASURE_AGGR_COUNT (2) identifies that the measure aggregates from COUNT.
--  MDMEASURE_AGGR_MIN (3) identifies that the measure aggregates from MIN.
--  MDMEASURE_AGGR_MAX (4) identifies that the measure aggregates from MAX.
--  MDMEASURE_AGGR_AVG (5) identifies that the measure aggregates from AVG.
--  MDMEASURE_AGGR_VAR (6) identifies that the measure aggregates from VAR.
--  MDMEASURE_AGGR_STD (7) identifies that the measure aggregates from STDEV.
--  MDMEASURE_AGGR_DST (8) identifies that the measure aggregates from DISTINCT COUNT.
--  MDMEASURE_AGGR_NONE (9) identifies that the measure aggregates from NONE.
--  MDMEASURE_AGGR_AVGCHILDREN (10) identifies that the measure aggregates from AVERAGEOFCHILDREN.
--  MDMEASURE_AGGR_FIRSTCHILD (11) identifies that the measure aggregates from FIRSTCHILD.
--  MDMEASURE_AGGR_LASTCHILD (12) identifies that the measure aggregates from LASTCHILD.
--  MDMEASURE_AGGR_FIRSTNONEMPTY (13) identifies that the measure aggregates from FIRSTNONEMPTY,
--  MDMEASURE_AGGR_LASTNONEMPTY (14) identifies that the measure aggregates from LASTNONEMPTY.
--  MDMEASURE_AGGR_BYACCOUNT (15) identifies that the measure aggregates from BYACCOUNT.
--    MDMEASURE_AGGR_CALCULATED (127) identifies that the measure was derived from a formula that was not any single function above.
--  MDMEASURE_AGGR_UNKNOWN (0) identifies that the measure was derived from an unknown aggregation function or formula.
/*  To do:  Need to determine correct datatype along with precision and scale.  Hard coded for now to Number = 139 */
--  CASE avm.datatype
--    WHEN 'DECMAL' THEN sys.dbms_mdx_odbo.mdx_measure_aggregator('DBTYPE_DECIMAL')
--    WHEN 'DATE' THEN sys.dbms_mdx_odbo.mdx_measure_aggregator('DBTYPE_DATE')
--    ...
--    ...
--    ELSE NULL
--  END DATA_TYPE,
  /*  Setting datatype to number since all_analytic_view_columns does not
      have this data right now  */
  dbms_mdx_odbo.mdx_datatype(avm.data_type) DATA_TYPE,
  /*  Setting precision and scale to 20,2 since all_analytic_view_columns
      does not have this data right now */
  avm.data_precision NUMERIC_PRECISION,
  avm.data_scale NUMERIC_SCALE,
  NULL MEASURE_UNITS,
  NVL(avmc_desc_l.value, NVL(avmc_desc_n.value, avm.measure_name)) DESCRIPTION,
  1 MEASURE_IS_VISIBLE,
  NULL MEASURE_DISPLAY_FOLDER,
  /*  To DO:  Need to set default format string.   It is found in the
      all_analytic_view_meas_class view */
  NULL DEFAULT_FORMAT_STRING
FROM all_analytic_views av,
     (select owner, analytic_view_name, column_name measure_name,
      data_type, data_precision, data_scale from all_analytic_view_columns
      where role = 'BASE' or role = 'CALC')
      avm,
     v$nls_parameters nls,
     all_analytic_view_meas_class avmc_cap_l,
     all_analytic_view_meas_class avmc_cap_n,
     all_analytic_view_meas_class avmc_desc_l,
     all_analytic_view_meas_class avmc_desc_n,
     all_analytic_view_class mdname,
     all_analytic_view_class mdhiername,
     all_analytic_view_class mdlvlname,
     all_objects ao
WHERE nls.parameter = 'NLS_LANGUAGE' AND
      av.owner (+)= avm.owner AND
      av.analytic_view_name (+)= avm.analytic_view_name AND
      avmc_cap_l.owner (+)= avm.owner AND
      avmc_cap_l.analytic_view_name (+)= avm.analytic_view_name AND
      avmc_cap_l.measure_name (+)= avm.measure_name AND
      avmc_cap_l.classification (+)= 'CAPTION' AND
      avmc_cap_l.language (+)= nls.value AND
      avmc_cap_n.owner (+)= avm.owner AND
      avmc_cap_n.analytic_view_name (+)= avm.analytic_view_name AND
      avmc_cap_n.measure_name (+)= avm.measure_name AND
      avmc_cap_n.classification (+)= 'CAPTION' AND
      avmc_cap_n.language (+) IS NULL AND
      avmc_desc_l.owner (+)= avm.owner AND
      avmc_desc_l.analytic_view_name (+)= avm.analytic_view_name AND
      avmc_desc_l.measure_name (+)= avm.measure_name AND
      avmc_desc_l.classification (+)= 'DESCRIPTION' AND
      avmc_desc_l.language (+)= nls.value AND
      avmc_desc_n.owner (+)= avm.owner AND
      avmc_desc_n.analytic_view_name (+)= avm.analytic_view_name AND
      avmc_desc_n.measure_name (+)= avm.measure_name AND
      avmc_desc_n.classification (+)= 'DESCRIPTION' AND
      avmc_desc_n.language (+) IS NULL AND
      mdname.owner (+)= av.owner AND
      mdname.analytic_view_name (+)= av.analytic_view_name AND
      mdname.classification (+)= 'MEAS_DIM_NAME' AND
      mdhiername.owner (+)= av.owner AND
      mdhiername.analytic_view_name (+)= av.analytic_view_name AND
      mdhiername.classification (+)= 'MEAS_DIM_HIER_NAME' AND
      mdlvlname.owner (+)= av.owner AND
      mdlvlname.analytic_view_name (+)= av.analytic_view_name AND
      mdlvlname.classification (+)= 'MEAS_DIM_HIER_LVL_NAME' AND
      ao.owner = av.owner AND
      ao.object_name = av.analytic_view_name AND
      ao.object_type = 'ANALYTIC VIEW' AND
      ao.status = 'VALID'
))
/

