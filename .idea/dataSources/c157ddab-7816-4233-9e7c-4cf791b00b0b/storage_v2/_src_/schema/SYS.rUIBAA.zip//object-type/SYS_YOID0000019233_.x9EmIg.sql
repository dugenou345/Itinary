create type       "SYS_YOID0000019233$"              as object( "SYS_NC00001$" NUMBER)
/

