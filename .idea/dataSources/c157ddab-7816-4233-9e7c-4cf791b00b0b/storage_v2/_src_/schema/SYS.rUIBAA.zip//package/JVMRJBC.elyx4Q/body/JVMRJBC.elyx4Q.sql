create package body jvmrjbc as
function init return VARCHAR2 as
  sessid VARCHAR2(100);
begin
  loop
    begin
      sessid := dbms_pipe.unique_session_name||dbms_crypto.randombytes(35);
      insert into java$jvm$rjbc values (sessid, null, empty_blob);
      commit;
      return sessid;
    exception when others then
      if sqlcode not in (-1) then raise; end if;
    end;
  end loop;
end;

procedure putpath(sessid VARCHAR2, pathname VARCHAR2) as
begin
    update java$jvm$rjbc set path=pathname where id=sessid;
    commit;
end;

function getlob(sessid VARCHAR2) return BLOB as
      lob BLOB;
begin -- this package is definers, no error to not qualify with sys.
      select lob into lob from java$jvm$rjbc where id=sessid;
      return lob;
end;

function getpath(sessid VARCHAR2) return VARCHAR2 as
      p VARCHAR2(4000);
begin -- this package is definers, no error to not qualify with sys.
      select path into p from java$jvm$rjbc where id=sessid;
      return p;
end;

procedure putlob(sessid VARCHAR2, l BLOB) as
  tl BLOB;
begin -- this package is definers, no error to not qualify with sys.
    select lob into tl from java$jvm$rjbc where id=sessid for update;
    dbms_lob.trim(tl, 0);
    dbms_lob.append(tl, l);
    commit;
end;

procedure done(sessid VARCHAR2) as
begin
    delete from java$jvm$rjbc where id=sessid;
    commit;
end;

end jvmrjbc;
/

