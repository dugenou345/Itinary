create view KU$_UNLOAD_METHOD_VIEW (OBJ_NUM, UNLOAD_METHOD, ET_PARALLEL) as
select t.obj#,
      decode (
           -- Condition 1: Table has FGAC for SELECT enabled?
        (select count(*) from rls$ r where r.obj#=t.obj#
                and r.enable_flag=1 and bitand(r.stmt_type,1)=1)
        +  -- Condition 2 and 3: Encrypted cols or queue table?
        bitand(t.trigflag, 65536+8388608)
        + -- Condition 4a: BFILE columns?
        bitand(t.property, 32768)
        + -- Condition 4b: Opaque columns?
        (select count(*) FROM opqtype$ o where o.obj# = t.obj#)
        + -- Condition 5: Cols of evolved types that need upgrading?
        (select count(*) FROM coltype$ c where c.obj#=t.obj# and
                bitand(c.flags,256)>0)
--       Obsolete, now supported by direct unload.
--        + -- Condition 6: Any LONG or LONG RAW columns that are not last?
--        (select count(*) from col$ c where c.obj#=t.obj# and c.type# IN (8,24)
--                and c.segcol# !=
--                (select MAX(c2.segcol#) from col$ c2 where c2.obj#=t.obj#) )
        + -- Condition 7: Columns with embedded opaques?
        (select count(*) from coltype$ c, type$ ty where c.obj#=t.obj# and
                c.toid=ty.toid and bitand(ty.properties, 4096) > 0)
        + -- Condition 8: table with column added that has NOT NULL and
          -- DEFAULT VALUE specified
        (select count(*) from ecol$ e where e.tabobj# = t.obj#)
        + -- Condition 9: target is 10g instance and table contains subtype,
          -- sql_plan_allstat_row_type.  This subtype does not exist in 10.2.
        (select count(*) from subcoltype$ sc where sc.obj# = t.obj# and
                              sc.toid = '00000000000000000000000000020215' and
                              dbms_metadata.get_version < '11.00.00.00.00')
        + -- Condition 10: table with a RADM masking policy
        (select count(*) from radm$ r where r.obj# = t.obj#)
        + -- Condition 11: table is ILM enabled
          -- KQLDTVCP2_LIFECYCLE    0x00008000
        (bitand(t.property,(32768*4294967296)))
        + -- Condition 12: partitioned clustered table
          -- KQLDTVCP_PTI           0x00000020
          -- KQLDTVCP_CLU           0x00000400
        (decode (bitand(property,(32+1024)),(32+1024),1,0))
        + -- Condition 13: sharing=extended data
        (case when bitand(property,(1048576*power(2,32))) != 0 then 1
              else 0
         end)
        + -- Condition 14: export shard table from shard catalog
        (dbms_metadata_util.is_shard_tbl_in_shard_catalog(t.obj#))
        + -- Condition 15: has "DST upgrade in progress" bit set, so db's
          -- TSTZ version is in the process of being upgraded.  If table
          -- hasn't finished being upgraded, then external table is needed
          -- so SQL SELECT will do on-the-fly upgrade of TSTZ while rows
          -- are being fetched.
        (bitand(t.property, 137438953472))
       , 0, 1, 4),
--
-- NOTE: The values 1 and 4 from the decode above correspond to the constants
-- prefer_direct and require_external from the package kupd$data_int defined in
-- datapump/dml/prvthpdi. If these values ever change in the package, they must
-- be changed here as well. Can't use pkg's constants because catmeta executes
-- before pkg header is installed.
--
  --
  -- Ext. Tbls. cannot unload in parallel if:
  -- 1. FGAC (row level security) is enabled. Note: The data layer must execute
  --    as invoker's rights for unload on FGAC-enabled tables so the security
  --    of the caller is enforced (security hole if SYS as definer unloaded the
  --    table). But, kxfp processes started in response to a parallel ET unload
  --    would also run as the unprived invoker and they then fail calling our
  --    internal definer's pkg's like queueing and file mgt. Forcing parallel=1
  --    in this case stays in the context of the worker process which *can* see
  --    the internal pkgs because they share the same owner (SYS).
  --
      decode (
        (select count(*) from rls$ r where r.obj#=t.obj# and r.enable_flag=1)
        , 0, 1, 0)  -- 1: Can do ET parallel unload  0: Can't
   from tab$ t
/

