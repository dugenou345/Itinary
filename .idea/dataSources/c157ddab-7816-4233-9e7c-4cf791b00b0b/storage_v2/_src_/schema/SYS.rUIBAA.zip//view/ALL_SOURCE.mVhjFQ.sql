create view ALL_SOURCE (OWNER, NAME, TYPE, LINE, TEXT, ORIGIN_CON_ID) as
select OWNER, NAME, TYPE, LINE, TEXT,  ORIGIN_CON_ID
from int$dba_source ods
where
  (
    OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
    or
    OWNER='PUBLIC'
    or
    (
      (
         (
          (TYPE# in (7 /* proc */, 8 /* func */, 9 /* pkg */, 13 /* type */,
                       22 /* library */, 87 /* assembly */ ))
          and
          OBJ_ID(OWNER, NAME, TYPE#, OBJECT_ID) in
                   (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (12 /* EXECUTE */, 26 /* DEBUG */))
        )
        or
        (
          (TYPE# in (11 /* package body */, 14 /* type body */))
          and
          exists
          (
           select null
             from sys."_ACTUAL_EDITION_OBJ" specobj,
                  sys.dependency$ dep, sys.objauth$ oa, sys.user$ u
            where u.name = ods.OWNER
              and specobj.owner# = u.user#
              and specobj.name = ods.NAME
              and specobj.type# = decode(ods.TYPE#,
                                         11 /* pkg body */, 9 /* pkg */,
                                         14 /* type body */, 13 /* type */,
                                         null)
              and dep.d_obj# = OBJ_ID(ods.OWNER,
                                      ods.NAME,
                                      ods.TYPE#,
                                      ods.OBJECT_ID)
              and dep.p_obj# = specobj.obj#
              and oa.obj# = specobj.obj#
              and oa.grantee# in (select kzsrorol from x$kzsro)
              and oa.privilege# = 26 /* DEBUG */)
        )
        or
        (
          (TYPE# = 12 /* trigger */)
          and
          exists
          (
           select null from sys.trigger$ t, sys.objauth$ oa
            where bitand(t.property, 24) = 0
              and t.obj# = OBJ_ID(ods.OWNER,
                                  ods.NAME, 12,
                                  ods.OBJECT_ID)
              and oa.obj# = t.baseobject
              and oa.grantee# in (select kzsrorol from x$kzsro)
              and oa.privilege# = 26 /* DEBUG */)
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (TYPE# = 7 or TYPE# = 8 or TYPE# = 9)
              and
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* package body */
              TYPE# = 11 and
              (
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type */
              TYPE# = 13
              and
              (
                privilege# = -184 /* EXECUTE ANY TYPE */
                or
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type body */
              TYPE# = 14 and
              (
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* triggers */
              TYPE# = 12 and
              (
                privilege# = -152 /* CREATE ANY TRIGGER */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* library */
              TYPE# = 22 and
              (
                privilege# = -192 /* EXECUTE ANY LIBRARY */
                or
                privilege# = -189 /* CREATE ANY LIBRARY */
              )
            )
            or
            (
              /* assembly */
              TYPE# = 87 and
              (
                privilege# = -285 /* EXECUTE ANY ASSEMBLY */
                or
                privilege# = -282 /* CREATE ANY ASSEMBLY */
              )
            )
          )
        )
      )
    )
    or
    (
      TYPE# = 28
      and
      (
        (
          OBJ_ID(OWNER, NAME, 28, OBJECT_ID) in (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (12 /* EXECUTE */, 26 /* DEBUG */))
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
          )
        )
      )
    )
  )
/

comment on table ALL_SOURCE is 'Current source on stored objects that user is allowed to create'
/

comment on column ALL_SOURCE.OWNER is 'Owner of the object'
/

comment on column ALL_SOURCE.NAME is 'Name of the object'
/

comment on column ALL_SOURCE.TYPE is 'Type of the object'
/

comment on column ALL_SOURCE.LINE is 'Line number of this line of source'
/

comment on column ALL_SOURCE.TEXT is 'Source text'
/

comment on column ALL_SOURCE.ORIGIN_CON_ID is 'ID of Container where row originates'
/

