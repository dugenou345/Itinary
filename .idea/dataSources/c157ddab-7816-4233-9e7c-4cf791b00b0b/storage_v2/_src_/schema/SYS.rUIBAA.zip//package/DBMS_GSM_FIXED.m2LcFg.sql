create PACKAGE dbms_gsm_fixed
AS
-- since changes to gsmadmin_internal tables aren't propagated to logical
--  standbys, mark all gsm packages as unsupported
PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED);

TYPE name_list IS TABLE OF
  varchar2(gsmadmin_internal.dbms_gsm_common.max_ident)
  index by binary_integer;

TYPE connect_list IS TABLE OF varchar2(1000) index by binary_integer;

PROCEDURE executeGenericProcedureFix (payload         IN  varchar2,
                                      change_type     IN  number,
                                      response_code   OUT number,
                                      response_info   OUT varchar2);

PROCEDURE setupBC (primary_db       IN   varchar2,
                   prim_conn_str    IN   varchar2,
                   prot_mode        IN   number,
                   standby_dbs      IN   name_list,
                   standby_conn_str IN   connect_list,
                   err_num          OUT  number,
                   err_string       OUT  varchar2);

PROCEDURE fixBC (new_db           IN   varchar2,
                 new_conn_str     IN   varchar2,
                 old_db_name      IN   varchar2,
                 prot_mode        IN   number,
                 err_num          OUT  number,
                 err_string       OUT  varchar2,
                 primary_db       IN   varchar2 default NULL,
                 primary_conn_str IN   varchar2 default NULL);

PROCEDURE deleteBC (standby_db       IN   varchar2,
                    is_last_standby  IN   boolean,
                    response_code    OUT  number,
                    response_info    OUT  varchar2);

PROCEDURE validateParameters (reptype IN NUMBER);

procedure getColumnInfoEx(object_owner in varchar2, object_name in varchar2,
  column_name in varchar2, col_type out number, adt_num out number);

function getTablespaceDDLInternal(tablespaceName varchar2,
    remapName varchar2 default null) return varchar2;

function getCatalogEP
  return varchar2;
PRAGMA SUPPLEMENTAL_LOG_DATA(getCatalogEP, READ_ONLY);
PROCEDURE checkCatalogSysLink;
PRAGMA SUPPLEMENTAL_LOG_DATA(checkCatalogSysLink, READ_ONLY);
PROCEDURE setCatalogSysLink(gsmusrpwd IN VARCHAR2, gsm_endpoint IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(setCatalogSysLink, READ_ONLY);

PROCEDURE syncSchema (schemas           IN gsmadmin_internal.schema_list_t DEFAULT NULL,
                      nversion          IN number,
                      response_code     OUT number,
                      response_info     OUT varchar2);

FUNCTION ptshdGetSXML(objtype IN varchar2,
                      schema_name IN varchar2,
                      objname IN varchar2)
  RETURN clob;

PROCEDURE execAsUserID(exec_id     number,
                       ddlid       number,
                       qstring       blob,
                       ignore_error  boolean DEFAULT FALSE,
                       curr_key        number DEFAULT 0)
ACCESSIBLE BY (PACKAGE GSMADMIN_INTERNAL.dbms_gsm_dbadmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_pooladmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_common,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_cloudadmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_utility,
               PACKAGE ggsys.ggsharding,
               PROCEDURE sys.execAsUser,
               PROCEDURE gsmadmin_internal.executeDDL,
               PROCEDURE gsmadmin_internal.executeCommand);

PROCEDURE execAsUser(exec_user     varchar2,
                     ddlid         number,
                     qstring       blob,
                     ignore_error  boolean DEFAULT FALSE,
                     cur_key       number DEFAULT 0)
ACCESSIBLE BY (PACKAGE GSMADMIN_INTERNAL.dbms_gsm_dbadmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_pooladmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_common,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_cloudadmin,
               PACKAGE GSMADMIN_INTERNAL.dbms_gsm_utility,
               PACKAGE ggsys.ggsharding,
               PROCEDURE gsmadmin_internal.executeDDL,
               PROCEDURE gsmadmin_internal.executeCommand);

PROCEDURE trimDDL (ddl_id     IN  number,
                   pwd_start  OUT number,
                   trim_ddl   OUT varchar2);
PRAGMA SUPPLEMENTAL_LOG_DATA(trimDDL, READ_ONLY);

-------------------------------------------------------------------------------
  pragma TIMESTAMP('2014-03-14:18:43:00');
-------------------------------------------------------------------------------


END dbms_gsm_fixed;
/

