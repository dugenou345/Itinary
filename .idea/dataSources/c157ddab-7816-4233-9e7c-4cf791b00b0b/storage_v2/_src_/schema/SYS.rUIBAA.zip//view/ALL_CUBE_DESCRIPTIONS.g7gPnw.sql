create view ALL_CUBE_DESCRIPTIONS (OWNER, OBJECT_NAME, OBJECT_TYPE, DESCRIPTION_TYPE, DESCRIPTION_VALUE, LANGUAGE) as
SELECT
  u.name OWNER,
  CASE d.owning_object_type
  WHEN 4 -- ASSIGNMENT
  THEN (SELECT o.name || '.' || m.model_name || '.' || a.member_name
        FROM olap_model_assignments$ a, olap_models$ m, obj$ o
        WHERE d.owning_object_id = a.assignment_id
              AND m.model_id = a.model_id
              AND m.owning_obj_type = 11
              AND m.owning_obj_id = o.obj#
        )
  WHEN 3 -- model
  THEN (SELECT o.name || '.' || m.model_name
        FROM olap_models$ m, obj$ o
        WHERE d.owning_object_id = m.model_id
              AND m.owning_obj_type = 11
              AND m.owning_obj_id = o.obj#
        )
  WHEN 14 -- hier_level
  THEN (SELECT o.name || '.' || h.hierarchy_name || '.' || dl.level_name
        FROM olap_hier_levels$ hl, olap_dim_levels$ dl,
             olap_hierarchies$ h, obj$ o
        WHERE d.owning_object_id = hl.hierarchy_level_id
              AND hl.dim_level_id = dl.level_id
              AND hl.hierarchy_id = h.hierarchy_id
              AND h.dim_obj# = o.obj#
        )
  WHEN 13 -- hierarchy
  THEN (SELECT o.name || '.' || h.hierarchy_name
        FROM olap_hierarchies$ h, obj$ o
        WHERE d.owning_object_id = h.hierarchy_id
              AND h.dim_obj# = o.obj#
       )
  WHEN 12 -- dim_level
  THEN (SELECT o.name || '.' || dl.level_name
        FROM olap_dim_levels$ dl, obj$ o
        WHERE d.owning_object_id = dl.level_id
              AND dl.dim_obj# = o.obj#
       )
  WHEN 15 -- attribute
  THEN (SELECT o.name || '.' || a.attribute_name
        FROM olap_attributes$ a, obj$ o
        WHERE d.owning_object_id = a.attribute_id
              AND a.dim_obj# = o.obj#
       )
  WHEN 6 -- calc_member
  THEN (SELECT o.name || '.' || c.member_name
        FROM OLAP_CALCULATED_MEMBERS$ c, obj$ o
        WHERE d.owning_object_id = c.member_id
              AND c.dim_obj# = o.obj#
       )
  WHEN 11 -- dimension
  THEN (SELECT o.name
        FROM obj$ o
        WHERE d.owning_object_id = o.obj#
       )
  ELSE null
  END AS OBJECT_NAME,
  decode(d.owning_object_type, '4', 'ASSIGNMENT',
                               '3', 'MODEL',
                               '14', 'HIERARCHY LEVEL',
                               '13', 'HIERARCHY',
                               '12', 'DIMENSION LEVEL',
                               '15', 'ATTRIBUTE',
                               '6', 'CALCULATION MEMBER',
                               '11', 'DIMENSION') OBJECT_TYPE,
  d.description_type DESCRIPTION_TYPE,
  d.description_value DESCRIPTION_VALUE,
  d.language LANGUAGE
FROM
  olap_descriptions$ d,
  user$ u,
  obj$ o
WHERE
  d.description_class is null
  AND d.obj# = o.obj#
  AND o.owner# = u.user#
  AND d.owning_object_type in (3, 4, 6, 11, 12, 13, 14, 15)
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
UNION ALL
SELECT
  u.name OWNER,
  CASE d.owning_object_type
  WHEN 2 -- measure
  THEN (SELECT o.name || '.' || m.measure_name
        FROM olap_measures$ m, olap_cubes$ c, obj$ o
        WHERE d.owning_object_id = m.measure_id
              AND m.cube_obj# = c.obj#
              AND c.obj# = o.obj#
        )
  WHEN 1 -- cube
  THEN (SELECT o.name
        FROM obj$ o
        WHERE d.owning_object_id = o.obj#
       )
  ELSE null
  END AS OBJECT_NAME,
  decode(d.owning_object_type, '1', 'CUBE',
                               '2', 'MEASURE') OBJECT_TYPE,
  d.description_type DESCRIPTION_TYPE,
  d.description_value DESCRIPTION_VALUE,
  d.language LANGUAGE
FROM
  olap_descriptions$ d,
  user$ u,
  obj$ o,
  (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ora_check_SYS_privilege (do.owner#, do.type#) = 1
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      dependency$ d,
      obj$ do
    WHERE
      do.obj# = d.p_obj#
      AND do.type# = 92 -- CUBE DIMENSION
      AND c.obj# = d.d_obj#
    )
    GROUP BY obj# ) da
WHERE
  d.description_class is null
  AND d.obj# = o.obj#
  AND o.owner# = u.user#
  AND o.obj#=da.obj#(+)
  AND d.owning_object_type in (1, 2)
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
UNION ALL
SELECT
  u.name OWNER,
  o2.name OBJECT_NAME,
  'MEASURE FOLDER' OBJECT_TYPE,
  d.description_type DESCRIPTION_TYPE,
  d.description_value DESCRIPTION_VALUE,
  d.language LANGUAGE
FROM
  olap_descriptions$ d,
  user$ u,
  obj$ o,
  obj$ o2
WHERE
  d.description_class is null
  AND d.obj# = o.obj#
  AND o.owner# = u.user#
  AND d.owning_object_id = o2.obj#
  AND d.owning_object_type = 10 -- MEASURE FOLDER
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
       or   -- user has access to cubes in measure folder
              ( exists (select null from olap_meas_folder_contents$ mfc, olap_measures$ m
                        where mfc.measure_folder_obj# = o2.obj#
                          and m.measure_id  = mfc.object_id
                          and (
                              m.cube_obj# in
                                ( select obj#  -- directly granted authorization
                                  from sys.objauth$
                                  where grantee# in ( select kzsrorol from x$kzsro )
                                )
                              )
                       )
              )
            )
UNION ALL
SELECT
  u.name OWNER,
  o2.name OBJECT_NAME,
  'BUILD PROCESS' OBJECT_TYPE,
  d.description_type DESCRIPTION_TYPE,
  d.description_value DESCRIPTION_VALUE,
  d.language LANGUAGE
FROM
  olap_descriptions$ d,
  user$ u,
  obj$ o,
  obj$ o2
WHERE
  d.description_class is null
  AND d.obj# = o.obj#
  AND o.owner# = u.user#
  AND d.owning_object_id = o2.obj#
  AND d.owning_object_type = 8 --BUILD_PROCESS
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
/

comment on table ALL_CUBE_DESCRIPTIONS is 'OLAP Descriptions in the database that are accessible to the user'
/

comment on column ALL_CUBE_DESCRIPTIONS.OWNER is 'Owner of the OLAP Description'
/

comment on column ALL_CUBE_DESCRIPTIONS.OBJECT_NAME is 'NAME of the OLAP object that has the description'
/

comment on column ALL_CUBE_DESCRIPTIONS.OBJECT_TYPE is 'Text value indicating the type of the OLAP object that has the description'
/

comment on column ALL_CUBE_DESCRIPTIONS.DESCRIPTION_TYPE is 'Text value indicating the type the of OLAP Description'
/

comment on column ALL_CUBE_DESCRIPTIONS.DESCRIPTION_VALUE is 'Text of the OLAP Description'
/

comment on column ALL_CUBE_DESCRIPTIONS.LANGUAGE is 'Language of the OLAP Description'
/

