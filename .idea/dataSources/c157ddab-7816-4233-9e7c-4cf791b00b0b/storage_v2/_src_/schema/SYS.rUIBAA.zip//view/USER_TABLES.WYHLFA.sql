create view USER_TABLES
            (TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS, PCT_FREE, PCT_USED, INI_TRANS, MAX_TRANS,
             INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING,
             BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, AVG_SPACE_FREELIST_BLOCKS,
             NUM_FREELIST_BLOCKS, DEGREE, INSTANCES, CACHE, TABLE_LOCK, SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED,
             IOT_TYPE, TEMPORARY, SECONDARY, NESTED, BUFFER_POOL, FLASH_CACHE, CELL_FLASH_CACHE, ROW_MOVEMENT,
             GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING, CLUSTER_OWNER, DEPENDENCIES, COMPRESSION,
             COMPRESS_FOR, DROPPED, READ_ONLY, SEGMENT_CREATED, RESULT_CACHE, CLUSTERING, ACTIVITY_TRACKING,
             DML_TIMESTAMP, HAS_IDENTITY, CONTAINER_DATA, INMEMORY, INMEMORY_PRIORITY, INMEMORY_DISTRIBUTE,
             INMEMORY_COMPRESSION, INMEMORY_DUPLICATE, DEFAULT_COLLATION, DUPLICATED, SHARDED, EXTERNALLY_SHARDED,
             EXTERNALLY_DUPLICATED, EXTERNAL, HYBRID, CELLMEMORY, CONTAINERS_DEFAULT, CONTAINER_MAP, EXTENDED_DATA_LINK,
             EXTENDED_DATA_LINK_MAP, INMEMORY_SERVICE, INMEMORY_SERVICE_NAME, CONTAINER_MAP_OBJECT, MEMOPTIMIZE_READ,
             MEMOPTIMIZE_WRITE, HAS_SENSITIVE_COLUMN, ADMIT_NULL, DATA_LINK_DML_ENABLED, LOGICAL_REPLICATION)
as
select o.name,
       decode(bitand(t.property,2151678048), 0, ts.name,
              decode(t.ts#, 0, null, ts.name)),
       decode(bitand(t.property, 1024), 0, null, co.name),
       decode((bitand(t.property, 512)+bitand(t.flags, 536870912)),
              0, null, co.name),
       decode(bitand(t.trigflag, 1073741824), 1073741824, 'UNUSABLE', 'VALID'),
       decode(bitand(t.property, 32+64), 0, mod(t.pctfree$, 100), 64, 0, null),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
          decode(bitand(t.property, 32+64), 0, t.pctused$, 64, 0, null)),
       decode(bitand(t.property, 32), 0, t.initrans, null),
       decode(bitand(t.property, 32), 0, t.maxtrans, null),
       decode(bitand(t.property, 17179869184), 17179869184,
                     ds.initial_stg * ts.blocksize,
                     s.iniexts * ts.blocksize),
       decode(bitand(t.property, 17179869184), 17179869184,
              ds.next_stg * ts.blocksize,
              s.extsize * ts.blocksize),
       decode(bitand(t.property, 17179869184), 17179869184,
              ds.minext_stg, s.minexts),
       decode(bitand(t.property, 17179869184), 17179869184,
              ds.maxext_stg, s.maxexts),
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
              decode(bitand(t.property, 17179869184), 17179869184,
                            ds.pctinc_stg, s.extpct)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1,
                decode(bitand(t.property, 17179869184), 17179869184,
                       decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                       decode(s.lists, 0, 1, s.lists)))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1,
                decode(bitand(t.property, 17179869184), 17179869184,
                       decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                       decode(s.groups, 0, 1, s.groups)))),
       decode(bitand(t.property, 32+64), 0,
                decode(bitand(t.flags, 32), 0, 'YES', 'NO'), null),
       decode(bitand(t.flags,1), 0, 'Y', 1, 'N', '?'),
       t.rowcnt,
       decode(bitand(t.property, 64), 0, t.blkcnt, null),
       decode(bitand(t.property, 64), 0, t.empcnt, null),
       decode(bitand(t.property, 64), 0, t.avgspc, null),
       t.chncnt, t.avgrln, t.avgspc_flb,
       decode(bitand(t.property, 64), 0, t.flbcnt, null),
       lpad(decode(t.degree, 32767, 'DEFAULT', nvl(t.degree,1)),10),
       lpad(decode(t.instances, 32767, 'DEFAULT', nvl(t.instances,1)),10),
       lpad(decode(bitand(t.flags, 8), 8, 'Y', 'N'),5),
       decode(bitand(t.flags, 6), 0, 'ENABLED', 'DISABLED'),
       t.samplesize, t.analyzetime,
       decode(bitand(t.property, 32), 32, 'YES', 'NO'),
       decode(bitand(t.property, 64), 64, 'IOT',
               decode(bitand(t.property, 512), 512, 'IOT_OVERFLOW',
               decode(bitand(t.flags, 536870912), 536870912, 'IOT_MAPPING', null))),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       decode(bitand(t.property, 8192), 8192, 'YES',
              decode(bitand(t.property, 1), 0, 'NO', 'YES')),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
              decode(bitand(decode(bitand(t.property, 17179869184), 17179869184,
                            ds.bfp_stg, s.cachehint), 3),
                            1, 'KEEP', 2, 'RECYCLE', 'DEFAULT')),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
              decode(bitand(decode(bitand(t.property, 17179869184), 17179869184,
                            ds.bfp_stg, s.cachehint), 12)/4,
                            1, 'KEEP', 2, 'NONE', 'DEFAULT')),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
              decode(bitand(decode(bitand(t.property, 17179869184), 17179869184,
                            ds.bfp_stg, s.cachehint), 48)/16,
                            1, 'KEEP', 2, 'NONE', 'DEFAULT')),
       decode(bitand(t.flags, 131072), 131072, 'ENABLED', 'DISABLED'),
       decode(bitand(t.flags, 512), 0, 'NO', 'YES'),
       decode(bitand(t.flags, 256), 0, 'NO', 'YES'),
       decode(bitand(o.flags, 2), 0, NULL,
           decode(bitand(t.property, 8388608), 8388608,
                  'SYS$SESSION', 'SYS$TRANSACTION')),
       decode(bitand(t.flags, 1024), 1024, 'ENABLED', 'DISABLED'),
       decode(bitand(o.flags, 2), 2, 'NO',
           decode(bitand(t.property, 2147483648), 2147483648, 'NO',
              decode(ksppcv.ksppstvl, 'TRUE', 'YES', 'NO'))),
       decode(bitand(t.property, 1024), 0, null, cu.name),
       decode(bitand(t.flags, 8388608), 8388608, 'ENABLED', 'DISABLED'),
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 4), 4, 'ENABLED', 'DISABLED')
       else
         decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED')
       end,
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
          decode(bitand(ds.flags_stg, 4), 4,
          case when bitand(ds.cmpflag_stg, 3) = 1 then 'BASIC'
               when bitand(ds.cmpflag_stg, 3) = 2 then 'ADVANCED'
               else concat(decode(ds.cmplvl_stg, 1, 'QUERY LOW',
                                                 2, 'QUERY HIGH',
                                                 3, 'ARCHIVE LOW',
                                                    'ARCHIVE HIGH'),
                           decode(bitand(ds.flags_stg, 524288), 524288,
                                  ' ROW LEVEL LOCKING', '')) end,
               null)
       else
         decode(bitand(s.spare1, 2048), 0, null, 2048,
         case when bitand(s.spare1, 16777216) = 16777216   -- 0x1000000
                   then 'ADVANCED'
              when bitand(s.spare1, 100663296) = 33554432  -- 0x2000000
                   then concat('QUERY LOW',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 100663296) = 67108864  -- 0x4000000
                   then concat('QUERY HIGH',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 100663296) = 100663296 -- 0x2000000+0x4000000
                   then concat('ARCHIVE LOW',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              when bitand(s.spare1, 134217728) = 134217728 -- 0x8000000
                   then concat('ARCHIVE HIGH',
                               decode(bitand(s.spare1, 2147483648),
                                      2147483648, ' ROW LEVEL LOCKING', ''))
              else 'BASIC' end, null)
       end,
       decode(bitand(o.flags, 128), 128, 'YES', 'NO'),
       decode(bitand(t.trigflag, 2097152), 2097152, 'YES',
              decode(bitand(t.property, 32), 32, 'N/A', 'NO')),
       decode(bitand(t.property, 17179869184), 17179869184, 'NO',
              decode(bitand(t.property, 32), 32, 'N/A', 'YES')),
       decode(bitand(t.property,16492674416640),2199023255552,'FORCE',
                     4398046511104,'MANUAL','DEFAULT'),
       decode(bitand(t.property, 18014398509481984), 18014398509481984,
                     'YES', 'NO'),
       case when bitand(t.property, 1125899906842624) = 1125899906842624
                 then 'ROW ACCESS TRACKING'
            when bitand(t.property, 2251799813685248) = 2251799813685248
                 then 'SEGMENT ACCESS TRACKING'
        end,
       case when bitand(t.property, 844424930131968) = 844424930131968
                 then 'ROW CREATION/MODIFICATION'
            when bitand(t.property, 281474976710656) = 281474976710656
                 then 'ROW MODIFICATION'
            when bitand(t.property, 562949953421312) = 562949953421312
                 then 'ROW CREATION'
        end,
       decode(bitand(t.property, 288230376151711744), 288230376151711744,
              'YES', 'NO'),
       decode(bitand(t.property/4294967296, 134217728), 134217728, 'YES', 'NO'),
       -- INMEMORY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 2147483648 ) = 2147483648) then
         decode(bitand(xt.property,16), 16, 'ENABLED', 'DISABLED')
       when (bitand(t.property, 17179869184) = 17179869184) then
         -- flags/imcflag_stg (stgdef.h)
         decode(bitand(ds.flags_stg, 6291456),
             2097152, 'ENABLED',
             4194304, 'DISABLED', 'DISABLED')
       else
         -- ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 70373039144960),
             4294967296,     'ENABLED',
             70368744177664, 'DISABLED', 'DISABLED')
       end,
       -- INMEMORY_PRIORITY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 4), 4,
                decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 7936),
                256, 'NONE',
                512, 'LOW',
                1024, 'MEDIUM',
                2048, 'HIGH',
                4096, 'CRITICAL', 'UNKNOWN'), null),
                'NONE'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 34359738368), 34359738368,
                decode(bitand(s.spare1, 61572651155456),
                8796093022208, 'LOW',
                17592186044416, 'MEDIUM',
                35184372088832, 'HIGH',
                52776558133248, 'CRITICAL', 'NONE'),
                'NONE'),
                null)
       end,
       -- INMEMORY_DISTRIBUTE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 1), 1,
                       decode(bitand(ds.imcflag_stg, (16+32)),
                              16,  'BY ROWID RANGE',
                              32,  'BY PARTITION',
                              48,  'BY SUBPARTITION',
                               0,  'AUTO'),
                  null), null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 8589934592), 8589934592,
                        decode(bitand(s.spare1, 206158430208),
                        68719476736,   'BY ROWID RANGE',
                        137438953472,  'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        'UNKNOWN'),
                  null)
       end,
       -- INMEMORY_COMPRESSION
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 2147483648 ) = 2147483648) then
             decode(bitand(xt.property, (16+32+64+128+256)),
                         (16+32), 'NO MEMCOMPRESS',
                         (16+64), 'FOR DML',
                      (16+32+64), 'FOR QUERY LOW',
                        (16+128), 'FOR QUERY HIGH',
                     (16+128+32), 'FOR CAPACITY LOW',
                     (16+128+64), 'FOR CAPACITY HIGH',
                     (16+256+32), 'AUTO', NULL)
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 6291456),
                2097152,
                decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              2,   'NO MEMCOMPRESS',
                              8,   'FOR DML',
                              10,  'FOR QUERY LOW',
                              64,  'FOR QUERY HIGH',
                              66,  'FOR CAPACITY LOW',
                              72,  'FOR CAPACITY HIGH',
                              130, 'AUTO', 'UNKNOWN'),
                4194304,
                decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              128, 'NO INMEMORY', null),
                null)
       else
         decode(bitand(s.spare1, 70373039144960),
                4294967296,
                decode(bitand(s.spare1, 1941325217792),
                              17179869184,   'NO MEMCOMPRESS',
                              274877906944,  'FOR DML',
                              292057776128,  'FOR QUERY LOW',
                              549755813888,  'FOR QUERY HIGH',
                              566935683072,  'FOR CAPACITY LOW',
                              824633720832,  'FOR CAPACITY HIGH',
                              1116691496960, 'AUTO', 'UNKNOWN'),
                 70368744177664,
                 decode(bitand(s.spare1, 1941325217792),
                              1099511627776, 'NO INMEMORY',
                              null),
                 null)
       end,
       -- INMEMORY_DUPLICATE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
        decode(bitand(ds.flags_stg, 2097152), 2097152,
               decode(bitand(ds.imcflag_stg, (8192+16384)),
                              8192,   'NO DUPLICATE',
                              16384,  'DUPLICATE',
                              24576,  'DUPLICATE ALL',
                              'UNKNOWN'),
                null)
       else
          decode(bitand(s.spare1, 4294967296), 4294967296,
                   decode(bitand(s.spare1, 6597069766656),
                           2199023255552, 'NO DUPLICATE',
                           4398046511104, 'DUPLICATE',
                           6597069766656, 'DUPLICATE ALL', 'UNKNOWN'),
                 null)
       end,
       nls_collation_name(nvl(o.dflcollid, 16382)),
       -- DUPLICATED TABLE
       decode(bitand(t.property, power(2,76) + power(2,94)),
                     0, 'N',
                     power(2,76), 'Y', /* Catalog: KQLDTVCP3_RFRENCE_TBL set */
                     power(2,94), 'Y',       /* Shard: KQLDTVCP3_DUP_TBL set */
                     'N'),
       -- SHARDED TABLE: KQLDTVCP3_SHARDED_TBL set
       decode(bitand(t.property, power(2,75)), 0, 'N', power(2,75), 'Y', 'N'),
       -- EXTERNALLY SHARDED TABLE: KQLDTVCP4_EXT_SHARDED_TBL set
       decode(bitand(t.property, power(2,100)), 0, 'N', power(2,100), 'Y', 'N'),
       -- EXTERNALLY DUPLICATED TABLE: KQLDTVCP4_EXT_DUP_TBL set
       decode(bitand(t.property, power(2,101)), 0, 'N', power(2,101), 'Y', 'N'),
       decode(bitand(t.property, power(2,90)), power(2,90), 'NO',
         decode(bitand(t.property, 2147483648), 2147483648, 'YES', 'NO')),
       decode(bitand(t.property, power(2,90)), power(2,90), 'YES', 'NO'),
       -- CELLMEMORY
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         -- deferred segment: stgccflags (stgdef.h)
         decode(ccflag_stg,
             8194, 'NO MEMCOMPRESS',
             8196, 'MEMCOMPRESS FOR QUERY',
             8200, 'MEMCOMPRESS FOR CAPACITY',
             16384, 'DISABLED', null)
       else
         -- created segment: ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 4362862139015168),
              281474976710656, 'DISABLED',
              703687441776640, 'NO MEMCOMPRESS',
             1266637395197952, 'MEMCOMPRESS FOR QUERY',
             2392537302040576, 'MEMCOMPRESS FOR CAPACITY', null)
       end,
       -- CONTAINERS_DEFAULT
       decode(bitand(t.property, power(2,72)), power(2,72), 'YES', 'NO'),
       -- CONTAINER_MAP
       decode(bitand(t.property, power(2,80)), power(2,80), 'YES', 'NO'),
       -- EXTENDED_DATA_LINK
       decode(bitand(t.property, power(2,52)), power(2,52), 'YES', 'NO'),
       -- EXTENDED_DATA_LINK_MAP
       decode(bitand(t.property, power(2,79)), power(2,79), 'YES', 'NO'),
       -- INMEMORY_SERVICE
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'UNKNOWN'), 'DEFAULT'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'UNKNOWN'), 'DEFAULT'),
                 null)
       end,
       -- INMEMORY_SERVICE_NAME
       case when (bitand(t.property, 32) = 32) then
         null
       when (bitand(t.property, 17179869184) = 17179869184) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       svc.svcname, null),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       svc.svcname, null),
                null)
       end,
       -- CONTAINER_MAP_OBJECT
       decode(bitand(t.property, power(2,87)), power(2,87), 'YES', 'NO'),
       -- MEMOPTIMIZE_READ
       case when bitand(t.property, 32) = 32
              then 'N/A'
       else
          decode(bitand(t.property, power(2,91)), power(2,91),
                        'ENABLED', 'DISABLED')
       end,
       -- MEMOPTIMIZE_WRITE
       case when bitand(t.property, 32) = 32
              then 'N/A'
       else
          decode(bitand(t.property, power(2,92)), power(2,92),
                        'ENABLED', 'DISABLED')
       end,
       -- HAS_SENSITIVE_COLUMN
       decode(bitand(t.property, power(2,89)), power(2,89), 'YES', 'NO'),
       -- ADMIT_NULL
       decode(bitand(t.property, power(2,78)), power(2,78), 'YES', 'NO'),
       -- DATA_LINK_DML_ENABLED
       decode(bitand(t.property, power(2,81)), power(2,81), 'YES', 'NO'),
       -- LOGICAL_REPLICATION
       decode(bitand(t.property, power(2,83)), power(2,83),
             'DISABLED', 'ENABLED')
from sys.ts$ ts, sys.seg$ s, sys.obj$ co, sys.tab$ t, sys.external_tab$ xt,
     sys."_CURRENT_EDITION_OBJ" o,
     sys.deferred_stg$ ds, sys.obj$ cx, sys.user$ cu, x$ksppcv ksppcv,
     x$ksppi ksppi, sys.imsvc$ svc
where o.owner# = userenv('SCHEMAID')
  and o.obj# = t.obj#
  and t.obj# = xt.obj# (+)
  and bitand(t.property, 1) = 0
  and bitand(o.flags, 128) = 0
  and t.bobj# = co.obj# (+)
  and t.ts# = ts.ts#
  and t.file# = s.file# (+)
  and t.block# = s.block# (+)
  and t.ts# = s.ts# (+)
  and t.obj# = ds.obj# (+)
  and t.dataobj# = cx.obj# (+)
  and cx.owner# = cu.user# (+)
  and ksppi.indx = ksppcv.indx
  and ksppi.ksppinm = '_dml_monitoring_enabled'
  and bitand(t.property, power(2,65)) = 0 -- Do not show granular token sets
  and t.obj# = svc.obj# (+)
  and svc.subpart#(+) is null
/

comment on table USER_TABLES is 'Description of the user''s own relational tables'
/

comment on column USER_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column USER_TABLES.TABLESPACE_NAME is 'Name of the tablespace containing the table'
/

comment on column USER_TABLES.CLUSTER_NAME is 'Name of the cluster, if any, to which the table belongs'
/

comment on column USER_TABLES.IOT_NAME is 'Name of the index-only table, if any, to which the overflow or mapping table entry belongs'
/

comment on column USER_TABLES.STATUS is 'Status of the table will be UNUSABLE if a previous DROP TABLE operation failed,
VALID otherwise'
/

comment on column USER_TABLES.PCT_FREE is 'Minimum percentage of free space in a block'
/

comment on column USER_TABLES.PCT_USED is 'Minimum percentage of used space in a block'
/

comment on column USER_TABLES.INI_TRANS is 'Initial number of transactions'
/

comment on column USER_TABLES.MAX_TRANS is 'Maximum number of transactions'
/

comment on column USER_TABLES.INITIAL_EXTENT is 'Size of the initial extent in bytes'
/

comment on column USER_TABLES.NEXT_EXTENT is 'Size of secondary extents in bytes'
/

comment on column USER_TABLES.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column USER_TABLES.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column USER_TABLES.PCT_INCREASE is 'Percentage increase in extent size'
/

comment on column USER_TABLES.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column USER_TABLES.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column USER_TABLES.LOGGING is 'Logging attribute'
/

comment on column USER_TABLES.BACKED_UP is 'Has table been backed up since last modification?'
/

comment on column USER_TABLES.NUM_ROWS is 'The number of rows in the table'
/

comment on column USER_TABLES.BLOCKS is 'The number of used blocks in the table'
/

comment on column USER_TABLES.EMPTY_BLOCKS is 'The number of empty (never used) blocks in the table'
/

comment on column USER_TABLES.AVG_SPACE is 'The average available free space in the table'
/

comment on column USER_TABLES.CHAIN_CNT is 'The number of chained rows in the table'
/

comment on column USER_TABLES.AVG_ROW_LEN is 'The average row length, including row overhead'
/

comment on column USER_TABLES.AVG_SPACE_FREELIST_BLOCKS is 'The average freespace of all blocks on a freelist'
/

comment on column USER_TABLES.NUM_FREELIST_BLOCKS is 'The number of blocks on the freelist'
/

comment on column USER_TABLES.DEGREE is 'The number of threads per instance for scanning the table'
/

comment on column USER_TABLES.INSTANCES is 'The number of instances across which the table is to be scanned'
/

comment on column USER_TABLES.CACHE is 'Whether the table is to be cached in the buffer cache'
/

comment on column USER_TABLES.TABLE_LOCK is 'Whether table locking is enabled or disabled'
/

comment on column USER_TABLES.SAMPLE_SIZE is 'The sample size used in analyzing this table'
/

comment on column USER_TABLES.LAST_ANALYZED is 'The date of the most recent time this table was analyzed'
/

comment on column USER_TABLES.PARTITIONED is 'Is this table partitioned? YES or NO'
/

comment on column USER_TABLES.IOT_TYPE is 'If index-only table, then IOT_TYPE is IOT or IOT_OVERFLOW or IOT_MAPPING else NULL'
/

comment on column USER_TABLES.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column USER_TABLES.SECONDARY is 'Is this table object created as part of icreate for domain indexes?'
/

comment on column USER_TABLES.NESTED is 'Is the table a nested table?'
/

comment on column USER_TABLES.BUFFER_POOL is 'The default buffer pool to be used for table blocks'
/

comment on column USER_TABLES.FLASH_CACHE is 'The default flash cache hint to be used for table blocks'
/

comment on column USER_TABLES.CELL_FLASH_CACHE is 'The default cell flash cache hint to be used for table blocks'
/

comment on column USER_TABLES.ROW_MOVEMENT is 'Whether partitioned row movement is enabled or disabled'
/

comment on column USER_TABLES.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column USER_TABLES.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column USER_TABLES.DURATION is 'If temporary table, then duration is sys$session or sys$transaction else NULL'
/

comment on column USER_TABLES.SKIP_CORRUPT is 'Whether skip corrupt blocks is enabled or disabled'
/

comment on column USER_TABLES.MONITORING is 'Should we keep track of the amount of modification?'
/

comment on column USER_TABLES.CLUSTER_OWNER is 'Owner of the cluster, if any, to which the table belongs'
/

comment on column USER_TABLES.DEPENDENCIES is 'Should we keep track of row level dependencies?'
/

comment on column USER_TABLES.COMPRESSION is 'Whether table compression is enabled or not'
/

comment on column USER_TABLES.COMPRESS_FOR is 'Compress what kind of operations'
/

comment on column USER_TABLES.DROPPED is 'Whether table is dropped and is in Recycle Bin'
/

comment on column USER_TABLES.READ_ONLY is 'Whether table is read only or not'
/

comment on column USER_TABLES.SEGMENT_CREATED is 'Whether the table segment is created or not'
/

comment on column USER_TABLES.RESULT_CACHE is 'The result cache mode annotation for the table'
/

comment on column USER_TABLES.CLUSTERING is 'Whether table has clustering clause or not'
/

comment on column USER_TABLES.ACTIVITY_TRACKING is 'ILM activity tracking mode'
/

comment on column USER_TABLES.DML_TIMESTAMP is 'ILM row modification or creation timestamp tracking mode'
/

comment on column USER_TABLES.HAS_IDENTITY is 'Whether the table has an identity column'
/

comment on column USER_TABLES.CONTAINER_DATA is 'An indicator of whether the table contains Container-specific data'
/

comment on column USER_TABLES.INMEMORY is 'Whether in-memory is enabled or not'
/

comment on column USER_TABLES.INMEMORY_PRIORITY is 'User defined priority in which in-memory column store object is loaded'
/

comment on column USER_TABLES.INMEMORY_DISTRIBUTE is 'How the in-memory columnar store object is distributed'
/

comment on column USER_TABLES.INMEMORY_COMPRESSION is 'Compression level for the in-memory column store option'
/

comment on column USER_TABLES.INMEMORY_DUPLICATE is 'How the in-memory column store object is duplicated'
/

comment on column USER_TABLES.DEFAULT_COLLATION is 'Default collation for the table'
/

comment on column USER_TABLES.EXTERNAL is 'Whether the table is an  external table or not'
/

comment on column USER_TABLES.HYBRID is 'Whether the table is a hybrid table or not'
/

comment on column USER_TABLES.CELLMEMORY is 'Cell columnar cache'
/

comment on column USER_TABLES.CONTAINERS_DEFAULT is 'Whether the table is enabled for CONTAINERS() by default'
/

comment on column USER_TABLES.CONTAINER_MAP is 'Whether the table is enabled for use with container_map database property'
/

comment on column USER_TABLES.EXTENDED_DATA_LINK is 'Whether the table is enabled for fetching extended data link from Root'
/

comment on column USER_TABLES.EXTENDED_DATA_LINK_MAP is 'Whether the table is enabled for use with extended data link map'
/

comment on column USER_TABLES.INMEMORY_SERVICE is 'How the in-memory columnar store object is distributed for service'
/

comment on column USER_TABLES.INMEMORY_SERVICE_NAME is 'Service on which the in-memory columnar store object is distributed'
/

comment on column USER_TABLES.CONTAINER_MAP_OBJECT is 'Whether the table is used as the value of container_map database property'
/

comment on column USER_TABLES.MEMOPTIMIZE_READ is 'Whether the table is enabled for Fast Key Based Access'
/

comment on column USER_TABLES.MEMOPTIMIZE_WRITE is 'Whether the table is enabled for Fast Data Ingestion'
/

comment on column USER_TABLES.HAS_SENSITIVE_COLUMN is 'Whether the table has one or more sensitive columns'
/

comment on column USER_TABLES.ADMIT_NULL is 'An indicator of whether the table admits null CON_ID data'
/

comment on column USER_TABLES.DATA_LINK_DML_ENABLED is 'An indicator of whether DML is permitted on the Data Link table'
/

comment on column USER_TABLES.LOGICAL_REPLICATION is 'Whether the table is enabled for logical replication'
/

