create type       "SYS_YOID0000017830$"              as object( "SYS_NC00001$" NUMBER)
/

