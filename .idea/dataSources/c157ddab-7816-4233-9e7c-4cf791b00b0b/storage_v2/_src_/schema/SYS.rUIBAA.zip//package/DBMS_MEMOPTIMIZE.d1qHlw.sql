create package dbms_memoptimize authid current_user as

/*
 *
 * Bugs 25368492 and 25367835: Define Exceptions
 *
 */
          schema_name_invalid         exception;
              pragma  exception_init(schema_name_invalid,
                                     -62135);

          table_name_invalid         exception;
              pragma  exception_init(table_name_invalid,
                                     -62136);



/*********************************************************************
 *                                                                   *
 *           START - APIs for fast lookup project                    *
 *                                                                   *
 ********************************************************************/


/*--------------------------POPULATE----------------------------------
 *
 * Procedure:
 *   DBMS_MEMOPTIMZE.POPULATE()
 *
 * Description:
 *   Used for populating the in-memory hash index with object's data
 *
 * Parameters:
 *   schema_name    --     Name of object owner of the object
 *   table_name     --     Name of table whose data is to be stored
 *                         into in-memory hash index.
 *   partition_name --     Name of the table partition. If not NULL,
 *                         the data from this particular partition
 *                         will be stored in in-memory hash index.
 *
 *------------------------------------------------------------------*/


      PROCEDURE populate(
          schema_name       in      varchar2,
          table_name        in      varchar2,
          partition_name    in      varchar2 DEFAULT NULL
       );


/*--------------------------DROP_OBJECT-------------------------------
 *
 * Procedure:
 *   DBMS_MEMOPTIMZE.DROP_OBJECT()
 *
 * Description:
 *   Used for dropping an object (table, partition, subpartition) from
 *   in-memory hashindex.
 *
 * Parameters:
 *   schema_name    --     Name of object owner of the object
 *   table_name     --     Name of table whose data is to be stored
 *                         into in-memory hash index.
 *   partition_name --     Name of the table partition. If not NULL,
 *                         the data from this particular partition
 *                         will be stored in in-memory hash index.
 *
 *------------------------------------------------------------------*/


      PROCEDURE drop_object(
          schema_name       in      varchar2,
          table_name        in      varchar2,
          partition_name    in      varchar2 DEFAULT NULL
       );



/********************************************************************
 *                                                                  *
 *           END - APIs for fast lookup project                     *
 *                                                                  *
 *******************************************************************/





/********************************************************************
 *                                                                  *
 *           START - APIs for fast ingest project                   *
 *                                                                  *
 *******************************************************************/

  -----------------------------------------------------------------------------
  -- NAME:
  --     get_apply_hwm_seqid
  --
  -- DESCRIPTION
  --     Returns the global low HWM of sequence numbers that have
  --     successfully been flushed to disk
  --
  -- PARAMETERS:
  --
  -- RETURNS:
  --     Global low HWM sequence id flushed to disk
  --
  -- EXCEPTIONS:
  --
  -----------------------------------------------------------------------------
  FUNCTION get_apply_hwm_seqid
  RETURN binary_double;

  -----------------------------------------------------------------------------
  -- NAME:
  --     get_write_hwm_seqid
  --
  -- DESCRIPTION
  --     Returns the HWM of sequence numbers written by this session; it
  --     is the sequence id of the last write made by this session
  --
  -- PARAMETERS:
  --
  -- RETURNS:
  --     HWM sequence id for writes by this session
  --
  -- EXCEPTIONS:
  --
  -----------------------------------------------------------------------------
  FUNCTION get_write_hwm_seqid
  RETURN binary_double;

  -----------------------------------------------------------------------------
  -- NAME:
  --     write_end
  --
  -- DESCRIPTION
  --     This signals IGA teardown for the current session;
  --     it does cleanup, currently limited flushing all data from the
  --     IGA for the most recently written table
  --
  -- PARAMETERS:
  --     None
  --
  -- RETURNS:
  --     No return value
  --
  -- EXCEPTIONS:
  --     None
  -----------------------------------------------------------------------------
  PROCEDURE write_end;

/********************************************************************
 *                                                                  *
 *           END - APIs for fast ingest project                     *
 *                                                                  *
 *******************************************************************/

end dbms_memoptimize;
/

