create view USER_IND_STATISTICS
            (INDEX_NAME, TABLE_OWNER, TABLE_NAME, PARTITION_NAME, PARTITION_POSITION, SUBPARTITION_NAME,
             SUBPARTITION_POSITION, OBJECT_TYPE, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY,
             AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS, AVG_CACHED_BLOCKS, AVG_CACHE_HIT_RATIO, SAMPLE_SIZE,
             LAST_ANALYZED, GLOBAL_STATS, USER_STATS, STATTYPE_LOCKED, STALE_STATS, SCOPE)
as
SELECT
    o.name, ut.name, ot.name,
    NULL,NULL, NULL, NULL, 'INDEX',
    i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac, i.rowcnt,
    ins.cachedblk, ins.cachehit, i.samplesize, i.analyzetime,
    decode(bitand(i.flags, 2048), 0, 'NO', 'YES'),
    decode(bitand(i.flags, 64), 0, 'NO', 'YES'),
    decode(bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728),
           0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL'),
    case when
           (i.analyzetime is null or
            t.analyzetime is null) then null
         when (i.analyzetime < t.analyzetime or
               (dbms_stats_internal.is_stale(t.obj#,
                  null,
                  null,
                  (m.inserts + m.deletes + m.updates),
                  t.rowcnt, m.flags) > 0)) then 'YES'
         else  'NO'
    end,
    'SHARED'
  FROM
    sys.ind$ i, sys.obj$ o, sys.ind_stats$ ins,
    sys.obj$ ot, sys.user$ ut, sys.tab$ t, sys.mon_mods_v m
  WHERE
      o.obj# = i.obj#
  and bitand(i.flags, 4096) = 0
  and i.type# in (1, 2, 4, 6, 7, 8)
  and i.obj# = ins.obj# (+)
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and ot.obj# = t.obj#
  and t.obj# = m.obj# (+)
  and o.owner# = userenv('SCHEMAID') and o.subname IS NULL
  and o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
  and bitand(o.flags, 128) = 0 -- not in recycle bin
  UNION ALL
  /* Cluster indexes */
  SELECT
    o.name, ut.name, ot.name,
    NULL,NULL, NULL, NULL, 'INDEX',
    i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac, i.rowcnt,
    ins.cachedblk, ins.cachehit, i.samplesize, i.analyzetime,
    decode(bitand(i.flags, 2048), 0, 'NO', 'YES'),
    decode(bitand(i.flags, 64), 0, 'NO', 'YES'),
    -- a cluster index is considered locked if any of the table in
    -- the cluster is locked.
    decode((select
           decode(nvl(sum(decode(bitand(t.trigflag, 67108864), 0, 0, 1)),0),
                  0, 0, 67108864) +
           decode(nvl(sum(decode(bitand(nvl(t.trigflag, 0), 134217728),
                                 0, 0, 1)), 0),
                  0, 0, 134217728)
           from  sys.tab$ t where i.bo# = t.bobj#),
           0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL'),
    case
         when i.analyzetime is null then null
         when
           (select                                 -- STALE
              sum(case when
                      i.analyzetime < tab.analyzetime or
                      (dbms_stats_internal.is_stale(ot.obj#,
                        null,
                        null,
                         (m.inserts + m.deletes + m.updates),
                         tab.rowcnt, m.flags) > 0)
                  then 1 else 0 end)
            from sys.tab$ tab, sys.mon_mods_v m
            where
              m.obj#(+) = tab.obj# and tab.bobj# = i.bo#) > 0 then 'YES'
         else 'NO' end,
    'SHARED'
  FROM
    sys.ind$ i, sys.obj$ o, sys.ind_stats$ ins,
    sys.obj$ ot, sys.user$ ut
  WHERE
      o.obj# = i.obj#
  and bitand(i.flags, 4096) = 0
  and i.type# = 3  /* Cluster index */
  and i.obj# = ins.obj# (+)
  and i.bo# = ot.obj#
  and ot.owner# = ut.user#
  and o.owner# = userenv('SCHEMAID') and o.subname IS NULL
  and o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
  and bitand(o.flags, 128) = 0 -- not in recycle bin
  UNION ALL
  /* Partitions (not local index) */
  SELECT
    io.name, ut.name, ot.name,
    io.subname, ip.part#, NULL, NULL, 'PARTITION',
    ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey,
    ip.clufac, ip.rowcnt, ins.cachedblk, ins.cachehit,
    ip.samplesize, ip.analyzetime,
    decode(bitand(ip.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(ip.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- not a local index, just look at the lock at table level
       decode(bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728),
              0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL')
       FROM sys.tab$ t
       where t.obj# = i.bo#),
    /* stale_stats */
    case     when (i.analyzetime is null or
                   tab.analyzetime is null) then null
             when (i.analyzetime < tab.analyzetime  or
                   (dbms_stats_internal.is_stale(tab.obj#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tab.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ io, sys.indpartv$ ip, sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tab$ tab, sys.mon_mods_v m
  WHERE
      io.obj# = ip.obj#
  and ip.obj# = ins.obj# (+)
  and ip.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and io.owner# = userenv('SCHEMAID')
  and tab.obj# = i.bo# and tab.obj# = m.obj# (+)
  and io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL
  and bitand(io.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 0   -- not local index
  UNION ALL
  /* Partitions (local index) */
  SELECT
    io.name, ut.name, ot.name,
    io.subname, ip.part#, NULL, NULL, 'PARTITION',
    ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey, ip.dblkkey,
    ip.clufac, ip.rowcnt, ins.cachedblk, ins.cachehit,
    ip.samplesize, ip.analyzetime,
    decode(bitand(ip.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(ip.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- local index, we need to see if the corresponding partn is locked
       decode(
       /*
        * Following decode returns 1 if DATA stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 67108864) + bitand(tp.flags, 32), 0, 0, 1) +
       /*
        * Following decode returns 2 if CACHE stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 134217728) + bitand(tp.flags, 64), 0, 0, 2),
       /* if 0 => not locked, 3 => data and cache stats locked */
       0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL')
       FROM sys.tabpartv$ tp, sys.tab$ t
       where tp.bo# = i.bo# and tp.phypart# = ip.phypart# and
             tp.bo# = t.obj#),
    /* stale_stats */
    case     when (ip.analyzetime is null or
                   tp.analyzetime is null) then null
             when (ip.analyzetime < tp.analyzetime  or
                   (dbms_stats_internal.is_stale(tp.bo#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tp.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ io, sys.indpartv$ ip, sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tabpartv$ tp, sys.mon_mods_v m
  WHERE
      io.obj# = ip.obj#
  and ip.obj# = ins.obj# (+)
  and ip.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and io.owner# = userenv('SCHEMAID')
  and tp.bo# = i.bo# and tp.phypart# = ip.phypart#
  and tp.obj# = m.obj# (+)
  and io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL
  and bitand(io.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 1   -- local index
  UNION ALL
  /* Composite partitions (not local index) */
  SELECT
    io.name, ut.name, ot.name,
    io.subname, icp.part#, NULL, NULL, 'PARTITION',
    icp.blevel, icp.leafcnt, icp.distkey, icp.lblkkey, icp.dblkkey,
    icp.clufac, icp.rowcnt, ins.cachedblk, ins.cachehit,
    icp.samplesize, icp.analyzetime,
    decode(bitand(icp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(icp.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- not a local index, just look at the lock at table level
       decode(bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728),
              0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL')
       FROM sys.tab$ t
       where t.obj# = i.bo#),
    /* stale_stats */
    case     when (i.analyzetime is null or
                   tab.analyzetime is null) then null
             when (i.analyzetime < tab.analyzetime  or
                   (dbms_stats_internal.is_stale(tab.obj#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tab.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ io, sys.indcompartv$ icp, sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tab$ tab, sys.mon_mods_v m
  WHERE
      io.obj# = icp.obj#
  and io.obj# = ins.obj# (+)
  and icp.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and io.owner# = userenv('SCHEMAID')
  and tab.obj# = i.bo# and tab.obj# = m.obj# (+)
  and io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL
  and bitand(io.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 0   -- not local index
  UNION ALL
  /* Composite partitions (local index) */
  SELECT
    io.name, ut.name, ot.name,
    io.subname, icp.part#, NULL, NULL, 'PARTITION',
    icp.blevel, icp.leafcnt, icp.distkey, icp.lblkkey, icp.dblkkey,
    icp.clufac, icp.rowcnt, ins.cachedblk, ins.cachehit,
    icp.samplesize, icp.analyzetime,
    decode(bitand(icp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(icp.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- local index, we need to see if the corresponding partn is locked
       decode(
       /*
        * Following decode returns 1 if DATA stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 67108864) + bitand(tcp.flags, 32), 0, 0, 1) +
       /*
        * Following decode returns 2 if CACHE stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 134217728) + bitand(tcp.flags, 64), 0, 0, 2),
       /* if 0 => not locked, 3 => data and cache stats locked */
       0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL')
       FROM sys.tabcompartv$ tcp, sys.tab$ t
       where tcp.bo# = i.bo# and tcp.phypart# = icp.phypart# and
             tcp.bo# = t.obj#),
    /* stale_stats */
    case     when (icp.analyzetime is null or
                   tcp.analyzetime is null) then null
             when (icp.analyzetime < tcp.analyzetime  or
                   (dbms_stats_internal.is_stale(tcp.bo#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tcp.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ io, sys.indcompartv$ icp, sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tabcompartv$ tcp, sys.mon_mods_v m
  WHERE
      io.obj# = icp.obj#
  and io.obj# = ins.obj# (+)
  and icp.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and io.owner# = userenv('SCHEMAID')
  and tcp.bo# = i.bo# and tcp.phypart# = icp.phypart#
  and tcp.obj# = m.obj# (+)
  and io.namespace = 4 and io.remoteowner IS NULL and io.linkname IS NULL
  and bitand(io.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 1   -- local index
  UNION ALL
  /* Subpartitions (not local index) */
  SELECT
    op.name, ut.name, ot.name,
    op.subname, icp.part#, os.subname, isp.subpart#,
    'SUBPARTITION',
    isp.blevel, isp.leafcnt, isp.distkey, isp.lblkkey, isp.dblkkey,
    isp.clufac, isp.rowcnt, ins.cachedblk, ins.cachehit,
    isp.samplesize, isp.analyzetime,
    decode(bitand(isp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(isp.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- not a local index, just look at the lock at table level
       decode(bitand(t.trigflag, 67108864) + bitand(t.trigflag, 134217728),
              0, NULL, 67108864, 'DATA', 134217728, 'CACHE', 'ALL')
       FROM sys.tab$ t
       where t.obj# = i.bo#),
    /* stale_stats */
    case     when (i.analyzetime is null or
                   tab.analyzetime is null) then null
             when (i.analyzetime < tab.analyzetime  or
                   (dbms_stats_internal.is_stale(tab.obj#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tab.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ os, sys.obj$ op, sys.indcompartv$ icp, sys.indsubpartv$ isp,
    sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tab$ tab, sys.mon_mods_v m
  WHERE
      os.obj# = isp.obj#
  and op.obj# = icp.obj#
  and icp.obj# = isp.pobj#
  and isp.obj# = ins.obj# (+)
  and icp.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and op.owner# = userenv('SCHEMAID')
  and tab.obj# = i.bo# and tab.obj# = m.obj# (+)
  and op.namespace = 4 and op.remoteowner IS NULL and op.linkname IS NULL
  and bitand(op.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 0   -- not local index
  UNION ALL
  /* Subpartitions (local index) */
  SELECT
    op.name, ut.name, ot.name,
    op.subname, icp.part#, os.subname, isp.subpart#,
    'SUBPARTITION',
    isp.blevel, isp.leafcnt, isp.distkey, isp.lblkkey, isp.dblkkey,
    isp.clufac, isp.rowcnt, ins.cachedblk, ins.cachehit,
    isp.samplesize, isp.analyzetime,
    decode(bitand(isp.flags, 16), 0, 'NO', 'YES'),
    decode(bitand(isp.flags, 8), 0, 'NO', 'YES'),
    /* stattype_locked */
    (select
       -- local index, we need to see if the corresponding composite partn
       -- is locked
       decode(
       /*
        * Following decode returns 1 if DATA stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 67108864) + bitand(tcp.flags, 32), 0, 0, 1) +
       /*
        * Following decode returns 2 if CACHE stats locked for partition
        * or at table level
        */
       decode(bitand(t.trigflag, 134217728) + bitand(tcp.flags, 64), 0, 0, 2),
       /* if 0 => not locked, 3 => data and cache stats locked */
       0, NULL, 1, 'DATA', 2, 'CACHE', 'ALL')
       FROM  sys.tabcompartv$ tcp, sys.tabsubpartv$ tsp, sys.tab$ t
       where tcp.bo# = i.bo# and tcp.phypart# = icp.phypart# and
             tsp.pobj# = tcp.obj# and
             isp.physubpart# = tsp.physubpart# and
             tcp.bo# = t.obj#),
    /* stale_stats */
    case     when (isp.analyzetime is null or
                   tsp.analyzetime is null) then null
             when (isp.analyzetime < tsp.analyzetime  or
                   (dbms_stats_internal.is_stale(tcp.bo#,
                      null,
                      null,
                      (m.inserts + m.deletes + m.updates),
                      tsp.rowcnt, m.flags) > 0)) then 'YES'
             else 'NO'
    end,
    'SHARED'
  FROM
    sys.obj$ os, sys.obj$ op, sys.indcompartv$ icp, sys.indsubpartv$ isp,
    sys.ind_stats$ ins,
    sys.ind$ i, sys.obj$ ot, sys.user$ ut, sys.partobj$ po,
    sys.tabcompartv$ tcp, sys.tabsubpartv$ tsp, sys.mon_mods_v m
  WHERE
      os.obj# = isp.obj#
  and op.obj# = icp.obj#
  and icp.obj# = isp.pobj#
  and isp.obj# = ins.obj# (+)
  and icp.bo# = i.obj#
  and i.type# != 9  --  no domain indexes
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and i.obj# = po.obj#
  and op.owner# = userenv('SCHEMAID')
  and tcp.bo# = i.bo# and tcp.phypart# = icp.phypart#
  and tsp.pobj# = tcp.obj#
  and isp.physubpart# = tsp.physubpart#
  and tsp.obj# = m.obj# (+)
  and op.namespace = 4 and op.remoteowner IS NULL and op.linkname IS NULL
  and bitand(op.flags, 128) = 0 -- not in recycle bin
  and bitand(po.flags, 1) = 1   -- local index
UNION ALL
  SELECT
    o.name, ut.name, ot.name,
    NULL,NULL, NULL, NULL, 'INDEX',
    sesi.blevel_kxttst_is, sesi.leafcnt_kxttst_is,
    sesi.distkey_kxttst_is, sesi.lblkkey_kxttst_is,
    sesi.dblkkey_kxttst_is, sesi.clufac_kxttst_is, sesi.rowcnt_kxttst_is,
    sesi.cachedblk_kxttst_is, sesi.cachehit_kxttst_is,
    sesi.samplesize_kxttst_is, sesi.analyzetime_kxttst_is,
    decode(bitand(sesi.flags_kxttst_is, 2048), 0, 'NO', 'YES'),
    decode(bitand(sesi.flags_kxttst_is, 64), 0, 'NO', 'YES'),
    null,       /* no lock on session private stats */
    null,       /* session based dml monitoring not available */
    'SESSION'
  FROM
    sys.x$kxttsteis sesi,
    sys.ind$ i, sys.obj$ o,
    sys.obj$ ot, sys.user$ ut
  WHERE
      o.obj# = i.obj#
  and i.obj# = sesi.obj#_kxttst_is
  and bitand(i.flags, 4096) = 0
  and i.type# in (1, 2, 4, 6, 7, 8)
  and i.bo# = ot.obj#
  and ot.type# = 2
  and ot.owner# = ut.user#
  and o.owner# = userenv('SCHEMAID') and o.subname IS NULL
  and o.namespace = 4 and o.remoteowner IS NULL and o.linkname IS NULL
  and bitand(o.flags, 128) = 0 -- not in recycle bin
/

comment on table USER_IND_STATISTICS is 'Optimizer statistics for user''s own indexes'
/

comment on column USER_IND_STATISTICS.INDEX_NAME is 'Name of the index'
/

comment on column USER_IND_STATISTICS.TABLE_OWNER is 'Owner of the indexed object'
/

comment on column USER_IND_STATISTICS.TABLE_NAME is 'Name of the indexed object'
/

comment on column USER_IND_STATISTICS.PARTITION_NAME is 'Name of the partition'
/

comment on column USER_IND_STATISTICS.PARTITION_POSITION is 'Position of the partition within index'
/

comment on column USER_IND_STATISTICS.SUBPARTITION_NAME is 'Name of the subpartition'
/

comment on column USER_IND_STATISTICS.SUBPARTITION_POSITION is 'Position of the subpartition within partition'
/

comment on column USER_IND_STATISTICS.OBJECT_TYPE is 'Type of the object (INDEX, PARTITION, SUBPARTITION)'
/

comment on column USER_IND_STATISTICS.BLEVEL is 'B-Tree level'
/

comment on column USER_IND_STATISTICS.LEAF_BLOCKS is 'The number of leaf blocks in the index'
/

comment on column USER_IND_STATISTICS.DISTINCT_KEYS is 'The number of distinct keys in the index'
/

comment on column USER_IND_STATISTICS.AVG_LEAF_BLOCKS_PER_KEY is 'The average number of leaf blocks per key'
/

comment on column USER_IND_STATISTICS.AVG_DATA_BLOCKS_PER_KEY is 'The average number of data blocks per key'
/

comment on column USER_IND_STATISTICS.CLUSTERING_FACTOR is 'A measurement of the amount of (dis)order of the table this index is for'
/

comment on column USER_IND_STATISTICS.NUM_ROWS is 'The number of rows in the index'
/

comment on column USER_IND_STATISTICS.AVG_CACHED_BLOCKS is 'Average number of blocks in buffer cache'
/

comment on column USER_IND_STATISTICS.AVG_CACHE_HIT_RATIO is 'Average cache hit ratio for the object'
/

comment on column USER_IND_STATISTICS.SAMPLE_SIZE is 'The sample size used in analyzing this index'
/

comment on column USER_IND_STATISTICS.LAST_ANALYZED is 'The date of the most recent time this index was analyzed'
/

comment on column USER_IND_STATISTICS.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column USER_IND_STATISTICS.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column USER_IND_STATISTICS.STATTYPE_LOCKED is 'type of statistics lock'
/

comment on column USER_IND_STATISTICS.STALE_STATS is 'Whether statistics for the object is stale or not'
/

comment on column USER_IND_STATISTICS.SCOPE is 'whether statistics for the object is shared or session'
/

