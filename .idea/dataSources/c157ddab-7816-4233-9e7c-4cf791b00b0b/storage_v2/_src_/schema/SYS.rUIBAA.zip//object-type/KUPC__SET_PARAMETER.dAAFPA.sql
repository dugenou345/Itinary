create TYPE kupc$_set_parameter FORCE UNDER kupc$_shadow_msg (
                                parameter_name     VARCHAR2(30),
                                parameter_value_t  VARCHAR2(4000),
                                parameter_value_n  NUMBER,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                pn   VARCHAR2,
                                pvt  VARCHAR2,
                                pvn  NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                qh   NUMBER,
                                pn   VARCHAR2,
                                pvt  VARCHAR2,
                                pvn  NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                pn   VARCHAR2,
                                pvt  VARCHAR2
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                qh   NUMBER,
                                pn   VARCHAR2,
                                pvt  VARCHAR2
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                pn   VARCHAR2,
                                pvn  NUMBER
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_set_parameter(
                                qh   NUMBER,
                                pn   VARCHAR2,
                                pvn  NUMBER
                                ) RETURN SELF AS RESULT
        )
/

