create view USER_SCHEDULER_JOBS
            (JOB_NAME, JOB_SUBNAME, JOB_STYLE, JOB_CREATOR, CLIENT_ID, GLOBAL_UID, PROGRAM_OWNER, PROGRAM_NAME,
             JOB_TYPE, JOB_ACTION, NUMBER_OF_ARGUMENTS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE,
             REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, EVENT_RULE,
             FILE_WATCHER_OWNER, FILE_WATCHER_NAME, END_DATE, JOB_CLASS, ENABLED, AUTO_DROP, RESTART_ON_RECOVERY,
             RESTART_ON_FAILURE, STATE, JOB_PRIORITY, RUN_COUNT, UPTIME_RUN_COUNT, MAX_RUNS, FAILURE_COUNT,
             UPTIME_FAILURE_COUNT, MAX_FAILURES, RETRY_COUNT, LAST_START_DATE, LAST_RUN_DURATION, NEXT_RUN_DATE,
             SCHEDULE_LIMIT, MAX_RUN_DURATION, LOGGING_LEVEL, STORE_OUTPUT, STOP_ON_WINDOW_CLOSE, INSTANCE_STICKINESS,
             RAISE_EVENTS, SYSTEM, JOB_WEIGHT, NLS_ENV, SOURCE, NUMBER_OF_DESTINATIONS, DESTINATION_OWNER, DESTINATION,
             CREDENTIAL_OWNER, CREDENTIAL_NAME, INSTANCE_ID, DEFERRED_DROP, ALLOW_RUNS_IN_RESTRICTED_MODE, COMMENTS,
             FLAGS, RESTARTABLE, HAS_CONSTRAINTS, CONNECT_CREDENTIAL_OWNER, CONNECT_CREDENTIAL_NAME,
             FAIL_ON_SCRIPT_ERROR)
as
SELECT jo.name, jo.subname, 'REGULAR', j.creator, j.client_id, j.guid,
    DECODE(bitand(j.flags,4194304),4194304,
      substr(j.program_action,1,instr(j.program_action,'"')-1),NULL),
    /* PROGRAM_NAME */
    DECODE(bitand(j.flags,4194304),4194304,
      substr(j.program_action,instr(j.program_action,'"')+1,
        length(j.program_action)-instr(j.program_action,'"')) ,NULL),
    /* JOB_TYPE */
    DECODE(BITAND(j.flags,131072+262144+2097152+524288+281474976710656+
                          562949953421312+1125899906842624),
      131072, 'PLSQL_BLOCK', 262144, 'STORED_PROCEDURE',
      2097152, 'EXECUTABLE', 524288, 'CHAIN',
      281474976710656, 'EXTERNAL_SCRIPT', 562949953421312, 'SQL_SCRIPT',
      1125899906842624, 'BACKUP_SCRIPT', NULL),
    /* JOB_ACTION */
    DECODE(bitand(j.flags,4194304),0,j.program_action,NULL),
    /* NUMBER_OF_ARGUMENTS */
    j.number_of_args,
    /* SCHEDULE_OWNER */
    DECODE(bitand(j.flags,1024+4096),0,NULL,
      substr(j.schedule_expr,1,instr(j.schedule_expr,'"')-1)),
    /* SCHEDULE_NAME */
    DECODE(bitand(j.flags,1024+4096),0,NULL,
      substr(j.schedule_expr,instr(j.schedule_expr,'"') + 1,
        length(j.schedule_expr)-instr(j.schedule_expr,'"'))),
    /* SCHEDULE_TYPE */
    DECODE(BITAND(j.flags, 1+2+512+1024+2048+4096+8192+16384+134217728+34359738368),
      512,'PLSQL',1024,'NAMED',2048,'CALENDAR',4096,'WINDOW',4098,'WINDOW_GROUP',
      8192,'ONCE',16384,'IMMEDIATE',34493956096, 'FILE_WATCHER',
      134217728,'EVENT',NULL),
    /* START_DATE */
    j.start_date,
    /* REPEAT_INTERVAL */
    DECODE(BITAND(j.flags,1024+4096+134217728), 0, j.schedule_expr, NULL),
    /* EVENT_QUEUE_OWNER */
    j.queue_owner,
    /* EVENT_QUEUE_NAME */
    j.queue_name,
    /* EVENT_QUEUE_AGENT */
    j.queue_agent,
    /* EVENT_CONDITION */
    DECODE(BITAND(j.flags,134217728), 0, NULL,
      DECODE(BITAND(j.flags,1024+4096), 0, j.schedule_expr, NULL)),
    /* EVENT_RULE */
    j.event_rule,
    /* FILE_WATCHER_OWNER */
    DECODE(BITAND(j.flags, 34359738368), 0, NULL,
      substr(j.fw_name,1,instr(j.fw_name,'"')-1)),
    /* FILE_WATCHER_NAME */
    DECODE(BITAND(j.flags, 34359738368), 0, NULL,
      substr(j.fw_name,instr(j.fw_name,'"') + 1,
        length(j.fw_name)-instr(j.fw_name,'"'))),
    /* END_DATE */
    j.end_date,
    /* JOB_CLASS */
    co.name,
    /* ENABLED */
    DECODE(BITAND(j.job_status,1),0,'FALSE','TRUE'),
    /* AUTO_DROP */
    DECODE(BITAND(j.flags,32768),0,'TRUE','FALSE'),
    /* RESTART_ON_RECOVERY */
    DECODE(BITAND(j.flags, 35184372088832),0,'FALSE','TRUE'),
    /* RESTART_ON_FAILURE */
    DECODE(BITAND(j.flags, 70368744177664),0,'FALSE','TRUE'),
    /* STATE */
    (CASE WHEN j.job_dest_id <> 0 AND
     bitand(j.flags, 549755813888) <> 0 THEN 'RUNNING'
     ELSE
    DECODE(BITAND(j.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
    DECODE(BITAND(j.job_status,1+4+8+16+32+128+8192+524288),0,'DISABLED',1,
      (CASE WHEN j.retry_count>0  AND bitand(j.flags, 549755813888) = 0
            THEN 'RETRY SCHEDULED'
            WHEN (bitand(j.job_status, 1024) <> 0) THEN 'READY TO RUN'
            WHEN (bitand(j.job_status,8589934592)=8589934592) THEN 'BLOCKED'
            WHEN (bitand(j.job_status,4294967296)=4294967296)
                      THEN 'RESOURCE_UNAVAILABLE'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED',
      524288, 'SOME FAILED', NULL)) END),
    j.priority, j.run_count, cast(NULL as number), j.max_runs,
    j.failure_count, cast(NULL as number), j.max_failures,
    decode(bitand(j.flags, 549755813888), 0, j.retry_count, 0),
    /* LAST_START_DATE */
    j.last_start_date,
    /* LAST_RUN_DURATION */
    (CASE WHEN j.last_end_date>j.last_start_date THEN j.last_end_date-j.last_start_date
       ELSE NULL END),
    /* NEXT_RUN_DATE */
    j.next_run_date,
    /* SCHEDULE_LIMIT */
    j.schedule_limit,
    /* MAX_RUN_DURATION */
    j.max_run_duration,
    /* LOGGING_LEVEL */
    DECODE(BITAND(j.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
    /* STORE_OUTPUT */
    DECODE(BITAND(j.flags,9007199254740992),0,'FALSE','TRUE'),
    /* STOP_ON_WINDOW_CLOSE */
    DECODE(BITAND(j.flags,8),0,'FALSE','TRUE'),
    /* INSTANCE_STICKINESS */
    DECODE(BITAND(j.flags,16),0,'FALSE','TRUE'),
    /* RAISE_EVENTS */
    sys.dbms_scheduler.generate_event_list(j.job_status),
    /* SYSTEM */
    DECODE(BITAND(j.flags,16777216),0,'FALSE','TRUE'),
    /* JOB_WEIGHT */
    j.job_weight,
    /* NLS_ENV */
    j.nls_env,
    /* SOURCE */
    j.source,
    /* NUMBER_OF_DESTINATIONS */
    decode(bitand(j.flags, 274877906944), 0, 1,
    decode(bitand(j.flags, 549755813888), 0, 1,
    (select count(*) from user_scheduler_job_dests ujd
     where ujd.job_name = jo.name))),
    /* DESTINATION_OWNER */
    decode(bitand(j.flags, 274877906944), 0, NULL,
       substr(j.destination, 1, instr(j.destination, '"')-1)),
    /* DESTINATION */
    decode(bitand(j.flags, 274877906944), 0, j.destination,
    substr(j.destination, instr(j.destination, '"')+1,
           length(j.destination) - instr(j.destination, '"'))),
    /* CREDENTIAL_OWNER */
    j.credential_owner,
    /* CREDENTIAL_NAME */
    j.credential_name,
    /* INSTANCE_ID */
    j.instance_id,
    /* DEFERRED_DROP */
    DECODE(BITAND(j.job_status,131072),0,'FALSE','TRUE'),
    /* ALLOW_RUNS_IN_RESTRICTED_MODE */
    DECODE(BITAND(j.flags,17179869184),0,'FALSE','TRUE'),
    /* COMMENTS */
    j.comments,
    /* FLAGS */
    j.flags,
    /* RESTARTABLE */
    DECODE(BITAND(j.flags,35184372088832 + 70368744177664),
          35184372088832 + 70368744177664,'TRUE','FALSE'),
    /* has_constraints */
    DECODE(BITAND(j.flags,2251799813685248),0,'FALSE','TRUE'),
    /* connect credential owner and name */
    j.connect_credential_owner, j.connect_credential_name,
    /* FAIL_ON_SCRIPT_ERROR*/
    DECODE(BITAND(j.flags, 36028797018963968), 0,'FALSE', 'TRUE')
  FROM sys.scheduler$_job j, obj$ jo, obj$ co
  WHERE j.obj# = jo.obj# AND
    j.class_oid = co.obj#(+) AND jo.owner# = USERENV('SCHEMAID')
  AND ( (j.database_role = SYS_CONTEXT('userenv','database_role')) OR
        (j.database_role = 'ALL')           OR
        (j.database_role is null AND SYS_CONTEXT('userenv','database_role') = 'PRIMARY'))
 UNION ALL
  SELECT
    /* JOB_NAME */
    lo.name,
    /* JOB_SUBNAME */
    lo.subname,
    /* JOB_STYLE */
    decode(bitand(l.flags, 17592186044416), 0, 'LIGHTWEIGHT',
      'IN_MEMORY_RUNTIME'),
    /* JOB_CREATOR */
    l.creator,
    /* CLIENT_ID */
    l.client_id,
    /* GLOBAL_UID */
    l.guid,
    /* PROGRAM_OWNER */
    lu.name,
    /* PROGRAM_NAME */
    po.name,
    /* JOB_TYPE */
    NULL,
    /* JOB_ACTION */
    NULL,
    /* NUMBER_OF_ARGUMENTS */
    NULL,
    /* SCHEDULE_OWNER */
    DECODE(bitand(l.flags,1024+4096),0,NULL,
      substr(l.schedule_expr,1,instr(l.schedule_expr,'"')-1)),
    /* SCHEDULE_NAME */
    DECODE(bitand(l.flags,1024+4096),0,NULL,
      substr(l.schedule_expr,instr(l.schedule_expr,'"') + 1,
        length(l.schedule_expr)-instr(l.schedule_expr,'"'))),
    /* SCHEDULE_TYPE */
    DECODE(BITAND(l.flags, 1+2+512+1024+2048+4096+8192+16384+134217728+34359738368),
      512,'PLSQL',1024,'NAMED',2048,'CALENDAR',4096,'WINDOW',4098,'WINDOW_GROUP',
      8192,'ONCE',16384,'IMMEDIATE',34493956096, 'FILE_WATCHER',
      134217728,'EVENT',NULL),
    /* START_DATE */
    l.start_date,
    /* REPEAT_INTERVAL */
    DECODE(BITAND(l.flags,1024+4096+134217728), 0, l.schedule_expr, NULL),
    /* EVENT_QUEUE_OWNER */
    l.queue_owner,
    /* EVENT_QUEUE_NAME */
    l.queue_name,
    /* EVENT_QUEUE_AGENT */
    l.queue_agent,
    /* EVENT_CONDITION */
    DECODE(BITAND(l.flags,134217728), 0, NULL,
      DECODE(BITAND(l.flags,1024+4096), 0, l.schedule_expr, NULL)),
    /* EVENT_RULE */
    l.event_rule,
    /* FILE_WATCHER_OWNER */
    DECODE(BITAND(l.flags, 34359738368), 0, NULL,
      substr(l.fw_name,1,instr(l.fw_name,'"')-1)),
    /* FILE_WATCHER_NAME */
    DECODE(BITAND(l.flags, 34359738368), 0, NULL,
      substr(l.fw_name,instr(l.fw_name,'"') + 1,
        length(l.fw_name)-instr(l.fw_name,'"'))),
    /* END_DATE */
    l.end_date,
    /* JOB_CLASS */
    lco.name,
    /* ENABLED */
    DECODE(BITAND(l.job_status,1),0,'FALSE','TRUE'),
    /* AUTO_DROP */
    DECODE(BITAND(l.flags,32768),0,'TRUE','FALSE'),
    /* RESTART_ON_RECOVERY */
    DECODE(BITAND(l.flags, 35184372088832),0,'FALSE','TRUE'),
    /* RESTART_ON_FAILURE */
    DECODE(BITAND(l.flags, 70368744177664),0,'FALSE','TRUE'),
    /* STATE */
    DECODE(BITAND(l.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
    DECODE(BITAND(l.job_status,1+4+8+16+32+128+8192),0,'DISABLED',1,
      (CASE WHEN l.retry_count>0 THEN 'RETRY SCHEDULED'
            WHEN (bitand(l.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)),
    NULL,
    decode(bitand(l.flags, 17592186044416), 0,
           l.run_count, cast(NULL as number)),
    decode(bitand(l.flags, 17592186044416), 0,
           cast(NULL as number), l.run_count),
    NULL,
    decode(bitand(l.flags, 17592186044416), 0,
           l.failure_count, cast(NULL as number)),
    decode(bitand(l.flags, 17592186044416), 0,
           cast(NULL as number), l.failure_count),
    NULL,
    l.retry_count, l.last_start_date,
    (CASE WHEN l.last_end_date>l.last_start_date THEN l.last_end_date-l.last_start_date
       ELSE NULL END),
    /* NEXT_RUN_DATE */
    l.next_run_date,
    /* SCHEDULE_LIMIT */
    NULL,
    /* MAX_RUN_DURATION */
    NULL,
    /* LOGGING_LEVEL */
    DECODE(BITAND(l.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
    /* STORE_OUTPUT */
    DECODE(BITAND(l.flags,9007199254740992),0,'FALSE','TRUE'),
    /* STOP_ON_WINDOW_CLOSE */
    DECODE(BITAND(l.flags,8),0,'FALSE','TRUE'),
    /* INSTANCE_STICKINESS */
    DECODE(BITAND(l.flags,16),0,'FALSE','TRUE'),
    /* RAISE_EVENTS */
    sys.dbms_scheduler.generate_event_list(l.job_status),
    /* SYSTEM */
    DECODE(BITAND(l.flags,16777216),0,'FALSE','TRUE'),
    /* JOB_WEIGHT */
    NULL,
    /* NLS_ENV */
    NULL,
    /* SOURCE */
    NULL,
    /* NUMBER_OF_DESTINATIONS */
    1,
    /* DESTINATION_OWNER */
    NULL,
    /* DESTINATION */
    NULL,
    /* CREDENTIAL_OWNER */
    NULL,
    /* CREDENTIAL_NAME */
    NULL,
    /* INSTANCE_ID */
    l.instance_id,
    /* DEFERRED_DROP */
    DECODE(BITAND(l.job_status,131072),0,'FALSE','TRUE'),
    /* ALLOW_RUNS_IN_RESTRICTED_MODE */
    DECODE(BITAND(l.flags,17179869184),0,'FALSE','TRUE'),
    /* COMMENTS */
    NULL,
    /* FLAGS */
    l.flags,
    /* RESTARTABLE */
    DECODE(BITAND(l.flags,35184372088832 + 70368744177664),
            35184372088832 + 70368744177664,'TRUE','FALSE'),
    'FALSE', NULL, NULL,
    /* FAIL_ON_SCRIPT_ERROR */
    NULL
  FROM scheduler$_lwjob_obj lo, user$ lu, obj$ lco,
    scheduler$_comb_lw_job l, obj$ po
  WHERE ((bitand(l.flags, 8589934592) = 0 AND po.type# = 67) OR
         (bitand(l.flags, 8589934592) <> 0 AND po.type# = 66))
    AND bitand(l.flags, 137438953472) = 0
    AND l.obj# = lo.obj# AND l.program_oid = po.obj#
    AND lo.userid = lu.user# AND
    l.class_oid = lco.obj#(+) AND lu.user# = USERENV('SCHEMAID')
UNION ALL
 SELECT mr.name, NULL, 'IN_MEMORY_FULL', md.creator, md.client_id,
   md.guid, mu.name, mpo.name, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   mco.name, decode(bitand(mr.job_status, 1), 1, 'TRUE', 'FALSE'), 'TRUE',
   'FALSE', 'FALSE',
   DECODE(BITAND(mr.job_status,2+65536),2,'RUNNING',2+65536,'CHAIN_STALLED',
     DECODE(BITAND(mr.job_status,1+4+8+16+32+128+8192),0,'DISABLED',1,
      (CASE WHEN (bitand(mr.job_status, 1024) <> 0) THEN 'READY TO RUN'
            ELSE 'SCHEDULED' END),
      4,'COMPLETED',8,'BROKEN',16,'FAILED',
      32,'SUCCEEDED' ,128,'REMOTE',8192, 'STOPPED', NULL)),
   NULL, cast(NULL as number), mr.run_count, NULL,
   cast(NULL as number), mr.failure_count, NULL, NULL, mr.last_start_date,
   NULL, mr.next_run_date, NULL, NULL,
   DECODE(BITAND(md.flags,32+64+128+256),32,'OFF',64,'RUNS',128,'FAILED RUNS',
      256,'FULL',NULL),
   DECODE(BITAND(md.flags,9007199254740992),0,'FALSE','TRUE'),
   'FALSE', 'TRUE', NULL,
   DECODE(BITAND(md.flags,16777216),0,'FALSE','TRUE'),
   NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, md.instance_id, 'FALSE', 'FALSE',
   NULL, md.flags, 'FALSE', 'FALSE', NULL, NULL,
   /* FAIL_ON_SCRIPT_ERROR */
   NULL
 FROM GV$SCHEDULER_INMEM_MDINFO md, GV$SCHEDULER_INMEM_RTINFO mr,
      obj$ mpo, user$ mu, obj$ mco
 WHERE md.objid = mr.objid and mpo.obj# = md.prgoid and md.clsoid = mco.obj#(+)
  AND mu.user# = mr.userid AND mu.user# = USERENV('SCHEMAID') AND mr.id_type = 2
/

comment on table USER_SCHEDULER_JOBS is 'All scheduler jobs in the database'
/

comment on column USER_SCHEDULER_JOBS.JOB_NAME is 'Name of the scheduler job'
/

comment on column USER_SCHEDULER_JOBS.JOB_SUBNAME is 'Subname of the scheduler job (for a job running a chain step)'
/

comment on column USER_SCHEDULER_JOBS.JOB_STYLE is 'Job style - regular, lightweight or volatile'
/

comment on column USER_SCHEDULER_JOBS.JOB_CREATOR is 'Original creator of this job'
/

comment on column USER_SCHEDULER_JOBS.CLIENT_ID is 'Client id of user creating this job'
/

comment on column USER_SCHEDULER_JOBS.GLOBAL_UID is 'Global uid of user creating this job'
/

comment on column USER_SCHEDULER_JOBS.PROGRAM_OWNER is 'Owner of the program associated with the job'
/

comment on column USER_SCHEDULER_JOBS.PROGRAM_NAME is 'Name of the program associated with the job'
/

comment on column USER_SCHEDULER_JOBS.JOB_TYPE is 'Inlined job action type'
/

comment on column USER_SCHEDULER_JOBS.JOB_ACTION is 'Inlined job action'
/

comment on column USER_SCHEDULER_JOBS.NUMBER_OF_ARGUMENTS is 'Inlined job number of arguments'
/

comment on column USER_SCHEDULER_JOBS.SCHEDULE_OWNER is 'Owner of the schedule that this job uses (can be a window or window group)'
/

comment on column USER_SCHEDULER_JOBS.SCHEDULE_NAME is 'Name of the schedule that this job uses (can be a window or window group)'
/

comment on column USER_SCHEDULER_JOBS.SCHEDULE_TYPE is 'Type of the schedule that this job uses'
/

comment on column USER_SCHEDULER_JOBS.START_DATE is 'Original scheduled start date of this job (for an inlined schedule)'
/

comment on column USER_SCHEDULER_JOBS.REPEAT_INTERVAL is 'Inlined schedule PL/SQL expression or calendar string'
/

comment on column USER_SCHEDULER_JOBS.EVENT_QUEUE_OWNER is 'Owner of source queue into which event will be raised'
/

comment on column USER_SCHEDULER_JOBS.EVENT_QUEUE_NAME is 'Name of source queue into which event will be raised'
/

comment on column USER_SCHEDULER_JOBS.EVENT_QUEUE_AGENT is 'Name of AQ agent used by user on the event source queue (if it is a secure queue)'
/

comment on column USER_SCHEDULER_JOBS.EVENT_CONDITION is 'Boolean expression used as subscription rule for event on the source queue'
/

comment on column USER_SCHEDULER_JOBS.EVENT_RULE is 'Name of rule used by the coordinator to trigger event based job'
/

comment on column USER_SCHEDULER_JOBS.FILE_WATCHER_OWNER is 'Owner of file watcher on which this job is based'
/

comment on column USER_SCHEDULER_JOBS.FILE_WATCHER_NAME is 'Name of file watcher on which this job is based'
/

comment on column USER_SCHEDULER_JOBS.END_DATE is 'Date after which this job will no longer run (for an inlined schedule)'
/

comment on column USER_SCHEDULER_JOBS.JOB_CLASS is 'Name of job class associated with the job'
/

comment on column USER_SCHEDULER_JOBS.ENABLED is 'Whether the job is enabled'
/

comment on column USER_SCHEDULER_JOBS.AUTO_DROP is 'Whether this job will be dropped when it has completed'
/

comment on column USER_SCHEDULER_JOBS.RESTART_ON_RECOVERY is 'Whether this job can be restarted after a db crash'
/

comment on column USER_SCHEDULER_JOBS.RESTART_ON_FAILURE is 'Whether this job can be re-tried if it fails'
/

comment on column USER_SCHEDULER_JOBS.STATE is 'Current state of the job'
/

comment on column USER_SCHEDULER_JOBS.JOB_PRIORITY is 'Priority of the job relative to others within the same class'
/

comment on column USER_SCHEDULER_JOBS.RUN_COUNT is 'Number of times this job has run'
/

comment on column USER_SCHEDULER_JOBS.MAX_RUNS is 'Maximum number of times this job is scheduled to run'
/

comment on column USER_SCHEDULER_JOBS.FAILURE_COUNT is 'Number of times this job has failed to run'
/

comment on column USER_SCHEDULER_JOBS.MAX_FAILURES is 'Number of times this job will be allowed to fail before being marked broken'
/

comment on column USER_SCHEDULER_JOBS.RETRY_COUNT is 'Number of times this job has retried, if it is retrying.'
/

comment on column USER_SCHEDULER_JOBS.LAST_START_DATE is 'Last date on which the job started running'
/

comment on column USER_SCHEDULER_JOBS.LAST_RUN_DURATION is 'How long the job took last time'
/

comment on column USER_SCHEDULER_JOBS.NEXT_RUN_DATE is 'Next date the job is scheduled to run on'
/

comment on column USER_SCHEDULER_JOBS.SCHEDULE_LIMIT is 'Time in minutes after which a job which has not run yet will be rescheduled'
/

comment on column USER_SCHEDULER_JOBS.MAX_RUN_DURATION is 'This column is reserved for future use'
/

comment on column USER_SCHEDULER_JOBS.LOGGING_LEVEL is 'Amount of logging that will be done pertaining to this job'
/

comment on column USER_SCHEDULER_JOBS.STORE_OUTPUT is 'Determines if full job output is to be stored'
/

comment on column USER_SCHEDULER_JOBS.STOP_ON_WINDOW_CLOSE is 'Whether this job will stop if a window it is associated with closes'
/

comment on column USER_SCHEDULER_JOBS.INSTANCE_STICKINESS is 'Whether this job is sticky'
/

comment on column USER_SCHEDULER_JOBS.RAISE_EVENTS is 'List of job events to raise for this job'
/

comment on column USER_SCHEDULER_JOBS.SYSTEM is 'Whether this is a system job'
/

comment on column USER_SCHEDULER_JOBS.JOB_WEIGHT is 'Weight of this job'
/

comment on column USER_SCHEDULER_JOBS.NLS_ENV is 'NLS environment of this job'
/

comment on column USER_SCHEDULER_JOBS.SOURCE is 'Source global database identifier'
/

comment on column USER_SCHEDULER_JOBS.DESTINATION_OWNER is 'Owner of destination object (if used) else NULL'
/

comment on column USER_SCHEDULER_JOBS.DESTINATION is 'Destination that this job will run on'
/

comment on column USER_SCHEDULER_JOBS.CREDENTIAL_OWNER is 'Owner of login credential'
/

comment on column USER_SCHEDULER_JOBS.CREDENTIAL_NAME is 'Name of login credential'
/

comment on column USER_SCHEDULER_JOBS.INSTANCE_ID is 'Instance user requests job to run on.'
/

comment on column USER_SCHEDULER_JOBS.DEFERRED_DROP is 'Whether this job will be dropped when completed due to user request.'
/

comment on column USER_SCHEDULER_JOBS.COMMENTS is 'Comments on the job'
/

comment on column USER_SCHEDULER_JOBS.FLAGS is 'This column is for internal use.'
/

comment on column USER_SCHEDULER_JOBS.RESTARTABLE is 'Whether this job can be restarted or not'
/

comment on column USER_SCHEDULER_JOBS.HAS_CONSTRAINTS is 'Whether this job (not including program of job) is part of a resource constraint or incompatibility'
/

comment on column USER_SCHEDULER_JOBS.CONNECT_CREDENTIAL_OWNER is 'Owner of connect credential'
/

comment on column USER_SCHEDULER_JOBS.CONNECT_CREDENTIAL_NAME is 'Name of connect credential'
/

comment on column USER_SCHEDULER_JOBS.FAIL_ON_SCRIPT_ERROR is 'Whether this job is set as failed when a script error occurs'
/

