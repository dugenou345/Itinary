create type ku$_triggerdep_t force as object
(
  vers_major  char(1),                                /* UDT major version # */
  vers_minor  char(2),                                /* UDT minor version # */
  obj_num     number,                                     /* obj# of trigger */
  p_trgowner  varchar2(128),                         /* parent trigger owner */
  p_trgname   varchar2(128),                          /* parent trigger name */
  flag        number                              /* 0x01 FOLLOWS dependency */
                                                 /* 0x02 PRECEDES dependency */
                                  /* 0x04 - schema user not specified in ddl */
)
not persistable
/

