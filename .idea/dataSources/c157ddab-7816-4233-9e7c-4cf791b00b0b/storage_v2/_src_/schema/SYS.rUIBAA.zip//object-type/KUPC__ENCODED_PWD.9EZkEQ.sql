create TYPE kupc$_encoded_pwd FORCE UNDER kupc$_master_msg (
                                encoded_pwd RAW(2000),
                                encoded_pwd_len NUMBER,
        CONSTRUCTOR FUNCTION kupc$_encoded_pwd(
                                encPwd    RAW,
                                encPwdLen NUMBER
                               ) RETURN SELF AS RESULT
        )
/

