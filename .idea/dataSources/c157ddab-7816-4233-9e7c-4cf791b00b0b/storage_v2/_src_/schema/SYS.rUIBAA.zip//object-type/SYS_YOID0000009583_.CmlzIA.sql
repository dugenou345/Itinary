create type       "SYS_YOID0000009583$"              as object( "SYS_NC00001$" NUMBER)
/

