create view USER_TABLESPACES
            (TABLESPACE_NAME, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, MAX_SIZE, PCT_INCREASE,
             MIN_EXTLEN, STATUS, CONTENTS, LOGGING, FORCE_LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE,
             SEGMENT_SPACE_MANAGEMENT, DEF_TAB_COMPRESSION, RETENTION, BIGFILE, PREDICATE_EVALUATION, ENCRYPTED,
             COMPRESS_FOR, DEF_INMEMORY, DEF_INMEMORY_PRIORITY, DEF_INMEMORY_DISTRIBUTE, DEF_INMEMORY_COMPRESSION,
             DEF_INMEMORY_DUPLICATE, SHARED, DEF_INDEX_COMPRESSION, INDEX_COMPRESS_FOR, DEF_CELLMEMORY,
             DEF_INMEMORY_SERVICE, DEF_INMEMORY_SERVICE_NAME, LOST_WRITE_PROTECT, CHUNK_TABLESPACE)
as
select ts.name, ts.blocksize, ts.blocksize * ts.dflinit,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                        ts.blocksize * ts.dflincr),
          ts.dflminext,
          decode(ts.contents$, 1, to_number(NULL), ts.dflmaxext),
          decode(bitand(ts.flags, 4096), 4096, ts.affstrength, NULL),
          decode(bitand(ts.flags, 3), 1, to_number(NULL), ts.dflextpct),
          ts.blocksize * ts.dflminlen,
          decode(ts.online$, 1, 'ONLINE', 2, 'OFFLINE',
                 4, 'READ ONLY', 'UNDEFINED'),
          decode(ts.contents$, 0,
                (decode(bitand(ts.flags, 4503599627370512), 16, 'UNDO',
                 4503599627370496, 'LOST WRITE PROTECTION',
                 'PERMANENT')), 1, 'TEMPORARY'),
          decode(bitand(ts.dflogging, 1), 0, 'NOLOGGING', 1, 'LOGGING'),
          decode(bitand(ts.dflogging, 2), 0, 'NO', 2, 'YES'),
          decode(ts.bitmapped, 0, 'DICTIONARY', 'LOCAL'),
          decode(bitand(ts.flags, 3), 0, 'USER', 1, 'SYSTEM', 2, 'UNIFORM',
                 'UNDEFINED'),
          decode(bitand(ts.flags,32), 32,'AUTO', 'MANUAL'),
          --DEF_TAB_COMPRESSION (KTT_COMPRESSED || KTT_TBL_COMPRESSED)
          decode(bitand(ts.flags,64+2251799813685248), 0, 'DISABLED',
                        64, 'ENABLED', 2251799813685248, 'ENABLED',
                        (64+2251799813685248), 'ENABLED'),
          decode(bitand(ts.flags,16), 16, (decode(bitand(ts.flags, 512), 512,
                 'GUARANTEE', 'NOGUARANTEE')), 'NOT APPLY'),
          decode(bitand(ts.flags,256), 256, 'YES', 'NO'),
          decode(tsattr.storattr, 1, 'STORAGE', 'HOST'),
          decode(bitand(ts.flags,16384), 16384, 'YES', 'NO'),
          --COMPRESS_FOR ktstsflg (ktt3.h)
          decode(bitand(ts.flags,64+2251799813685248), 0, null,
            (case when bitand(ts.flags,  65536) = 65536
                    then 'ADVANCED'
                  when bitand(ts.flags, (131072+262144)) = 131072
                    then concat('QUERY LOW',
                                decode(bitand(ts.flags, 4194304), 4194304,
                                       ' ROW LEVEL LOCKING', ''))
                  when bitand(ts.flags, (131072+262144)) = 262144
                    then concat('QUERY HIGH',
                                decode(bitand(ts.flags, 4194304), 4194304,
                                       ' ROW LEVEL LOCKING', ''))
                  when bitand(ts.flags, (131072+262144)) = (131072+262144)
                    then concat('ARCHIVE LOW',
                                decode(bitand(ts.flags, 4194304), 4194304,
                                       ' ROW LEVEL LOCKING', ''))
                  when bitand(ts.flags, 524288) = 524288
                    then concat('ARCHIVE HIGH',
                                decode(bitand(ts.flags, 4194304), 4194304,
                                       ' ROW LEVEL LOCKING', ''))
                  else 'BASIC' end)),
          --DEF_INMEMORY ktstsflg (ktt3.h)
          decode(bitand(ts.flags, 2203318222848),
                  4294967296,     'ENABLED',
                  2199023255552,  'DISABLED', 'DISABLED'),
          --DEF_INMEMORY_PRIORITY
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 34359738368), 34359738368,
                        decode(bitand(ts.flags, 123145302310912),
                        17592186044416, 'LOW',
                        35184372088832, 'MEDIUM',
                        52776558133248, 'HIGH',
                        70368744177664, 'CRITICAL', 'NONE'),
                        'NONE'),
                 null),
          --DEF_INMEMORY_DISTRIBUTE
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 8589934592), 8589934592,
                        decode(bitand(ts.flags, 206158430208),
                        68719476736,   'BY ROWID RANGE',
                        137438953472,  'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        null),
                  null),
          --DEF_INMEMORY_COMPRESSION
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 841813590016),
                              17179869184,  'NO MEMCOMPRESS',
                              274877906944, 'FOR DML',
                              292057776128, 'FOR QUERY LOW',
                              549755813888, 'FOR QUERY HIGH',
                              566935683072, 'FOR CAPACITY LOW',
                              824633720832, 'FOR CAPACITY HIGH',
                              116691496960, 'AUTO', 'UNKNOWN'),
                 null),
          --DEF_INMEMORY_DUPLICATE
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 13194139533312),
                         4398046511104, 'NO DUPLICATE',
                         8796093022208, 'DUPLICATE',
                         13194139533312, 'DUPLICATE ALL', null),
                 null),
          --SHARED
          -- Bits: 0x800000000002
          decode(bitand(ts.flags, 18155135997837312),
                 140737488355328, 'LOCAL_ON_LEAF',
                 18155135997837312, 'LOCAL_ON_ALL', 'SHARED') shared,
          --DEF_INDEX_COMPRESSION (KTT_COMPRESSED || KTT_IDX_COMPRESSED)
          decode(bitand(ts.flags,(64+281474976710656)), 0, 'DISABLED',
                        64, 'ENABLED', 281474976710656, 'ENABLED',
                        (64+281474976710656), 'ENABLED'),
          --INDEX_COMPRESS_FOR
          -- Bits: 0x1000000000000 and 0x6000000000000 and F0000
          decode(bitand(ts.flags, 64), 0,
                    (decode(bitand(ts.flags, 281474976710656), 0, null,
                            (decode(bitand(ts.flags,
                                     (562949953421312 + 1125899906842624)),
                             0,                'NONE',
                             562949953421312,  'ADVANCED LOW',
                             1125899906842624, 'ADVANCED HIGH', 'UNKNOWN')))),
                    (decode(bitand(ts.flags, (65536+131072+262144+524288)),
                             0,                'NONE',
                             -- table OLTP
                             65536,            'ADVANCED LOW',
                             -- table Query Low
                             131072,           'ADVANCED HIGH',
                             -- table Query High
                             262144,           'ADVANCED HIGH',
                             -- table Archive Low
                             (131072+262144),  'ADVANCED HIGH',
                             -- table Archive High
                             524288,           'ADVANCED HIGH', 'UNKNOWN'))),
          -- DEF_CELLMEMORY ktstsflg (ktt3.h)
          -- 0xF80000000000000
          decode(bitand(ts.flags, 1116892707587883008),
                         36028797018963968, 'ENABLED',
                         72057594037927936, 'DISABLED',
                        180143985094819840, 'NO CACHECOMPRESS',
                        324259173170675712, 'FOR QUERY',
                        612489549322387456, 'FOR CAPACITY', null),
          -- DEF_INMEMORY_SERVICE
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 1152921504606846976),
                        1152921504606846976,
                        decode(bitand(svc.svcflags,7),
                               1, 'DEFAULT',
                               2, 'NONE',
                               3, 'ALL',
                               4, 'USER_DEFINED',
                               'DEFAULT'),
                        'DEFAULT'),
                 null),
          -- DEF_INMEMORY_SERVICE_NAME
          decode(bitand(ts.flags, 4294967296), 4294967296,
                 decode(bitand(ts.flags, 1152921504606846976),
                        1152921504606846976, svc.svcname, null),
                  null),
          -- LOST_WRITE_PROTECT
          -- Bits: 0x2000000000000000 and 0x4000000000000000
          -- KTT_LOST_ENABLED and KTT_LOST_SUSPEND (suspended)
          decode(bitand(ts.flags, 6917529027641081856), 0, 'OFF',
                  2305843009213693952, 'ENABLED',
                  4611686018427387904, 'SUSPEND'),
          --Bit: 0x8000000000000000
          --CHUNK_TABLESPACE
          decode(bitand(ts.flags,9223372036854775808),9223372036854775808,'Y','N')
from sys.ts$ ts, x$kcfistsa tsattr, sys.imsvcts$ svc
where ts.online$ != 3
and bitand(flags,2048) != 2048
and bitand(ts.flags, 16777216) != 16777216
      and (   exists (select null from sys.tsq$ tsq
                 where tsq.ts# = ts.ts#
                   and tsq.user# = userenv('SCHEMAID') and
                   (tsq.blocks > 0 or tsq.maxblocks != 0))
           or exists
              (select null
              from sys.v$enabledprivs
              where priv_number = -15 /* UNLIMITED TABLESPACE */))
      and ts.ts# = tsattr.tsid and ts.ts# = svc.ts# (+)
/

comment on table USER_TABLESPACES is 'Description of accessible tablespaces'
/

comment on column USER_TABLESPACES.TABLESPACE_NAME is 'Tablespace name'
/

comment on column USER_TABLESPACES.BLOCK_SIZE is 'Tablespace block size'
/

comment on column USER_TABLESPACES.INITIAL_EXTENT is 'Default initial extent size'
/

comment on column USER_TABLESPACES.NEXT_EXTENT is 'Default incremental extent size'
/

comment on column USER_TABLESPACES.MIN_EXTENTS is 'Default minimum number of extents'
/

comment on column USER_TABLESPACES.MAX_EXTENTS is 'Default maximum number of extents'
/

comment on column USER_TABLESPACES.MAX_SIZE is 'Default maximum size of segments'
/

comment on column USER_TABLESPACES.PCT_INCREASE is 'Default percent increase for extent size'
/

comment on column USER_TABLESPACES.MIN_EXTLEN is 'Minimum extent size for the tablespace'
/

comment on column USER_TABLESPACES.STATUS is 'Tablespace status: "ONLINE", "OFFLINE", or "READ ONLY"'
/

comment on column USER_TABLESPACES.CONTENTS is 'Tablespace contents: "PERMANENT", or "TEMPORARY"'
/

comment on column USER_TABLESPACES.LOGGING is 'Default logging attribute'
/

comment on column USER_TABLESPACES.FORCE_LOGGING is 'Tablespace force logging mode'
/

comment on column USER_TABLESPACES.EXTENT_MANAGEMENT is 'Extent management tracking: "DICTIONARY" or "LOCAL"'
/

comment on column USER_TABLESPACES.ALLOCATION_TYPE is 'Type of extent allocation in effect for this tablespace'
/

comment on column USER_TABLESPACES.SEGMENT_SPACE_MANAGEMENT is 'Segment space management tracking: "AUTO" or "MANUAL"'
/

comment on column USER_TABLESPACES.DEF_TAB_COMPRESSION is 'Default table compression enabled or not: "ENABLED" or "DISABLED"'
/

comment on column USER_TABLESPACES.RETENTION is 'Undo tablespace retention: "GUARANTEE", "NOGUARANTEE" or "NOT APPLY"'
/

comment on column USER_TABLESPACES.BIGFILE is 'Bigfile tablespace indicator: "YES" or "NO"'
/

comment on column USER_TABLESPACES.PREDICATE_EVALUATION is 'Predicates evaluated by: "HOST" or "STORAGE"'
/

comment on column USER_TABLESPACES.ENCRYPTED is 'Encrypted tablespace indicator: "YES" or "NO"'
/

comment on column USER_TABLESPACES.COMPRESS_FOR is 'Default compression for what kind of operations'
/

comment on column USER_TABLESPACES.DEF_INMEMORY is 'Default in-memory attribute'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_PRIORITY is 'Default priority in which in-memory column store objects are loaded'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_DISTRIBUTE is 'Default for how in-memory columnar store objects are distributed'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_COMPRESSION is 'Default compression level for the in-memory column store option'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_DUPLICATE is 'Default for how in-memory column store objects are duplicated'
/

comment on column USER_TABLESPACES.SHARED is 'Local temp tablespace type: "LOCAL_ON_LEAF" or "LOCAL_ON_ALL" or "SHARED"'
/

comment on column USER_TABLESPACES.DEF_INDEX_COMPRESSION is 'Default index compression enabled or not: "ENABLED" or "DISABLED"'
/

comment on column USER_TABLESPACES.INDEX_COMPRESS_FOR is 'Default index compression level: "ADVANCED HIGH/LOW" or "NONE"'
/

comment on column USER_TABLESPACES.DEF_CELLMEMORY is 'Default for columnar compression in storage cell flash cache'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_SERVICE is 'How the in-memory columnar store objects are distributed for service'
/

comment on column USER_TABLESPACES.DEF_INMEMORY_SERVICE_NAME is 'Service on which the in-memory columnar store objects are distributed'
/

comment on column USER_TABLESPACES.LOST_WRITE_PROTECT is 'LOST_WRITE indicator: "OFF" or "ENABLED" or "SUSPEND" - also check dba_data_files'
/

