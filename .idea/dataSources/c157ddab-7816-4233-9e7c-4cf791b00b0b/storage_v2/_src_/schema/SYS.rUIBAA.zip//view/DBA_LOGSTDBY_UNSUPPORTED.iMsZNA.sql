create view DBA_LOGSTDBY_UNSUPPORTED (OWNER, TABLE_NAME, COLUMN_NAME, ATTRIBUTES, DATA_TYPE) as
with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, table_name, column_name, attributes,
  substrb(decode(type#, 1, decode(charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                2, decode(scale, null, decode(precision#, null,
                          'NUMBER', 'FLOAT'), 'NUMBER'),
                8, 'LONG',
                9, decode(charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                12, 'DATE',
                23, 'RAW',
                24, 'LONG RAW',
                58, 'OPAQUE',
                69, 'ROWID',
                96, decode(charsetform, 2, 'NCHAR', 'CHAR'),
                100, 'BINARY_FLOAT',
                101, 'BINARY_DOUBLE',
                105, 'MLSLABEL',
                106, 'MLSLABEL',
                110, 'REF',
                111, 'REF',
                112, decode(charsetform, 2, 'NCLOB', 'CLOB'),
                113, 'BLOB',
                114, 'BFILE',
                115, 'CFILE',
                119, 'JSON',
                121, 'OBJECT',
                122, 'NESTED TABLE',
                123, 'VARRAY',
                178, 'TIME(' ||scale|| ')',
                179, 'TIME(' ||scale|| ')' || ' WITH TIME ZONE',
                180, 'TIMESTAMP(' ||scale|| ')',
                181, 'TIMESTAMP(' ||scale|| ')' || ' WITH TIME ZONE',
                231, 'TIMESTAMP(' ||scale|| ')' || ' WITH LOCAL TIME ZONE',
                182, 'INTERVAL YEAR(' ||precision#||') TO MONTH',
                183, 'INTERVAL DAY(' ||precision#||') TO SECOND('
                                     || scale || ')',
                208, 'UROWID',
                'UNDEFINED'),1,106) data_type
  from (
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_12_2 u, redo_compat c
    where c.compat like '12.2%' and c.compat not like '12.2.0.2%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupp_tab_12_2_0_2 u, redo_compat c
    where c.compat like '12.2.0.2%' or c.compat like '18.0%'
          or c.compat like '18.1%'
    UNION ALL
    -- In 19.0, the compat-specific views for LSBY check the RU
    -- event in-line.  From 20.0 onward, we make the check here.  If not
    -- in rolling upgrade, or if replication metadata maintenance
    -- is disabled via event setting, then the obj$ support mode metadata is
    -- not valid, or does not apply, so we must use the compat-specific view.
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupp_tab_19 u, redo_compat c
    where c.compat like '19.%' or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_DG_ROLLING_UPGRADE') = 'FALSE') or
          (c.compat like '2%.%' and
           sys_context('userenv', 'IS_REPL_META_DISABLED') = 'TRUE')
    UNION ALL
    -- Transient/Rolling LSBY views are common to all compats from 20.0 onward
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_ru_unsupp_tab_common u, redo_compat c
    where c.compat like '2%.%' and
          sys_context('userenv', 'IS_DG_ROLLING_UPGRADE') = 'TRUE' and
          sys_context('userenv', 'IS_REPL_META_DISABLED') = 'FALSE'
)
  where gensby = 0
/

comment on table DBA_LOGSTDBY_UNSUPPORTED is 'List of all the columns that are not supported by Logical Standby'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED.OWNER is 'Schema name of unsupported column'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED.TABLE_NAME is 'Table name of unsupported column'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED.COLUMN_NAME is 'Column name of unsupported column'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED.ATTRIBUTES is 'If not a data type issue, gives the reason why the table is unsupported'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED.DATA_TYPE is 'Datatype of unsupported column'
/

