create PACKAGE dbms_registry AS

-- inline PRAGMA declarations to handle PL/SQL packages rolling upgrade
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

-- RELEASE CONSTANTS
--    The values are taken from sqlplus constants defined in
--    dbms_registry_basic.sql. The sqlplus constants are
--    derived from the build variables BANNERVERSION, BANNERVERSIONFULL,
--    and BANNER_STATUS.  The constants reflect the scripts in rdbms/admin,
--    as opposed to the server code running in an instance.

release_version       CONSTANT registry$.version%type :=
                               '21.0.0.0.0';
release_version_full  CONSTANT registry$.version_full%type :=
                               '21.3.0.0.0';
release_status        CONSTANT VARCHAR2(30) := 'Production';

-- Component Hierarchy Type and CONSTANTS
TYPE comp_list_t      IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
IMD_COMPS             CONSTANT NUMBER :=1;  /* immediate subcomponents */
TRM_COMPS             CONSTANT NUMBER :=2;  /* terminal subcomponents */
ALL_COMPS             CONSTANT NUMBER :=3;  /* all subcomponents */

-- Schema List Parameter
TYPE schema_list_t    IS TABLE OF dbms_id;

-- Component dependency Type - table of component IDs
TYPE comp_depend_list_t IS TABLE OF VARCHAR2(30);

-- Component dependency Type - table of component IDs and associated namespaces
TYPE comp_depend_record_t IS RECORD(
    cid VARCHAR2(30), -- component id
    cnamespace VARCHAR2(30) -- component namespace
    );

TYPE comp_depend_rec IS TABLE OF comp_depend_record_t INDEX BY BINARY_INTEGER;

PROCEDURE set_session_namespace (namespace IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_session_namespace, UNSUPPORTED);

PROCEDURE set_comp_namespace (comp_id IN VARCHAR2,
                              namespace IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_comp_namespace, UNSUPPORTED);

PROCEDURE set_rdbms_status(comp_id      IN VARCHAR2,
                           status       IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_rdbms_status, UNSUPPORTED);

PROCEDURE invalid     (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(invalid, UNSUPPORTED);

PROCEDURE valid       (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(valid, UNSUPPORTED);

PROCEDURE loading     (comp_id      IN VARCHAR2,
                       comp_name    IN VARCHAR2,
                       comp_proc    IN VARCHAR2 DEFAULT NULL,
                       comp_schema  IN VARCHAR2 DEFAULT NULL,
                       comp_parent  IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(loading, UNSUPPORTED);

PROCEDURE loading     (comp_id      IN VARCHAR2,
                       comp_name    IN VARCHAR2,
                       comp_proc    IN VARCHAR2,
                       comp_schema  IN VARCHAR2,
                       comp_schemas IN schema_list_t,
                       comp_parent  IN VARCHAR2 DEFAULT NULL);

PROCEDURE loaded      (comp_id      IN VARCHAR2,
                       comp_version IN VARCHAR2 DEFAULT NULL,
                       comp_banner  IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(loaded, UNSUPPORTED);

PROCEDURE upgrading   (comp_id      IN VARCHAR2,
                       new_name     IN VARCHAR2 DEFAULT NULL,
                       new_proc     IN VARCHAR2 DEFAULT NULL,
                       new_schema   IN VARCHAR2 DEFAULT NULL,
                       new_parent   IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(upgrading, UNSUPPORTED);

PROCEDURE upgrading   (comp_id      IN VARCHAR2,
                       new_name     IN VARCHAR2,
                       new_proc     IN VARCHAR2,
                       new_schema   IN VARCHAR2,
                       new_schemas  IN schema_list_t,
                       new_parent   IN VARCHAR2 DEFAULT NULL);

PROCEDURE upgraded     (comp_id      IN VARCHAR2,
                       new_version   IN VARCHAR2 DEFAULT NULL,
                       new_banner    IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(upgraded, UNSUPPORTED);

PROCEDURE downgrading (comp_id      IN VARCHAR2,
                       old_name     IN VARCHAR2 DEFAULT NULL,
                       old_proc     IN VARCHAR2 DEFAULT NULL,
                       old_schema   IN VARCHAR2 DEFAULT NULL,
                       old_parent   IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(downgrading, UNSUPPORTED);

PROCEDURE downgraded  (comp_id      IN VARCHAR2,
                       old_version  IN VARCHAR2 DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(downgraded, UNSUPPORTED);

PROCEDURE removing    (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(removing, UNSUPPORTED);

PROCEDURE removed     (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(removed, UNSUPPORTED);

PROCEDURE option_off  (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(option_off, UNSUPPORTED);

PROCEDURE startup_required (comp_id IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(startup_required, UNSUPPORTED);

PROCEDURE startup_complete (comp_id IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(startup_complete, UNSUPPORTED);

PROCEDURE reset_version (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(reset_version, UNSUPPORTED);

PROCEDURE update_schema_list
                      (comp_id      IN VARCHAR2,
                       comp_schemas IN schema_list_t);
PRAGMA SUPPLEMENTAL_LOG_DATA(update_schema_list, UNSUPPORTED);

FUNCTION  status_name  (status NUMBER) RETURN VARCHAR2;

FUNCTION  status      (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  version     (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  prev_version (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  version_full (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  prev_version_full (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  version_greater (left_version VARCHAR2, right_version VARCHAR2)
  RETURN BOOLEAN;

FUNCTION  edition      (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  schema      (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  schema_list (comp_id IN VARCHAR2) RETURN schema_list_t;

FUNCTION  schema_list_string  (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  subcomponents (comp_id IN VARCHAR2,
                         comp_option IN NUMBER DEFAULT 1)
                         RETURN comp_list_t;

FUNCTION  comp_name   (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  session_namespace RETURN VARCHAR2;

FUNCTION  script      (comp_id IN VARCHAR2,
                       script_name IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  script_path  (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  script_prefix  (comp_id IN VARCHAR2) RETURN VARCHAR2;

FUNCTION  nothing_script RETURN VARCHAR2;

FUNCTION  is_loaded   (comp_id IN VARCHAR2,
                       version IN VARCHAR2 DEFAULT NULL) RETURN NUMBER;

FUNCTION  is_valid   (comp_id IN VARCHAR2,
                       version IN VARCHAR2 DEFAULT NULL) RETURN NUMBER;

FUNCTION  is_startup_required (comp_id IN VARCHAR2) RETURN NUMBER;

FUNCTION  is_component (comp_id VARCHAR2) RETURN BOOLEAN;

FUNCTION  is_server_component (comp_id VARCHAR2) RETURN NUMBER DETERMINISTIC;

FUNCTION  is_in_registry (comp_id IN VARCHAR2) RETURN BOOLEAN;

FUNCTION  count_errors_in_registry (comp_id IN VARCHAR2) RETURN NUMBER;

FUNCTION  is_in_upgrade_mode RETURN BOOLEAN;

FUNCTION  is_trace_event_set(trace_event VARCHAR2) RETURN BOOLEAN;

FUNCTION  is_db_consolidated RETURN BOOLEAN;

FUNCTION  is_db_root         RETURN BOOLEAN;

FUNCTION  is_db_pdb          RETURN BOOLEAN;

FUNCTION  is_db_pdb_seed     RETURN BOOLEAN;

FUNCTION  is_upgrade_running RETURN BOOLEAN;

FUNCTION  is_stats_from_upgrade RETURN BOOLEAN;

FUNCTION  get_container_name(con_id IN container$.con_id#%TYPE)
          RETURN obj$.name%TYPE;

FUNCTION  num_of_exadata_cells RETURN NUMBER;

PROCEDURE check_server_instance;
PRAGMA SUPPLEMENTAL_LOG_DATA(check_server_instance, UNSUPPORTED);

PROCEDURE set_progress_action (comp_id IN VARCHAR2,
                               action  IN VARCHAR2,
                               value   IN VARCHAR2 DEFAULT NULL,
                               step    IN NUMBER DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_progress_action, UNSUPPORTED);

PROCEDURE delete_progress_action (comp_id IN VARCHAR2,
                                  action  IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(delete_progress_action, UNSUPPORTED);

PROCEDURE set_progress_value (comp_id IN VARCHAR2,
                              action  IN VARCHAR2,
                              value   IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_progress_value, UNSUPPORTED);

PROCEDURE set_progress_step (comp_id IN VARCHAR2,
                             action  IN VARCHAR2,
                             step    IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_progress_step, UNSUPPORTED);

FUNCTION get_progress_value (comp_id IN VARCHAR2,
                             action  IN VARCHAR2) RETURN VARCHAR2;

FUNCTION get_progress_step (comp_id IN VARCHAR2,
                            action  IN VARCHAR2) RETURN NUMBER;

PROCEDURE set_required_comps (comp_id IN VARCHAR2,
                              comp_depend_list IN comp_depend_list_t );
PRAGMA SUPPLEMENTAL_LOG_DATA(set_required_comps, UNSUPPORTED);

PROCEDURE set_required_comps (comp_id IN VARCHAR2,
                              comp_depend_list IN comp_depend_rec );

FUNCTION get_required_comps (comp_id IN VARCHAR2) RETURN comp_depend_list_t;

FUNCTION get_required_comps_rec (comp_id IN VARCHAR2) RETURN comp_depend_rec;

FUNCTION get_dependent_comps (comp_id IN VARCHAR2) RETURN comp_depend_list_t;

FUNCTION get_dependent_comps_rec (comp_id IN VARCHAR2) RETURN comp_depend_rec;

PROCEDURE set_edition (comp_id      IN VARCHAR2);
PRAGMA SUPPLEMENTAL_LOG_DATA(set_edition, UNSUPPORTED);

PROCEDURE set_edition (comp_id      IN VARCHAR2,
                       edition_var  IN VARCHAR2);

FUNCTION get_con_id RETURN NUMBER;

PROCEDURE RU_apply    (comp_version      IN VARCHAR2  DEFAULT NULL,
                       build_description IN VARCHAR2  DEFAULT NULL,
                       build_timestamp   IN TIMESTAMP DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(RU_apply, UNSUPPORTED);

PROCEDURE RU_rollback (comp_version      IN VARCHAR2  DEFAULT NULL,
                       build_description IN VARCHAR2  DEFAULT NULL,
                       build_timestamp   IN TIMESTAMP DEFAULT NULL);
PRAGMA SUPPLEMENTAL_LOG_DATA(RU_rollback, UNSUPPORTED);

END dbms_registry;
/

