create view USER_ROLE_PRIVS
            (USERNAME, GRANTED_ROLE, ADMIN_OPTION, DELEGATE_OPTION, DEFAULT_ROLE, OS_GRANTED, COMMON, INHERITED) as
select groles.username, groles.granted_role, groles.admin_option,
       groles.delegate_option, groles.default_role, groles.os_granted,
       groles.common, groles.inherited
from
(
/* Locally granted Privileges */
select /*+ index(sa I_SYSAUTH1) */
    decode(sa.grantee#, 1, 'PUBLIC', u1.name) username,
    u2.name granted_role,
    decode(min(bitand(nvl(option$, 0), 1)), 1, 'YES', 'NO') admin_option,
    decode(min(bitand(nvl(option$, 0), 2)), 2, 'YES', 'NO') delegate_option,
    decode(min(u1.defrole), 0, 'NO',
      1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'),
      2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
      3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO') default_role,
    'NO' os_granted, 'NO' common, 'NO' inherited
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee# in (userenv('SCHEMAID'),1) and sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$, 0), 4) = 0
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union all
/* Commonly granted Privileges */
select /*+ index(sa I_SYSAUTH1) */
  decode(sa.grantee#, 1, 'PUBLIC', u1.name) username,
  u2.name granted_role,
  decode(min(bitand(nvl(option$, 0), 16)), 16, 'YES', 'NO') admin_option,
  decode(min(bitand(nvl(option$, 0), 32)), 32, 'YES', 'NO') delegate_option,
  decode(min(u1.defrole), 0, 'NO',
    1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'),
    2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
    3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO') default_role,
  'NO' os_granted, 'YES' common,
   decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES') inherited
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee# in (userenv('SCHEMAID'),1) and sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$,0), 8) = 8
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union all
/* Federationally granted Privileges */
select /*+ index(sa I_SYSAUTH1) */
  decode(sa.grantee#, 1, 'PUBLIC', u1.name) username,
  u2.name granted_role,
  decode(min(bitand(nvl(option$, 0), 128)), 128, 'YES', 'NO') admin_option,
  decode(min(bitand(nvl(option$, 0), 256)), 256, 'YES', 'NO') delegate_option,
  decode(min(u1.defrole), 0, 'NO',
    1, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'),
    2, decode(min(ud.role#), NULL, 'NO', decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO')),
    3, decode(min(ud.role#), NULL, decode(min(u2.password), NULL, decode(min(u2.spare4), NULL, 'YES', 'NO'), 'NO'), 'NO'), 'NO') default_role,
  'NO' os_granted, 'YES' common,
  decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'),
         'YES', 'YES', 'NO') inherited
from sysauth$ sa, user$ u1, user$ u2, defrole$ ud
where sa.grantee# in (userenv('SCHEMAID'),1) and sa.grantee#=ud.user#(+)
  and sa.privilege#=ud.role#(+) and u1.user#=sa.grantee#
  and u2.user#=sa.privilege#
  and bitand(nvl(option$,0), 64) = 64
group by decode(sa.grantee#,1,'PUBLIC',u1.name),u2.name
union
select su.name username,u.name granted_role,
       decode(kzdosadm,'A','YES','NO') admin_option, NULL delegate_option,
       decode(kzdosdef,'Y','YES','NO') default_role,
       'YES' os_granted, 'NO' common, 'NO' inherited
from sys.user$ u,x$kzdos, sys.user$ su
where u.user#=x$kzdos.kzdosrol and
      su.user#=userenv('SCHEMAID')
) groles
where sys_context('userenv', 'proxy_user') is null
      or
      (sys_context('userenv', 'proxy_user') is not null and
      (EXISTS (select 1 from
               sys.proxy_info$ p where
               p.client#=userenv('SCHEMAID') and
               p.proxy# = sys_context('userenv', 'proxy_userid')
               and BITAND(p.flags,2) =0 and (BITAND(p.flags,1)>0  or
       EXISTS (select 1 from sys.proxy_role_info$ pr, sys.user$ u where
               p.client# = pr.client# and p.proxy# = pr.proxy# and
               ((BITAND(p.flags,4) > 0 and
              (pr.role# = u.user# and u.name = groles.granted_role)) or
             (BITAND(p.flags,8) > 0 and
              (pr.role# = u.user# and u.name != groles.granted_role)))))) or
              /* it could be a RAS proxy session. Since xs$proxy_role is not yet created,
               * assume RAS proxy session if no row found in proxy_info$.
               */
       NOT EXISTS (select 1 from
                   sys.proxy_info$ p where
                   p.client#=userenv('SCHEMAID') and
                   p.proxy# = sys_context('userenv', 'proxy_userid'))))
/

comment on table USER_ROLE_PRIVS is 'Roles granted to current user'
/

comment on column USER_ROLE_PRIVS.USERNAME is 'User Name or PUBLIC'
/

comment on column USER_ROLE_PRIVS.GRANTED_ROLE is 'Granted role name'
/

comment on column USER_ROLE_PRIVS.ADMIN_OPTION is 'Grant was with the ADMIN option'
/

comment on column USER_ROLE_PRIVS.DELEGATE_OPTION is 'Grant was with the DELEGATE option'
/

comment on column USER_ROLE_PRIVS.DEFAULT_ROLE is 'Role is designated as a DEFAULT ROLE for the user'
/

comment on column USER_ROLE_PRIVS.OS_GRANTED is 'Role is granted via the operating system (using OS_ROLES = TRUE)'
/

comment on column USER_ROLE_PRIVS.COMMON is 'Role was granted commonly'
/

comment on column USER_ROLE_PRIVS.INHERITED is 'Was role grant inherited from another container'
/

