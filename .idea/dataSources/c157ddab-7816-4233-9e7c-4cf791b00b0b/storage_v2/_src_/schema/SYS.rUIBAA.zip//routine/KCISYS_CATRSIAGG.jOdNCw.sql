create function     KCISYS_CATRSIAGG(
  input                 CLOB,
  index_name            VARCHAR2,
  query                 VARCHAR2,
  result_set_descriptor CLOB,
  part_name             VARCHAR2 DEFAULT NULL,
  format                NUMBER DEFAULT 0,
  parallel_degree       NUMBER DEFAULT 1)
return CLOB aggregate using sys.CATRSIAggImp;
/

