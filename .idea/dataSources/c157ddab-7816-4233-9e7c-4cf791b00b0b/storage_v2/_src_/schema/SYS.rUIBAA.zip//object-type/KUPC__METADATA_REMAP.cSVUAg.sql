create TYPE kupc$_metadata_remap FORCE UNDER kupc$_shadow_msg (
        remap_name                VARCHAR2(30),
        remap_old_value           VARCHAR2(4000),
        remap_new_value           VARCHAR2(4000),
        object_type               VARCHAR2(128),
        CONSTRUCTOR FUNCTION kupc$_metadata_remap(
                                rn   VARCHAR2,
                                rov  VARCHAR2,
                                rnv  VARCHAR2,
                                ot   VARCHAR2
                                ) RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION kupc$_metadata_remap(
                                qh   NUMBER,
                                rn   VARCHAR2,
                                rov  VARCHAR2,
                                rnv  VARCHAR2,
                                ot   VARCHAR2
                                ) RETURN SELF AS RESULT
        )
/

