create type ku$_11_2_tab_stats_t force as object
(
  vers_major        char(1),                    -- UDT major version #
  vers_minor        char(1),                    -- UDT minor version #
  obj_num           number,                     -- object number for table
  base_obj          ku$_schemaobj_t,            -- table information
  nested_tab_name   varchar2(30),               -- nested table name
  column_list       ku$_tab_col_list_t,         -- column list
  tab_info          ku$_tab_ptab_stats_t,       -- table statistics
  ptab_info_list    ku$_ptab_stats_list_t       -- partitioned statistics
)
not persistable
/

