create TYPE BODY kupc$_encoded_pwd wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
15a 10f
/+uNBQNINSOk3idOuK1dzpTGWPYwg/DQ7cusfC+pkEIY/QQhfyKp1PuD1i/u8oP2415bcGXM
b4YeBQn1f6vaIf5OTLnaIsTnvvEXU2iwIjKGDZ2yho/oxqZYoaZGZmqDniurngys1em4wjta
pPFp02P22r4zXf7BNXJGWhdVMyigYOHCLkqSHzT78H4qN69FpWEiKmGLfZALk7N6VXXxao34
hopin1IHuvwHkTH4RWyp8zoRvsozSPgU08zv21o/Fr21/L0l3Nzf
/

