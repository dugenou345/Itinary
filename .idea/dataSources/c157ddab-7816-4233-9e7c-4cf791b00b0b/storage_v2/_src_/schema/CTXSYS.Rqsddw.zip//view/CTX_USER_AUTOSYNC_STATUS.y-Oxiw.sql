create view CTX_USER_AUTOSYNC_STATUS as
select l.job_name  asj_job_name,
         i.idx_name  asj_index_name,
         null        asj_partition_name,
         l.log_date  asj_timestamp,
         l.status    asj_status,
         r.additional_info asj_error
    from sys.dba_scheduler_job_run_details r,
         sys.dba_scheduler_job_log l,
         dr$index i
   where
         i.idx_sync_jobname = l.job_name and
         l.owner = r.owner and
         l.log_id = r.log_id and
         l.job_name like '%$ASJ' and
         l.owner = 'CTXSYS' and
         i.idx_owner# = userenv('SCHEMAID')
   UNION ALL
   select l.job_name  asj_job_name,
          i.idx_name  asj_index_name,
          p.ixp_name  asj_partition_name,
          l.log_date  asj_timestamp,
          l.status    asj_status,
          r.additional_info asj_error
    from sys.dba_scheduler_job_run_details r,
         sys.dba_scheduler_job_log l,
         dr$index i, dr$index_partition p
   where
         p.ixp_sync_jobname = l.job_name and
         i.idx_id = p.ixp_idx_id and
         l.owner = r.owner and
         l.log_id = r.log_id and
         l.job_name like '%$ASJ' and
         l.owner = 'CTXSYS' and
         i.idx_owner# = userenv('SCHEMAID')
/

