create view CTX_AUTOSYNC_JOBS as
select j.job_name         asj_job_name,
         i.idx_name         asj_index_name,
         i.idx_id           asj_index_id,
         b.name             asj_index_owner,
         null               asj_partition_name,
         null               asj_partition_id,
         j.start_date       asj_start_date,
         j.repeat_interval  asj_repeat_interval,
         j.state            asj_state,
         j.run_count        asj_run_count
    from sys.dba_scheduler_jobs j, dr$index i,
         sys."_BASE_USER" b
   where
     i.idx_sync_jobname = j.job_name and
     i.idx_owner# = b.user# and
     j.job_name like '%$ASJ' and
     j.owner = 'CTXSYS'
  UNION ALL
  select j.job_name         asj_job_name,
         i.idx_name         asj_index_name,
         i.idx_id           asj_index_id,
         b.name             asj_index_owner,
         p.ixp_name         asj_partition_name,
         p.ixp_id           asj_partition_id,
         j.start_date       asj_start_date,
         j.repeat_interval  asj_repeat_interval,
         j.state            asj_state,
         j.run_count        asj_run_count
    from sys.dba_scheduler_jobs j,
         dr$index i, dr$index_partition p,
         sys."_BASE_USER" b
   where
     i.idx_id = p.ixp_idx_id and
     p.ixp_sync_jobname = j.job_name and
     i.idx_owner# = b.user# and
     j.job_name like '%$ASJ' and
     j.owner = 'CTXSYS'
/

