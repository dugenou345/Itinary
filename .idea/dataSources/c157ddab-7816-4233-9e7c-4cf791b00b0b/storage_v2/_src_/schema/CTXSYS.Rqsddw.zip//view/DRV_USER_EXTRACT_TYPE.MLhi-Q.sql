create view DRV$USER_EXTRACT_TYPE as
select "ERT_POL_ID","ERT_RULE_ID","ERT_TYPE_ID","ERT_TYPE","ERT_REFID" from dr$user_extract_type
where ert_pol_id = SYS_CONTEXT('DR$APPCTX', 'IDXID')
with check option
/

