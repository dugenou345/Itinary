create package drient as

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

/*--------------------------- compile ---------------------------------------*/

PROCEDURE compile(
  idx            IN dr_def.idx_rec,
  compile_choice IN NUMBER,
  locking        IN NUMBER
);

/*--------------------------- chkposup --------------------------------------*/
/* chkposup - Check data in erl_type after upgrade due to design change
            adding new types in user_extract_type                            */

PROCEDURE chkposup(
  idx            IN dr_def.idx_rec
);


/*--------------------------- chkextpol -------------------------------------*/
/* chkextpol - Check that policy is an extraction policy                     */
FUNCTION chkextpol(
  idx        IN dr_def.idx_rec
) return BOOLEAN;

PROCEDURE add_extract_rule(
  idx         IN  dr_def.idx_rec,
  rule_id     IN INTEGER,
  extraction_rule     IN VARCHAR2
);

PROCEDURE remove_extract_rule(
  idxid        IN NUMBER,
  remove_index IN BOOLEAN DEFAULT FALSE
);

end drient;
/

