create package drvxtabc authid current_user as

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

/* ====================================================================== */
/* ====================================================================== */
/*                              CTXCAT                                    */
/* ====================================================================== */
/* ====================================================================== */

/*----------------------- create_tables -----------------------------*/

PROCEDURE create_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- create_indexes  ---------------------------*/

PROCEDURE create_indexes(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- drop_tables  ---------------------------*/

PROCEDURE drop_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  has_p     in boolean default null
);

/*----------------------- trunc_tables  ---------------------------*/

PROCEDURE trunc_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- rename_tables  ---------------------------*/

PROCEDURE rename_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  new_name  in varchar2,
  has_idx   in boolean
);

/*----------------------- post_transport  ---------------------------*/

PROCEDURE post_transport(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- recreate_trigger  ---------------------------*/

PROCEDURE recreate_trigger(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

end drvxtabc;
/

