create view CTX_ALEXER_DICTS as
select idx.idx_owner# as ald_owner, b.dict_name as ald_name,
  a.dict_lang as ald_lang
  from DR$IDX_DICTIONARIES a, DR$DICTIONARY b, dr$index idx
  where idx.idx_owner# = b.dict_owner# and a.dict_lang = b.dict_lang
/

