create PACKAGE driacc authid current_user AS

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

--
-- NAME
--   split_spec - parse a spec into distinct parts
--
-- DESCRIPTION
--   This procedure takes an object spec and splits it into parts
--
-- ARGUMENTS
--   p_spec     (IN)     - the spec
--   p_type     (IN)     - COL, TABLE, POLICY, or PROC
--   p_owner    (OUT)    - the owner name
--   p_object   (OUT)    - the object or package name
--   p_function (OUT)    - the function name
--   p_link     (OUT)    - the db link name
--
-- NOTES
--
-- RETURN
--
PROCEDURE split_spec (
  p_spec     IN VARCHAR2,
  p_type     IN VARCHAR2,
  p_owner    IN OUT VARCHAR2,
  p_object   IN OUT VARCHAR2,
  p_function IN OUT VARCHAR2,
  p_link     IN OUT VARCHAR2
);
--
--
-- NAME
--   can - test whether user can access an object
--
-- DESCRIPTION
--   This function tests whether a user can access an object.
--   if the spec passed in is a synonym reference, will also
--   transform the spec to the base object.
--
-- ARGUMENTS
--   p_user     (IN)     - the user name
--   p_access   (IN)     - what kind of access (SELECT/EXECUTE/INSERT)
--   p_spec     (IN OUT) - spec of object
--
-- NOTES
--
-- RETURN
--   true if can access, false otherwise.
--
FUNCTION can (
  p_user     IN VARCHAR2,
  p_access   IN VARCHAR2,
  p_spec     IN OUT VARCHAR2
) RETURN BOOLEAN;
--
--
-- NAME
--   del_cache - mark as invalid cache nodes
--
-- DESCRIPTION
--   This procedure looks in the cache for an invalid object and set valid to
--   FALSE
-- ARGUMENTS
--   p_object    (IN)    - the access object spec
--
-- NOTES
--
-- RETURN
--
PROCEDURE del_cache (
    p_object IN VARCHAR2
);
--
--
-- NAME
--   can_execute - test whether user can execute a function/procedure
--
-- DESCRIPTION
--   This function tests whether a user can execute a function/procedure.
--   if the spec passed in is a synonym reference, will also
--   transform the spec to the base object.
--
-- ARGUMENTS
--   p_user     (IN)     - the user name
--   p_spec     (IN)     - spec of object
--
-- NOTES
--
-- RETURN
--   fully qualified name if can access, empty string otherwise.
--
FUNCTION can_execute (
  p_user     IN VARCHAR2,
  p_spec     IN VARCHAR2
) RETURN VARCHAR2;
--
--
-- NAME
--   verify_procedure - verify a procedure
--
-- DESCRIPTION
--   This function takes package.procedure_name or procedure_name
--   verifies that it exists and that ctxsys owns the package/procedure
--   this is called from the user datastore validation
--
-- ARGUMENTS
--   p_spec     (IN)  - package.procedure or procedure name
--
-- NOTES
--
-- RETURN
--   true if everything checks out, false otherwise.
--
FUNCTION verify_procedure (
  p_user       IN         VARCHAR2,
  p_spec       IN OUT     VARCHAR2
) RETURN BOOLEAN;

--
-- NAME
--  chk_access
-- DESCRIPTION
--  This function takes the object name and ensures that the current
--  user has the given privilege. Currently it only checks for privileges like
--  CREATE ANY TABLE or CREATE ANY INDEX. Using
--  dbms_priv_capture.ses_has_sys_priv
--
-- ARGUMENTS
--   p_oname    (IN)     - object name
--   p_priv     (IN)     - privilege to check
--
-- RETURN
--   true if everything checks out, false otherwise.
--
FUNCTION chk_access (
    p_oname     IN    VARCHAR2,
    p_priv      IN    VARCHAR2
) RETURN BOOLEAN;

--
-- NAME
--  chk_obj_access
-- DESCRIPTION
--  This function checks if a given user has an object privilege
--
-- ARGUMENTS
--   p_priv     (IN)     - privilege to check
--   p_oname    (IN)     - object name
--
-- RETURN
--   true if everything checks out, false otherwise.
--
FUNCTION chk_obj_access (
    p_priv      IN    VARCHAR2,
    p_oname     IN    VARCHAR2
) RETURN BOOLEAN;

--
-- NAME
--   ud_access
--
-- DESCRIPTION
--   This function takes the index owner name and ensures that the
--   index owner can execute the user datastore procedure.  It is called
--   from set_store_objects
--
-- ARGUMENTS
--   p_user     (IN)     - the index owner
--   p_spec     (IN)     - the user datastore procedure name
--
-- NOTES
--   normally, would just be able to use CAN, but in this case
--   if the user datastore has just PROCEDURE, then a user with
--   package CTXSYS and procedure PROCEDURE would be able to fool CAN
--
-- RETURN
--   true if everything checks out, false otherwise.
--
FUNCTION ud_access (
  p_user      IN     VARCHAR2,
  p_spec      IN     VARCHAR2
) RETURN BOOLEAN;

FUNCTION user_access (
  p_user     IN VARCHAR2,
  p_access   IN VARCHAR2,
  p_owner    IN VARCHAR2,
  p_object   IN VARCHAR2
) RETURN BOOLEAN;


END driacc;
/

