create view CTX_USER_AUTOSYNC_JOBS as
select j.job_name         asj_job_name,
         i.idx_name         asj_index_name,
         i.idx_id           asj_index_id,
         null               asj_partition_name,
         null               asj_partition_id,
         j.start_date       asj_start_date,
         j.repeat_interval  asj_repeat_interval,
         j.state            asj_state,
         j.run_count        asj_run_count
    from sys.dba_scheduler_jobs j,
         dr$index i
   where
     i.idx_sync_jobname = j.job_name and
     j.job_name like '%$ASJ' and
     j.owner = 'CTXSYS' and
     i.idx_owner# = userenv('SCHEMAID')
  UNION ALL
  select j.job_name         asj_job_name,
         i.idx_name         asj_index_name,
         i.idx_id           asj_index_id,
         p.ixp_name         asj_partition_name,
         p.ixp_id           asj_partition_id,
         j.start_date       asj_start_date,
         j.repeat_interval  asj_repeat_interval,
         j.state            asj_state,
         j.run_count        asj_run_count
    from sys.dba_scheduler_jobs j,
         dr$index i, dr$index_partition p
   where
     p.ixp_sync_jobname = j.job_name and
     i.idx_id = p.ixp_idx_id and
     j.job_name like '%$ASJ' and
     j.owner = 'CTXSYS' and
     i.idx_owner# = userenv('SCHEMAID')
/

