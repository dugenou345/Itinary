create PACKAGE driacchelp authid definer
accessible by (PACKAGE driacc)
AS

PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

--
--
-- NAME
--   do_syn - reduce one synonym link
--
-- DESCRIPTION
--   This function takes in an object owner and name and
--   tries to follow synonym links to find out the real owner and
--   name.   Then verifies that the base object exists.  Return
--   TRUE if base object exists, FALSE if not.
--
-- ARGUMENTS
--   p_owner     (IN OUT)   - the name of the owner
--   p_object    (IN OUT)   - the name of the object
--
-- RETURN
--   TRUE if exists, FALSE otherwise
--
FUNCTION do_syn (
  p_objtype    IN VARCHAR2,
  p_owner  IN OUT VARCHAR2,
  p_object IN OUT VARCHAR2,
  p_func   IN OUT VARCHAR2,
  p_link   IN OUT VARCHAR2
) RETURN BOOLEAN;

FUNCTION get_role_direct(p_user in varchar2,
                         p_role in varchar2) return number;

PROCEDURE open_role_privs (p_user in varchar2,
                           c_role_privs out SYS_REFCURSOR);
FUNCTION fetch_role_privs(c_role_privs in SYS_REFCURSOR,
                          l_role out varchar2) return number;
PROCEDURE close_role_privs(c_role_privs in SYS_REFCURSOR);

FUNCTION get_tab_privs (cv_system_pattern in varchar2,
                        p_user in varchar2, p_access in varchar2,
                        p_owner in varchar2, p_object in varchar2)
return number;

END driacchelp;
/

