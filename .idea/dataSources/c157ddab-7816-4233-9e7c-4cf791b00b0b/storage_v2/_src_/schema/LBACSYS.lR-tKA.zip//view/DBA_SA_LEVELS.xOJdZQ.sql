create view DBA_SA_LEVELS as
SELECT p.pol_name AS policy_name, l.level# AS level_num,
          l.code AS short_name, l.name AS long_name
   FROM LBACSYS.ols$pol p, LBACSYS.ols$levels l
   WHERE p.pol# = l.pol#
/

