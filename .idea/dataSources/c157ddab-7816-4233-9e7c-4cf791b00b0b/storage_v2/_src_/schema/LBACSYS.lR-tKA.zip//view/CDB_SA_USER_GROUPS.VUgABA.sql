create view CDB_SA_USER_GROUPS as
SELECT k."POLICY_NAME",k."USER_NAME",k."GRP",k."RW_ACCESS",k."DEF_GROUP",k."ROW_GROUP",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_USER_GROUPS") k
/

comment on table CDB_SA_USER_GROUPS is ' in all containers'
/

comment on column CDB_SA_USER_GROUPS.CON_ID is 'container id'
/

