create view DBA_SA_LABELS as
SELECT p.pol_name AS policy_name,
         l.slabel AS label,
         l.nlabel AS label_tag,
         DECODE (l.flags,2,'USER LABEL',
                 3, 'USER/DATA LABEL', 'UNDEFINED') AS label_type
  FROM LBACSYS.ols$lab l, LBACSYS.ols$pol p
  WHERE p.pol# = l.pol#
/

