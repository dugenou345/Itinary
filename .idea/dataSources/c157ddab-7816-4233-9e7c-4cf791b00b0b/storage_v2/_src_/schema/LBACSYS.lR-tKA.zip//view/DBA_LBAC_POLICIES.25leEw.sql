create view DBA_LBAC_POLICIES (POLICY_NAME, COLUMN_NAME, PACKAGE, STATUS, POLICY_OPTIONS, POLICY_SUBSCRIBED) as
SELECT pol_name,
         column_name, package,
         DECODE(bitand(flags,1),0,'DISABLED',1,'ENABLED','ERROR'),
         LBACSYS.lbac_cache.option_string(options),
         DECODE(bitand(flags,16),0,'FALSE',16,'TRUE','ERROR')
  FROM LBACSYS.ols$pol
/

