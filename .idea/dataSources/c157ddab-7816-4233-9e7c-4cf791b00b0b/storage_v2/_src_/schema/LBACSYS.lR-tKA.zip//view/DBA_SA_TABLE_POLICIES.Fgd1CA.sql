create view DBA_SA_TABLE_POLICIES as
SELECT t.policy_name, schema_name, table_name, t.status,
         table_options, function, predicate
  FROM LBACSYS.dba_lbac_policies p, LBACSYS.dba_lbac_table_policies t
  WHERE p.policy_name=t.policy_name
    AND p.package='LBAC$SA'
/

