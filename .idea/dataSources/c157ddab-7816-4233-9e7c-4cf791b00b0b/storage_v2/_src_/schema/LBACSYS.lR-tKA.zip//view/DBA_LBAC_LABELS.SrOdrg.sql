create view DBA_LBAC_LABELS as
SELECT pol_name AS policy_name,
         slabel AS label,
         nlabel AS label_tag,
         DECODE (l.flags,2,'USER LABEL',
                 3, 'USER/DATA LABEL', 'UNDEFINED') AS label_type
  FROM LBACSYS.ols$lab l, LBACSYS.ols$pol p
  WHERE p.pol# = l.pol#
/

