create view DBA_SA_USERS as
SELECT user_name,  u.policy_name, user_privileges,
         LABEL1 AS MAX_READ_LABEL, LABEL2 AS MAX_WRITE_LABEL,
         LABEL3 AS MIN_WRITE_LABEL , LABEL4 AS DEFAULT_READ_LABEL,
         LABEL5 AS DEFAULT_WRITE_LABEL, LABEL6 AS DEFAULT_ROW_LABEL
  FROM LBACSYS.dba_lbac_policies p, LBACSYS.dba_ols_users u
  WHERE p.policy_name=u.policy_name
/

