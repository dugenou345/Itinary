create PROCEDURE         dp_drop_rls_policy wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
222 15c
/+wNXGzbEpWvR3U+zJRfgroUkMYwg5DIf/ZqfC8C2sHqdmuEHeiEKTwp2HabN2ZYt2gbTCF3
DK8v7iVrc4ENaASOWr3DbVO/uxB2ZJSwEQW9NU/gJBxedgfQdUpq+AUfaDuPl07la6Rgbdrh
YaVfUauJB/wnfHB5fSytsTmfPMFp9s+R/Vq3fiuKrw49pCfhRIiCA7GaaqUxsD9ZHpMhcZmX
+1nwlyzkEPkg2q7TsC51YpZ2q2lI4buEQbqJ9I5a5CXG3kJ7YdjK0DW0/Pxx35GBooHk8gjQ
dgVi1XTc3bEMKOmhbEWJlvdyC5zdDG1Mc1SNkG//D4aLKYtbGL4Q0w==
/

