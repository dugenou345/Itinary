create view DBA_SA_SCHEMA_POLICIES as
SELECT s.policy_name, schema_name, s.status, schema_options
  FROM LBACSYS.dba_lbac_policies p, LBACSYS.dba_lbac_schema_policies s
  WHERE p.policy_name=s.policy_name
    AND p.package='LBAC$SA'
/

