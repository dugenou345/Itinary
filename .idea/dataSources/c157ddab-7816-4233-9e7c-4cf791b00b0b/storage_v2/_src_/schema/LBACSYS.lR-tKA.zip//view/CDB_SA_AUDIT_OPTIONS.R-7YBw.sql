create view CDB_SA_AUDIT_OPTIONS as
SELECT k."POLICY_NAME",k."USER_NAME",k."APY",k."REM",k."SET_",k."PRV",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_AUDIT_OPTIONS") k
/

comment on table CDB_SA_AUDIT_OPTIONS is ' in all containers'
/

comment on column CDB_SA_AUDIT_OPTIONS.CON_ID is 'container id'
/

