create view DBA_LBAC_LABEL_TAGS as
SELECT pol_name AS policy_name,
         slabel AS labelvalue,
         nlabel AS labeltag,
         DECODE (l.flags,2,'USER LABEL',
                 3, 'USER/DATA LABEL','UNDEFINED') AS
         labeltype
  FROM LBACSYS.ols$lab l, LBACSYS.ols$pol p
  WHERE p.pol# = l.pol#
/

