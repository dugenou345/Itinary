create view DBA_LBAC_DATA_LABELS as
SELECT pol_name AS policy_name,
         slabel AS label,
         nlabel AS label_tag
  FROM LBACSYS.ols$lab l, LBACSYS.ols$pol p
  WHERE p.pol# = l.pol# AND BITAND(l.flags,1)=1
/

