create view USER_SA_SESSION as
SELECT p.pol_name AS policy_name,
         lbacsys.sa_session.sa_user_name(p.pol_name)    AS sa_user_name,
         lbacsys.sa_session.privs(p.pol_name)           AS privs,
         lbacsys.sa_session.max_read_label(p.pol_name)  AS max_read_label,
         lbacsys.sa_session.max_write_label(p.pol_name) AS max_write_label,
         lbacsys.sa_session.min_level(p.pol_name)       AS min_level,
         lbacsys.sa_session.label(p.pol_name)           AS label,
         lbacsys.sa_session.comp_write(p.pol_name)      AS comp_write,
         lbacsys.sa_session.group_write(p.pol_name)     AS group_write,
         lbacsys.sa_session.row_label(p.pol_name)       AS row_label
  FROM LBACSYS.ols$pol p
  WHERE p.package='LBAC$SA'
/

