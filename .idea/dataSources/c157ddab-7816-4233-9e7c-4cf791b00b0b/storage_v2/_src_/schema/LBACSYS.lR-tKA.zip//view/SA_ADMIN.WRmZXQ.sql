create view SA$ADMIN as
SELECT POL#, pol_name, granted_role admin_role, R.grantee usr_name
  FROM LBACSYS.ols$pol P,
       sys.dba_role_privs R
 WHERE P.package = 'LBAC$SA'
   AND R.granted_role = P.pol_role
/

