create view ORDDCM_STORED_TAGS_USR as
select ATTR_TAG, DOC_ID
from  ORDDATA.ORDDCM_STORED_TAGS_TMP
with read only
/

