create type         "SYS_YOID0000075491$"              as object( "SYS_NC00001$" VARCHAR2(8 BYTE))
/

