create type       ku$_dv_auth_ras_as_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  oidval        raw(16),                                       /* unique id */
  grantee_name  varchar2(128),                           /* name of grantee */
  ras_user      varchar2(128)                   /* name of application user */
)
/

