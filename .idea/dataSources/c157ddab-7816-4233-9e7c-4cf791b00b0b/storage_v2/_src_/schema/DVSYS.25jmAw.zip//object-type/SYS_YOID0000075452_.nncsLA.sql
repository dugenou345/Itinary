create type         "SYS_YOID0000075452$"              as object( "SYS_NC00001$" RAW(16))
/

