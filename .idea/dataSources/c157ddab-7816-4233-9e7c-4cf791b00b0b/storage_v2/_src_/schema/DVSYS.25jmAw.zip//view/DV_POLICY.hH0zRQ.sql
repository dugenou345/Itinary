create view DV$POLICY (ID#, NAME, DESCRIPTION, STATE, PL_SQL_STACK) as
SELECT
    p.id#
  , pt.name
  , pt.description
  , p.state
  , decode(p.pl_sql_stack, 0, 'NO',
                           1, 'YES')
FROM dvsys.policy$ p, dvsys.policy_t$ pt
WHERE p.id# = pt.id# AND
      pt.language = DVSYS.dvlang(pt.id#, 7)
/

