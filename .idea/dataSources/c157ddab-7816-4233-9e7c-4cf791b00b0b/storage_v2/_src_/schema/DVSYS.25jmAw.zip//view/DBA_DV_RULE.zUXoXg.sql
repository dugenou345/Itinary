create view DBA_DV_RULE (NAME, RULE_EXPR, COMMON, INHERITED, ID#, ORACLE_SUPPLIED) as
SELECT
      d.name
    , m.rule_expr
    , decode(m.scope, 1, 'NO',
                      2, 'YES',
                      3, 'YES') common
    , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
           THEN 'YES'
           ELSE 'NO'
      END inherited
    , m.id#
    , CASE WHEN (m.id# < 5000)
           THEN 'YES'
           ELSE 'NO'
      END
FROM dvsys.rule$ m, dvsys.rule_t$ d
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 4)
/

