create PACKAGE       dbms_macutl AS

  /********************/
  /* Global Constants */
  /********************/
  -- Yes constant for enabled and label_ind columns (Boolean TRUE)
  g_yes CONSTANT VARCHAR2(1) := 'Y';
  -- No constant for enabled and label_ind columns (Boolean FALSE)
  g_no  CONSTANT VARCHAR2(1) := 'N';
  -- constant for training mode
  -- Bug 22840314: Change 'T' for training to 'S' for simulation
  g_simulation CONSTANT VARCHAR2(1) := 'S';

  -- Factor audit_options: No audit
  g_audit_off                       CONSTANT NUMBER := 0;
  -- Factor audit_options: Always audit
  g_audit_always                    CONSTANT NUMBER := POWER(2,0);
  -- Factor audit_options: Audit if get_expr returns an error
  g_audit_on_get_error              CONSTANT NUMBER := POWER(2,1);
  -- Factor audit_options: Audit if get_expr is null
  g_audit_on_get_null               CONSTANT NUMBER := POWER(2,2);
  -- Factor audit_options: Audit if validation function returns error
  g_audit_on_validate_error         CONSTANT NUMBER := POWER(2,3);
  -- Factor audit_options: Audit if validation function is false
  g_audit_on_validate_false         CONSTANT NUMBER := POWER(2,4);
  -- Factor audit_options: Audit if no trust level
  g_audit_on_trust_level_null       CONSTANT NUMBER := POWER(2,5);
  -- Factor audit_options: Audit if trus level is negative
  g_audit_on_trust_level_neg        CONSTANT NUMBER := POWER(2,6);

  -- Fail_options: Fail with message
  g_fail_with_message   CONSTANT NUMBER := POWER(2,0);
  -- Fail_options: Fail with message
  g_fail_silently       CONSTANT NUMBER := POWER(2,1);

  -- Factor identify_by column: Fixed value in get_expr column
  g_identify_by_constant    CONSTANT NUMBER := 0;
  -- Factor identify_by column: Expression in get_expr column
  g_identify_by_method      CONSTANT NUMBER := 1;
  -- Factor identify_by column: Sub-factors via factor_link$ table
  g_identify_by_factor      CONSTANT NUMBER := 2;
  -- Factor identify_by session context
  g_identify_by_context     CONSTANT NUMBER := 3;

  -- Factor identify_by column:  Expression and Rule Set via factor_expr$ table
  -- g_identify_by_ruleset     CONSTANT NUMBER := 4;

  -- Factor eval_options: Evaluate once upon login
  g_eval_on_session CONSTANT NUMBER := 0;
  -- Factor eval_options: Re-evaluate on each access
  g_eval_on_access  CONSTANT NUMBER := 1;
  -- Factor eval_options: Evaluate once at database startup
  g_eval_on_startup  CONSTANT NUMBER := 2;

  -- Factor labeled_by column: Factor's identities are labeled
  g_labeled_by_self     CONSTANT NUMBER := 0;
  -- Factor labeled_by column: Derive label from sub-factor and merge algorithm
  g_labeled_by_factors  CONSTANT NUMBER := 1;

  -- Realm Objects: Wild card to indicate all object names or all object types
  g_all_object CONSTANT VARCHAR2(1) := '%';

  -- Rule Set audit_options: No auditing
  g_ruleset_audit_off            CONSTANT NUMBER := 0;
  -- Rule Set audit_options: Audit on Rule Set failure
  g_ruleset_audit_fail           CONSTANT NUMBER := POWER(2,0);
  -- Rule Set audit_options: Audit on Rule Set success
  g_ruleset_audit_success        CONSTANT NUMBER := POWER(2,1);

  -- Rule Set eval_options: Rule Set succeeds if all Rules are TRUE
  g_ruleset_eval_all             CONSTANT NUMBER := 1;
  -- Rule Set eval_options: Rule Set succeeds if any Rule is TRUE
  g_ruleset_eval_any             CONSTANT NUMBER := 2;

  -- Rule Set fail_options: Show error message
  g_ruleset_fail_show            CONSTANT NUMBER := 1;
  -- Rule Set fail_options: No error message
  g_ruleset_fail_silent          CONSTANT NUMBER := 2;

  -- Rule Set handler_options: No call to handler
  g_ruleset_handler_off          CONSTANT NUMBER := 0;
  -- Rule Set handler_options: Call handler on Rule Set failure
  g_ruleset_handler_fail         CONSTANT NUMBER := POWER(2,0);
  -- Rule Set handler_options: Call handler on Rule Set success
  g_ruleset_handler_success      CONSTANT NUMBER := POWER(2,1);

  -- Realm audit_options: No auditing
  g_realm_audit_off              CONSTANT NUMBER := 0;
  -- Realm audit_options: Audit on realm violation
  g_realm_audit_fail             CONSTANT NUMBER := POWER(2,0);
  -- Realm audit_options: Audit on successful realm access
  g_realm_audit_success          CONSTANT NUMBER := POWER(2,1);

  -- Realm authoriations: Participant
  g_realm_auth_participant       CONSTANT NUMBER := 0;
  -- Realm authoriations: Owner
  g_realm_auth_owner             CONSTANT NUMBER := 1;

  -- Code groups: Audit Event Descriptions
  g_codes_audit_events    CONSTANT VARCHAR2(30) := 'AUDIT_EVENTS';
  -- Code groups: Boolean values
  g_codes_boolean         CONSTANT VARCHAR2(30) := 'BOOLEAN';
  -- Code groups: DDL commands
  g_codes_ddl_cmds        CONSTANT VARCHAR2(30) := 'DDL_CMDS';
  -- Code groups: Factor audit_options
  g_codes_factor_audit    CONSTANT VARCHAR2(30) := 'FACTOR_AUDIT';
  -- Code groups: Factor eval_options
  g_codes_factor_eval     CONSTANT VARCHAR2(30) := 'FACTOR_EVALUATE';
  -- Code groups: Factor fail_options
  g_codes_factor_fail     CONSTANT VARCHAR2(30) := 'FACTOR_FAIL';
  -- Code groups: Factor identity_by
  g_codes_factor_identify CONSTANT VARCHAR2(30) := 'FACTOR_IDENTIFY';
  -- Code groups: Factor labeled_by
  g_codes_factor_label    CONSTANT VARCHAR2(30) := 'FACTOR_LABEL';
  -- Code groups: Database object types
  g_codes_db_object_type  CONSTANT VARCHAR2(30) := 'DB_OBJECT_TYPE';
  -- Code groups: OLS Policy merge algorithms
  g_codes_label_alg       CONSTANT VARCHAR2(30) := 'LABEL_ALG';
  -- Code groups: DV Error messages
  g_codes_messages        CONSTANT VARCHAR2(30) := 'DV_MESSAGES';
  -- Code groups: SQL relational operators
  g_codes_operators       CONSTANT VARCHAR2(30) := 'OPERATORS';
  -- Code groups: Realm audit_options
  g_codes_realm_audit     CONSTANT VARCHAR2(30) := 'REALM_AUDIT';
  -- Code groups: Rule Set audit_options
  g_codes_ruleset_audit   CONSTANT VARCHAR2(30) := 'RULESET_AUDIT';
  -- Code groups: Rule Set evaluate_options
  g_codes_ruleset_eval    CONSTANT VARCHAR2(30) := 'RULESET_EVALUATE';
  -- Code groups: Rule Set handler_options
  g_codes_ruleset_event   CONSTANT VARCHAR2(30) := 'RULESET_EVENT';
  -- Code groups: Rule Set fail_options
  g_codes_ruleset_fail    CONSTANT VARCHAR2(30) := 'RULESET_FAIL';
  -- Code groups: SQL Commands
  g_codes_sql_cmds        CONSTANT VARCHAR2(30) := 'SQL_CMDS';

  -- Context:   Namespace, Attribute, Value
  -- MACSEC/MACOLS context start with this
  g_context_prefix CONSTANT VARCHAR2(30) := 'MAC$';
  -- Factor Labels:    MAC$F$<policy>, <factor_name>, <factor label>
  g_context_factor_label CONSTANT VARCHAR2(30) := g_context_prefix||'F$';
  -- Session Labels:   MAC$S$<policy>, <session attribute>, <label>
  g_context_session_label CONSTANT VARCHAR2(30) := g_context_prefix||'S$';
  -- Factors:   MAC$FACTOR,<factor name>, <factor value>
  g_context_factor CONSTANT VARCHAR2(30) := g_context_prefix||'FACTOR';
  -- Realm:   MAC$REALM,<factor name>, <factor value>
  g_context_realm CONSTANT VARCHAR2(30) := g_context_prefix||'REALM';

  -- This is that label that a factor will a null label will default to
  g_min_policy_label CONSTANT VARCHAR2(30) := 'MIN_POLICY_LABEL';
  -- This is the highest label a user could set based on the factors
  -- (it does not take into account the user's label)
  g_max_session_label CONSTANT VARCHAR2(30) := 'MAX_SESSION_LABEL';
  -- The user's OLS session label at the time init_session is executed
  g_ols_session_label CONSTANT VARCHAR2(30) := 'OLS_SESSION_LABEL';
  -- This is what MACOLS decided the user's label should be set to
  -- after factoring in the above values.
  g_user_policy_label CONSTANT VARCHAR2(30) := 'USER_POLICY_LABEL';

  -- Variables to set scope of DV Realms, Command Rules, Rules, and Rule Sets.
  g_scope_local         CONSTANT NUMBER := 1;
  g_scope_common        CONSTANT NUMBER := 2;

  -- Constants to indicate ACTION strings for datapump authorization API.
  g_dp_act_all               CONSTANT VARCHAR2(30) := '%';
  g_dp_act_table             CONSTANT VARCHAR2(30) := 'TABLE';
  g_dp_act_grant             CONSTANT VARCHAR2(30) := 'GRANT';
  g_dp_act_create_user       CONSTANT VARCHAR2(30) := 'CREATE_USER';

  /**
  * Returns an indicator as to whether or not OLS is installed
  *
  * @return TRUE if OLS is installed
  */
  FUNCTION is_ols_installed RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_ols_installed, NONE);


  /**
  * Returns an indicator as to whether or not OLS is installed
  *
  * @return Y if OLS is installed, N otherwise
  */
  FUNCTION is_ols_installed_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_ols_installed_varchar, NONE);

  /**
  * Returns an indicator as to whether or not DV is enabled
  *
  * @return TRUE if DV is enabled, FALSE otherwise
  */
  FUNCTION is_dv_enabled RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_dv_enabled, NONE);

  -- check DATAPUMP DV authorization at full database level
  FUNCTION check_full_dvauth RETURN BINARY_INTEGER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_full_dvauth, NONE);

  -- check DATAPUMP/TTS DV authorization for a specified tablespace
  FUNCTION check_ts_dvauth(ts_name IN VARCHAR2) RETURN BINARY_INTEGER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_ts_dvauth, NONE);

  -- check DATAPUMP/TTS DV authorization for a specified table
  FUNCTION check_tab_dvauth(schema_name IN VARCHAR2,
                            table_name  IN VARCHAR2) RETURN BINARY_INTEGER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_tab_dvauth, NONE);

  /**
  * Returns an indicator as to whether or not DV is enabled
  *
  * @return Y if DV is enabled, N otherwise
  */
  FUNCTION is_dv_enabled_varchar RETURN VARCHAR2 ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_dv_enabled_varchar, NONE);

  /**
  * Returns an indicator as to whether or not OID enabled OLS is installed
  *
  * @return TRUE if OID enabled OLS is installed
  */
  FUNCTION is_oid_enabled_ols RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_oid_enabled_ols, NONE);

  /**
  * Returns ldap user if OID enabled OLS is installed
  *
  * @return logon user
  */
  FUNCTION ols_ldap_user RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(ols_ldap_user, NONE);

  /**
  * Returns unique user ID whether user is from OID or standard database accounts
  *
  * @return unique user ID from OID or dbms_standard.login_user
  */
  FUNCTION unique_user RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(unique_user, NONE);

  /**
  * Returns ALLOW COMMON OPERATION status
  *
  * @return status string for ALLOW COMMON OPERATION
  */
  FUNCTION GET_ACO_STATUS RETURN PLS_INTEGER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(GET_ACO_STATUS, NONE);

  /**
  * Looks up the value for a code within a code group
  *
  * @param p_code_group Code group - e.g. AUDIT_EVENTS or BOOLEAN
  * @return Value of the code
  */
  FUNCTION get_code_value(p_code_group VARCHAR2, p_code VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_code_value, NONE);

  /**
  * Looks up the id for a code within a code group
  *
  * @param p_code_group Code group - e.g. AUDIT_EVENTS or BOOLEAN
  * @return Id of the code
  */
  FUNCTION get_code_id(p_code_group VARCHAR2, p_code VARCHAR2) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_code_id, NONE);

  /**
  * Looks up an error message and replaces parameters accordingly
  *
  * @param p_message_code VARCHAR Message code
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  * @param p_parameter4 Value to substitute for %4
  * @param p_parameter5 Value to substitute for %5
  * @param p_parameter6 Value to substitute for %6
  * @return Error message
  */
  FUNCTION get_message_label(p_message_code VARCHAR2,
                        p_parameter1   IN VARCHAR2 DEFAULT NULL,
                        p_parameter2   IN VARCHAR2 DEFAULT NULL,
                        p_parameter3   IN VARCHAR2 DEFAULT NULL,
                        p_parameter4   IN VARCHAR2 DEFAULT NULL,
                        p_parameter5   IN VARCHAR2 DEFAULT NULL,
                        p_parameter6   IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_message_label, NONE);

  /**
  * Looks up an error message and replaces parameters accordingly
  *
  * @param p_message_code NUMBER Message code
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  * @param p_parameter4 Value to substitute for %4
  * @param p_parameter5 Value to substitute for %5
  * @param p_parameter6 Value to substitute for %6
  * @return Error message
  */
  FUNCTION get_message_label(p_message_code NUMBER,
                        p_parameter1   IN VARCHAR2 DEFAULT NULL,
                        p_parameter2   IN VARCHAR2 DEFAULT NULL,
                        p_parameter3   IN VARCHAR2 DEFAULT NULL,
                        p_parameter4   IN VARCHAR2 DEFAULT NULL,
                        p_parameter5   IN VARCHAR2 DEFAULT NULL,
                        p_parameter6   IN VARCHAR2 DEFAULT NULL) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_message_label, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  */
  PROCEDURE raise_error(p_message_code IN NUMBER);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2,
                        p_parameter2   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2,
                        p_parameter2   IN VARCHAR2,
                        p_parameter3   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  * @param p_parameter4 Value to substitute for %4
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2,
                        p_parameter2   IN VARCHAR2,
                        p_parameter3   IN VARCHAR2,
                        p_parameter4   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  * @param p_parameter4 Value to substitute for %4
  * @param p_parameter5 Value to substitute for %5
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2,
                        p_parameter2   IN VARCHAR2,
                        p_parameter3   IN VARCHAR2,
                        p_parameter4   IN VARCHAR2,
                        p_parameter5   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);

  /**
  * Convience function to look up an error message and
  * replaces parameters accordingly and raise an exception
  *
  * @param p_message_code Oracle error number
  * @param p_parameter1 Value to substitute for %1
  * @param p_parameter2 Value to substitute for %2
  * @param p_parameter3 Value to substitute for %3
  * @param p_parameter4 Value to substitute for %4
  * @param p_parameter5 Value to substitute for %5
  * @param p_parameter6 Value to substitute for %6
  */
  PROCEDURE raise_error(p_message_code IN NUMBER,
                        p_parameter1   IN VARCHAR2,
                        p_parameter2   IN VARCHAR2,
                        p_parameter3   IN VARCHAR2,
                        p_parameter4   IN VARCHAR2,
                        p_parameter5   IN VARCHAR2,
                        p_parameter6   IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_error, NONE);


  /**
  * Converts the audit_options value for a table to a VARCHAR2 form.
  *
  * @param p_table_name Name of a DV table with a audit_options column (e.g. realm$)
  * @param p_audit_options Audit_options column value (can be several options 'OR-ed' together')
  * @return Audit_options in VARCHAR2 form, separated by commas
  */
  FUNCTION decode_audit_options(p_table_name IN VARCHAR2,
                                p_audit_options IN NUMBER) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(decode_audit_options, NONE);

  /**
  * Constructs an XML document which contains the values for all of the factors.  Note that
  * the document is only intended for auditing or tracing and will be truncated if it is
  * longer than 4000 characters.
  *
  * @return XML document containing the factor context
  */
  FUNCTION get_factor_context(skip_default IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_factor_context, NONE);

  /**
  * Concatenates the elements of an ora_name_list_t into a single VARCHAR2.
  *
  * @param p_sql_test Table of VARCHAR2 strings
  * @return Single string
  */
  FUNCTION get_sql_text(p_sql_text IN ora_name_list_t) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_sql_text, NONE);

  /**
  * Checks whether the character is alphabetic.
  *
  * @param c String with one character
  * @return TRUE if the character is alphabetic
  */
  FUNCTION is_alpha(c IN varchar2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_alpha, NONE);

  /**
  * Checks whether the character is numeric
  *
  * @param c String with one character
  * @return TRUE if the character is a digit
  */
  FUNCTION is_digit(c IN varchar2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_digit, NONE);

  /**
  * Alters a string to make it a legal Oracle identifier
  *
  * @param id Illegal identifier
  * @return Identifier
  */
  FUNCTION to_oracle_identifier(id IN varchar2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(to_oracle_identifier, NONE);

  /**
  * Validates and canonicalizes the given user/role name
  *
  * @param   user/role name
  * @return  canonicalized name
  *
  * Note: This function will raise ORA-44003 if the given name is not
  *       a valid SQL name.
  */
  FUNCTION validate_name(name IN varchar2) RETURN DBMS_ID;
  PRAGMA SUPPLEMENTAL_LOG_DATA(validate_name, NONE);

  /**
  * Convenience procedure for generic disallowed operation exception.
  *
  * @param p_user User performing the operation
  */
  PROCEDURE raise_unauthorized_operation(p_user IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(raise_unauthorized_operation, NONE);

  /**
  * Determines whether a user is authorized to manage the DV configuration.  The
  * DVSYS user and users granted the DV_OWNER role are authorized.
  *
  * @param p_user     User to check
  * @param p_profile  Whether to capture role usage
  * @param p_scope    COMMON or LOCAL
  *
  * @return TRUE if user is authorized
  */
  FUNCTION is_dvsys_owner(p_user    IN VARCHAR2 DEFAULT
                            sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                          p_profile IN BOOLEAN DEFAULT TRUE,
                          p_scope   IN VARCHAR2 := 'LOCAL') RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_dvsys_owner, NONE);

  /**
  * Verifies that a public-APIs are not being bypassed by users updating the DV
  * configuration.
  *
  * @param p_user User performing the operation
  */
  PROCEDURE check_dvsys_dml_allowed(p_user IN VARCHAR2 DEFAULT
                                      sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE));
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_dvsys_dml_allowed, NONE);

  /**
  * Checks for a string in the PL/SQL call stack
  *
  * @param p_search_term String to search for
  * @return TRUE if string is in the call stack
  */
  FUNCTION in_call_stack(p_search_term IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(in_call_stack, NONE);

  /**
  * Checks whether a user has a role granted directly or indirectly (via another role).
  *
  * @param p_role Role privilege to check for
  * @param p_user User
  * @param p_profile Whether to capture the role usage; When the role checked
  *        is used, please set p_profile to TRUE
  * @param p_scope COMMON or LOCAL
  * @return TRUE if user has the role granted with the specified scope
  */
  FUNCTION user_has_role(p_role IN VARCHAR2,
                         p_user IN VARCHAR2 DEFAULT
                            sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                         p_profile IN BOOLEAN DEFAULT TRUE,
                         p_scope IN VARCHAR2 := 'LOCAL')
    RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(user_has_role, NONE);

  /**
  * Checks whether 'alter system dump datafile' is only dumping header block.
  *
  */
  FUNCTION alter_system_dump_allowed
    RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_system_dump_allowed, NONE);

  FUNCTION alter_system_dump_varchar
    RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_system_dump_varchar, NONE);

  /**
  * Checks whether the given role is enabled in the current session.
  *
  * @param p_role Role to check
  * @return TRUE if the role is enabled in the current session
  */
  FUNCTION session_enabled_role(p_role    IN VARCHAR2)
    RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(session_enabled_role, NONE);


  /**
  * Checks whether a user or role may access an object via a object privilege
  * grant.  The object privilege may have been granted directly to the
  * specified user/role or may have been granted indirectly via another role.
  *
  * @param p_user User or Role
  * @param p_object_owner Object owner
  * @param p_object_name Object name
  * @param p_privilege Object privilege (SELECT, UPDATE, INSERT, ...)
  * @param p_profile Whether to capture the object privilege; When the
  *        privilege checked by this function is used, please set p_profile
  *        to TRUE.
  * @return TRUE if user/role has the privilege
  */
  FUNCTION user_has_object_privilege(p_user         IN VARCHAR2,
                                     p_object_owner IN VARCHAR2,
                                     p_object_name  IN VARCHAR2,
                                     p_privilege    IN VARCHAR2,
                                     p_profile      IN BOOLEAN DEFAULT TRUE)
   RETURN BOOLEAN;
   PRAGMA SUPPLEMENTAL_LOG_DATA(user_has_object_privilege, NONE);

  /**
  * Checks whether a user has a role granted directly or indirectly (via another role).
  *
  * @param p_role Role privilege to check for
  * @param p_user User
  * @param p_profile Whether to capture the role usage; When the role checked
  *        is used, please set p_profile to 1.
  * @param p_scope COMMON or LOCAL
  * @return Y if use has the role granted with the specified scope, N otherwise
  */
  FUNCTION user_has_role_varchar(p_role IN VARCHAR2,
                                 p_user IN VARCHAR2 DEFAULT
                                 sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                                 p_profile IN INTEGER DEFAULT 1,
                                 p_scope IN VARCHAR2 := 'LOCAL')
   RETURN VARCHAR2;
   PRAGMA SUPPLEMENTAL_LOG_DATA(user_has_role_varchar, NONE);

  /**
  * Checks whether a user has a role granted directly or indirectly (via another role)
  * with a sufficient scope or the role currently is enabled in the session while
  * the role is not granted.
  *
  * @param p_role Role privilege to check for
  * @param p_user User
  * @param p_scope COMMON or LOCAL
  * @param p_profile Whether to capture the role usage; When the role checked
  *        is used, please set p_profile to 1.
  * @return Y if use has the role granted with the specified scope or
  *  the role is not granted but enabled in the session, N otherwise
  */
  FUNCTION role_granted_enabled_varchar(p_role IN VARCHAR2,
                                        p_user IN VARCHAR2 DEFAULT
                                           sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                                        p_profile IN INTEGER DEFAULT 1,
                                        p_scope IN VARCHAR2 := 'LOCAL')
   RETURN VARCHAR2;
   PRAGMA SUPPLEMENTAL_LOG_DATA(role_granted_enabled_varchar, NONE);

  /**
  * Checks whether the given role is enabled in the current session.
  *
  * @param p_role Role to check
  * @return Y if the role is enabled in the current session, N otherwise
  */
  FUNCTION session_enabled_role_varchar(p_role    IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(session_enabled_role_varchar, NONE);

  /**
  * Checks whether a user has a system privilege, directly or indirectly (via a role).
  *
  * @param p_role System privilege to check for
  * @param p_user User
  * @param p_profile Whether to capture the system privilege; When the
  *        privilege checked by this function is used, please set p_profile
  *        to TRUE.
  * @return TRUE if use has the privilege
  */
  FUNCTION user_has_system_privilege(p_privilege IN VARCHAR2,
                                     p_user IN VARCHAR2 DEFAULT
                                        sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                                     p_profile IN BOOLEAN DEFAULT TRUE)
   RETURN BOOLEAN;
   PRAGMA SUPPLEMENTAL_LOG_DATA(user_has_system_privilege, NONE);

  /**
  * Checks whether a user has a system privilege, directly or indirectly (via a role).
  *
  * @param p_role System privilege to check for
  * @param p_user User
  * @param p_profile Whether to capture the system privilege; When the
  *        privilege checked by this function is used, please set p_profile
  *        to TRUE.
  * @return Y if use has the privilege; N otherwise
  */
  FUNCTION user_has_system_priv_varchar (p_privilege IN VARCHAR2,
                                         p_user IN VARCHAR2 DEFAULT
                                            sys.dbms_assert.enquote_name(SYS_CONTEXT('USERENV', 'CURRENT_USER'), FALSE),
                                         p_profile IN BOOLEAN DEFAULT TRUE)
   RETURN VARCHAR2;
   PRAGMA SUPPLEMENTAL_LOG_DATA(user_has_system_priv_varchar, NONE);

 /*
  * Checks whether the given user can perform Streams administrative operation.
  * This is determined by whether the user has DV_STREAMS_ADMIN role. Note that
  * if DV is not enabled, then this function returns TRUE.
  *
  * @param p_user User
  * @return TRUE if 1) DV is not enabled, or 2) the user has DV_STREAMS_ADMIN role.
  *         FALSE otherwise.
  */
  FUNCTION check_streams_admin(p_user IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_streams_admin, NONE);

 /*
  * Checks whether the given user can perform Golden Gate extract operation.
  * This is determined by whether the user has DV_GOLDENGATE_ADMIN role. Note
  * that if DV is not enabled, then this function returns TRUE.
  *
  * @param p_user User
  * @return TRUE if 1) DV is not enabled, or 2) user has DV_GOLDENGATE_ADMIN role.
  *         FALSE otherwise.
  */
  FUNCTION check_goldengate_admin(p_user IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_goldengate_admin, NONE);

 /*
  * Checks whether the given user can perform XSTREAM capture operation.
  * This is determined by whether the user has DV_XSTREAM_ADMIN role. Note
  * that if DV is not enabled, then this function returns TRUE.
  *
  * @param p_user User
  * @return TRUE if 1) DV is not enabled, or 2) user has DV_XSTREAM_ADMIN role.
  *         FALSE otherwise.
  */
  FUNCTION check_xstream_admin(p_user IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_xstream_admin, NONE);

 /*
  * Checks whether the given user can perform Golden Gate extract operation
  * using the OCI interface. This is determined by whether the user has the
  * DV_GOLDENGATE_REDO_ACCESS role. Note that if DV is not enabled, then this
  * function always returns TRUE.
  *
  * @param p_user User
  * @return TRUE if 1) DV is not enabled, or
  *                 2) user has DV_GOLDENGATE_REDO_ACCESS role.
  *         FALSE otherwise.
  */
  FUNCTION check_goldengate_redo_access(p_user IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_goldengate_redo_access, NONE);

 /*
  * Obtain the pipelined table of status of the events 10079 and 24473.
  *
  * @return pipelined table
  */
  FUNCTION get_event_status RETURN dvsys.event_status_table_type PIPELINED;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_event_status, NONE);

  /**
  * Returns the month in Oracle MM format (01-12).
  * @param p_date Date
  * @return Month 01-12.
  */
  FUNCTION get_month(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_month, NONE);

  /**
  * Returns the day in Oracle DD format (01-31).
  *
  * @param p_date Date
  * @return Day 01-31.
  */
  FUNCTION get_day(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_day, NONE);

  /**
  * Returns the year in Oracle YYYY format (0001-9999).
  *
  * @param p_date Date
  * @return Year 0001-9999.
  */
  FUNCTION get_year(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_year, NONE);

  /**
  * Returns the month in Oracle HH24 format (00-23).
  *
  * @param p_date Date
  * @return Hour 00-23.
  */
  FUNCTION get_hour(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_hour, NONE);

  /**
  * Returns the minute in Oracle MI format (00-59).
  *
  * @param p_date Date
  * @return Minute 00-59.
  */
  FUNCTION get_minute(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_minute, NONE);

  /**
  * Returns the seconds in Oracle SS format (00-59).
  *
  * @param p_date Date
  * @return Second 00-59.
  */
  FUNCTION get_second(p_date IN DATE DEFAULT SYSDATE) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_second, NONE);

END;
/

