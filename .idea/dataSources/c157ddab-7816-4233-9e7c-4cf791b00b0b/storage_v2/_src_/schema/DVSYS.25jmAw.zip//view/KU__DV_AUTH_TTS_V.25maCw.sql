create view KU$_DV_AUTH_TTS_V (VERS_MAJOR, VERS_MINOR, GRANTEE_NAME, TS_NAME) as
select '0','0',
          t.grantee,
          t.tsname
  from    dvsys.dba_dv_tts_auth t
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

