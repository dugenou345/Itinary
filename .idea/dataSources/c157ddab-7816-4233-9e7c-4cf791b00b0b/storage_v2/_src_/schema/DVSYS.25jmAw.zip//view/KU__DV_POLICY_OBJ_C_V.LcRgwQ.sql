create view KU$_DV_POLICY_OBJ_C_V
            (VERS_MAJOR, VERS_MINOR, OIDVAL, POLICY_NAME, COMMAND, OBJECT_OWNER, OBJECT_NAME, SCOPE) as
select '0','0',sys_guid(),
          p.name,
          cr.command,
          cr.object_owner,
          cr.object_name,
          decode(crtab.scope, 1, 1,
                              2, 2,
                              3, 2)
  from    dvsys.policy_t$               p,
          dvsys.policy_object$          po,
          dvsys.dba_dv_command_rule_id  cr,
          dvsys.command_rule$           crtab
  where   po.id# >= 5000 and cr.id# = crtab.id#
    and   po.object_type = 2  -- command rule
    and   cr.command <> 'ALTER SYSTEM'
    and   cr.command <> 'ALTER SESSION'
    and   po.policy_id# = p.id#
    and   po.object_id# = cr.id#
    and   p.language = DVSYS.dvlang(p.id#, 7)
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

