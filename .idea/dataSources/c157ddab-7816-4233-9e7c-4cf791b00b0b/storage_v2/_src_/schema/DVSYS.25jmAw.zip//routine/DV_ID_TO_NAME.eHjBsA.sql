create function       dv_id_to_name (A   in dvsys.simulation_ids,
                                                dv_obj_type in pls_integer)
return VARCHAR2 as
  name_str    varchar2(32767) := '';
  i           integer         := 0;
  dv_name     varchar2(128);
  stmt        varchar2(50);
  vchartyp    varchar2(16)    := 'STANDARD';
  maxvcharsz  number;
begin
  IF (A.count > 0) THEN

    stmt := 'select value from v$parameter where name = :1';
    EXECUTE IMMEDIATE stmt INTO vchartyp USING 'max_string_size';

    IF vchartyp = 'EXTENDED' THEN
      maxvcharsz := 32767;
    ELSE -- STANDARD
      maxvcharsz := 4000;
    END IF;

    -- Set Execute Statement
    IF (dv_obj_type = 1) THEN -- Realm
      stmt := 'SELECT name FROM dvsys.dv$realm where id# = :1';
    ELSIF (dv_obj_type = 2) THEN -- Rule Set
      stmt := 'SELECT name FROM dvsys.dv$rule_set where id# = :1';
    ELSE
      raise_application_error(-20000,
                              'invalid input value for parameter dv_obj_type');
    END IF;

    -- Create comma separated string inside name_str
    FOR i in 1..A.count LOOP
      EXECUTE IMMEDIATE stmt INTO dv_name USING IN A(i);

      -- Remaining buffer length is not sufficient for append dv_name
      IF (maxvcharsz - LENGTH(name_str)) < (LENGTH(dv_name) + 2) THEN
         EXIT; -- Break the loop
      END IF;

      IF name_str IS NOT NULL THEN
        name_str := name_str || ', ' || dv_name;
      ELSE
        name_str := dv_name;
      END IF;
    END LOOP;
  END IF;

  RETURN name_str;
end;
/

