create view POLICY_OWNER_REALM_OBJECT as
SELECT
     d.name
    , d.common
    , d.inherited
    , u.name
    , m.object_name
    , m.object_type
FROM dvsys.realm_object$ m, dvsys.dv$realm d, sys."_BASE_USER" u
WHERE
    d.id# = m.realm_id# AND m.owner_uid# = u.user#
    AND d.id# IN (SELECT object_id#
                   FROM dvsys.policy_object$ pb, dvsys.policy_owner$ pw
                   WHERE pb.policy_id# = pw.policy_id# AND
                         pw.owner_id# =  sys_context('userenv', 'current_userid') AND
                         pb.object_type = 1) --dvsys.dbms_macutl.G_REALM
UNION
SELECT
     d.name
    , d.common
    , d.inherited
    , '%'
    , m.object_name
    , m.object_type
FROM dvsys.realm_object$ m, dvsys.dv$realm d
WHERE
    d.id# = m.realm_id# AND m.owner_uid# = 2147483636
    AND d.id# IN (SELECT object_id#
                   FROM dvsys.policy_object$ pb, dvsys.policy_owner$ pw
                   WHERE pb.policy_id# = pw.policy_id# AND
                         pw.owner_id# =  sys_context('userenv', 'current_userid') AND
                         pb.object_type = 1) --dvsys.dbms_macutl.G_REALM
/

