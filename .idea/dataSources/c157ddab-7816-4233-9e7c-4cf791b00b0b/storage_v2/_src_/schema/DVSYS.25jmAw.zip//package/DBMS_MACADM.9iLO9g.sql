create PACKAGE       dbms_macadm AS

  /* Global Constants */

  MANDATORY_REALM                  CONSTANT BINARY_INTEGER := 1;
  FACTOR_TYPE_CREATION_AUDIT       CONSTANT PLS_INTEGER :=     20032;
  FACTOR_TYPE_DELETION_AUDIT       CONSTANT PLS_INTEGER :=     20033;
  FACTOR_TYPE_UPDATE_AUDIT         CONSTANT PLS_INTEGER :=     20034;
  FACTOR_TYPE_RENAME_AUDIT         CONSTANT PLS_INTEGER :=     20035;

  FACTOR_CREATION_AUDIT            CONSTANT PLS_INTEGER :=     20036;
  FACTOR_DELETION_AUDIT            CONSTANT PLS_INTEGER :=     20037;
  FACTOR_UPDATE_AUDIT              CONSTANT PLS_INTEGER :=     20038;
  FACTOR_RENAME_AUDIT              CONSTANT PLS_INTEGER :=     20039;

  ADD_FACTOR_LINK_AUDIT            CONSTANT PLS_INTEGER :=     20040;
  DELETE_FACTOR_LINK_AUDIT         CONSTANT PLS_INTEGER :=     20041;
  ADD_POLICY_FACTOR_AUDIT          CONSTANT PLS_INTEGER :=     20042;
  DELETE_POLICY_FACTOR_AUDIT       CONSTANT PLS_INTEGER :=     20043;

  IDENTITY_CREATION_AUDIT          CONSTANT PLS_INTEGER :=     20044;
  IDENTITY_DELETION_AUDIT          CONSTANT PLS_INTEGER :=     20045;
  IDENTITY_UPDATE_AUDIT            CONSTANT PLS_INTEGER :=     20046;
  CHANGE_IDENTITY_FACTOR_AUDIT     CONSTANT PLS_INTEGER :=     20047;
  CHANGE_IDENTITY_VALUE_AUDIT      CONSTANT PLS_INTEGER :=     20048;

  IDENTITY_MAP_CREATION_AUDIT      CONSTANT PLS_INTEGER :=     20049;
  IDENTITY_MAP_DELETION_AUDIT      CONSTANT PLS_INTEGER :=     20050;

  POLICY_LABEL_CREATION_AUDIT      CONSTANT PLS_INTEGER :=     20051;
  POLICY_LABEL_DELETION_AUDIT      CONSTANT PLS_INTEGER :=     20052;
  MAC_POLICY_CREATION_AUDIT        CONSTANT PLS_INTEGER :=     20053;
  MAC_POLICY_UPDATE_AUDIT          CONSTANT PLS_INTEGER :=     20054;
  MAC_POLICY_DELETION_AUDIT        CONSTANT PLS_INTEGER :=     20055;

  ROLE_CREATION_AUDIT              CONSTANT PLS_INTEGER :=     20056;
  ROLE_DELETION_AUDIT              CONSTANT PLS_INTEGER :=     20057;
  ROLE_UPDATE_AUDIT                CONSTANT PLS_INTEGER :=     20058;
  ROLE_RENAME_AUDIT                CONSTANT PLS_INTEGER :=     20059;

  DOMAIN_IDENTITY_CREATION_AUDIT   CONSTANT PLS_INTEGER :=     20060;
  DOMAIN_IDENTITY_DROP_AUDIT       CONSTANT PLS_INTEGER :=     20061;

  -- Constants for Database Vault policy states
  g_disabled CONSTANT NUMBER := 0;
  g_enabled  CONSTANT NUMBER := 1;
  g_simulation CONSTANT NUMBER := 2;
  g_partial  CONSTANT NUMBER := 3;

  -- Constants for Database Vault object types
  g_realm        CONSTANT NUMBER := 1;
  g_command_rule CONSTANT NUMBER := 2;

  /*****************************/
  /**Public Administration API */
  /*****************************/

  /**
  * Used to enable auditing on activities performed by user with
  * DV_PATCH_ADMIN role. If DV authorization is successful only because of
  * a user having dv_patch_admin, we would not normally audit this event. But
  * if this procedure is executed, we will record the event in the audit trail.
  */
  PROCEDURE enable_dv_patch_admin_audit;
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_dv_patch_admin_audit, AUTO_WITH_COMMIT);

  /**
  * Used to disable auditing on dv_patch_admin bypass of DV protection.
  */
  PROCEDURE disable_dv_patch_admin_audit;
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_dv_patch_admin_audit, AUTO_WITH_COMMIT);


  /**
  * Used to do the sanity check before configure DV. Check Items includes:
  * The total number of dvsys tables, views, packages package bodies
  * dvf packages, dvf package bodies, dvf functions
  * dependent lbacsys packages and all the dv roles' existence
  */
  PROCEDURE dv_sanity_check;
  PRAGMA SUPPLEMENTAL_LOG_DATA(dv_sanity_check, NONE);

  /**
  * Used to allow mixed case identifiers.  By default, they are not allowed.
  *
  * @param setting TRUE to allow mixed case
  */
  PROCEDURE set_preserve_case(setting IN BOOLEAN);
  PRAGMA SUPPLEMENTAL_LOG_DATA(set_preserve_case, NONE);

  /* Factor Type */

  /**
  * Create a Factor Type
  *
  * @param name Factor Type name
  * @param description Description
  */
  PROCEDURE create_factor_type
              (name        IN varchar2,
               description IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_factor_type, AUTO_WITH_COMMIT);

  /**
  * Delete a Factor Type
  *
  * @param name Factor Type name
  */
  PROCEDURE delete_factor_type
              (name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_factor_type, AUTO_WITH_COMMIT);

  /**
  * Update a Factor Type
  *
  * @param name Factor Type name
  * @param description New Description
  */
  PROCEDURE update_factor_type
              (name IN varchar2,
               description IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_factor_type, AUTO_WITH_COMMIT);

  /**
  * Rename a Factor Type
  *
  * @param old_name Previous Factor Type name
  * @param new_name New Factor Type name
  */
  PROCEDURE rename_factor_type
              (old_name IN varchar2,
               new_name    IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_factor_type, AUTO_WITH_COMMIT);

  /* Factor */

  /**
  * Create a Factor
  *
  * @param factor_name Factor Name
  * @param factor_type_name Factor Type Name
  * @param description Factor description
  * @param rule_set_name Rule Set Name (for assignment)
  * @param get_expr Expression for evaluating Factor
  * @param validate_expr Name of function to validate Factor
  * @param identify_by Options for determining the Factor's identity (see dbms_macutl)
  * @param labeled_by Options for labeling the Factor (see dbms_macutl)
  * @param eval_options Options for evaluating the Factor (see dbms_macutl)
  * @param audit_options Options for auditing the Factor (see dbms_macutl)
  * @param fail_options Options for reporting Factor errors (see dbms_macutl)
  *
  */
  PROCEDURE create_factor
              (factor_name      IN varchar2,
               factor_type_name IN varchar2,
               description      IN varchar2,
               rule_set_name    IN varchar2,
               get_expr         IN varchar2,
               validate_expr    IN varchar2,
               identify_by      IN number,
               labeled_by       IN number,
               eval_options     IN number,
               audit_options    IN number,
               fail_options     IN number,
               namespace           IN varchar2 DEFAULT NULL,
               namespace_attribute IN varchar2 DEFAULT NULL
               );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_factor, AUTO_WITH_COMMIT);

  /**
  * Update a Factor
  *
  * @param factor_name Factor Name
  * @param factor_type_name Factor Type Name
  * @param description Factor description
  * @param rule_set_name Rule Set Name (for assignment)
  * @param get_expr Expression for evaluating Factor
  * @param validate_expr Name of function to validate Factor
  * @param identify_by Options for determining the Factor's identity (see dbms_macutl)
  * @param labeled_by Options for labeling the Factor (see dbms_macutl)
  * @param eval_options Options for evaluating the Factor (see dbms_macutl)
  * @param audit_options Options for auditing the Factor (see dbms_macutl)
  * @param fail_options Options for reporting Factor errors (see dbms_macutl)
  *
  */
  PROCEDURE update_factor
              (factor_name      IN varchar2,
               factor_type_name IN varchar2,
               description      IN varchar2,
               rule_set_name    IN varchar2,
               get_expr         IN varchar2,
               validate_expr    IN varchar2,
               identify_by      IN number,
               labeled_by       IN number,
               eval_options     IN number,
               audit_options    IN number,
               fail_options     IN number,
               namespace           IN varchar2 DEFAULT NULL,
               namespace_attribute IN varchar2 DEFAULT NULL
               );
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_factor, AUTO_WITH_COMMIT);

  /**
  * Delete a Factor
  *
  * @param factor_name Factor to delete
  *
  */
  PROCEDURE delete_factor
              (factor_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_factor, AUTO_WITH_COMMIT);

  /**
  * Rename a Factor
  *
  * @param factor_name Factor to rename
  *
  */
  PROCEDURE rename_factor
              (factor_name IN varchar2, new_factor_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_factor, AUTO_WITH_COMMIT);

  /**Factor Link **/

  /**
  * Specify a parent-child relationship for two factors.  The relationship may be
  * used for computing the Factor's identity or label.
  *
  * @param parent_factor_name Parent Factor name
  * @param child_factor_name Child Factor name
  * @param label_indicator Indication of whether the child contributes to the parent's label
  */
  PROCEDURE add_factor_link
              (parent_factor_name IN varchar2,
               child_factor_name  IN varchar2,
               label_indicator    IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_factor_link, AUTO_WITH_COMMIT);

  /**
  * Remove a parent-child relationship for two factors.
  *
  * @param parent_factor_name Parent Factor name
  * @param child_factor_name Child Factor name
  *
  */
  PROCEDURE delete_factor_link
              (parent_factor_name IN varchar2,
               child_factor_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_factor_link, AUTO_WITH_COMMIT);


  /* Policy Factor */

  /**
  * Specify that the label for a Factor contributes to the MAC OLS Label for a
  * policy.
  *
  * @param policy_name OLS Policy Name
  * @param factor_name Factor Name
  *
  */
  PROCEDURE add_policy_factor
              (policy_name IN varchar2,
               factor_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_policy_factor, AUTO_WITH_COMMIT);

  /**
  * Remove the Factor from contributing to the MAC OLS Label.
  *
  * @param policy_name OLS Policy Name
  * @param factor_name Factor Name
  *
  */
  PROCEDURE delete_policy_factor
              (policy_name IN varchar2,
               factor_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_policy_factor, AUTO_WITH_COMMIT);


  /**
  * Create an Identity.  Entities in the environment which will be labeled should be
  * given an identity (except for users, which are handled by OLS).
  *
  * @param factor_name Factor Name
  * @param value VARCHAR2 value associated with the identity
  * @param trust_level >0 for trust level, =0 for not trusted, <0 for distrust level
  *
  */
  PROCEDURE create_identity
              (factor_name IN varchar2,
               value       IN varchar2,
               trust_level IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_identity, AUTO_WITH_COMMIT);

  /**
  * Update an Identity.
  *
  * @param factor_name Factor Name
  * @param value VARCHAR2 value associated with the identity
  * @param trust_level >0 for trust level, =0 for not trusted, <0 for distrust level
  *
  */
  PROCEDURE update_identity
              (factor_name IN varchar2,
               value       IN varchar2,
               trust_level IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_identity, AUTO_WITH_COMMIT);

  /**
  * Associate an identity with a different Factor.
  *
  * @param factor_name Current Factor Name
  * @param value Value of the Identity to update
  * @param new_factor_name Factor Name
  *
  */
  PROCEDURE change_identity_factor
              (factor_name      IN varchar2,
               value            IN varchar2,
               new_factor_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(change_identity_factor, AUTO_WITH_COMMIT);

  /**
  * Update the value of an Identity.
  *
  * @param factor_name Factor Name
  * @param value Current value associated with the identity
  * @param new_value New Identity value
  *
  */
  PROCEDURE change_identity_value
              (factor_name IN varchar2,
               value       IN varchar2,
               new_value   IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(change_identity_value, AUTO_WITH_COMMIT);

  /**
  * Remove an Identity.
  *
  * @param factor_name Factor Name
  * @param value Value associated with the identity
  *
  */
  PROCEDURE delete_identity
              (factor_name IN varchar2,
               value       IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_identity, AUTO_WITH_COMMIT);

  /* Identity Map */

  /*
  * Define a set of tests that are used to derive the identity of a Factor from
  * the value of linked child factors (sub-factors).
  *
  * @param identity_factor_name Factor the identity map is for
  * @param identity_factor_value Value the Factor will assume if the Identity Map is TRUE
  * @param parent_factor_name Identifies the Factor Link the Map is related to
  * @param child_factor_name Identifies the Factor Link the Map is related to
  * @param operation Relational operator for the Map (i.e. <, >, =, ...)
  * @param operand1 Left operand for the relational operator
  * @param operand1 Right operand for the relational operator
  *
  */
  PROCEDURE create_identity_map
               (identity_factor_name  IN varchar2,
                identity_factor_value IN varchar2,
                parent_factor_name    IN varchar2,
                child_factor_name     IN varchar2,
                operation             IN varchar2,
                operand1              IN varchar2,
                operand2              IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_identity_map, AUTO_WITH_COMMIT);

  /*
  * Remove an Identity Map for a Factor.
  *
  * @param identity_factor_name Factor the identity map is for
  * @param identity_factor_value Value the Factor will assume if the Identity Map is TRUE
  * @param parent_factor_name Identifies the Factor Link the Map is related to
  * @param child_factor_name Identifies the Factor Link the Map is related to
  * @param operation Relational operator for the Map (i.e. <, >, =, ...)
  * @param operand1 Left operand for the relational operator
  * @param operand1 Right operand for the relational operator
  *
  */
  PROCEDURE delete_identity_map
               (identity_factor_name  IN varchar2,
                identity_factor_value IN varchar2,
                parent_factor_name    IN varchar2,
                child_factor_name     IN varchar2,
                operation             IN varchar2,
                operand1              IN varchar2,
                operand2              IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_identity_map, AUTO_WITH_COMMIT);

  /**Policy Label */

  /**
  * Label an Identity within a MAC OLS Policy.
  *
  * @param identity_factor_name Name of factor being labeled
  * @param identity_factor_value Value of Identity for the Factor being labeled
  * @param policy_name OLS Policy Name
  * @param label OLS Label
  *
  */
  PROCEDURE create_policy_label
              (identity_factor_name  IN varchar2,
               identity_factor_value IN varchar2,
               policy_name           IN varchar2,
               label                 IN varchar2);
               -- algorithm             IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy_label, AUTO_WITH_COMMIT);

  /**
  * Remove the Label from an Identity within a MAC OLS Policy.
  *
  * @param identity_factor_name Name of factor being labeled
  * @param identity_factor_value Value of Identity for the Factor being labeled
  * @param policy_name OLS Policy Name
  * @param label OLS Label
  *
  */
  PROCEDURE delete_policy_label
              (identity_factor_name  IN varchar2,
               identity_factor_value IN varchar2,
               policy_name           IN varchar2,
               label                 IN varchar2);
               -- algorithm             IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_policy_label, AUTO_WITH_COMMIT);

  /* MAC Policy Algorithm */

  /**
  * Specify the algorithm that is used to merge labels when computing the label for
  * a Factor, or the MAC OLS Session label.  The algorithm is a 3-letter acronym
  * (e.g. LII, HUU, ...).  Consult OLS documentation for details.
  *
  * @param policy_name OLS Policy Name
  * @param algorithm Merge algorithm
  *
  */
  PROCEDURE create_mac_policy
              (policy_name           IN varchar2,
               algorithm             IN varchar2,
               error_label           IN varchar2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_mac_policy, AUTO_WITH_COMMIT);

  /**
  * Specify the algorithm that is used to merge labels when computing the label for
  * a Factor, or the MAC OLS Session label.  The algorithm is a 3-letter acronym
  * (e.g. LII, HUU, ...).  Consult OLS documentation for details.
  *
  * @param policy_name OLS Policy Name
  * @param algorithm Merge algorithm
  *
  */
  PROCEDURE update_mac_policy
              (policy_name  IN varchar2,
               algorithm             IN varchar2,
               error_label           IN varchar2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_mac_policy, AUTO_WITH_COMMIT);

  /**
  * Deletes all DV objects related to an OLS policy.  This method should be called
  * after an OLS policy has been deleted to ensure that there are not any broken
  * references between DV and OLS.  Note that there is not any referential integrity
  * constraints between DV and OLS.  The affected objects are in the mac_policy$,
  * mac_policy_factor$, and policy_label$ tables.
  *
  * @param policy_name OLS Policy Name
  *
  */
  PROCEDURE delete_mac_policy_cascade(policy_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_mac_policy_cascade, AUTO_WITH_COMMIT);

  /* Realm */

  /**
  * Create a Realm
  *
  * @param realm_name Realm name
  * @param description Realm description
  * @param enabled Indication of whether the realm checking is on or off (g_yes/g_no)
  * @param audit_options How to audit realm (described in dbms_macutl)
  * @param realm_type Realm type
  * @param realm_scope Realm scope
  * @param pl_sql_stack Indication of whether to record PL/SQL stack
  *
  */
  PROCEDURE create_realm
              (realm_name  IN varchar2,
               description IN varchar2,
               enabled IN varchar2,
               audit_options IN number,
               realm_type    IN number default NULL,
               realm_scope   IN number := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack  IN boolean default FALSE) ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_realm, AUTO_WITH_COMMIT);

  /**
  * Update a Realm
  *
  * @param realm_name Realm name
  * @param description Realm description
  * @param enabled Indication of whether the realm checking is on or off (g_yes/g_no)
  * @param audit_options How to audit realm (described in dbms_macutl)
  * @param realm_type Realm type
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE update_realm
              (realm_name  IN varchar2,
               description IN varchar2,
               enabled IN varchar2,
               audit_options IN number default NULL,
               realm_type    IN number default NULL,
               pl_sql_stack  IN boolean default NULL) ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_realm, AUTO_WITH_COMMIT);

  /**
  * Rename a Realm
  *
  * @param realm_name Realm name
  * @param new_name New Realm name
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE rename_realm
              (realm_name  IN varchar2,
               new_name    IN varchar2) ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_realm, AUTO_WITH_COMMIT);

  /**
  * Drop a Realm
  *
  * @param realm_name Realm name
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE delete_realm
              (realm_name  IN varchar2) ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_realm, AUTO_WITH_COMMIT);

  /**
  * Deletes a DV realm, including the related Realm objects (realm_object$),
  * and authorizations (realm_auth$).
  *
  * @param realm_name Realm name
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE delete_realm_cascade
              (realm_name  IN varchar2) ;
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_realm_cascade, AUTO_WITH_COMMIT);

  /**
  * Authorize a user or role to access a realm as a participant or owner.  The
  * authorization can be made conditional based on a Rule Set (i.e. only authorized
  * if the Rule Set evaluates to TRUE).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  * @param realm_scope Realm scope
  * @param auth_scope Authorization scope
  *
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2,
               auth_options  IN number,
               auth_scope    IN number := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_auth_to_realm, AUTO_WITH_COMMIT);

  /**
  * Authorize a user or role to access a realm as a participant.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  *
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_auth_to_realm, AUTO_WITH_COMMIT);

  /**
  * Authorize a user or role to access a realm as an owner or participant (no Rule Set).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  *
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               auth_options  IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_auth_to_realm, AUTO_WITH_COMMIT);

  /**
  * Authorize a user or role to access a realm as a participant (optional).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  *
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_auth_to_realm, AUTO_WITH_COMMIT);

  /**
  * Remove the authorization of a user or role to access a realm.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param realm_scope Realm scope
  * @param auth_scope Authorization scope
  *
  */
  PROCEDURE delete_auth_from_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               auth_scope    IN number := dvsys.dbms_macutl.g_scope_local);
               -- rule_set_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_auth_from_realm, AUTO_WITH_COMMIT);

  /**
  * Update the authorization of a user or role to access a realm.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  * @param realm_scope Realm scope
  * @param auth_scope Authorization scope
  *
  */
  PROCEDURE update_realm_auth
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2,
               auth_options  IN number,
               auth_scope    IN number := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_realm_auth, AUTO_WITH_COMMIT);

  /**
  * Register a set of objects for Realm protection.
  *
  * @param realm_name Realm name
  * @param object_owner Object owner
  * @param object_name Object name (Wild card % is allowed)
  * @param object_type Object type (Wild card % is allowed)
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE add_object_to_realm
              (realm_name    IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               object_type   IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_object_to_realm, AUTO_WITH_COMMIT);

  /**
  * Remove a set of objects from Realm protection.
  *
  * @param realm_name Realm name
  * @param object_owner Object owner
  * @param object_name Object name (Wild card % is allowed)
  * @param object_type Object type (Wild card % is allowed)
  * @param realm_scope Realm scope
  *
  */
  PROCEDURE delete_object_from_realm
              (realm_name    IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               object_type   IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_object_from_realm, AUTO_WITH_COMMIT);

  /**
  * Enable/disable Event
  *
  * @param enable
  *
  */
  PROCEDURE enable_event(event IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_event, NONE);

  PROCEDURE disable_event(event IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_event, NONE);

  /* Rule Set */

  /**
  * Create a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param description Description
  * @param enabled Whether to evaluate Rule Set or ignore it
  * @param eval_options Evaluation options (see dbms_macutl)
  * @param audit_options Audit options (see dbms_macutl)
  * @param fail_options Fail options (see dbms_macutl)
  * @param fail_message Error message for failure
  * @param fail_code Error code to return on failure
  * @param handler_options Handler options (see dbms_macutl)
  * @param handler Handler method
  *
  */
  PROCEDURE create_rule_set
              (rule_set_name   IN varchar2,
               description     IN varchar2,
               enabled         IN varchar2,
               eval_options    IN number,
               audit_options   IN number,
               fail_options    IN number,
               fail_message    IN varchar2,
               fail_code       IN number,
               handler_options IN number,
               handler         IN varchar2,
               is_static       IN boolean default false,
               scope           IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_rule_set, AUTO_WITH_COMMIT);

  /**
  * Update a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param description Description
  * @param enabled Whether to evaluate Rule Set or ignore it
  * @param eval_options Evaluation options (see dbms_macutl)
  * @param audit_options Audit options (see dbms_macutl)
  * @param fail_options Fail options (see dbms_macutl)
  * @param fail_message Error message for failure
  * @param fail_code Error code to return on failure
  * @param handler_options Handler options (see dbms_macutl)
  * @param handler Handler method
  *
  */
  PROCEDURE update_rule_set
              (rule_set_name   IN varchar2,
               description     IN varchar2,
               enabled         IN varchar2,
               eval_options    IN number,
               audit_options   IN number,
               fail_options    IN number,
               fail_message    IN varchar2,
               fail_code       IN number,
               handler_options IN number,
               handler         IN varchar2,
               is_static       IN boolean default false);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_rule_set, AUTO_WITH_COMMIT);

  /**
  * Rename a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param new_name New rule set name
  *
  */
  PROCEDURE rename_rule_set
              (rule_set_name IN varchar2,
               new_name      IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_rule_set, AUTO_WITH_COMMIT);

  /**
  * Delete a Rule Set.
  *
  * @param rule_set_name Rule Set name
  *
  */
  PROCEDURE delete_rule_set
              (rule_set_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_rule_set, AUTO_WITH_COMMIT);

  /**
  * Add a Rule to a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  * @param rule_order Order of evaluation for Rule in Rule Set
  * @param enabled Whether or not the Rule is enabled
  *
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2,
               rule_order    IN number,
               enabled       IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_rule_to_rule_set, AUTO_WITH_COMMIT);

  /**
  * Add an enabled Rule to a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  * @param rule_order Order of evaluation for Rule in Rule Set
  *
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2,
               rule_order    IN number);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_rule_to_rule_set, AUTO_WITH_COMMIT);

  /**
  * Add an enabled Rule to the end of Rule Set (i.e. evaluated last).
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  *
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_rule_to_rule_set, AUTO_WITH_COMMIT);

  /**
  * Delete a Rule from a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  *
  */
  PROCEDURE delete_rule_from_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_rule_from_rule_set, AUTO_WITH_COMMIT);

  /* Rule */

  /**
  * Create a Rule
  *
  * @param rule_name Rule name
  * @param rule_expr PL/SQL Boolean expression
  *
  */
  PROCEDURE create_rule
              (rule_name  IN varchar2,
               rule_expr  IN varchar2,
               scope      IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_rule, AUTO_WITH_COMMIT);

  /**
  * Update a Rule
  *
  * @param rule_name Rule name
  * @param rule_expr PL/SQL Boolean expression
  *
  */
  PROCEDURE update_rule
              (rule_name  IN varchar2,
               rule_expr  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_rule, AUTO_WITH_COMMIT);

  /**
  * Rename a Rule
  *
  * @param rule_name Rule name
  * @param new_name New Rule name
  *
  */
  PROCEDURE rename_rule
              (rule_name  IN varchar2,
               new_name   IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_rule, AUTO_WITH_COMMIT);

  /**
  * Delete a Rule
  *
  * @param rule_name Rule name
  *
  */
  PROCEDURE delete_rule
              (rule_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_rule, AUTO_WITH_COMMIT);

  /* Role */

  /**
  * Create a DV Secure Application Role.  Access to the role is protected
  * by a Rule Set.
  *
  * @param role_name Role name
  * @param enabled Whether the role is enabled or diabled
  * @param rule_set_name Rule Set to determine whether a user can set the role
  *
  *
  */
  PROCEDURE create_role
              (role_name IN varchar2,
               enabled   IN varchar2,
               rule_set_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_role, AUTO_WITH_COMMIT);

  /**
  * Delete a DV Secure Application Role.
  *
  * @param role_name Role name
  *
  *
  */
  PROCEDURE delete_role
              (role_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_role, AUTO_WITH_COMMIT);

  /**
  * Update a DV Secure Application Role.  Access to the role is protected
  * by a Rule Set.
  *
  * @param role_name Role name
  * @param enabled Whether the role is enabled or diabled
  * @param rule_set_name Rule Set to determine whether a user can set the role
  *
  *
  */
  PROCEDURE update_role
              (role_name IN varchar2,
               enabled   IN varchar2,
               rule_set_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_role, AUTO_WITH_COMMIT);

  /**
  * Rename a DV Secure Application Role.
  *
  * @param role_name Role name
  * @param new_role_name Role name
  *
  *
  */
  PROCEDURE rename_role
              (role_name IN varchar2,
               new_role_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_role, AUTO_WITH_COMMIT);

  /* Command Rule */

  /**
  * Protect a database command by associating it with a Rule Set.  The
  * command can only be executed if the Rule Set evaluates to TRUE.
  *
  * @param command SQL command to protect
  * @param rule_set_name Rule Set to protect command
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  * @param enabled Whether the command rule is enabled or disabled
  * @param clause_name clause name of the ALTER SYSTEM/SESSION command
  * @param parameter_name parameter name of the ALTER SYSTEM/SESSION command clause
  * @param event_name event name of the ALTER SYSTEM/SESSION set events scenario
  * @param component_name component name of the ALTER SYSTEM/SESSION set events scenario
  * @param action_name action name of the ALTER SYSTEM/SESSION set events scenario
  * @param pl_sql_stack Whether to record PL/SQL stack for the command rule
  *
  */
  PROCEDURE create_command_rule
              (command IN varchar2,
               rule_set_name IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               enabled       IN varchar2,
               privilege_scope IN NUMBER DEFAULT NULL,
               clause_name IN varchar2 := '%',
               parameter_name IN varchar2 := '%',
               event_name IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name IN varchar2 := '%',
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack IN boolean default FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_command_rule, AUTO_WITH_COMMIT);

  /**
  * Drop a Command Rule declaration.
  *
  * @param command SQL command to protect
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  * @param clause_name clause name of the ALTER SYSTEM/SESSION command
  * @param parameter_name parameter name of the ALTER SYSTEM/SESSION command clause
  * @param event_name event name of the ALTER SYSTEM/SESSION set events scenario
  * @param component_name component name of the ALTER SYSTEM/SESSION set events scenario
  * @param action_name action name of the ALTER SYSTEM/SESSION set events scenario
  *
  */
  PROCEDURE delete_command_rule
              (command IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               clause_name IN varchar2 := '%',
               parameter_name IN varchar2 := '%',
               event_name IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name IN varchar2 := '%',
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_command_rule, AUTO_WITH_COMMIT);

  /**
  * Update a Command Rule declaration.
  *
  * @param command SQL command to protect
  * @param rule_set_name Rule Set to protect command
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  * @param enabled Whether the command rule is enabled or disabled
  * @param clause_name clause name of the ALTER SYSTEM/SESSION command
  * @param parameter_name parameter name of the ALTER SYSTEM/SESSION command clause
  * @param event_name event name of the ALTER SYSTEM/SESSION set events scenario
  * @param component_name component name of the ALTER SYSTEM/SESSION set events scenario
  * @param action_name action name of the ALTER SYSTEM/SESSION set events scenario
  * @param pl_sql_stack Whether to record PL/SQL stack for the command rule
  *
  */
  PROCEDURE update_command_rule
              (command IN varchar2,
               rule_set_name IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               enabled       IN varchar2,
               privilege_scope IN NUMBER DEFAULT NULL,
               clause_name IN varchar2 := '%',
               parameter_name IN varchar2 := '%',
               event_name IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name IN varchar2 := '%',
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack IN boolean default NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_command_rule, AUTO_WITH_COMMIT);

  /**
  * Create a CONNECT Command Rule declaration.
  *
  * @param user_name Name of the target user
  * @param rule_set_name Rule Set to protect the connection
  * @param enabled Whether the command rule is enabled or disabled
  *
  */
  PROCEDURE create_connect_command_rule
              (user_name     IN varchar2,
               rule_set_name IN varchar2,
               enabled       IN varchar2,
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_connect_command_rule, AUTO_WITH_COMMIT);

  /**
  * Update a CONNECT Command Rule declaration.
  *
  * @param user_name Name of the target user
  * @param rule_set_name Rule Set to protect the connection
  * @param enabled Whether the command rule is enabled or disabled
  *
  */
  PROCEDURE update_connect_command_rule
              (user_name     IN varchar2,
               rule_set_name IN varchar2,
               enabled       IN varchar2,
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_connect_command_rule, AUTO_WITH_COMMIT);

  /**
  * Delete a CONNECT Command Rule declaration.
  *
  * @param user_name Name of the target user
  *
  */
  PROCEDURE delete_connect_command_rule
              (user_name     IN varchar2,
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_connect_command_rule, AUTO_WITH_COMMIT);

  /**
  * Create a session event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SESSION set events scenario
  * @param component_name component name of the ALTER SESSION set events scenario
  * @param action_name action name of the ALTER SESSION set events scenario
  *
  */
  PROCEDURE create_session_event_cmd_rule
              (rule_set_name  IN varchar2,
               enabled        IN varchar2,
               event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack   IN boolean default FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_session_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Update a session event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SESSION set events scenario
  * @param component_name component name of the ALTER SESSION set events scenario
  * @param action_name action name of the ALTER SESSION set events scenario
  * @param pl_sql_stack Whether to record PL/SQL stack for the command rule
  *
  * @throws ORA 20081 Command not found
  * @throws ORA 20100 Command rule already defined
  * @throws ORA 20102 Error creating Command Rule
  */
  PROCEDURE update_session_event_cmd_rule
              (rule_set_name  IN varchar2,
               enabled        IN varchar2,
               event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack   IN boolean default NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_session_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Delete a session event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SESSION set events scenario
  * @param component_name component name of the ALTER SESSION set events scenario
  * @param action_name action name of the ALTER SESSION set events scenario
  *
  */
  PROCEDURE delete_session_event_cmd_rule
              (event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_session_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Create a system event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SYSTEM set events scenario
  * @param component_name component name of the ALTER SYSTEM set events scenario
  * @param action_name action name of the ALTER SYSTEM set events scenario
  * @param pl_sql_stack Whether to record PL/SQL stack for the command rule
  *
  */
  PROCEDURE create_system_event_cmd_rule
              (rule_set_name  IN varchar2,
               enabled        IN varchar2,
               event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack   IN boolean default FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_system_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Update a system event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SYSTEM set events scenario
  * @param component_name component name of the ALTER SYSTEM set events scenario
  * @param action_name action name of the ALTER SYSTEM set events scenario
  * @param pl_sql_stack Whether to record PL/SQL stack for the command rule
  *
  * @throws ORA 20081 Command not found
  * @throws ORA 20100 Command rule already defined
  * @throws ORA 20102 Error creating Command Rule
  */
  PROCEDURE update_system_event_cmd_rule
              (rule_set_name  IN varchar2,
               enabled        IN varchar2,
               event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local,
               pl_sql_stack   IN boolean default NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_system_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Delete a system event command rule declaration
  *
  * @param rule_set_name Rule Set to protect command
  * @param enabled Whether the command rule is enabled or disabled
  * @param event_name event name of the ALTER SYSTEM set events scenario
  * @param component_name component name of the ALTER SYSTEM set events scenario
  * @param action_name action name of the ALTER SYSTEM set events scenario
  *
  */
  PROCEDURE delete_system_event_cmd_rule
              (event_name     IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name    IN varchar2 := '%',
               scope          IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_system_event_cmd_rule, AUTO_WITH_COMMIT);

  /**
  * Returns information from the sys.v_$instance view.
  *
  *  @param p_parameter Column name in sys.v_$instance
  *  @return Value of column p_parameter in sys.v_$instance
  */
  FUNCTION get_instance_info(p_parameter IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_instance_info, NONE);

  /**
  * Returns information from the sys.v_$session view for the current session
  *
  *  @param p_parameter Column name in sys.v_$session
  *  @return Value of column p_parameter in sys.v_$session
  */
  FUNCTION get_session_info(p_parameter IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_session_info, NONE);

  /**
  * Add a RAC database node to a domain. If the identity for the domain does
  * not exist the identity will be added.
  * Creates the required identity map information for the database hostname provided.
  * If the OLS policy is provided, domain will be added as a policy factor
  * if it is not already associated. If the label for the identity of this domain
  * does not exist the label will be added.
  * This call must be made with the instance running on the host specified.
  *
  * @param domain_name Name of the domain to add the host to
  * @param domain_host RAC host name being added to the domain
  * @param policy_name OLS Policy Name to label the domain for
  * @param label OLS Label to label the domain within this policy
  *
  */
  PROCEDURE create_domain_identity
              (domain_name IN varchar2,
               domain_host IN varchar2,
               policy_name IN varchar2 DEFAULT NULL,
               domain_label IN varchar2 DEFAULT NULL
               );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_domain_identity, AUTO_WITH_COMMIT);

  /**
  * Remove a RAC database node from a domain.
  * Creates the required identity map information for the database hostname provided.
  *
  * @param domain_name Name of the domain to add the host to
  * @param domain_host RAC host name being added to the domain
  *
  */
  PROCEDURE drop_domain_identity
              (domain_name IN varchar2,
               domain_host IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_domain_identity, AUTO_WITH_COMMIT);

  /**
  * Returns the character set for the database
  *
  * @return character set for the database
  */
  FUNCTION get_db_charset RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_db_charset, NONE);

  /**
  * Returns the 3 character Oracle language for the current administration session
  * Based on set_ora_lang_from_java
  *
  * @return 3 character oracle language identifier for the administration current session
  */
  FUNCTION get_ora_lang RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_ora_lang, NONE);

  /**
  * check to see if alter system set system_trig_enabled
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_trig_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_trig_parm_varchar, NONE);

  /**
  * check to see if following O7_DICTIONARY_ACCESSIBILITY
  * is allowed:
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_o7_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_o7_parm_varchar, NONE);

  /**
  * check to see if alter system set _dynamic_rls_policies
  * are allowed
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_dynrls_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_dynrls_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM security system parameters
  * are allowed :
  *    _SYSTEM_TRIG_ENABLED POLICIES
  *    O7_DICTIONARY_ACCESSIBILITY
  *    _DYNAMIC_RLS_POLICIES
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_sys_sec_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_sys_sec_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM dump or dest parameters
  * are allowed :
  *    MAX_DUMP_FILE_SIZE
  *    %DUMP%
  *    %_DEST%
  *    LOG_ARCHIVE%
  *    STANDBY_ARCHIVE%
  *    DB_RECOVERY_FILE_DEST_SIZE
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_dump_dest_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_dump_dest_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM backup restore parameters
  * are allowed :
  *    RECYCLEBIN
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_backup_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_backup_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM database file parameters
  * are allowed :
  *    CONTROL_FILES
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_db_file_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_db_file_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM optimizer parameters
  * are allowed :
  *    OPTIMIZER_SECURE_VIEW_MERGING
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_optimizer_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_optimizer_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM plsql parameters
  * are allowed :
  *    UTL_FILE_DIR
  *    PLSQL_DEBUG
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_plsql_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_plsql_parm_varchar, NONE);

  /**
  * check to see if following ALTER SYSTEM security parameters
  * are allowed :
  *    AUDIT_SYS_OPERATIONS
  *    AUDIT_TRAIL
  *    AUDIT_SYSLOG_LEVEL
  *    REMOTE_OS_ROLES
  *    OS_ROLES
  *    SQL92_SECURITY
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_security_parm_varchar RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(check_security_parm_varchar, NONE);

  /**
  * check to see if alter dvsys
  *
  * return 'Y' or 'N'
  */
  FUNCTION is_alter_user_allow_varchar(login_user VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_alter_user_allow_varchar, NONE);

  FUNCTION is_drop_user_allow_varchar(login_user VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_drop_user_allow_varchar, NONE);

  PROCEDURE authorize_datapump_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL,
       objname     IN VARCHAR2 DEFAULT NULL,
       action      IN VARCHAR2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_datapump_user, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_datapump_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL,
       objname     IN VARCHAR2 DEFAULT NULL,
       action      IN VARCHAR2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_datapump_user, AUTO_WITH_COMMIT);

  PROCEDURE auth_datapump_create_user(uname IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(auth_datapump_create_user, AUTO_WITH_COMMIT);

  PROCEDURE unauth_datapump_create_user(uname IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauth_datapump_create_user, AUTO_WITH_COMMIT);

  PROCEDURE auth_datapump_grant(
       uname       IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(auth_datapump_grant, AUTO_WITH_COMMIT);

  PROCEDURE unauth_datapump_grant(
       uname       IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauth_datapump_grant, AUTO_WITH_COMMIT);

  PROCEDURE auth_datapump_grant_role(
       uname       IN VARCHAR2,
       role        IN VARCHAR2 DEFAULT '%'
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(auth_datapump_grant_role, AUTO_WITH_COMMIT);


  PROCEDURE unauth_datapump_grant_role(
       uname       IN VARCHAR2,
       role        IN VARCHAR2 DEFAULT '%'
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauth_datapump_grant_role, AUTO_WITH_COMMIT);

  PROCEDURE auth_datapump_grant_syspriv(
       uname       IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(auth_datapump_grant_syspriv, AUTO_WITH_COMMIT);

  PROCEDURE unauth_datapump_grant_syspriv(
       uname       IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauth_datapump_grant_syspriv, AUTO_WITH_COMMIT);

  PROCEDURE authorize_tts_user(
       uname       IN VARCHAR2,
       tsname      IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_tts_user, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_tts_user(
       uname       IN VARCHAR2,
       tsname      IN VARCHAR2
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_tts_user, AUTO_WITH_COMMIT);

  /* API to authorize a user to run jobs in the schema of other users. */
  PROCEDURE authorize_scheduler_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL
   );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_scheduler_user, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_scheduler_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL
   );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_scheduler_user, AUTO_WITH_COMMIT);

  /* APIs to authorize a user to proxy as another user. */
  PROCEDURE authorize_proxy_user
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_proxy_user, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_proxy_user
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_proxy_user, AUTO_WITH_COMMIT);

  /* APIs to authorize a user to execute DDLs on another user's schema. */
  PROCEDURE authorize_ddl
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_ddl, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_ddl
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_ddl, AUTO_WITH_COMMIT);

  /* APIs to authorize a user to execute PREPROCESSOR directive in external
   * tables.
   */
  PROCEDURE authorize_preprocessor
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_preprocessor, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_preprocessor
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_preprocessor, AUTO_WITH_COMMIT);

  /* APIs to authorize a user to execute maintenance related DDLs. */
  PROCEDURE authorize_maintenance_user
           ( uname       IN VARCHAR2,
             sname       IN VARCHAR2 DEFAULT NULL,
             objname     IN VARCHAR2 DEFAULT NULL,
             objtype     IN VARCHAR2 DEFAULT '%',
             action      IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_maintenance_user, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_maintenance_user
           ( uname       IN VARCHAR2,
             sname       IN VARCHAR2 DEFAULT NULL,
             objname     IN VARCHAR2 DEFAULT NULL,
             objtype     IN VARCHAR2 DEFAULT '%',
             action      IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_maintenance_user, AUTO_WITH_COMMIT);

  -- APIs to authorize a user as diagnostic admin who can access the following
  -- fixed tables/views: v$diag_trace_File_contents, v$diag_opt_trace_records,
  -- v$diag_sess_opt_trace_records, x$dbgtfview, x$dbgtfoptt, x$dbgtfsoptt.
  -- Note that the list above is as of 12.2, and additional tables/views may
  -- be added later in the future.
  PROCEDURE authorize_diagnostic_admin
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_diagnostic_admin, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_diagnostic_admin
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_diagnostic_admin, AUTO_WITH_COMMIT);

  -- Add a function to the index functions list for function based index.
  PROCEDURE add_index_function
           ( objname     IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_index_function, AUTO_WITH_COMMIT);

 -- Delete a function from the index functions list for function based index.
  PROCEDURE delete_index_function
           ( objname     IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_index_function, AUTO_WITH_COMMIT);

  /* APIs to authorize a user to connect another user's session to a PL/SQL
   * debugger.
   */
  PROCEDURE authorize_debug_connect
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_debug_connect, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_debug_connect
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_debug_connect, AUTO_WITH_COMMIT);

  /* BUG FIX 10225918 - Procedure to insert DV metadata in supported languages.
   Supported input Language values are :
   ENGLISH
   GERMAN
   SPANISH
   FRENCH
   ITALIAN
   JAPANESE
   KOREAN
   BRAZILIAN PORTUGUESE
   SIMPLIFIED CHINESE
   TRADITIONAL CHINESE
  */
  PROCEDURE add_nls_data(
       lang         IN VARCHAR2
   );
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_nls_data, AUTO_WITH_COMMIT);

  /*
  * Enable/disable DV enforcement
  */

  PROCEDURE enable_dv(strict_mode IN VARCHAR2 DEFAULT 'N');
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_dv, AUTO_WITH_COMMIT);

  PROCEDURE disable_dv;
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_dv, AUTO_WITH_COMMIT);

  -- Control ORADEBUG in Database Vault environment
  PROCEDURE enable_oradebug;
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_oradebug, AUTO_WITH_COMMIT);

  PROCEDURE disable_oradebug;
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_oradebug, AUTO_WITH_COMMIT);

  -- Control whether user can log into DVSYS and DVF accounts
  PROCEDURE enable_dv_dictionary_accts;
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_dv_dictionary_accts, AUTO_WITH_COMMIT);

  PROCEDURE disable_dv_dictionary_accts;
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_dv_dictionary_accts, AUTO_WITH_COMMIT);

  /**
  * Create a Database Vault policy
  *
  * @param policy_name:  Policy name
  * @param description:  Policy description
  * @param policy_state: Initial state of policy (DBMS_MACADM.G_DISABLED,
  *                                               DBMS_MACADM.G_ENABLED,
  *                                               DBMS_MACADM.G_SIMULATION,
  *                                               DBMS_MACADM.G_PARTIAL)
  * @param pl_sql_stack: Whether to record PL/SQL stack for the policy (TRUE,
  *                                                                     FALSE)
  */
  PROCEDURE create_policy
              (policy_name  IN varchar2,
               description  IN varchar2,
               policy_state IN number,
               pl_sql_stack IN boolean default FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_policy, AUTO_WITH_COMMIT);

  /**
  * Update the description of exiting Database Vault policy
  *
  * @param policy_name: Policy name
  * @param description: Policy description
  */
  PROCEDURE update_policy_description
              (policy_name IN varchar2,
               description IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_policy_description, AUTO_WITH_COMMIT);

  /**
  * Rename exiting Database Vault policy
  *
  * @param policy_name:     Policy name
  * @param new_policy_name: New policy name
  */
  PROCEDURE rename_policy
              (policy_name     IN varchar2,
               new_policy_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(rename_policy, AUTO_WITH_COMMIT);

  /**
  * Drop exiting Database Vault policy
  *
  * @param policy_name:     Policy name
  */
  PROCEDURE drop_policy
              (policy_name IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_policy, AUTO_WITH_COMMIT);

  /**
  * Update the state of existing Database Vault policy
  *
  * @param policy_name:  Policy name
  * @param policy_state: Policy state (DBMS_MACADM.G_DISABLED,
  *                                    DBMS_MACADM.G_ENABLED,
  *                                    DBMS_MACADM.G_SIMULATION,
  *                                    DBMS_MACADM.G_PARTIAL)
  * @param pl_sql_stack: Whether to record PL/SQL stack for the policy (TRUE,
  *                                                                     FALSE)
  */
  PROCEDURE update_policy_state
              (policy_name         IN varchar2,
               policy_state        IN number,
               pl_sql_stack        IN boolean default NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(update_policy_state, AUTO_WITH_COMMIT);

  /**
  * Add a realm to Database Vault policy
  *
  * @param policy_name: Policy name
  * @param realm_name:  Realm name
  */
  PROCEDURE add_realm_to_policy
              (policy_name IN varchar2,
               realm_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_realm_to_policy, AUTO_WITH_COMMIT);

  /**
  * Delete a realm from Database Vault policy
  *
  * @param policy_name: Policy name
  * @param realm_name:  Realm name
  */
  PROCEDURE delete_realm_from_policy
              (policy_name IN varchar2,
               realm_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_realm_from_policy, AUTO_WITH_COMMIT);

  /**
  * Add a command rule to Database Vault policy
  *
  * @param policy_name:     Policy name
  * @param command:         Command
  * @param object_owner:    Object owner
  * @param object_name:     Object name
  * @param clause_name:     Clause name
  * @param parameter_name:  Parameter name
  * @param event_name:      Event name
  * @param component_name:  Component name
  * @param action_name:     Action name
  */
  PROCEDURE add_cmd_rule_to_policy
              (policy_name  IN varchar2,
               command      IN varchar2,
               object_owner IN varchar2,
               object_name  IN varchar2,
               clause_name IN varchar2 := '%',
               parameter_name IN varchar2 := '%',
               event_name IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name IN varchar2 := '%',
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_cmd_rule_to_policy, AUTO_WITH_COMMIT);

  /**
  * Delete a command rule from Database Vault policy
  *
  * @param policy_name:     Policy name
  * @param command:         Command
  * @param object_owner:    Object owner
  * @param object_name:     Object name
  * @param clause_name:     Clause name
  * @param parameter_name:  Parameter name
  * @param event_name:      Event name
  * @param component_name:  Component name
  * @param action_name:     Action name
  */
  PROCEDURE delete_cmd_rule_from_policy
              (policy_name  IN varchar2,
               command      IN varchar2,
               object_owner IN varchar2,
               object_name  IN varchar2,
               clause_name IN varchar2 := '%',
               parameter_name IN varchar2 := '%',
               event_name IN varchar2 := '%',
               component_name IN varchar2 := '%',
               action_name IN varchar2 := '%',
               scope IN NUMBER := dvsys.dbms_macutl.g_scope_local);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_cmd_rule_from_policy, AUTO_WITH_COMMIT);

  /**
  * Add an owner to Database Vault policy
  *
  * @param policy_name: Policy name
  * @param owner_name:  Policy owner name
  */
  PROCEDURE add_owner_to_policy
              (policy_name IN varchar2,
               owner_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_owner_to_policy, AUTO_WITH_COMMIT);

  /**
  * Delete an owner from Database Vault policy
  *
  * @param policy_name: Policy name
  * @param owner_name:  Policy owner name
  */
  PROCEDURE delete_owner_from_policy
              (policy_name IN varchar2,
               owner_name  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_owner_from_policy, AUTO_WITH_COMMIT);

  -- APIs to authorize a user as Database Replay admin to run capture and
  -- replay
  PROCEDURE authorize_dbcapture
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_dbcapture, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_dbcapture
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_dbcapture, AUTO_WITH_COMMIT);

  PROCEDURE authorize_dbreplay
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_dbreplay, AUTO_WITH_COMMIT);

  PROCEDURE unauthorize_dbreplay
           ( uname       IN VARCHAR2
           );
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_dbreplay, AUTO_WITH_COMMIT);

  /**
  * set allow common operation status to TRUE or FALSE for the whole CDB
  *
  * @param status: The allow common operation status to set for the whole
  *                CDB.
  */
  PROCEDURE allow_common_operation(status IN BOOLEAN DEFAULT TRUE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(allow_common_operation, AUTO_WITH_COMMIT);

  /**
  * Enable application protection for whole CDB or one of the PDBs
  *
  * @param pdb_name: Name of the PDB.
  *                  If NULL protection is enabled for the all the PDBs
  *                  Else protection is enabled only for the specified PDB
  */
  PROCEDURE enable_app_protection (pdb_name IN VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(enable_app_protection, AUTO_WITH_COMMIT);

  /**
  * Disable application protection for whole CDB or one of the PDBs
  *
  * @param pdb_name: Name of the PDB
  *                  If NULL protection is disabled for the all the PDBs
  *                  Else protection is disabled only for the specified PDB
  */
  PROCEDURE disable_app_protection (pdb_name IN VARCHAR2 DEFAULT NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(disable_app_protection, AUTO_WITH_COMMIT);

  /**
  * Add a package to exception list
  *
  * @param owner: owner of the package to add to exception list
  * @param package_name: package name to add to exception list
  */
  PROCEDURE add_app_exception(owner IN VARCHAR2, package_name IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_app_exception, AUTO_WITH_COMMIT);

  /**
  * Remove a package to exception list
  *
  * @param owner: owner of the package to remove from exception list
  * @param package_name: package name to remove from exception list
  */
  PROCEDURE delete_app_exception(owner IN VARCHAR2, package_name IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_app_exception, AUTO_WITH_COMMIT);

  /**
  * Bug 29338861: Authorize RAS attach session API
  *
  * @param grantee  : Database user or RAS user
  * @param RAS_user : Existing RAS user
  */
  PROCEDURE authorize_ras_attach_session(grantee IN VARCHAR2, ras_user IN VARCHAR2 DEFAULT '%');
  PRAGMA SUPPLEMENTAL_LOG_DATA(authorize_ras_attach_session, AUTO_WITH_COMMIT);

  /**
  * Bug 29338861: Unauthorize RAS attach session API
  *
  * @param grantee  : Database user or RAS user
  * @param RAS_user : Existing RAS user
  */
  PROCEDURE unauthorize_ras_attach_session(grantee IN VARCHAR2, ras_user IN VARCHAR2 DEFAULT '%');
  PRAGMA SUPPLEMENTAL_LOG_DATA(unauthorize_ras_attach_session, AUTO_WITH_COMMIT);

END;
/

