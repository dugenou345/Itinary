create view KU$_DV_AUTH_AP_V (VERS_MAJOR, VERS_MINOR, OIDVAL, OWNER_NAME, PACKAGE_NAME) as
select '0','0', sys_guid(),
          d.owner,
          d.package
  from    dvsys.dba_dv_app_exception d
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists (select 1
                         from sys.session_roles
                         where role='DV_OWNER' ))
/

