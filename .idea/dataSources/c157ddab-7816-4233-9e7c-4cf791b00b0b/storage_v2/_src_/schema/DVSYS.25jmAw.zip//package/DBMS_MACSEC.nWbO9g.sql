create PACKAGE       dbms_macsec AS

  -- Audit action codes
  G_SECURE_ROLE_AUDIT_CODE CONSTANT PLS_INTEGER := 10006;

  /**
  * Set value of a Factor (if allowed by the assignment Rule Set)
  *
  * @param p_factor Factor name
  * @param p_value Value to assign to Factor
  */
  PROCEDURE set_factor(p_factor IN VARCHAR2,
                       p_value  IN VARCHAR2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(set_factor, NONE);

  /**
  * Returns the value of a factor.  Note that this method will return the
  * value cached in the context if the eval_option is set for evaluate on
  * session.
  *
  * @param p_factor Factor name
  */
  FUNCTION get_factor(p_factor IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_factor, NONE);

  /**
  * Returns the label of a factor.
  *
  * @param p_factor Factor name
  * @param p_policy_name OLS Policy name
  */
  FUNCTION get_factor_label(p_factor IN VARCHAR2, p_policy_name IN VARCHAR2) RETURN VARCHAR2;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_factor_label, NONE);

  /**
  * Get Trust Level of a Factor
  *
  * @param p_factor Factor name
  * @return > 0 indicates level of trust, 0 is no trust, < 0 indicates distrust
  */
  FUNCTION get_trust_level(p_factor IN VARCHAR2) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_trust_level, NONE);

  /**
  * Get Trust Level of a Factor Identity
  *
  * @param p_factor Factor name
  * @param p_identity Identity value
  * @return > 0 indicates level of trust, 0 is no trust, < 0 indicates distrust
  */
  FUNCTION get_trust_level(p_factor   IN VARCHAR2,
                           p_identity IN VARCHAR2) RETURN NUMBER;
  PRAGMA SUPPLEMENTAL_LOG_DATA(get_trust_level, NONE);

  /**
  * This method determines if a Secure Application Role is enabled
  * for use.
  * @param p_role Role name
  * @return TRUE if a SET ROLE command can be issued
  */
  FUNCTION role_is_enabled(p_role IN VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(role_is_enabled, NONE);

  /** Fix for Bug 6441524
  * Checks whether or not the given role is a secure application role
  *
  * @param role name
  * @return TRUE if the role is a secure application role; FALSE otherwise
  */
  FUNCTION is_secure_application_role(p_role VARCHAR2) RETURN BOOLEAN;
  PRAGMA SUPPLEMENTAL_LOG_DATA(is_secure_application_role, NONE);

END;
/

