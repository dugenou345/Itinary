create view DV$RULE_SET
            (ID#, NAME, DESCRIPTION, ENABLED, EVAL_OPTIONS, EVAL_OPTIONS_MEANING, AUDIT_OPTIONS, FAIL_OPTIONS,
             FAIL_OPTIONS_MEANING, FAIL_MESSAGE, FAIL_CODE, HANDLER_OPTIONS, HANDLER, VERSION, CREATED_BY, CREATE_DATE,
             UPDATED_BY, UPDATE_DATE, IS_STATIC, COMMON, INHERITED)
as
SELECT
      m.id#
    , d.name
    , d.description
    , m.enabled
    , m.eval_options - DECODE(bitand(m.eval_options, 128) , 128, 128, 0)
    , deval.value
    , m.audit_options
    , m.fail_options
    , dfail.value
    , d.fail_message
    , m.fail_code
    , m.handler_options
    , m.handler
    , m.version
    , m.created_by
    , m.create_date
    , m.updated_by
    , m.update_date
    , DECODE(bitand(m.eval_options, 128) , 128, 'TRUE', 'FALSE')
    , decode(m.scope, 1, 'NO',
                      2, 'YES',
                      3, 'YES') common
    , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
                (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
           THEN 'YES'
           ELSE 'NO'
      END inherited
FROM dvsys.rule_set$ m
    , dvsys.rule_set_t$ d
    , dvsys.dv$code deval
    , dvsys.dv$code dfail
WHERE
    m.id# = d.id#
    AND d.language = DVSYS.dvlang(d.id#, 5)
    AND deval.code = TO_CHAR(m.eval_options -
                             DECODE(bitand(m.eval_options,128) , 128, 128, 0))
    AND deval.code_group = 'RULESET_EVALUATE'
    AND dfail.code  = TO_CHAR(m.fail_options)
    AND dfail.code_group = 'RULESET_FAIL'
/

