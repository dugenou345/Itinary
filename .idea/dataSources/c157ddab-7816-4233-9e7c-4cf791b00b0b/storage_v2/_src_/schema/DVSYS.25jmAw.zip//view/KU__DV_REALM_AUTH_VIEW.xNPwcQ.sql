create view KU$_DV_REALM_AUTH_VIEW
            (VERS_MAJOR, VERS_MINOR, REALM_NAME, GRANTEE, RULE_SET_NAME, AUTH_OPTIONS, AUTH_SCOPE) as
select '0','0',
          rlmt.name,
          rlma.grantee,
          rs.name,
          decode(rlma.auth_options,
                 0,'DVSYS.DBMS_MACUTL.G_REALM_AUTH_PARTICIPANT',
                 1,'DVSYS.DBMS_MACUTL.G_REALM_AUTH_OWNER',
                 to_char(rlma.auth_options)),
          decode(rlma.common_auth, 'YES', 2, 'NO', 1)
  from    dvsys.realm_t$                 rlmt,
          dvsys.dv$realm_auth            rlma,
          (select m.id#,
                  d.name
             from dvsys.rule_set$   m,
                  dvsys.rule_set_t$ d
            where m.id# = d.id#)         rs
  where   rlmt.id# = rlma.realm_id#
    and   rs.id# (+)= rlma.auth_rule_set_id#
    and   rlmt.id# > 5000
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

