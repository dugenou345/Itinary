create view POLICY_OWNER_REALM
            (NAME, DESCRIPTION, AUDIT_OPTIONS, REALM_TYPE, COMMON_REALM, INHERITED_REALM, ENABLED, ID#,
             ORACLE_SUPPLIED) as
SELECT
    d.name
  , d.description
  , m.audit_options
  , decode(m.realm_type, 0, 'REGULAR',
                         1, 'MANDATORY')
  , decode(m.scope, 1, 'NO',
                    2, 'YES',
                    3, 'YES') common_realm
  , CASE WHEN (m.scope = 2 and sys_context('USERENV','IS_APPLICATION_PDB') = 'YES') or
              (m.scope = 3 and sys_context('USERENV','CON_ID') != 1)
         THEN 'YES'
         ELSE 'NO'
    END inherited_realm
  , m.enabled
  , m.id#
  , CASE WHEN (m.id# < 5000) OR
              (1000000000 <= m.id# AND m.id# < 1000005000)
         THEN 'YES'
         ELSE 'NO'
    END
FROM dvsys.realm$ m, dvsys.realm_t$ d
WHERE
    m.id# = d.id# AND
    d.language = DVSYS.dvlang(d.id#, 6) AND
    m.id# IN (SELECT object_id#
              FROM dvsys.policy_object$ pb, dvsys.policy_owner$ pw
              WHERE pb.policy_id# = pw.policy_id# AND
                    pw.owner_id# =  sys_context('userenv', 'current_userid') AND
                    pb.object_type = 1) -- dvsys.dbms_macutl.G_REALM
/

