create function       EVENT_LEVEL return VARCHAR2 as
begin
  return TO_NUMBER(SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'EVENT_LEVEL'));
end;
/

