create view POLICY_OWNER_RULE_SET_RULE as
SELECT
      d1.name
    , d2.name
    , d2.rule_expr
    , m.enabled
    , m.rule_order
FROM dvsys.rule_set_rule$ m
     ,dvsys.dv$rule_set d1
     ,dvsys.dv$rule d2
WHERE
    d1.id# = m.rule_set_id#
    AND d2.id# = m.rule_id#
    AND d1.name IN (SELECT pors.rule_set_name
                          FROM dvsys.policy_owner_rule_set pors)
/

