create view KU$_DV_POLICY_V (VERS_MAJOR, VERS_MINOR, POLICY_NAME, DESCRIPTION, POLICY_STATE) as
select '0','0',
          pt.name,
          pt.description,
          decode(p.state,
                 0, 'DVSYS.DBMS_MACADM.G_DISABLED',
                 1, 'DVSYS.DBMS_MACADM.G_ENABLED',
                 2, 'DVSYS.DBMS_MACADM.G_SIMULATION',
                 3, 'DVSYS.DBMS_MACADM.G_PARTIAL',
                 to_char(p.state))
  from    dvsys.policy$ p, dvsys.policy_t$ pt
  where   p.id# >= 5000 and p.id# = pt.id# and
          pt.language = dvsys.dvlang(pt.id#, 7)
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                       from sys.session_roles
                       where role='DV_OWNER' ))
/

