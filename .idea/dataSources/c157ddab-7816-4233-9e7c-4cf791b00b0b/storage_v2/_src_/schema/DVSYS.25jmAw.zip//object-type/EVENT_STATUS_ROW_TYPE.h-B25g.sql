create TYPE       event_status_row_type AS object
(
  event   number,
  enabled varchar2(5)
)
/

