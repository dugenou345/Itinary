create type         "SYS_YOID0000075467$"              as object( "SYS_NC00001$" RAW(16))
/

