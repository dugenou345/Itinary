create view DBA_DV_DEBUG_CONNECT_AUTH as
SELECT
    u1.name
  , u2.name
FROM dvsys.dv_auth$ da, sys."_BASE_USER" u1, sys."_BASE_USER" u2
WHERE grant_type = 'DEBUG_CONNECT' and da.grantee_id = u1.user# and
      da.object_owner_id = u2.user#
UNION
SELECT
    u1.name
  , '%'
FROM dvsys.dv_auth$ da, sys."_BASE_USER" u1
WHERE grant_type = 'DEBUG_CONNECT' and da.grantee_id = u1.user# and
      da.object_owner_id = 2147483636
UNION
SELECT
    '%'
  , u2.name
FROM dvsys.dv_auth$ da, sys."_BASE_USER" u2
WHERE grant_type = 'DEBUG_CONNECT' and da.grantee_id = 2147483636 and
      da.object_owner_id = u2.user#
UNION
SELECT
    '%'
  , '%'
FROM dvsys.dv_auth$ da
WHERE grant_type = 'DEBUG_CONNECT' and da.grantee_id = 2147483636 and
      da.object_owner_id = 2147483636
/

