create type       ku$_dv_realm_member_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  oidval        raw(16),                                       /* unique id */
  name          varchar2(128),              /* name of database vault realm */
  object_owner  varchar2(128),   /* owner of object protected by this realm */
  object_name   varchar2(128),    /* name of object protected by this realm */
  object_type   varchar2(32)      /* type of object protected by this realm */
)
/

