create FUNCTION       dvlang(lid IN NUMBER, langtab_no IN NUMBER)
RETURN VARCHAR2
AS
  l_lcnt NUMBER default 0;
  l_lang VARCHAR2(3);
  l_tab  VARCHAR2(128);
  l_stmt VARCHAR2(256);
  l_cursor    int;
  l_status    int;
BEGIN
  l_lang := LOWER(SYS_CONTEXT('USERENV','LANG'));
  l_tab :=
    CASE langtab_no
      WHEN 1 THEN 'CODE_T$'
      WHEN 2 THEN 'FACTOR_T$'
      WHEN 3 THEN 'FACTOR_TYPE_T$'
      WHEN 4 THEN 'RULE_T$'
      WHEN 5 THEN 'RULE_SET_T$'
      WHEN 6 THEN 'REALM_T$'
      WHEN 7 THEN 'POLICY_T$'
    END;

  l_stmt := 'SELECT COUNT(*) FROM ' || l_tab || ' WHERE id# = :id AND language = :lang';
  l_cursor := sys.dbms_sql.open_cursor;
  sys.dbms_sql.parse( l_cursor, l_stmt, sys.dbms_sql.native );
  sys.dbms_sql.bind_variable( l_cursor, ':id', lid );
  sys.dbms_sql.bind_variable( l_cursor, ':lang', l_lang );
  sys.dbms_sql.define_column( l_cursor, 1, l_lcnt );
  l_status := sys.dbms_sql.execute( l_cursor );
  if ( sys.dbms_sql.fetch_rows(l_cursor) > 0 )
    then
        sys.dbms_sql.column_value( l_cursor, 1, l_lcnt );
  end if;
  sys.dbms_sql.close_cursor(l_cursor);

  if (l_lcnt = 0) then
    return 'us';
  else
    return l_lang;
  end if;
END;
/

