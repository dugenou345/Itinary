create type         "SYS_YOID0000075455$"              as object( "SYS_NC00001$" RAW(16))
/

