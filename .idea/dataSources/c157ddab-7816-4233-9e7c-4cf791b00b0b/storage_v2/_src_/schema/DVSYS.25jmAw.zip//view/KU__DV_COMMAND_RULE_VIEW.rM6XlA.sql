create view KU$_DV_COMMAND_RULE_VIEW
            (VERS_MAJOR, VERS_MINOR, OIDVAL, COMMAND, RULE_SET_NAME, OBJECT_OWNER, OBJECT_NAME, ENABLED, SCOPE) as
select '0','0', sys_guid(),
          cvcr.command,
          cvcr.rule_set_name,
          cvcr.object_owner,
          cvcr.object_name,
          cvcr.enabled,
          decode(cr.scope, 1, 1,
                           2, 2,
                           3, 2)
  from    dvsys.dv$command_rule cvcr, dvsys.command_rule$ cr
  where   cvcr.id# >= 5000 and cvcr.id# = cr.id#
    and   cvcr.command <> 'ALTER SYSTEM'
    and   cvcr.command <> 'ALTER SESSION'
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

