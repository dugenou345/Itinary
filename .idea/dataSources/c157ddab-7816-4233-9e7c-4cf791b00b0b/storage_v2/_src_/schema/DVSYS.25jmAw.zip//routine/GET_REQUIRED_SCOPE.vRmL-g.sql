create function       GET_REQUIRED_SCOPE return VARCHAR2 as
  checkScope varchar2(12) := 'LOCAL';
  l_con_id number;
  isAppRoot varchar(3);
begin
  select sys_context('USERENV','CON_ID') into l_con_id from sys.dual;

  IF l_con_id = 0 THEN    --legacy db
    checkScope := 'LOCAL';
  ELSIF l_con_id = 1 THEN -- cdb$root
    checkScope := 'COMMON';
  ELSE
    select sys_context('USERENV','IS_APPLICATION_ROOT') into isAppRoot from sys.dual;
    IF isAppRoot = 'YES' THEN -- app root
      checkScope := 'COMMON';
    ELSE                  -- pdb
      checkScope := 'LOCAL';
    END IF;
  END IF;

  return checkScope;
end;
/

