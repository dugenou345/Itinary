create function       PARAMETER_NAME return VARCHAR2 as
begin
  return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'PARAMETER_NAME');
end;
/

