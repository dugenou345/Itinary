create view DV$OUT as
SELECT ROWNUM lineno, dvsys.dbms_macout.get_line( ROWNUM ) text
   FROM sys.all_objects
  WHERE ROWNUM < ( SELECT dvsys.dbms_macout.get_line_count FROM sys.dual )
/

