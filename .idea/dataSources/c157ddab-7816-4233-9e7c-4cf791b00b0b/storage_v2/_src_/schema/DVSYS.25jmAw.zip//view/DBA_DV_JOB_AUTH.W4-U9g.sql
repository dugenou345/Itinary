create view DBA_DV_JOB_AUTH as
SELECT
    u1.name
  , u2.name
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1,
     sys."_BASE_USER" u2
WHERE grant_type = 'JOB' and da.grantee_id = u1.user# and
      da.object_owner_id = u2.user#
UNION
SELECT
    u1.name
  , '%'
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1
WHERE grant_type = 'JOB' and da.grantee_id = u1.user# and
      da.object_owner_id = 2147483636
/

