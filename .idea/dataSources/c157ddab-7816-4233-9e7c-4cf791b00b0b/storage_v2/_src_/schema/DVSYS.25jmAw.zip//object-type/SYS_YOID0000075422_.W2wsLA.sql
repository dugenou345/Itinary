create type         "SYS_YOID0000075422$"              as object( "SYS_NC00001$" VARCHAR2(128 BYTE))
/

