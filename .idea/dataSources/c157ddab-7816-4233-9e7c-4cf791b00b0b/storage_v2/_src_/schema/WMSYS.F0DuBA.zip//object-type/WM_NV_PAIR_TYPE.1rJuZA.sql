create type       wm$nv_pair_type                                                                        authid definer
         as object (name   varchar2(100),
                    value  clob)
/

