create view WM$UDTRIG_INFO as
select ui.trig_owner_name,
       ui.trig_name,
       vt.owner table_owner_name,
       vt.table_name,
       decode(bitand(ui.wm$flag, 1), 0, 0, 1, 1) +
       decode(bitand(ui.wm$flag, 2), 0, 0, 2, 2) +
       decode(bitand(ui.wm$flag, 4), 0, 0, 4, 4) +
       decode(bitand(ui.wm$flag, 8), 0, 0, 8, 8) +
       decode(bitand(ui.wm$flag, 16), 0, 0, 16, 16) +
       decode(bitand(ui.wm$flag, 32), 0, 0, 32, 32) +
       decode(bitand(ui.wm$flag, 64), 0, 0, 64, 64) +
       decode(bitand(ui.wm$flag, 128), 0, 0, 128, 128) +
       decode(bitand(ui.wm$flag, 256), 0, 0, 256, 256) +
       decode(bitand(ui.wm$flag, 512), 0, 0, 512, 512) +
       decode(bitand(ui.wm$flag, 1024), 0, 0, 1024, 1024) +
       decode(bitand(ui.wm$flag, 2048), 0, 0, 2048, 2048) +
       decode(bitand(ui.wm$flag, 4096), 0, 0, 4096, 4096) trig_flag,
       decode(bitand(ui.wm$flag, 8192), 0, 'DISABLED', 8192, 'ENABLED') status,
       decode(proc#, null, null,
              decode(bitand(ui.wm$flag, 16384), 0, ui.trig_owner_name || '.WM$PROC_UDT_' || proc#, 16384, 'WMSYS.WM$PROC_RIC_' || proc#)) trig_procedure,
       ui.when_clause,
       ui.description,
       ui.trig_code,
       decode(bitand(ui.wm$flag, 16384), 0, 'USER_DEFINED', 16384, 'RIC_CHECK') internal_type,
       decode(bitand(ui.wm$flag, 32768), 0, 0, 32768, 32768) +
       decode(bitand(ui.wm$flag, 65536), 0, 0, 65536, 65536) +
       decode(bitand(ui.wm$flag, 131072), 0, 0, 131072, 131072) +
       decode(bitand(ui.wm$flag, 262144), 0, 0, 262144, 262144) +
       decode(bitand(ui.wm$flag, 524288), 0, 0, 524288, 524288) +
       decode(bitand(ui.wm$flag, 1048576), 0, 0, 1048576, 1048576) +
       decode(bitand(ui.wm$flag, 2097152), 0, 0, 2097152, 2097152) +
       decode(bitand(ui.wm$flag, 4194304), 0, 0, 4194304, 4194304) +
       decode(bitand(ui.wm$flag, 8388608), 0, 0, 8388608, 8388608) +
       decode(bitand(ui.wm$flag, 16777216), 0, 0, 16777216, 16777216) +
       decode(bitand(ui.wm$flag, 33554432), 0, 0, 33554432, 33554432) +
       decode(bitand(ui.wm$flag, 67108864), 0, 0, 67108864, 67108864) event_flag
from wmsys.wm$udtrig_info$ ui, wmsys.wm$versioned_tables$ vt
where ui.vtid# = vt.vtid#
/

