create view WM$CURRENT_PARVERS_VIEW as
select vht.version parent_vers, vht.workspace
from wmsys.wm$version_hierarchy_table vht
where (vht.workspace = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
       vht.version <= decode(sys_context('lt_ctx', 'version'),
                            -1, (select current_version
                                 from wmsys.wm$workspaces_table
                                 where workspace = sys_context('lt_ctx', 'state')),
                             null, (select current_version
                                    from wmsys.wm$workspaces_table
                                    where workspace = wmsys.ltUtil.getDefaultWorkspaceName),
                            sys_context('lt_ctx', 'version'))
      )
      or
      (exists (select 1
               from wmsys.wm$version_table vt
               where vt.workspace  = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
                     vht.workspace = vt.anc_workspace and
                     vht.version  <= vt.anc_version )
      )
WITH READ ONLY
/

