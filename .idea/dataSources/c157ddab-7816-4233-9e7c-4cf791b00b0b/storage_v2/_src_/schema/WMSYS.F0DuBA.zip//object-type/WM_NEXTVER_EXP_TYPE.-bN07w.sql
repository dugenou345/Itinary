create type       wm$nextver_exp_type authid definer
         as object (next_vers  integer,
                    orig_nv    varchar2(500),
                    rid        varchar2(100))
/

