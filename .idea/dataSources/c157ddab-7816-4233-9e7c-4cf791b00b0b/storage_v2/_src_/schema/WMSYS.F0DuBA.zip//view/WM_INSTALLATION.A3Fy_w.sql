create view WM_INSTALLATION as
select name, value
 from wmsys.wm$env_vars
 where hidden = 0
union
 select name, value
 from wmsys.wm$sysparam_all_values sv
 where isdefault = 'YES' and
       hidden = 0 and
       not exists (select 1 from wmsys.wm$env_vars ev where ev.name = sv.name)
union
 select 'OWM_VERSION', version from sys.registry$ where cid='OWM'
WITH READ ONLY
/

