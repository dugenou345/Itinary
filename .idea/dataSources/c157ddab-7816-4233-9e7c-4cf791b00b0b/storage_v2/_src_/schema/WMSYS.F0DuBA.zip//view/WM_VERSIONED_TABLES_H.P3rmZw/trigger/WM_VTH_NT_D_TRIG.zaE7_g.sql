create trigger WM$VTH_NT_D_TRIG
    instead of delete
    on WM$VERSIONED_TABLES$H
    for each row
begin
  delete table (select undo_code from wmsys.wm$versioned_tables$ where owner=:parent.owner and table_name=:parent.table_name)
  where index_type  = :old.index_type and
        index_field = :old.index_field ;
end;
/

