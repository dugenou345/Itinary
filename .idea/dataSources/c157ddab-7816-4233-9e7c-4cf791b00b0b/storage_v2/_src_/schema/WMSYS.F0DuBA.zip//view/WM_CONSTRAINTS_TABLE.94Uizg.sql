create view WM$CONSTRAINTS_TABLE as
select vt.owner,
       ct.constraint_name,
       decode(bitand(ct.wm$flag, 135), 0, 'P', 1, 'PN', 2, 'PU', 3, 'U', 4, 'UI', 5, 'UN', 6, 'UU', 7, 'C', 128, 'R') constraint_type,
       vt.table_name,
       ct.search_condition,
       decode(bitand(ct.wm$flag, 8), 0, 'DISABLED', 8, 'ENABLED') status,
       ct.index_owner,
       ct.index_name,
       decode(bitand(ct.wm$flag, 112), 0, null, 16, 'NORMAL', 32, 'BITMAP', 48, 'FUNCTION-BASED NORMAL',
                                       64, 'FUNCTION-BASED NORMAL DESC', 80, 'FUNCTION-BASED BITMAP', 96, 'DOMAIN') index_type,
       ct.aliasedcolumns,
       ct.numindexcols
from wmsys.wm$constraints_table$ ct, wmsys.wm$versioned_tables$ vt
where ct.vtid# = vt.vtid# and
      bitand(ct.wm$flag, 128) = 0
/

