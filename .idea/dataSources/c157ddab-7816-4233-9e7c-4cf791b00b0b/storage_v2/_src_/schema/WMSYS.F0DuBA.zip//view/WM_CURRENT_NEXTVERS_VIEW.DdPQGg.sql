create view WM$CURRENT_NEXTVERS_VIEW as
select nvt.next_vers, nvt.version
 from wmsys.wm$nextver_table$ nvt
 where nvt.workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId) and
       nvt.version <= decode(sys_context('lt_ctx', 'version'),
                             -1, (select current_version
                                  from wmsys.wm$workspaces_table$
                                  where workspace_lock_id = sys_context('lt_ctx', 'state_id')),
                             null, (select current_version
                                    from wmsys.wm$workspaces_table$
                                    where workspace_lock_id = wmsys.ltUtil.getDefaultWorkspaceId),
                             sys_context('lt_ctx', 'version'))
union all
 select nvt.next_vers, nvt.version
 from wmsys.wm$version_table$ vt, wmsys.wm$nextver_table$ nvt
 where vt.workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId) and
       vt.anc_workspace# = nvt.workspace# and
       nvt.version <= vt.anc_version
WITH READ ONLY
/

