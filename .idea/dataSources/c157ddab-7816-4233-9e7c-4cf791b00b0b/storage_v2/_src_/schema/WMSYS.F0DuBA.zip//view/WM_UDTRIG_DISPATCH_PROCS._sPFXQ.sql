create view WM$UDTRIG_DISPATCH_PROCS as
select vt.owner table_owner_name,
       vt.table_name,
       'WMSYS.WM$DSP_UDT_' || udp.proc# dispatcher_name,
       udp.wm$flag trig_flag
from wmsys.wm$udtrig_dispatch_procs$ udp, wmsys.wm$versioned_tables$ vt
where udp.vtid# = vt.vtid#
/

