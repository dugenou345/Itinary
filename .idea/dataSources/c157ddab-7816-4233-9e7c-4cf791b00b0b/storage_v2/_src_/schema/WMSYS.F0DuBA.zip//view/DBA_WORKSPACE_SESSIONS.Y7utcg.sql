create view DBA_WORKSPACE_SESSIONS as
select sut.username, sut.workspace, sut.sid, decode(t.ses_addr, null, 'INACTIVE', 'ACTIVE') status, decode(isImplicit, 1, 'YES', 'NO') isImplicit
from wmsys.wm$workspace_sessions_view sut, gv$transaction t
where sut.lockMode = 'S' and sut.inst_id = t.inst_id(+) and sut.saddr = t.ses_addr(+)
WITH READ ONLY
/

