create type body       wm_period wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
e
db ef
IQMBRbtfSUi1VSiJ59958/Z/MQIwgxDwa8sVfI7ps/gYwUVsFnZY/IN4FpMFQ4F5aVwdDC82
rK+KhpOEfOfiU+pubnFKAOaGMkaxYgDRch5zdBuOpiszcLPfWlDL3C0Iy0rfgVrUHok+qChd
cIkaM/HfLDuvkFLZFR8DroicqEBGSRsmV7LYl8yfYMRdeQ05Uuet66CUlEeC45NdOgrCKUUP
DYdKsylFhQ0jHdFt2m4=
/

