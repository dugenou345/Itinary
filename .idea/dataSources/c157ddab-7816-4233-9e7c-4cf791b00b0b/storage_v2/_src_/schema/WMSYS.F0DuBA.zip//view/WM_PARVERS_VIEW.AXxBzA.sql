create view WM$PARVERS_VIEW as
select version parent_vers
 from wmsys.wm$version_hierarchy_table$
 where workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId)
union all
 select vht.version
 from wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$version_table$ vt
 where vt.workspace# = coalesce(to_number(sys_context('lt_ctx', 'state_id')), wmsys.ltUtil.getDefaultWorkspaceId) and
       vht.workspace# = vt.anc_workspace# and
       vht.version <= vt.anc_version
WITH READ ONLY
/

