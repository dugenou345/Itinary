create view WM$BASE_HIERARCHY_VIEW as
select vht.version
 from wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$base_version_view bv
 where vht.workspace# = bv.workspace# and
       vht.version <= bv.version
union all
 select vht.version
 from wmsys.wm$version_table$ vt, wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$base_version_view bv
 where vt.workspace# = bv.workspace# and
       vht.workspace# = vt.anc_workspace# and
       vht.version <= vt.anc_version
WITH READ ONLY
/

