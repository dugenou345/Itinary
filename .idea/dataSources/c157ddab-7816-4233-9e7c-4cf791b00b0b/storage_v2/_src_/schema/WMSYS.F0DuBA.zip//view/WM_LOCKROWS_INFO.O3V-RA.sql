create view WM$LOCKROWS_INFO as
select wt.workspace, vt.owner, vt.table_name, li.where_clause
from wmsys.wm$lockrows_info$ li, wmsys.wm$workspaces_table$i wt, wmsys.wm$versioned_tables$ vt
where li.vtid# = vt.vtid# and
      li.workspace# = wt.workspace_lock_id
/

