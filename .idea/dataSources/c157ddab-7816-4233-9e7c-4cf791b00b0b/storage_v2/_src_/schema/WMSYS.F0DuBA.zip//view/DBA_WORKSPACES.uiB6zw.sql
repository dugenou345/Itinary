create view DBA_WORKSPACES as
select asp.workspace, asp.workspace_lock_id workspace_id, asp.parent_workspace, ssp.savepoint parent_savepoint,
       asp.owner, asp.createTime, asp.description,
       decode(asp.freeze_status, 'LOCKED', 'FROZEN', 'UNLOCKED', 'UNFROZEN') freeze_status,
       decode(asp.oper_status, null, asp.freeze_mode, 'INTERNAL') freeze_mode,
       decode(asp.freeze_mode, '1WRITER_SESSION', s.username, asp.freeze_writer) freeze_writer,
       to_number(decode(asp.freeze_mode, '1WRITER_SESSION', substr(asp.freeze_writer, 1, instr(asp.freeze_writer, ',')-1), null)) sid,
       to_number(decode(asp.freeze_mode, '1WRITER_SESSION', substr(asp.freeze_owner, instr(asp.freeze_owner, ',')+1,
                                                                   instr(asp.freeze_owner, ',',1,2)-instr(asp.freeze_owner, ',')-1), null)) serial#,
       to_number(decode(asp.freeze_mode, '1WRITER_SESSION', substr(asp.freeze_writer, instr(asp.freeze_writer, ',', 1, 2)+1), null)) inst_id,
       decode(asp.session_duration, 0, asp.freeze_owner, s.username) freeze_owner,
       decode(asp.freeze_status, 'UNLOCKED', null, decode(asp.session_duration, 1, 'YES', 'NO')) session_duration,
       decode(asp.session_duration, 1,
              decode((select 1 from sys.dual
                      where s.sid = sys_context('lt_ctx', 'cid') and
                            s.serial# = sys_context('lt_ctx', 'serial#') and
                            s.inst_id = dbms_utility.current_instance),
                     1, 'YES', 'NO'),
              null) current_session,
       decode(rst.workspace,null, 'INACTIVE', 'ACTIVE') resolve_status,
       rst.resolve_user,
       mp_root mp_root_workspace
from   wmsys.wm$workspaces_table$d asp, wmsys.wm$workspace_savepoints_table ssp,
       wmsys.wm$resolve_workspaces_table rst, gv$session s
where  (asp.freeze_mode is null or asp.freeze_mode <> 'REMOVED') and
       asp.parent_version = ssp.version (+) and
       nvl(ssp.is_implicit,1) = 1 and
       asp.workspace = rst.workspace (+) and
       to_char(s.sid(+)) = substr(asp.freeze_owner, 1, instr(asp.freeze_owner, ',')-1)  and
       to_char(s.serial#(+)) = substr(asp.freeze_owner, instr(asp.freeze_owner, ',')+1, instr(asp.freeze_owner, ',',1,2)-instr(asp.freeze_owner, ',')-1) and
       to_char(s.inst_id(+)) = substr(asp.freeze_owner, instr(asp.freeze_owner, ',', 1, 2)+1)
WITH READ ONLY
/

