create view WM$WORKSPACES_TABLE as
select workspace, current_version, parent_version, post_version, verlist, owner, createtime, description, workspace_lock_id, freeze_status, freeze_mode, freeze_writer, oper_status, wm_lockmode,
       isrefreshed, freeze_owner, session_duration, implicit_sp_cnt, cr_status, sync_parver, last_change, depth, mp_root, keep, parent_workspace#, parent_workspace, parent_current_version
from wmsys.wm$workspaces_table$d
where nvl(freeze_mode, 'NULL') not in ('REMOVED', 'DEFERRED_REMOVAL')
/

