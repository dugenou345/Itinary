create trigger WM$RT_I_TRIG
    instead of insert
    on WM$RIC_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid1  integer := wmsys.ltUtil.getVtid(:new.ct_owner, :new.ct_name) ;
  vtid2  integer := wmsys.ltUtil.getVtid(:new.pt_owner, :new.pt_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$ric_table$f(:new.my_mode, :new.status) ;

  insert into wmsys.wm$ric_table$(ct_vtid#, pt_vtid#, ric_name, ct_cols, pt_cols, pt_unique_const_name, wm$flag)
  values (vtid1, vtid2, :new.ric_name, :new.ct_cols, :new.pt_cols, :new.pt_unique_const_name, flag_v) ;

  flag_v := wmsys.owm_dml_pkg.wm$constraints_table$f('R', :new.status, null) ;

  insert into wmsys.wm$constraints_table$(vtid#, constraint_name, wm$flag, owner) values(vtid1, :new.ric_name, flag_v, :new.ct_owner) ;
end;
/

