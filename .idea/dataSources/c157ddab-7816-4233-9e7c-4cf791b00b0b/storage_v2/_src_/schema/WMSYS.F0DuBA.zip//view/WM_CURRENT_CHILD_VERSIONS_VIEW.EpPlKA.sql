create view WM$CURRENT_CHILD_VERSIONS_VIEW as
select vht.version
 from wmsys.wm$version_hierarchy_table vht, wmsys.wm$version_table vt
 where vht.workspace = vt.workspace and
       vt.anc_workspace = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
       vt.anc_version >= decode(sys_context('lt_ctx', 'version'),
                                 -1, (select current_version
                                      from wmsys.wm$workspaces_table
                                      where workspace = sys_context('lt_ctx', 'state')),
                                 null, (select current_version
                                        from wmsys.wm$workspaces_table
                                        where workspace = wmsys.ltUtil.getDefaultWorkspaceName),
                                 sys_context('lt_ctx', 'version')
                               )
union all
 select vht.version
 from wmsys.wm$version_hierarchy_table vht
 where vht.workspace = coalesce(sys_context('lt_ctx', 'state'), wmsys.ltUtil.getDefaultWorkspaceName) and
       vht.version > decode(sys_context('lt_ctx', 'version'),
                             -1, (select current_version
                                  from wmsys.wm$workspaces_table
                                  where workspace = sys_context('lt_ctx', 'state')),
                             null, (select current_version
                                    from wmsys.wm$workspaces_table
                                    where workspace = wmsys.ltUtil.getDefaultWorkspaceName),
                             sys_context('lt_ctx', 'version')
                           )
WITH READ ONLY
/

