create trigger WM$RT_D_TRIG
    instead of delete
    on WM$RIC_TABLE
    for each row
declare
  vtid   integer := wmsys.ltUtil.getVtid(:old.ct_owner, :old.ct_name) ;
begin
  delete wmsys.wm$ric_table$
  where ct_vtid# = vtid and
        ric_name = :old.ric_name ;

  delete wmsys.wm$constraints_table$
  where vtid# = vtid and
        constraint_name = :old.ric_name ;
end ;
/

