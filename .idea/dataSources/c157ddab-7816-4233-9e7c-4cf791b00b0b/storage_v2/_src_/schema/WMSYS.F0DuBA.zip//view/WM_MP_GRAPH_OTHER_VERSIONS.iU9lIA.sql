create view WM$MP_GRAPH_OTHER_VERSIONS as
select vht.version, vht.workspace
 from wmsys.wm$version_hierarchy_table vht, wmsys.wm$version_table vt
 where vt.workspace = sys_context('lt_ctx', 'new_mp_leaf') and
       vht.workspace = vt.anc_workspace and
       vht.version <= vt.anc_version and
       vt.refCount > 0 and
       vt.anc_workspace not in
             (select sys_context('lt_ctx', 'new_mp_root')
              from sys.dual
             union all
              select anc_workspace
              from wmsys.wm$version_table root_anc
              where workspace = sys_context('lt_ctx', 'new_mp_root'))
union all
 select vht.version, vht.workspace
 from wmsys.wm$version_hierarchy_table vht, wmsys.wm$version_table vt
 where vt.anc_workspace = sys_context('lt_ctx', 'new_mp_leaf') and
        vht.workspace = vt.workspace
union all
 select vht.version, vht.workspace
 from wmsys.wm$version_hierarchy_table vht
 where vht.workspace = sys_context('lt_ctx', 'new_mp_leaf')
union all
 select version, workspace
 from wmsys.wm$mp_graph_cons_versions
WITH READ ONLY
/

