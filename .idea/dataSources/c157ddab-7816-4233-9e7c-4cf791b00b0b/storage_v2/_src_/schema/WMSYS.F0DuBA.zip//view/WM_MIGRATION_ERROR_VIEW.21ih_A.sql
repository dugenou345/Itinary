create view WM$MIGRATION_ERROR_VIEW as
select vfield3 error_text
from table(wmsys.ltUtil.wm$getErrors)
/

