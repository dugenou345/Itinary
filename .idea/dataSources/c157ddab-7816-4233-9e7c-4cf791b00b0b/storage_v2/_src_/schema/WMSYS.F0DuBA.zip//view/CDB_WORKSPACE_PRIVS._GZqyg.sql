create view CDB_WORKSPACE_PRIVS as
SELECT k."GRANTEE",k."WORKSPACE",k."PRIVILEGE",k."GRANTOR",k."GRANTABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("WMSYS"."DBA_WORKSPACE_PRIVS") k
/

comment on table CDB_WORKSPACE_PRIVS is ' in all containers'
/

comment on column CDB_WORKSPACE_PRIVS.CON_ID is 'container id'
/

