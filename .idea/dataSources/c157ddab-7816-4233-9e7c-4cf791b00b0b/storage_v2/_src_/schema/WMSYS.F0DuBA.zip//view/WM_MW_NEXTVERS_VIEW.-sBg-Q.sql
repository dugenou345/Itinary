create view WM$MW_NEXTVERS_VIEW as
select nvt.next_vers
from wmsys.wm$nextver_table  nvt
where  nvt.workspace in (select workspace from wmsys.wm$mw_table)
       or
       exists (select 1
               from wmsys.wm$version_table vt
               where vt.workspace in (select workspace from wmsys.wm$mw_table) and
                     nvt.workspace = vt.anc_workspace and
                     nvt.version  <= vt.anc_version)
WITH READ ONLY
/

