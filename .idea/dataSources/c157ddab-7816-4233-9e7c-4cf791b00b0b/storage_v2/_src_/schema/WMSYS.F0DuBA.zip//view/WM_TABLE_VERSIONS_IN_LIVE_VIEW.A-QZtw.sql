create view WM$TABLE_VERSIONS_IN_LIVE_VIEW as
select vtid# vtid, mt.version parent_vers
from wmsys.wm$modified_tables$ mt
where mt.workspace# = 0
WITH READ ONLY
/

