create view WM$HINT_TABLE as
select ht.hint_id, vt.owner, vt.table_name, ht.hint_text, decode(bitand(ht.wm$flag, 1), 0, 0, 1, 1) isdefault
from wmsys.wm$hint_table$ ht, wmsys.wm$versioned_tables$ vt
where ht.vtid# = vt.vtid#(+)
/

