create trigger WM$MT_I_TRIG
    instead of insert
    on WM$MODIFIED_TABLES
    for each row
declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
  vtid   integer := wmsys.ltUtil.getVtid(substr(upper(:new.table_name), 1, instr(:new.table_name, '.')-1),
                                         substr(upper(:new.table_name), instr(:new.table_name, '.')+1)) ;
begin
  insert into wmsys.wm$modified_tables$(vtid#, version, workspace#)
  values (vtid, :new.version, ws#) ;
end;
/

