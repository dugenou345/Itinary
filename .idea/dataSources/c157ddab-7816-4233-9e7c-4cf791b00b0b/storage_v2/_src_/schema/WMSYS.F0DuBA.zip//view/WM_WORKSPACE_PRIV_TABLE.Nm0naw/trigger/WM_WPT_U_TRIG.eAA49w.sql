create trigger WM$WPT_U_TRIG
    instead of update
    on WM$WORKSPACE_PRIV_TABLE
    for each row
declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
  ws#     integer := wmsys.ltUtil.getWorkspaceLockId(:old.workspace) ;
begin
  if (updating('ADMIN')) then
    flag_v := wmsys.owm_dml_pkg.wm$workspace_priv_table$f(:new.priv, :new.admin) ;
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' wm$flag=:1' ;
  end if ;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null or :4 is null)) then
           null ;
         end if;

         if (:3 is not null) then
           update wmsys.wm$workspace_priv_table$
           set ' || substr(sqlstr, 2) || '
           where grantee = :2 and
                 workspace# = :3 and
                 bitand(wm$flag, 31) = decode(:4, null, 0, ''U'', 0,
                                                  ''A'', 1, ''M'', 2, ''R'', 3, ''D'', 4, ''C'', 5, ''F'', 6, ''G'', 13,
                                                  ''AA'', 7, ''MA'', 8, ''RA'', 9, ''DA'', 10, ''CA'', 11, ''FA'', 12, ''GA'', 14,
                                                  ''W'', 15) ;
         else
           update wmsys.wm$workspace_priv_table$
           set ' || substr(sqlstr, 2) || '
           where grantee = :2 and
                 workspace# is null and
                 bitand(wm$flag, 31) = decode(:4, null, 0, ''U'', 0,
                                                  ''A'', 1, ''M'', 2, ''R'', 3, ''D'', 4, ''C'', 5, ''F'', 6, ''G'', 13,
                                                  ''AA'', 7, ''MA'', 8, ''RA'', 9, ''DA'', 10, ''CA'', 11, ''FA'', 12, ''GA'', 14,
                                                  ''W'', 15) ;
         end if ;
       end;' using flag_v, :old.grantee, ws#, :old.priv ;
  end if ;
end;
/

