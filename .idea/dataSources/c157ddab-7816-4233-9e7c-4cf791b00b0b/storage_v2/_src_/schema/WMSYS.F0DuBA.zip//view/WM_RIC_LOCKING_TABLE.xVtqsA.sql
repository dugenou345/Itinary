create view WM$RIC_LOCKING_TABLE as
select vt.owner pt_owner, vt.table_name pt_name, rlt.slockno, rlt.elockno
from wmsys.wm$ric_locking_table$ rlt, wmsys.wm$versioned_tables$ vt
where rlt.pt_vtid# = vt.vtid#
/

