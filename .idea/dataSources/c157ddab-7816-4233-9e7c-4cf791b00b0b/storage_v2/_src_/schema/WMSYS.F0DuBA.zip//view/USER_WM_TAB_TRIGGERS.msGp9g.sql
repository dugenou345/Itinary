create view USER_WM_TAB_TRIGGERS as
select trig_name trigger_name,
       table_owner_name table_owner,
       table_name,
       wmsys.ltUtil.getTrigTypes(trig_flag) trigger_type,
       status,
       when_clause,
       description,
       trig_code trigger_body,
       decode(bitand(event_flag, 32768), 0, 'OFF', 'ON') tab_merge_wo_remove,
       decode(bitand(event_flag, 65536), 0, 'OFF', 'ON') tab_merge_w_remove,
       decode(bitand(event_flag, 131072), 0, 'OFF', 'ON') wspc_merge_wo_remove,
       decode(bitand(event_flag, 262144), 0, 'OFF', 'ON') wspc_merge_w_remove,
       decode(bitand(event_flag, 524288), 0, 'OFF', 'ON') dml,
       decode(bitand(event_flag, 33554432), 0, 'OFF', 'ON') table_import
from wmsys.wm$udtrig_info
where trig_owner_name = sys_context('userenv', 'current_user') and
      internal_type = 'USER_DEFINED'
WITH READ ONLY
/

