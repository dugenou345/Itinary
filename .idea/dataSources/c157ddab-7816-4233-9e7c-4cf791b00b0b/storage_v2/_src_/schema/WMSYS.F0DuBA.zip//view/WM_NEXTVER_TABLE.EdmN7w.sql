create view WM$NEXTVER_TABLE as
select nt.version, nt.next_vers, wt.workspace, nt.split
from wmsys.wm$nextver_table$ nt, wmsys.wm$workspaces_table$i wt
where nt.workspace# = wt.workspace_lock_id
/

