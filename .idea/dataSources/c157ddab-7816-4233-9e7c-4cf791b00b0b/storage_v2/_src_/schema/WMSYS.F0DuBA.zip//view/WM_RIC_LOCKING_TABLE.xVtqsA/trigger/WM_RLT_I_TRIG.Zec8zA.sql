create trigger WM$RLT_I_TRIG
    instead of insert
    on WM$RIC_LOCKING_TABLE
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.pt_owner, :new.pt_name) ;
begin
  insert into wmsys.wm$ric_locking_table$(pt_vtid#, slockno, elockno)
  values (vtid, :new.slockno, :new.elockno) ;
end;
/

