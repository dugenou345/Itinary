create trigger WM$UDP_I_TRIG
    instead of insert
    on WM$UDTRIG_DISPATCH_PROCS
    for each row
declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.table_owner_name, :new.table_name) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$udtrig_dispatch_procs$f(:new.trig_flag) ;

  insert into wmsys.wm$udtrig_dispatch_procs$(vtid#, proc#, wm$flag)
  values (vtid, regexp_substr(:new.dispatcher_name, '[[:digit:]]+$'), flag_v) ;
end;
/

