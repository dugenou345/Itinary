create view WM$MP_GRAPH_CONS_VERSIONS as
select vht.version, vht.workspace
from wmsys.wm$mp_graph_workspaces_table mpg, wmsys.wm$version_hierarchy_table vht
where instr(sys_context('lt_ctx', 'current_mp_leafs'), mpg.mp_leaf_workspace) > 0 and
      mpg.mp_graph_flag = 'I' and
      vht.workspace = mpg.mp_graph_workspace and
      vht.version <= mpg.anc_version and
      ((nvl(sys_context('lt_ctx', 'rowlock_status'), 'X') = 'F' and nvl(sys_context('lt_ctx', 'flip_version'), 'N') = 'Y')
       or
       (nvl(sys_context('lt_ctx', 'isrefreshed'), '0') = '1')
      )
WITH READ ONLY
/

