create view USER_WM_CONS_COLUMNS as
select /*+ LEADING(t1) */ t1.owner, t1.constraint_name, t1.table_name, t1.column_name, t1.position
from wmsys.wm$cons_columns t1, user_views t2
where t1.owner = sys_context('userenv', 'current_user') and
      t1.table_name = t2.view_name
WITH READ ONLY
/

