create trigger WM$VTH_D_TRIG
    instead of delete
    on WM$VERSIONED_TABLES$H
    for each row
begin
  delete wmsys.wm$batch_compressible_tables$
  where vtid#=:old.vtid ;

  delete wmsys.wm$constraints_table$
  where vtid#=:old.vtid ;

  delete wmsys.wm$cons_columns$
  where vtid#=:old.vtid ;

  delete wmsys.wm$hint_table$
  where vtid#=:old.vtid ;

  delete wmsys.wm$lockrows_info$
  where vtid#=:old.vtid ;

  delete wmsys.wm$modified_tables$
  where vtid#=:old.vtid ;

  delete wmsys.wm$nested_columns_table$
  where vtid#=:old.vtid ;

  delete wmsys.wm$ric_table$
  where ct_vtid#=:old.vtid ;

  delete wmsys.wm$ric_triggers_table$
  where ct_vtid#=:old.vtid ;

  delete wmsys.wm$udtrig_dispatch_procs$
  where vtid#=:old.vtid ;

  delete wmsys.wm$udtrig_info$
  where vtid#=:old.vtid ;

  delete wmsys.wm$vt_errors_table$
  where vtid#=:old.vtid ;

  delete wmsys.wm$versioned_tables$
  where vtid#=:old.vtid ;
end;
/

