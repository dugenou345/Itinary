create trigger WM$SAV_I_TRIG
    instead of insert
    on WM$SYSPARAM_ALL_VALUES
    for each row
declare
  flag_v integer := 0;
begin
  flag_v := wmsys.owm_dml_pkg.wm$sysparam_all_values$f(:new.isdefault, :new.hidden) ;

  insert into wmsys.wm$sysparam_all_values$(name, value, wm$flag)
  values (:new.name, :new.value, flag_v) ;
end;
/

