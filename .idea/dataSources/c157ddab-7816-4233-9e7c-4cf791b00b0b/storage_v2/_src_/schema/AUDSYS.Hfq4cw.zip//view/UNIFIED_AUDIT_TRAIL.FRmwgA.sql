create view UNIFIED_AUDIT_TRAIL as
(select  act.component,
         sessionid,
         proxy_sessionid,
         os_user,
         host_name,
         terminal,
         instance_id,
         dbid,
         authentication_type,
         userid,
         proxy_userid,
         external_userid,
         global_userid,
         client_program_name,
         dblink_info,
         xs_user_name,
         xs_sessionid,
         entry_id,
         statement_id,
         cast((from_tz(event_timestamp, '00:00') at local) as timestamp),
         event_timestamp,
         act.name,
         return_code,
         os_process,
         transaction_id,
         scn,
         execution_id,
         obj_owner,
         obj_name,
         sql_text,
         sql_binds,
         application_contexts,
         client_identifier,
         new_owner,
         new_name,
         object_edition,
         system_privilege_used,
         spx.name,
         aom.name,
         object_privileges,
         role,
         target_user,
         excluded_user,
         excluded_schema,
         excluded_object,
         current_user,
         additional_info,
         unified_audit_policies,
         fga_policy_name,
         xs_inactivity_timeout,
         xs_entity_type,
         xs_target_principal_name,
         xs_proxy_user_name,
         xs_datasec_policy_name,
         xs_schema_name,
         xs_callback_event_type,
         xs_package_name,
         xs_procedure_name,
         xs_enabled_role,
         xs_cookie,
         xs_ns_name,
         xs_ns_attribute,
         xs_ns_attribute_old_val,
         xs_ns_attribute_new_val,
         dv_action_code,
         dv_action_name,
         dv_extended_action_code,
         dv_grantee,
         dv_return_code,
         dv_action_object_name,
         dv_rule_set_name,
         dv_comment,
         dv_factor_context,
         dv_object_status,
         ols_policy_name,
         ols_grantee,
         ols_max_read_label,
         ols_max_write_label,
         ols_min_write_label,
         ols_privileges_granted,
         ols_program_unit_name,
         ols_privileges_used,
         ols_string_label,
         ols_label_component_type,
         ols_label_component_name,
         ols_parent_group_name,
         ols_old_value,
         ols_new_value,
         rman_session_recid,
         rman_session_stamp,
         rman_operation,
         rman_object_type,
         rman_device_type,
         dp_text_parameters1,
         dp_boolean_parameters1,
         dp_warnings1,
         direct_path_num_columns_loaded,
         rls_info,
         ksacl_user_name,
         ksacl_service_name,
         ksacl_source_location,
         protocol_session_id,
         protocol_return_code,
         protocol_action_name,
         protocol_userhost,
         protocol_message,
         db_unique_name,
         decode(object_type, 2, 'TABLE',
                             4, 'VIEW',
                             6, 'SEQUENCE',
                             7, 'PROCEDURE',
                             8, 'FUNCTION',
                             9, 'PACKAGE',
                            13, 'TYPE',
                            22, 'LIBRARY',
                            23, 'DIRECTORY',
                            28, 'JAVA SOURCE',
                            29, 'JAVA CLASS',
                            30, 'JAVA RESOURCE',
                            56, 'JAVA SHARED DATA',
                            57, 'EDITION',
                            82, 'MINING MODEL',
                            87, 'ASSEMBLY',
                            92, 'OLAP CUBE DIMENSION',
                            93, 'OLAP CUBE',
                            94, 'OLAP MEASURE FOLDER',
                            95, 'OLAP CUBE BUILD PROCESS',
                           150, 'HIERARCHY',
                           151, 'ATTRIBUTE DIMENSION',
                           152, 'ANALYTIC VIEW', '')
from sys.gv_$unified_audit_trail uview, sys.all_unified_audit_actions act,
     sys.system_privilege_map spx, sys.stmt_audit_option_map aom
where   uview.action = act.action   (+)
  and - uview.system_privilege = spx.privilege (+)
  and   uview.audit_option = aom.option#   (+)
  and   uview.audit_type = act.type
UNION ALL
select  act1.component,
         sessionid,
         proxy_sessionid,
         os_user,
         host_name,
         terminal,
         instance_id,
         dbid,
         authentication_type,
         userid,
         proxy_userid,
         external_userid,
         global_userid,
         client_program_name,
         dblink_info,
         xs_user_name,
         xs_sessionid,
         entry_id,
         statement_id,
         cast((from_tz(event_timestamp, '00:00') at local) as timestamp),
         event_timestamp,
         act1.name,
         return_code,
         os_process,
         transaction_id,
         scn,
         execution_id,
         obj_owner,
         obj_name,
         sql_text,
         sql_binds,
         application_contexts,
         client_identifier,
         new_owner,
         new_name,
         object_edition,
         system_privilege_used,
         spx1.name,
         aom1.name,
         object_privileges,
         role,
         target_user,
         excluded_user,
         excluded_schema,
         excluded_object,
         current_user,
         additional_info,
         unified_audit_policies,
         fga_policy_name,
         xs_inactivity_timeout,
         xs_entity_type,
         xs_target_principal_name,
         xs_proxy_user_name,
         xs_datasec_policy_name,
         xs_schema_name,
         xs_callback_event_type,
         xs_package_name,
         xs_procedure_name,
         xs_enabled_role,
         xs_cookie,
         xs_ns_name,
         xs_ns_attribute,
         xs_ns_attribute_old_val,
         xs_ns_attribute_new_val,
         dv_action_code,
         dv_action_name,
         dv_extended_action_code,
         dv_grantee,
         dv_return_code,
         dv_action_object_name,
         dv_rule_set_name,
         dv_comment,
         dv_factor_context,
         dv_object_status,
         ols_policy_name,
         ols_grantee,
         ols_max_read_label,
         ols_max_write_label,
         ols_min_write_label,
         ols_privileges_granted,
         ols_program_unit_name,
         ols_privileges_used,
         ols_string_label,
         ols_label_component_type,
         ols_label_component_name,
         ols_parent_group_name,
         ols_old_value,
         ols_new_value,
         rman_session_recid,
         rman_session_stamp,
         rman_operation,
         rman_object_type,
         rman_device_type,
         dp_text_parameters1,
         dp_boolean_parameters1,
         dp_warnings1,
         direct_path_num_columns_loaded,
         rls_info,
         ksacl_user_name,
         ksacl_service_name,
         ksacl_source_location,
         protocol_session_id,
         protocol_return_code,
         protocol_action_name,
         protocol_userhost,
         protocol_message,
         db_unique_name,
         decode(object_type, 2, 'TABLE',
                             4, 'VIEW',
                             6, 'SEQUENCE',
                             7, 'PROCEDURE',
                             8, 'FUNCTION',
                             9, 'PACKAGE',
                            13, 'TYPE',
                            22, 'LIBRARY',
                            23, 'DIRECTORY',
                            28, 'JAVA SOURCE',
                            29, 'JAVA CLASS',
                            30, 'JAVA RESOURCE',
                            56, 'JAVA SHARED DATA',
                            57, 'EDITION',
                            82, 'MINING MODEL',
                            87, 'ASSEMBLY',
                            92, 'OLAP CUBE DIMENSION',
                            93, 'OLAP CUBE',
                            94, 'OLAP MEASURE FOLDER',
                            95, 'OLAP CUBE BUILD PROCESS',
                           150, 'HIERARCHY',
                           151, 'ATTRIBUTE DIMENSION',
                           152, 'ANALYTIC VIEW', '')
from audsys.aud$unified auduni, sys.all_unified_audit_actions act1,
     sys.system_privilege_map spx1, sys.stmt_audit_option_map aom1
where   auduni.action = act1.action   (+)
  and - auduni.system_privilege = spx1.privilege (+)
  and   auduni.audit_option = aom1.option#   (+)
  and   auduni.audit_type = act1.type)
/

comment on table UNIFIED_AUDIT_TRAIL is 'All audit trail entries'
/

comment on column UNIFIED_AUDIT_TRAIL.AUDIT_TYPE is 'Type of the Audit Record'
/

comment on column UNIFIED_AUDIT_TRAIL.SESSIONID is 'Audit Session Identifier of the User session'
/

comment on column UNIFIED_AUDIT_TRAIL.PROXY_SESSIONID is 'Proxy Audit Session Identifier in case of Proxy User session'
/

comment on column UNIFIED_AUDIT_TRAIL.OS_USERNAME is 'Operating System logon user name of the user whose actions were audited'
/

comment on column UNIFIED_AUDIT_TRAIL.USERHOST is 'Client host machine name'
/

comment on column UNIFIED_AUDIT_TRAIL.TERMINAL is 'Identifier for the user''s terminal'
/

comment on column UNIFIED_AUDIT_TRAIL.INSTANCE_ID is 'Instance number as specified in the initialization parameter file ''init.ora'''
/

comment on column UNIFIED_AUDIT_TRAIL.DBID is 'Database Identifier of the audited database'
/

comment on column UNIFIED_AUDIT_TRAIL.AUTHENTICATION_TYPE is 'Type of Authentication for the session user'
/

comment on column UNIFIED_AUDIT_TRAIL.DBUSERNAME is 'Name of the user whose actions were audited'
/

comment on column UNIFIED_AUDIT_TRAIL.DBPROXY_USERNAME is 'Name of the Proxy User in case of Proxy User sessions'
/

comment on column UNIFIED_AUDIT_TRAIL.EXTERNAL_USERID is 'External Identifier for externally authenticated users'
/

comment on column UNIFIED_AUDIT_TRAIL.GLOBAL_USERID is 'Global user identifier for the user, if the user had logged in as enterprise user'
/

comment on column UNIFIED_AUDIT_TRAIL.CLIENT_PROGRAM_NAME is 'Client Program Name which issued the commands in user session'
/

comment on column UNIFIED_AUDIT_TRAIL.DBLINK_INFO is 'Value of SYS_CONTEXT(''USERENV'', ''DBLINK_INFO'')'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_USER_NAME is 'Real Application User name'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_SESSIONID is 'Real Application User Session Identifier'
/

comment on column UNIFIED_AUDIT_TRAIL.ENTRY_ID is 'Numeric ID for each audit trail entry in the session'
/

comment on column UNIFIED_AUDIT_TRAIL.STATEMENT_ID is 'Numeric ID for each statement run (a statement may cause many actions)'
/

comment on column UNIFIED_AUDIT_TRAIL.EVENT_TIMESTAMP is 'Timestamp of the creation of audit trail entry in session''s time zone'
/

comment on column UNIFIED_AUDIT_TRAIL.EVENT_TIMESTAMP_UTC is 'Timestamp of the creation of audit trail entry in UTC time'
/

comment on column UNIFIED_AUDIT_TRAIL.ACTION_NAME is 'Name of the action executed by the user'
/

comment on column UNIFIED_AUDIT_TRAIL.RETURN_CODE is 'Oracle error code generated by the action.  Zero if the action succeeded'
/

comment on column UNIFIED_AUDIT_TRAIL.OS_PROCESS is 'Operating System process identifier of the Oracle server process'
/

comment on column UNIFIED_AUDIT_TRAIL.TRANSACTION_ID is 'Transaction identifier of the transaction in which the object is accessed or modified'
/

comment on column UNIFIED_AUDIT_TRAIL.SCN is 'SCN (System Change Number) of the query'
/

comment on column UNIFIED_AUDIT_TRAIL.EXECUTION_ID is 'Execution Context Identifier for each action'
/

comment on column UNIFIED_AUDIT_TRAIL.OBJECT_SCHEMA is 'Schema name of object affected by the action'
/

comment on column UNIFIED_AUDIT_TRAIL.OBJECT_NAME is 'Name of the object affected by the action'
/

comment on column UNIFIED_AUDIT_TRAIL.SQL_TEXT is 'SQL text of the query'
/

comment on column UNIFIED_AUDIT_TRAIL.SQL_BINDS is 'Bind variable data of the query'
/

comment on column UNIFIED_AUDIT_TRAIL.APPLICATION_CONTEXTS is 'SemiColon seperate list of Application Context Namespace, Attribute, Value information in (APPCTX_NSPACE,APPCTX_ATTRIBUTE=<value>) format'
/

comment on column UNIFIED_AUDIT_TRAIL.CLIENT_IDENTIFIER is 'Client identifier in each Oracle session'
/

comment on column UNIFIED_AUDIT_TRAIL.NEW_SCHEMA is 'The schema of the object named in the NEW_NAME column'
/

comment on column UNIFIED_AUDIT_TRAIL.NEW_NAME is 'New name of object after RENAME, or name of underlying object (e.g. CREATE INDEX owner.obj_name ON new_owner.new_name)'
/

comment on column UNIFIED_AUDIT_TRAIL.OBJECT_EDITION is 'The edition of the object affected by the action'
/

comment on column UNIFIED_AUDIT_TRAIL.SYSTEM_PRIVILEGE_USED is 'System privilege used to execute the action'
/

comment on column UNIFIED_AUDIT_TRAIL.SYSTEM_PRIVILEGE is 'System privileges granted/revoked by a GRANT/REVOKE statement'
/

comment on column UNIFIED_AUDIT_TRAIL.AUDIT_OPTION is 'Auditing option set with the audit statement'
/

comment on column UNIFIED_AUDIT_TRAIL.OBJECT_PRIVILEGES is 'Object privileges granted/revoked by a GRANT/REVOKE statement'
/

comment on column UNIFIED_AUDIT_TRAIL.ROLE is 'Role granted/revoked/set by a GRANT/REVOKE/SET ROLE statement'
/

comment on column UNIFIED_AUDIT_TRAIL.TARGET_USER is 'User on whom the GRANT/REVOKE/AUDIT/NOAUDIT statement was executed'
/

comment on column UNIFIED_AUDIT_TRAIL.EXCLUDED_USER is 'User who was excluded when the AUDIT/NOAUDIT statement was executed'
/

comment on column UNIFIED_AUDIT_TRAIL.EXCLUDED_SCHEMA is 'Schema of EXCLUDED_OBJECT'
/

comment on column UNIFIED_AUDIT_TRAIL.EXCLUDED_OBJECT is 'Object which was excluded when the SET ROLE/ALTER PLUGGABLE DATABASE statement was executed'
/

comment on column UNIFIED_AUDIT_TRAIL.CURRENT_USER is 'Effective user for the statement execution'
/

comment on column UNIFIED_AUDIT_TRAIL.ADDITIONAL_INFO is 'Text comment on the audit trail entry'
/

comment on column UNIFIED_AUDIT_TRAIL.UNIFIED_AUDIT_POLICIES is 'Unified Audit Policies that caused the audit trail entry'
/

comment on column UNIFIED_AUDIT_TRAIL.FGA_POLICY_NAME is 'Fine-Grained Audit Policy that caused the audit trail entry'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_INACTIVITY_TIMEOUT is 'Inactivity timeout of the Real Application Security session'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_ENTITY_TYPE is 'Type of the Real Application Security entity'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_TARGET_PRINCIPAL_NAME is 'Target principal name in Real Application Security operations'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_PROXY_USER_NAME is 'Real Application Security proxy user'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_DATASEC_POLICY_NAME is 'Real Application Security policy enabled or disabled'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_SCHEMA_NAME is 'Schema in enable, disable Real Application Security policy and global callback'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_CALLBACK_EVENT_TYPE is 'Real Application Security global callback event type'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_PACKAGE_NAME is 'Real Application Security callback package for global callback'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_PROCEDURE_NAME is 'Real Application Security callback procedure for global callback'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_ENABLED_ROLE is 'Enabled Real Application Security role'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_COOKIE is 'Real Application Security session cookie'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_NS_NAME is 'Real Application Security session namespace'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE is 'Real Application Security session namespace attribute'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE_OLD_VAL is 'Old value of the Real Application Security session namespace'
/

comment on column UNIFIED_AUDIT_TRAIL.XS_NS_ATTRIBUTE_NEW_VAL is 'New value of the Real Application Security session namespace'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_ACTION_CODE is 'Numeric action type code for Database Vault'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_ACTION_NAME is 'Name of the action whose numeric code appears in the DV_ACTION_CODE column'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_EXTENDED_ACTION_CODE is 'Numeric action type code for Database Vault administration'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_GRANTEE is 'Name of the user whose Database Vault authorization was modified'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_RETURN_CODE is 'Database Vault specific error code'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_ACTION_OBJECT_NAME is 'The unique name of the Database Vault object that was modified'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_RULE_SET_NAME is 'The unique name of the rule set that was executing and caused the audit event to trigger'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_COMMENT is 'Text comment on the audit trail entry'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_FACTOR_CONTEXT is 'XML document containing Database Vault factor identifiers for the current session'
/

comment on column UNIFIED_AUDIT_TRAIL.DV_OBJECT_STATUS is 'Indicates whether a particular Database Vault object is enabled or disabled'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_POLICY_NAME is 'Oracle Label Security policy for which this audit record is generated'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_GRANTEE is 'User whose OLS authorization was modified'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_MAX_READ_LABEL is 'Maximum read OLS label assigned to a user'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_MAX_WRITE_LABEL is 'Maximum write OLS label assigned to a user'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_MIN_WRITE_LABEL is 'Minimum write OLS label assigned to a user'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_PRIVILEGES_GRANTED is 'OLS privileges assigned to a user or a trusted stored procedure'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_PROGRAM_UNIT_NAME is 'Trusted stored procedure whose authorization was modified or executed'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_PRIVILEGES_USED is 'OLS privileges used for an event'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_STRING_LABEL is 'String representation of the OLS label'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_LABEL_COMPONENT_TYPE is 'Type of the OLS label component'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_LABEL_COMPONENT_NAME is 'Name of the OLS label component'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_PARENT_GROUP_NAME is 'Name of the parent of the OLS group'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_OLD_VALUE is 'Old value for OLS ALTER events'
/

comment on column UNIFIED_AUDIT_TRAIL.OLS_NEW_VALUE is 'New value for OLS ALTER events'
/

comment on column UNIFIED_AUDIT_TRAIL.RMAN_SESSION_RECID is 'RMAN Record Id'
/

comment on column UNIFIED_AUDIT_TRAIL.RMAN_SESSION_STAMP is 'RMAN Session Stamp'
/

comment on column UNIFIED_AUDIT_TRAIL.RMAN_OPERATION is 'RMAN Operation'
/

comment on column UNIFIED_AUDIT_TRAIL.RMAN_OBJECT_TYPE is 'RMAN Object Involved'
/

comment on column UNIFIED_AUDIT_TRAIL.RMAN_DEVICE_TYPE is 'Device Involved in RMAN Session'
/

comment on column UNIFIED_AUDIT_TRAIL.DP_TEXT_PARAMETERS1 is 'Audited DataPump parameters that have text values'
/

comment on column UNIFIED_AUDIT_TRAIL.DP_BOOLEAN_PARAMETERS1 is 'Audited DataPump parameters that have boolean values'
/

comment on column UNIFIED_AUDIT_TRAIL.DP_WARNINGS1 is 'Audited warnings from DataPump operation'
/

comment on column UNIFIED_AUDIT_TRAIL.DIRECT_PATH_NUM_COLUMNS_LOADED is 'Direct Path API load - number of columns loaded'
/

comment on column UNIFIED_AUDIT_TRAIL.RLS_INFO is 'RLS predicates along with the RLS policy names used for the object accessed'
/

comment on column UNIFIED_AUDIT_TRAIL.KSACL_USER_NAME is 'The connecting user name'
/

comment on column UNIFIED_AUDIT_TRAIL.KSACL_SERVICE_NAME is 'The target DB service name'
/

comment on column UNIFIED_AUDIT_TRAIL.KSACL_SOURCE_LOCATION is 'The source location of the initiating connection'
/

comment on column UNIFIED_AUDIT_TRAIL.PROTOCOL_SESSION_ID is 'Session id for audited protocol message'
/

comment on column UNIFIED_AUDIT_TRAIL.PROTOCOL_RETURN_CODE is 'Return code of audited protocol message reply'
/

comment on column UNIFIED_AUDIT_TRAIL.PROTOCOL_ACTION_NAME is 'Operation of audited protocol message'
/

comment on column UNIFIED_AUDIT_TRAIL.PROTOCOL_USERHOST is 'IP address of client system of audited protocol message'
/

comment on column UNIFIED_AUDIT_TRAIL.PROTOCOL_MESSAGE is 'Audited protocol message'
/

comment on column UNIFIED_AUDIT_TRAIL.DB_UNIQUE_NAME is 'Globally unique name for the database'
/

