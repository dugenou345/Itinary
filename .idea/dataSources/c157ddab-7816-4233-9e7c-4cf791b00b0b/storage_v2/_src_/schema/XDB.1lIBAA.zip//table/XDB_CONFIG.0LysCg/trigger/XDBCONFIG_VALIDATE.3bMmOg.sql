create trigger XDBCONFIG_VALIDATE
    before insert or update
    on XDB$CONFIG
    for each row
declare
  xdoc xmltype;
begin
  xdoc := :new.sys_nc_rowinfo$;
  xmltype.schemaValidate(xdoc);
end;
/

