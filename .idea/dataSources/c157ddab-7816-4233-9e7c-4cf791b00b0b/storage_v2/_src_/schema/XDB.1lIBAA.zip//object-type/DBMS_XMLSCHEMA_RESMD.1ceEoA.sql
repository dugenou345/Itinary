create TYPE     DBMS_XMLSCHEMA_RESMD FORCE as OBJECT (
        path_name varchar2(4000),
	path_oid raw(16)
);
/

