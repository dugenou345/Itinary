create type     path_linkinfo                                        wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
79 aa
g0V6zG8egE2xYLkdFQIyNY27Wowwg5n0dLhcFlpW+uNy+kfZ/0cM2cHAdCulv5vAMsvuJY8J
aee4dAhpqal8xsoXKMbK77KEHe+2RC9eXltNFTFq68aVcrOxlKEC9yaI5jWpC8gKD1o0nbBt
5sgLU0BrWBucGx2mqUqkyQ==
/

