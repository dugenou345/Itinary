create PACKAGE     dbms_xlsb AUTHID CURRENT_USER IS

PROCEDURE InsertResourceNXob(oid IN RAW, res IN CLOB,
                             flags IN NUMBER,
                             content IN BLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertResourceNXob, AUTO);

PROCEDURE InsertResourceNXobClob(oid IN RAW, res IN CLOB,
                             flags IN NUMBER,
                             content IN CLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertResourceNXobClob, AUTO);

PROCEDURE InsertResource(oid IN RAW, res IN CLOB,
                         flags IN NUMBER,
                         content IN CLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertResource, AUTO);

PROCEDURE InsertResourceRef(oid IN RAW, res IN CLOB,
                            flags IN NUMBER,
                            content IN RAW);
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertResourceRef, AUTO);

PROCEDURE LinkResource(parent_path IN VARCHAR2, name IN VARCHAR2,
                       child_path IN VARCHAR2, oid IN RAW,
                       linksn IN RAW, acloid IN RAW,
                       owner IN VARCHAR2, owner_format IN NUMBER,
                       flags IN NUMBER, types IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(LinkResource, AUTO);

PROCEDURE UnlinkResource(parent_path IN VARCHAR2,
                         name IN VARCHAR2, oid IN RAW,
                         flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(UnlinkResource, AUTO);

PROCEDURE DeleteResource(oid IN RAW, flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(DeleteResource, AUTO);

PROCEDURE SetRefcount(oid IN RAW, refcount IN NUMBER, flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(SetRefcount, AUTO);

PROCEDURE TouchOid(oid IN RAW, owner IN VARCHAR2, owner_format IN NUMBER,
                   mod_date IN RAW);
PRAGMA SUPPLEMENTAL_LOG_DATA(TouchOid, AUTO);

PROCEDURE UpdateResource(res IN CLOB,
                         flags IN NUMBER,
                         content IN CLOB, pref IN RAW);
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateResource, AUTO);

PROCEDURE UpdateResourceRef(res IN CLOB,
                            flags IN NUMBER,
                            content IN RAW, pref IN RAW);
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateResourceRef, AUTO);

PROCEDURE UpdateContentXob(content IN CLOB,
                           pref    IN RAW,
                           flags   IN NUMBER,
                           schema  IN NUMBER,
                           schoid  IN RAW      := NULL, /* 21608034,21656322 */
                           schurl  IN VARCHAR2 := NULL, /* 21608034,21656322 */
                           elname  IN VARCHAR2 := NULL);/* 21608034,21656322 */
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateContentXob, AUTO);

PROCEDURE SaveAcl(acloid       IN RAW,
                  resoid       IN RAW,
                  flags        IN NUMBER,
                  schema       IN VARCHAR2,
                  name         IN VARCHAR2,
                  oid          IN RAW,
                  owner        IN VARCHAR2 := NULL,              /* 21618836 */
                  owner_format IN NUMBER   := 0);                /* 21618836 */
PRAGMA SUPPLEMENTAL_LOG_DATA(SaveAcl, AUTO);

PROCEDURE UpdateLocks(oid IN RAW, lock_list IN CLOB, next_seq IN NUMBER,
                      flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateLocks, AUTO);

PROCEDURE UpdateNameLocks(oid IN RAW, name IN VARCHAR2,
                          token IN RAW, flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateNameLocks, AUTO);

PROCEDURE DelNameLocks(oid IN RAW, seq IN NUMBER, flags IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(DelNameLocks, AUTO);

PROCEDURE InsertToHTable(content IN CLOB, acloid IN RAW,
                         owner IN VARCHAR2, owner_format IN NUMBER,
                         oid IN RAW, flags IN NUMBER, schema IN NUMBER);
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertToHTable, AUTO);

PROCEDURE InsertToUserHTab(content IN CLOB, acloid IN RAW,
                           owner IN VARCHAR2, owner_format IN NUMBER,
                           oid IN RAW, flags IN NUMBER,
                           schoid IN RAW,
                           schema IN VARCHAR2,
                           elnum  IN NUMBER   := 0,    /* backward compatible*/
                           elname IN VARCHAR2 := NULL,           /* 20529144 */
                           resoid IN RAW      := NULL);          /* 21185636 */
PRAGMA SUPPLEMENTAL_LOG_DATA(InsertToUserHTab, AUTO);

PROCEDURE UpdateRootInfo(content IN CLOB);
PRAGMA SUPPLEMENTAL_LOG_DATA(UpdateRootInfo, AUTO);

END dbms_xlsb;
/

