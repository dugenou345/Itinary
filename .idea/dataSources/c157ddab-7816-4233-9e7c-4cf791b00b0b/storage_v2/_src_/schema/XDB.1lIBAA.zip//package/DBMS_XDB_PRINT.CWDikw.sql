create package     dbms_xdb_print wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
26d 17d
8u741JSWVtO/muw4PILraVZ3Kiswg/BQLgwdfy85cHL41Yu05pY7CRoMKAP69bLXH7c2/D5p
IwgO4yOlwROybZ6YlGRqgoK7X4BS20GPwD8/ck+cxz8QEiM6plkINaEv9Fh+Rz4v1p4uHY+T
jawaHRukAxfB9Ibv5xeEov2vG+uUNAVqRXOLQT7/UdfQLUiHzTO/HZ6AQ4JeuPREAY4j/Lmw
4nVUy3WjVCCwI1cDQY7ossSdUVFBMbw7f9kLwsLAPxekOKX16XewlOsw1BnKRl3tG14U/NhM
T2xgcV9kDzcyp6fpeITWthS2tjYYKoxS8W/5Di1bAcY62TOdwEQLFdXt5rabTxKrwtORF+Yi
+tHqgxnP+zIr6II=
/

