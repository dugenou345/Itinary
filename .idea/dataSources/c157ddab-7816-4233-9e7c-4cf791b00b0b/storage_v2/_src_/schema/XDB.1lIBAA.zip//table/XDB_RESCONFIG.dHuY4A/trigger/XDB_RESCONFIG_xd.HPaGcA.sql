create trigger "XDB$RESCONFIG$xd"
    after update or delete
    on XDB$RESCONFIG
    for each row
BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'C820FA6BCA4C2BA2E053362EE80AC6CF' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'C820FA6BCA4C2BA2E053362EE80AC6CF', user ); END IF; END;
/

