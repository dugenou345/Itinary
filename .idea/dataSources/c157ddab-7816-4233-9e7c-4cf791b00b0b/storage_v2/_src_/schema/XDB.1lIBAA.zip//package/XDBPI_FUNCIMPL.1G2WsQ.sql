create package     xdbpi_funcimpl as
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);
  function noop_func(res sys.xmltype) return number;
end;
/

