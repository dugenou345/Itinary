create package body     DBMS_XDB_VERSION as

  PROCEDURE makeversioned_int(pathname IN varchar2, resid OUT resid_type) is
    LANGUAGE C NAME "qmevsMakeVersioned"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString,
                  pathname indicator sb4,
                  resid,
                  resid    indicator sb4,
                  resid    length size_t
                 );

  FUNCTION makeversioned(pathname varchar2) RETURN resid_type is
    ret resid_type;
  BEGIN
    makeversioned_int(pathname, ret);
    return ret;
  END;

  PROCEDURE checkout(pathname varchar2) is
    LANGUAGE C NAME "qmevsCheckout"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname     OCIString,
                  pathname indicator sb4);

  PROCEDURE checkin_int(pathname IN varchar2, resid OUT resid_type) is
    LANGUAGE C NAME "qmevsCheckin"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString,
                  pathname indicator sb4,
                  resid,
                  resid    indicator sb4,
                  resid    length size_t
                 );

  FUNCTION checkin(pathname varchar2) RETURN resid_type is
    ret resid_type;
  BEGIN
    checkin_int(pathname, ret);
    return ret;
  END;

  PROCEDURE uncheckout_int(pathname IN varchar2, resid OUT resid_type) is
    LANGUAGE C NAME "qmevsUncheckout"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString,
                  pathname indicator sb4,
                  resid,
                  resid    indicator sb4,
                  resid    length size_t
                 );

  FUNCTION uncheckout(pathname varchar2) RETURN resid_type is
    ret resid_type;
  BEGIN
    uncheckout_int(pathname, ret);
    return ret;
  END;

  FUNCTION ischeckedout(pathname varchar2) RETURN BOOLEAN is
    LANGUAGE C NAME "qmevsIsResCheckedOut"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString, pathname indicator sb4,
                  RETURN INDICATOR sb4,
                  return
                 );

  FUNCTION getresid(pathname varchar2) RETURN resid_type is
    LANGUAGE C NAME "qmevsGetResID"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString, pathname indicator sb4,
                  RETURN INDICATOR sb4,
                  RETURN LENGTH size_t
                 );

  FUNCTION GetPredecessors(pathname varchar2) RETURN resid_list_type is
    resid  resid_type;
  BEGIN
    resid := getresid(pathname);
    return GetPredsByResId(resid);
  END;

  FUNCTION GetPredsByResId(resid resid_type) RETURN resid_list_type is
    LANGUAGE C NAME "qmevsGetPredsByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN
                 );

  FUNCTION GetSuccessors(pathname varchar2) RETURN resid_list_type is
    resid  resid_type;
  BEGIN
    resid := getresid(pathname);
    return GetSuccsByResId(resid);
  END;

  FUNCTION GetSuccsByResId(resid resid_type) RETURN resid_list_type is
    LANGUAGE C NAME "qmevsGetSuccsByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN
                 );

  FUNCTION GetResourceByResId(resid resid_type) RETURN XMLType is
    LANGUAGE C NAME "qmevsGetResByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN
                 );

  FUNCTION GetContentsBlobByResId(resid resid_type) RETURN BLOB is
    LANGUAGE C NAME "qmevsGetCtsBlobByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN OCILobLocator
                 );

  FUNCTION GetContentsClobByResId(resid resid_type) RETURN CLOB is
    LANGUAGE C NAME "qmevsGetCtsClobByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN OCILobLocator
                 );

  FUNCTION GetContentsXmlByResId(resid resid_type) RETURN XMLType is
    LANGUAGE C NAME "qmevsGetCtsXmlByResId"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN
                 );

  FUNCTION GetVersionHistoryID(pathname varchar2) RETURN resid_type is
    LANGUAGE C NAME "qmevsGetVerHistID"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  pathname OCIString, pathname indicator sb4,
                  RETURN INDICATOR sb4,
                  RETURN LENGTH size_t
                 );

  FUNCTION GetVersionHistory(resid resid_type) RETURN resid_list_type is
    LANGUAGE C NAME "qmevsGetVerHist"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN DURATION OCIDuration,
                  RETURN
                 );

  FUNCTION GetVersionHistoryRoot(resid resid_type) RETURN resid_type IS
    LANGUAGE C NAME "qmevsGetVerHistRoot"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  resid OCIRaw, resid indicator sb2,
                  RETURN INDICATOR sb4,
                  RETURN LENGTH size_t
                 );

  PROCEDURE CreateRealWorkspace(wsname        IN VARCHAR2,
                                initializer   IN VARCHAR2,
                                published     IN boolean,
                                privateNonVCR IN boolean) IS
    LANGUAGE C NAME "qmevsCreateRealWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname            OCIString,
                  wsname        indicator sb4,
                  initializer       OCIString,
                  initializer   indicator sb4,
                  published               ub2,
                  published     indicator sb4,
                  privateNonVCR           ub2,
                  privateNonVCR indicator sb4
                 );

  PROCEDURE CreateVirtualWorkspace(wsname      IN VARCHAR2,
                                   base_wsname IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsCreateVirtualWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname          OCIString,
                  wsname      indicator sb4,
                  base_wsname     OCIString,
                  base_wsname indicator sb4
                 );

  PROCEDURE DeleteWorkspace(wsname IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsDeleteWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname     OCIString,
                  wsname indicator sb4
                 );

  PROCEDURE SetWorkspace(wsname IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsSetWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname     OCIString,
                  wsname indicator sb4
                 );

  PROCEDURE GetWorkspace(wsname OUT VARCHAR2) IS
    LANGUAGE C NAME "qmevsGetWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname          STRING,
                  wsname   INDICATOR sb4,
                  wsname      LENGTH sb4,
                  wsname      MAXLEN sb4
                 );

  PROCEDURE PublishWorkspace(wsname IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsPublishWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname     OCIString,
                  wsname indicator sb4
                 );

  PROCEDURE UnPublishWorkspace(wsname IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsUnPublishWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  wsname     OCIString,
                  wsname indicator sb4
                 );

  PROCEDURE UpdateWorkspace(target_wsname IN VARCHAR2,
                            source_wsname IN VARCHAR2,
                            privateNonVCR IN BOOLEAN) IS
    LANGUAGE C NAME "qmevsUpdateWS"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  target_wsname     OCIString,
                  target_wsname indicator sb4,
                  source_wsname     OCIString,
                  source_wsname indicator sb4,
                  privateNonVCR           ub2,
                  privateNonVCR indicator sb4
                 );

  PROCEDURE CreateBranch(name IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsCreateBranch"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  name      OCIString,
                  name  indicator sb4
                 );

  PROCEDURE MakeShared(path IN VARCHAR2) IS
    LANGUAGE C NAME "qmevsMakeShared"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  path         OCIString,
                  path     indicator sb4
                 );

  PROCEDURE CreateVCR(path IN VARCHAR2, versionResID IN resid_type) IS
    LANGUAGE C NAME "qmevsCreateVCR"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  path             OCIString,
                  path         indicator sb4,
                  versionResID        OCIRaw,
                  versionResID indicator sb4
                 );

  PROCEDURE UpdateVCRVersion(path IN VARCHAR2, newResID IN resid_type) IS
    LANGUAGE C NAME "qmevsUpdateVCR"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  path             OCIString,
                  path         indicator sb4,
                  newResID            OCIRaw,
                  newResID     indicator sb4
                 );

  PROCEDURE DeleteVersion(versionResID IN resid_type) IS
    LANGUAGE C NAME "qmevsDelVersion"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  versionResID        OCIRaw,
                  versionResID indicator sb4
                 );

  PROCEDURE DeleteVersionHistory(vhid resid_type) IS
    LANGUAGE C NAME "qmevsDeleteVerHist"
      LIBRARY XDB.DBMS_XDB_VERSION_LIB
      WITH CONTEXT
      PARAMETERS (context,
                  vhid        OCIRaw,
                  vhid indicator sb4
                 );

end DBMS_XDB_VERSION;
/

