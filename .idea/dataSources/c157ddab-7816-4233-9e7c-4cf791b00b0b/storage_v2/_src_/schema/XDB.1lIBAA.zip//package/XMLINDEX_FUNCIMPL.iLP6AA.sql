create package     XMLIndex_FUNCIMPL authid current_user is
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);
  function xmlindex_noop(res sys.xmltype,
                         pathstr varchar2,
                         ia sys.odciindexctx,
                         sctx IN OUT XDB.XMLIndexMethods,
                         sflg number)
  return number;
end XMLIndex_FUNCIMPL;
/

