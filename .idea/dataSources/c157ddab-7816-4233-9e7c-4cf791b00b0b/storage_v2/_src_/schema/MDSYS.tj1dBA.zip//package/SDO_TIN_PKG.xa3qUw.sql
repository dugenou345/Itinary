create PACKAGE       sdo_tin_pkg authid current_user AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- all tables as "schema.table" for simpler interface.
  FUNCTION INIT(basetable varchar2, basecol varchar2,
       blktable varchar2,
       ptn_params varchar2 default null,
       tin_extent            mdsys.sdo_geometry default null,
       tin_tol               NUMBER default 0.000000000000005,
       tin_tot_dimensions    NUMBER default 2,
       tin_domain            mdsys.sdo_orgscl_type default null,
       tin_break_lines       MDSYS.SDO_GEOMETRY default null,
       tin_stop_lines        MDSYS.SDO_GEOMETRY default null,
       tin_void_rgns         MDSYS.SDO_GEOMETRY default null,
       tin_val_attr_tables   MDSYS.SDO_STRING_ARRAY default null,
       tin_other_attrs       SYS.XMLTYPE default null)
    RETURN MDSYS.SDO_TIN ;

  PROCEDURE CREATE_TIN(inp mdsys.sdo_tin, inptable varchar2,
                       clstpcdatatbl varchar2 default null);

  -- works as read if qry is null
  FUNCTION CLIP_TIN(inp mdsys.sdo_tin,
                   qry mdsys.sdo_geometry, qry_min_res number, qry_max_res number,
                   blkno number default null)
    RETURN MDSYS.SDO_TIN_BLK_TYPE PIPELINED ;

  PROCEDURE DROP_DEPENDENCIES(basetable varchar2, col varchar2);

  FUNCTION TO_GEOMETRY(pts BLOB, trs BLOB,
                       num_pts NUMBER, num_trs NUMBER,
                       tin_ind_dim NUMBER,
                       tin_tot_dim NUMBER, srid number default null,
                       blk_domain mdsys.sdo_orgscl_type default null,
                       get_ids NUMBER default NULL)
    RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

  PROCEDURE TO_DEM(
    tin                 IN     mdsys.sdo_tin,
    dem                 IN OUT mdsys.sdo_georaster,
    blocksize           IN     NUMBER,
    crs_units_per_pixel IN     NUMBER);
--  PRAGMA RESTRICT_REFERENCES(to_geometry, WNDS, WNPS, RNPS);

/*

  -- works as read if qry is null
  FUNCTION CLIP_Pts(inp mdsys.sdo_tin,
                    qry mdsys.sdo_geometry,
                    qry_min_res number, qry_max_res number,
                    blkno number default null)
    RETURN ANYDATASET;
  FUNCTION CLIP_PtIds(inp mdsys.sdo_tin,
                    qry mdsys.sdo_geometry,
                    qry_min_res number, qry_max_res number)
    RETURN ANYDATASET;

  -- works as read if qry is null
  FUNCTION CLIP_Triangles(inp mdsys.sdo_tin, qry mdsys.sdo_geometry,
                    qry_min_res number, qry_max_res number,
                    blkno number default null)
    RETURN ANYDATASET;
  FUNCTION CLIP_TriangleIds(inp mdsys.sdo_tin, qry mdsys.sdo_geometry,
                    qry_min_res number, qry_max_res number,
                    blkno number default null)
    RETURN ANYDATASET;
*/

  function clip_tin_into_pc(
    tin_inp         mdsys.sdo_tin,
    tin_qry         mdsys.sdo_geometry,
    tin_qry_min_res number,
    tin_qry_max_res number,
    pc_basetable    varchar2,
    pc_basecol      varchar2,
    pc_blktable     varchar2,
    pc_ptn_params   varchar2 default null,
    tin_blkno       number   default null)
      return mdsys.sdo_pc;

  function project_ordinates_onto_tin(
    ordinates2d mdsys.sdo_ordinate_array,
    tin         mdsys.sdo_tin)
      return mdsys.sdo_ordinate_array deterministic;

  function get_surface_of_tin(
    tin    mdsys.sdo_tin,
    geom2d mdsys.sdo_geometry)
      return number deterministic;

  function get_surface_of_tin_footprint(
    tin    mdsys.sdo_tin,
    geom2d mdsys.sdo_geometry)
      return number deterministic;

  function get_volume_under_tin(
    tin         mdsys.sdo_tin,
    geom2d      mdsys.sdo_geometry,
    base_height number)
      return number deterministic;

  procedure populate_zcoords_from_triangle(
    ordinates3d in out mdsys.sdo_ordinate_array,
    a_x         in     number,
    a_y         in     number,
    a_z         in     number,
    b_x         in     number,
    b_y         in     number,
    b_z         in     number,
    c_x         in     number,
    c_y         in     number,
    c_z         in     number);

  procedure create_contour_geometries(
    tin                 mdsys.sdo_tin,
    elevations          mdsys.sdo_number_array,
    region              mdsys.sdo_geometry,
    contour_table       varchar2);

  procedure create_contour_geometries(
    tin                 mdsys.sdo_tin,
    elevations_min      number,
    elevations_interval number,
    elevations_max      number,
    region              mdsys.sdo_geometry,
    contour_table       varchar2);

END sdo_tin_pkg;
/

