create TYPE       swipe_io_duration_type AS OBJECT (
  in_user_id        NUMBER,
  out_user_id       NUMBER,
  building_id       VARCHAR2(100),
  floor_id          VARCHAR2(100),
  room_id           VARCHAR2(100),
  segment_or_all    VARCHAR2(10),
  start_time        DATE,
  end_time          DATE,
  duration          NUMBER,
  num_contact_times NUMBER)
/

