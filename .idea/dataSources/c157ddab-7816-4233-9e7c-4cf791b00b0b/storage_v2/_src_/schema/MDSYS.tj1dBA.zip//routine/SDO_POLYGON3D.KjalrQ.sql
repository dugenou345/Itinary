create FUNCTION sdo_polygon3d return NUMBER is
 BEGIN
 return 3003;
 END sdo_polygon3d;
/

