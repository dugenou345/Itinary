create FUNCTION RDFSA_DOMLBL wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
56 89
BIPj+Yhr8xOF8UF8hH4/TeL6n3Mwg2LZmLKpfHREZyfoMERER2dDL8bmwHb69PYzmqzQFmRT
059fA4h6nNzqSFy34Fzy2EtN9BDWTufET3X701Jvq199sPoTnLCfkhkiVfx/b0I=
/

