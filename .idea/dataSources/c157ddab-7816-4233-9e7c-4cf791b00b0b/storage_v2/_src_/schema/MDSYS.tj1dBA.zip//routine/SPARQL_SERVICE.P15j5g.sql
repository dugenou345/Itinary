create function SPARQL_SERVICE wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
207 ff
Ha/Gajhc4kdseEbKAdeu3HczvNgwg5DMmMsVfHSRi9VlrEYEVFhZBgmMjxqfcSZe+bWWWjhn
ekDlGdwzkLnPkC2WibTeOYjgXIn3erlhSK90QGXtqC39Nc8owHtWBu8HbuPZoz+YG1Oid43k
foMLTawnLX1HsaH9ijT0G1L72hH9xm+GZZW6bV4T9A+A1dsJQROzJLtzLwWd2zZt+oKv8zCe
aWctU1mI7385F/LPc+W+JQDGo/8TW83eFwU=
/

