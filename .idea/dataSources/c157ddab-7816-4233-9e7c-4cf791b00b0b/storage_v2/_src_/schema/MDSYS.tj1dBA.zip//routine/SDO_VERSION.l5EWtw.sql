create function       SDO_VERSION wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
fc 103
LXNgbIVPvWP+5g1tcZNsPOf+Iokwg+nQf8vWfHTp2sGOGRGc5SfGTdahWfSObpffw1m+tWKr
FDYTgXOaA3pHdlaUOfBj0RSDyVvKkQN8VhY4okLmFO9Y00kNjo9trK1e4tu0Fyd5kAM9qTgU
Z3nkSIbAFuJkxteYQSLeTiCUl450MxPItJf0DXPKAeFMgRwS2CVXKpO6+f2h5+ZYvCrpMISx
DuJDpoXzd1DJVQZExxiQv8F4B1XaBn2Wqq8cZzg=
/

