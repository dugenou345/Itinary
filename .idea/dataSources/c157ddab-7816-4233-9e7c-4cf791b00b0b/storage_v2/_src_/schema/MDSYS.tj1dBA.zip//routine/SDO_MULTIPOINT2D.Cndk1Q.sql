create FUNCTION sdo_multipoint2d return NUMBER is
 BEGIN
 return 2005;
 END sdo_multipoint2d;
/

