create function       SDO_Aggr_Centroid wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
c2 be
ys8I6qifsiu105k2pP+3GipxKKIwg8eZgcfLCNL+XuefCNC/Wa6WGL/c19U+l3JZs7j1vyjA
Mr90UjK/gf4ysr0Yw48Jyh/ORTaAOR77zaaIq9OIj+W9IdWFKhQhhSioHyjEhZUq2yqFsety
glfb61iZuS8CUHCuJL9EL5oxPZYUhZrrlez7phci0X8=
/

