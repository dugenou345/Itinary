create FUNCTION sdo_linestring2d return NUMBER is
 BEGIN
 return 2002;
 END sdo_linestring2d;
/

