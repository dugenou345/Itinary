create Type location_msg_pkd as
      object(arr location_msg_arr)
/

