create package s_sem_rdfsa_dr is

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  function get_ols_policy_name return varchar2;

  function get_rdfols_options return number;

  procedure rdf_ols_state (
              policy_name      IN OUT VARCHAR2,
              policy_enabled   IN OUT BOOLEAN,
              has_eap_priv     IN OUT BOOLEAN);

  function get_model_id(p_model_name VARCHAR2) return number;

  function is_uri_type (intid  NUMBER) return boolean;

  procedure set_triple_label (
              p_model_id         NUMBER,
              p_triple_id        VARCHAR2,
              p_label_num        NUMBER,
              reset_option       BOOLEAN default false);

  procedure drop_vpd_policy (
              p_owner          VARCHAR2,
              p_name           VARCHAR2);

  procedure uninstall_vpd;

  procedure cleanup_vpd_objects;

  procedure remove_vpd_policy (
              p_owner          VARCHAR2,
              p_name           VARCHAR2,
              p_model          VARCHAR2);

  procedure process_vpd_patterns(
              policy_rid    IN VARCHAR2,
              matchPattern  IN OUT varchar2,
              applyPattern  IN OUT varchar2,
              aliases          MDSYS.RDF_Aliases,
              applyInstr    IN OUT sys.ODCIVarchar2List);

  procedure maintain_for_ddl (
              p_ddl_type          VARCHAR2,
              p_model_id          NUMBER,
              p_tbs_name          VARCHAR2 default null,
              p_model_tabid       NUMBER default null,
              p_triple_col        VARCHAR2 default null);

end;
/

