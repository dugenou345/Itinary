create package sdo_sem_http_ctx authid current_user as
   SDO_SEM_HTTP_CTX constant varchar2(20) := 'SDO_SEM_HTTP_CTX';

   -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
   PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

   procedure set_usr ( endpoint   in varchar2,
                       username   in varchar2 );
   procedure set_pwd ( endpoint   in varchar2,
                       password   in varchar2 );
   function get_usr  ( endpoint   in varchar2 ) return varchar2;
   function get_pwd  ( endpoint   in varchar2 ) return varchar2;
   function get_hash ( input_data in varchar2 ) return number;
   end sdo_sem_http_ctx;
/

