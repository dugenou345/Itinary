create FUNCTION sdo_multipolygon3d return NUMBER is
 BEGIN
 return 3007;
 END sdo_multipolygon3d;
/

