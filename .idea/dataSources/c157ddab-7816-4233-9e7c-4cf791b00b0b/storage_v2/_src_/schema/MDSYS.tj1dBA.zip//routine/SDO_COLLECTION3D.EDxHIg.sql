create FUNCTION sdo_collection3d return NUMBER is
 BEGIN
 return 3004;
 END sdo_collection3d;
/

