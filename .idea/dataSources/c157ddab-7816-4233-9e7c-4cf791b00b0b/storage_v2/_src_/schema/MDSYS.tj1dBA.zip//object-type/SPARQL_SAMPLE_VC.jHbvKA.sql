create TYPE SPARQL_Sample_VC authid current_user AS OBJECT(

curr_val      MDSYS.SDO_RDF_TERM,

STATIC FUNCTION ODCIAggregateInitialize(
        sctx IN OUT SPARQL_Sample_VC)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateIterate(
         self       IN OUT SPARQL_Sample_VC
       , value      IN VARCHAR2)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateMerge(
        self IN OUT SPARQL_Sample_VC
       ,ctx2 IN SPARQL_Sample_VC)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateTerminate (
        self IN SPARQL_Sample_VC
       ,return_value OUT VARCHAR2
       ,flags IN NUMBER)
RETURN NUMBER
);
/

