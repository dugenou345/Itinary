create PACKAGE sdo_rdf_mig wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
121 ef
eVNwWbW95ny628JKA0iJdL0D4nEwg/BKJJkVaXTbkPg+ZSt9XYM+vBpcR/iEkkH2p+BSLzWd
JFTavSt8dja5SoacUJBLFzBKvxJfH5hMSd1r4XWNjhLQfImJRgAHX+DTEu9HVLa/VBR4L+CP
ebpic311GGVXAUd+8pA6WlZplnLhI0ALqYLl2g65q4VTH4cIwb7+vhaVB400dNgPM18IoTWr
6yR0nWFXaZhC+42PDEE=
/

