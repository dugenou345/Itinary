create FUNCTION sdo_multipolygon2d return NUMBER is
 BEGIN
 return 2007;
 END sdo_multipolygon2d;
/

