create PACKAGE sdo_rdf_java_stp AUTHID current_user AS

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  -- from prvtrdfctx.sql
  procedure parse_rdfxml (
              docin             CLOB,
              docid             VARCHAR2,
              modelid           NUMBER,
              flags             NUMBER,
              stagtab           VARCHAR2,
              part_name         VARCHAR2) as
  language java name
    'oracle.spatial.rdf.util.RDFXMLParser.parseRDFXML(
              oracle.sql.CLOB,
              java.lang.String,
              int,
              int,
              java.lang.String,
              java.lang.String)';
  function getSelectVariables (
              query             VARCHAR2)
     return RDF_varcharArray as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSelectVariables(
        java.lang.String) return oracle.sql.STRUCT';

  function getWhereVariables (
              query             VARCHAR2,
              hint              VARCHAR2)
     return RDF_varcharArray as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getPatternVariables(
       java.lang.String,
       java.lang.String) return oracle.sql.STRUCT';

  function SPARQL_get_cols(query varchar2, hint varchar2) return RDF_varcharArray as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getPatternVariables(
       java.lang.String,
       java.lang.String)
  return oracle.sql.STRUCT';

  -- from pvtrdfsa.sql
  -- RDF_APIS_INTERNAL
  procedure w_process_vpd_patterns(
              policy_rid    IN VARCHAR2,
              matchPattern  IN OUT varchar2,
              applyPattern  IN OUT varchar2,
              aliases          RDF_Aliases,
              applyInstr    IN OUT sys.ODCIVarchar2List)
  is language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.processVPDCriteria
                    (java.lang.String, java.lang.String[],
                     java.lang.String[],  oracle.sql.ARRAY,
                     oracle.sql.ARRAY[])';

  -- from sdordfai.sql
  FUNCTION computeCLOBhash(c CLOB) return number deterministic is
  language java name
     'oracle.spatial.rdf.server.SQLEntryPoints.hashCLOB(oracle.sql.CLOB)
    return int';

  procedure expandPattern(antecedentPattern IN OUT varchar2,
                          consequentPattern IN OUT varchar2,
                          aliases                  RDF_Aliases,
                          propIDs              OUT SYS.ODCINumberList,
                          nconsTrips           OUT number,
                          nconsVars            OUT number
                        , network_owner        varchar2
                        , network_name         varchar2)
    is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.expandPattern
                    (java.lang.String[],
                     java.lang.String[],
                     oracle.sql.ARRAY,
                     oracle.sql.ARRAY[],
                     int[],
                     int[],
                     java.lang.String,
                     java.lang.String)';


  PROCEDURE SPARQL_to_SQL(attrs              SYS.ODCINumberList,
                          query              varchar2,
                          models             RDF_Models,
                          precompIdx         varchar2,
                          precompIdxID       number,
                          idxStatus          varchar2,
                          defaultGIDs        SYS.ODCINumberList,
                          namedGIDs          SYS.ODCINumberList,
                          defaultMIDs        SYS.ODCINumberList,
                          defaultModels      MDSYS.RDF_Models,
                          nsp                MDSYS.RDF_Aliases,
                          flag               number,
                          str_out        OUT RDF_longVarcharArray,
                          sig_out        OUT RDF_varcharArray,
                          options            varchar2,
                          vmViewName         varchar2,
                          flag_out       OUT number,
                          valIdCover_out OUT SYS.ODCINumberList,
                          orderBy_out    OUT varchar2,
                          model_types        SYS.ODCINumberList,
                          isRdfVModel        number,
                          networkOwner       varchar2,
                          networkName        varchar2) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int,
       java.lang.String,
       java.lang.String)';

  PROCEDURE SPARQL_get_sources(query             CLOB,
                               nsp               MDSYS.RDF_Aliases,
                               defaultG_out  OUT MDSYS.RDF_GRAPHS,
                               namedG_out    OUT MDSYS.RDF_GRAPHS,
                               options           varchar2) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSources(
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String)';

  -- RDF_APIS_USER
  procedure InferenceCallout(models MDSYS.RDF_Models,
                             rulebases MDSYS.RDF_Rulebases,
                             dest varchar2,
                             optiosn varchar2
                           , network_owner varchar2
                           , network_name varchar2
  ) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.doInference(oracle.sql.ARRAY,
                                                          oracle.sql.ARRAY,
                                                          java.lang.String,
                                                          java.lang.String,
                                                          java.lang.String,
                                                          java.lang.String)';
  procedure UpdateInferenceCallout(models     MDSYS.RDF_Models,
                                   rulebases  MDSYS.RDF_Rulebases,
                                   dest       varchar2,
                                   precompIdx varchar2,
                                   options    varchar2
                                 , network_owner varchar2
                                 , network_name varchar2
  ) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.updateInference
        (oracle.sql.ARRAY,
         oracle.sql.ARRAY,
         java.lang.String,
         java.lang.String,
         java.lang.String,
         java.lang.String,
         java.lang.String)';


  procedure UpdateInferenceCallout(sourceTab  varchar2,
                                   rulebases  MDSYS.RDF_Rulebases,
                                   dest       varchar2,
                                   precompIdx varchar2,
                                   options    varchar2
                                 , network_owner varchar2
                                 , network_name varchar2
  ) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.updateInference
        (java.lang.String,
         oracle.sql.ARRAY,
         java.lang.String,
         java.lang.String,
         java.lang.String,
         java.lang.String,
         java.lang.String)';

  -- from sdordfb.sql
  -- SDO_RDF_INTERNAL body
  PROCEDURE stg_tab_load_ttl(
    stg_tab_name   VARCHAR2
  , stg_tab_owner  VARCHAR2
  , ttl_data       CLOB CHARACTER SET ANY_CS
  , options        VARCHAR2
  ) IS
  LANGUAGE JAVA NAME
   'oracle.spatial.rdf.server.SQLEntryPoints.stgTabInsertTTL(
      java.lang.String,
      java.lang.String,
      oracle.jdbc.OracleClob,
      java.lang.String)';

  -- from sdordfm.sql
  -- RDF_MATCH_impl_t TYPE
  FUNCTION SPARQL_to_PRED(attrs       SYS.ODCINumberList,
                          query       varchar2,
                          models      RDF_Models,
                          precompIdx  varchar2,
                          idxStatus   varchar2,
                          nsp         MDSYS.RDF_Aliases,
                          flag        number)
 return sem_pred_array as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQuerytoPredicates(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       java.lang.String,
       oracle.sql.ARRAY,
       int)
  return oracle.sql.ARRAY';

  PROCEDURE SPARQL_get_sources(query             varchar2,
                               nsp               MDSYS.RDF_Aliases,
                               defaultG_out  OUT MDSYS.RDF_GRAPHS,
                               namedG_out    OUT MDSYS.RDF_GRAPHS,
                               options           varchar2) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSources(
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String)';

  -- from sdordfxb.sql
  -- PACKAGE BODY sdo_rdf
    PROCEDURE apply_update(
    apply_model        IN VARCHAR2
  , apply_model_id     IN NUMBER
  , model_owner        IN VARCHAR2
  , app_tabname        IN VARCHAR2
  , app_colname        IN VARCHAR2
  , update_stmt        IN CLOB
  , match_models       IN MDSYS.RDF_Models
  , precomp_idx        IN VARCHAR2
  , precomp_idx_id     IN NUMBER
  , match_index_status IN VARCHAR2
  , vm_view_name       IN VARCHAR2
  , is_rdf_vw_model    IN NUMBER
  , match_options      IN VARCHAR2
  , options            IN VARCHAR2
  , currentSchema      IN VARCHAR2
  , currentUser        IN VARCHAR2
  , rdfTablespace      IN VARCHAR2
  , ctxFlag            IN NUMBER
  , network_owner      IN VARCHAR2
  , network_name       IN VARCHAR2
  )
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.applyUpdate(
       java.lang.String,
       long,
       java.lang.String,
       java.lang.String,
       java.lang.String,
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       java.lang.String,
       int,
       java.lang.String,
       java.lang.String,
       java.lang.String,
       java.lang.String,
       java.lang.String,
       int,
       java.lang.String,
       java.lang.String
       )';

  PROCEDURE SPARQL_to_SQL(
    attrs              SYS.ODCINumberList
  , Q                  CLOB CHARACTER SET ANY_CS
  , models_in          MDSYS.RDF_Models
  , precompIndexName   VARCHAR2
  , precompIdxID       NUMBER
  , idxStatus          VARCHAR2
  , defaultGIDs        SYS.ODCINumberList
  , namedGIDs          SYS.ODCINumberList
  , defaultMIDs        SYS.ODCINumberList
  , defaultModels      MDSYS.RDF_Models
  , nsp_in             MDSYS.RDF_Aliases
  , flag               NUMBER
  , SQLstrings_out     OUT MDSYS.RDF_longVarcharArray
  , signature_out      OUT MDSYS.RDF_varcharArray
  , options            VARCHAR2
  , vmViewName         VARCHAR2
  , flag_out           OUT NUMBER
  , valIdList_out      OUT SYS.ODCINumberList
  , orderBy_out        OUT VARCHAR2
  , model_types        SYS.ODCINumberList
  , isRdfVModel        NUMBER
  , networkOwner       VARCHAR2
  , networkName        VARCHAR2
  ) IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int,
       java.lang.String,
       java.lang.String)';

  --------------------------- Jena helper functions ------------------------
  -- Needed because of restrictions in ATP-D environment. Regular users   --
  -- cannot create Java stored procedures, so we need to create these     --
  -- at install time as MDSYS.                                            --
  --------------------------------------------------------------------------
  PROCEDURE ORACLE_ORARDF_S2SGETSRC (
    query              varchar2,
    nsp                MDSYS.RDF_Aliases,
    defaultG_out   OUT MDSYS.RDF_GRAPHS,
    sig_out        OUT MDSYS.RDF_GRAPHS)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSources(
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[])';

  PROCEDURE ORACLE_ORARDF_S2SGETSRCCLOB (
    query              clob,
    nsp                MDSYS.RDF_Aliases,
    defaultG_out   OUT MDSYS.RDF_GRAPHS,
    sig_out        OUT MDSYS.RDF_GRAPHS)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSources(
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[])';

  PROCEDURE ORACLE_ORARDF_S2SSVR (
    attrs              SYS.ODCINumberList,
    query              varchar2,
    models             MDSYS.RDF_Models,
    precompIdx         varchar2,
    idxStatus          varchar2,
    nsp                MDSYS.RDF_Aliases,
    flag               number,
    str_out        OUT MDSYS.RDF_longVarcharArray,
    sig_out        OUT MDSYS.RDF_varcharArray,
    options            varchar2,
    vmViewName         varchar2,
    flag_out       OUT number,
    valIdCover_out OUT SYS.ODCINumberList,
    orderBy_out    OUT varchar2)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       java.lang.String,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[])';

  PROCEDURE ORACLE_ORARDF_S2SSVRNG (
    attrs              SYS.ODCINumberList,
    query              varchar2,
    models             MDSYS.RDF_Models,
    precompIdx         varchar2,
    precompIdxID       number,
    idxStatus          varchar2,
    defaultGIDs        SYS.ODCINumberList,
    namedGIDs          SYS.ODCINumberList,
    defaultMIDs        SYS.ODCINumberList,
    defaultModels      MDSYS.RDF_Models,
    nsp                MDSYS.RDF_Aliases,
    flag               number,
    str_out        OUT MDSYS.RDF_longVarcharArray,
    sig_out        OUT MDSYS.RDF_varcharArray,
    options            varchar2,
    vmViewName         varchar2,
    flag_out       OUT number,
    valIdCover_out OUT SYS.ODCINumberList,
    orderBy_out    OUT varchar2,
    model_types        SYS.ODCINumberList,
    isRDFVModel        number,
    networkOwner       varchar2,
    networkName        varchar2)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int,
       java.lang.String,
       java.lang.String)';

  PROCEDURE ORACLE_ORARDF_S2SSVRNGCLOB (
    attrs              SYS.ODCINumberList,
    query              clob,
    models             MDSYS.RDF_Models,
    precompIdx         varchar2,
    precompIdxID       number,
    idxStatus          varchar2,
    defaultGIDs        SYS.ODCINumberList,
    namedGIDs          SYS.ODCINumberList,
    defaultMIDs        SYS.ODCINumberList,
    defaultModels      MDSYS.RDF_Models,
    nsp                MDSYS.RDF_Aliases,
    flag               number,
    str_out        OUT MDSYS.RDF_longVarcharArray,
    sig_out        OUT MDSYS.RDF_varcharArray,
    options            varchar2,
    vmViewName         varchar2,
    flag_out       OUT number,
    valIdCover_out OUT SYS.ODCINumberList,
    orderBy_out    OUT varchar2,
    model_types        SYS.ODCINumberList,
    isRDFVModel        number,
    networkOwner       varchar2,
    networkName        varchar2)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int,
       java.lang.String,
       java.lang.String)';

  PROCEDURE ORACLE_ORARDF_S2SSVRNGNPV (
    attrs              SYS.ODCINumberList,
    query              varchar2,
    models             MDSYS.RDF_Models,
    precompIdx         varchar2,
    precompIdxID       number,
    idxStatus          varchar2,
    defaultGIDs        SYS.ODCINumberList,
    namedGIDs          SYS.ODCINumberList,
    defaultMIDs        SYS.ODCINumberList,
    defaultModels      MDSYS.RDF_Models,
    nsp                MDSYS.RDF_Aliases,
    flag               number,
    str_out        OUT MDSYS.RDF_longVarcharArray,
    sig_out        OUT MDSYS.RDF_varcharArray,
    options            varchar2,
    vmViewName         varchar2,
    flag_out       OUT number,
    valIdCover_out OUT SYS.ODCINumberList,
    orderBy_out    OUT varchar2,
    model_types        SYS.ODCINumberList,
    isRDFVModel        number)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int)';

  PROCEDURE ORACLE_ORARDF_S2SSVRNGCLOBNPV (
    attrs              SYS.ODCINumberList,
    query              clob,
    models             MDSYS.RDF_Models,
    precompIdx         varchar2,
    precompIdxID       number,
    idxStatus          varchar2,
    defaultGIDs        SYS.ODCINumberList,
    namedGIDs          SYS.ODCINumberList,
    defaultMIDs        SYS.ODCINumberList,
    defaultModels      MDSYS.RDF_Models,
    nsp                MDSYS.RDF_Aliases,
    flag               number,
    str_out        OUT MDSYS.RDF_longVarcharArray,
    sig_out        OUT MDSYS.RDF_varcharArray,
    options            varchar2,
    vmViewName         varchar2,
    flag_out       OUT number,
    valIdCover_out OUT SYS.ODCINumberList,
    orderBy_out    OUT varchar2,
    model_types        SYS.ODCINumberList,
    isRDFVModel        number)
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       oracle.jdbc.OracleClob,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int)';

  FUNCTION ORACLE_ORARDF_SGC (
    query varchar2)
  RETURN MDSYS.RDF_varcharArray
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getPatternVariables(
       java.lang.String)
     return oracle.sql.STRUCT';

  FUNCTION ORACLE_ORARDF_SGCCLOB (
    query clob)
  RETURN MDSYS.RDF_varcharArray
  IS
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getPatternVariables(
       oracle.jdbc.OracleClob)
     return oracle.sql.STRUCT';

  -------------------- End Jena Helper Functions ---------------------------

END sdo_rdf_java_stp;
/

