create function       SDO_Aggr_MBR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
82 aa
ru7MSH8RmWDnFT+3TZPl97ng9vYwg3nwqNNqfHQ2bU6er0DSHenyzwgR1Kfa8XSsdGr4qlDs
W7nRtIweHCWJeg2vsYGkMgMXYArDt0/57D9mFf8yqGWieO30iS9LxcUcwusH8Aw1iGkZnm//
McitZ1Xpgi75ZBnQLNb/FKE=
/

