create FUNCTION sdo_multicurve2d return NUMBER is
 BEGIN
 return 2006;
 END sdo_multicurve2d;
/

