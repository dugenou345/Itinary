create type sem_rule wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
f4 eb
G7gufkpZ0f7WbPy/46sb2K5DNPYwgzLwLcvWfHSi2k6UHPR3+y2fZfSZw9v0dlv09PTw0TuS
tY0O9ScgEP659Rg2ckMiJIce4XXKIXjCngH7pvP3Kq9Boj9K5khg827/2rvnVaoio2CuLCJR
tMtj0R7lZf0zXf3TU8lhg1tAykoUQ+iyVxQWgG3R5xLgAkGdvPuo1xUFa103P0jeWsUAxIA6
S5nHre37yw0ARA==
/

