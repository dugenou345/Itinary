create package sdo_sem_inference authid current_user as

  INF_EXT_ACTION_START constant varchar2(100) := 'START';   -- prepare phase
  INF_EXT_ACTION_RUN   constant varchar2(100) := 'RUN';     -- action phase
  INF_EXT_ACTION_END   constant varchar2(100) := 'END';     -- cleanup phase


  -- INF_EXT_OPT_FLAG_NONE means that there is no optimization
  INF_EXT_OPT_FLAG_NONE          constant integer := 0;
  -- INF_EXT_OPT_FLAG_ALL_IDS means that the output table contains only ID based triples/quads
  INF_EXT_OPT_FLAG_ALL_IDS       constant integer := 1;
  -- INF_EXT_OPT_FLAG_ALL_IDS means that the output table contains only new triples/quads
  INF_EXT_OPT_FLAG_NEWDATA_ONLY  constant integer := 2;
  -- INF_EXT_OPT_FLAG_ALL_IDS means that the output table contains only distinct triples/quads
  INF_EXT_OPT_FLAG_UNIQDATA_ONLY constant integer := 4;
  -- INF_EXT_OPT_FLAG_IGNORE_NULL means triples with null values for s, p, or o should be ignored
  INF_EXT_OPT_FLAG_IGNORE_NULL   constant integer := 8;

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE copy_network_info_to_pkg_vars;
  procedure create_rules_index(index_name_in          varchar2,
                               models_in              mdsys.rdf_models,
                               rulebases_in           mdsys.rdf_rulebases,
                               passes                 integer  default 0,
                               inf_components_in      varchar2 default null,
                               options                varchar2 default null,
                               delta_in               mdsys.rdf_models default null,
                               ng_tab_name            varchar2,
                               ng_tab_schema          varchar2 default null,
                               inf_ng_name            varchar2 default null,
                               inf_ext_user_func_name varchar2 default null,
                               ols_ladder_inf_lbl_seq varchar2 default null -- A string a numeric labels
                                                                            -- delimited by a space
                               );


  -- router version
  procedure create_rules_index(index_name_in           varchar2,
                               models_in               mdsys.rdf_models,
                               rulebases_in            mdsys.rdf_rulebases,
                               passes                  integer  default 0,
                               inf_components_in       varchar2 default null,
                               options                 varchar2 default null,
                               delta_in                mdsys.rdf_models default null,
                               include_named_g         sem_graphs       default null,
                               include_default_g       mdsys.rdf_models default null,
                               include_all_g           mdsys.rdf_models default null,
                               inf_ng_name             varchar2         default null,
                               inf_ext_user_func_name  varchar2         default null,
                               ols_ladder_inf_lbl_seq  varchar2 default null -- A string a numeric labels
                                                                             -- delimited by a space
                               );

  -- PR stub version
  procedure create_rules_index_PR(index_name_in           varchar2,
                               models_in               mdsys.rdf_models,
                               rulebases_in            mdsys.rdf_rulebases,
                               passes                  integer  default 0,
                               inf_components_in       varchar2 default null,
                               options                 varchar2 default null,
                               delta_in                mdsys.rdf_models default null,
                               include_named_g         sem_graphs       default null,
                               include_default_g       mdsys.rdf_models default null,
                               include_all_g           mdsys.rdf_models default null,
                               inf_ng_name             varchar2         default null,
                               inf_ext_user_func_name  varchar2         default null,
                               ols_ladder_inf_lbl_seq  varchar2 default null -- A string a numeric labels
                                                                             -- delimited by a space
                             , p_network_owner         varchar2 default NULL
                             , p_network_name          varchar2 default NULL
                               );
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_rules_index_PR, AUTO_WITH_COMMIT);

  -- worker version
  procedure w_create_rules_index(index_name_in          varchar2,
                               models_in              mdsys.rdf_models,
                               rulebases_in           mdsys.rdf_rulebases,
                               passes                 integer  default 0,
                               inf_components_in      varchar2 default null,
                               options                varchar2 default null,
                               delta_in               mdsys.rdf_models default null,
                               include_named_g        sem_graphs default null,
                               include_default_g      mdsys.rdf_models default null,
                               include_all_g          mdsys.rdf_models default null,
                               inf_ng_name            varchar2 default null,
                               inf_ext_user_func_name varchar2 default null,
                               ols_ladder_inf_lbl_seq varchar2 default null -- A string a numeric labels
                                                                            -- delimited by a space
                               );

  -- oracle_orardf_res2vid translates an RDF resource to
  -- its internal integer ID
  -- Note that a blank Node must has a string value that starts with _:
  -- And a literal RDF resource must start with a double quote.
  -- The rest of RDF resources will be treated as URIs.
  function oracle_orardf_res2vid(res in varchar2,
                                  lt in varchar2 default null,
                                lang in varchar2 default null) return number
      deterministic parallel_enable  -- result_cache
      ;

  function oracle_orardf_add_res(res in varchar2,
                                 lt in varchar2 default null,
                               lang in varchar2 default null) return number
      deterministic parallel_enable  -- result_cache
      ;

  -- This function will extract a delta view name
  -- from the src_tab_view argument.
  -- For example, if the src_tab_view is something like
  -- 'MDSYS.RDF#4#SV /* MDSYS.RDF#4#DV */'
  -- a string value of MDSYS.RDF#4#DV will be returned.
  -- This function will return NULL if there is no
  -- delta view embedded
  function extract_delta_view_name(src_tab_view in varchar2)
    return varchar2
      ;


  --
  -- This method extracts the entaliment ID information from
  -- the inf_ext_options that is passed into a user's inference
  -- extension function.
  -- A NULL value will be returned if the inf_ext_options
  -- is using an unexpected syntax.
  --
  function extract_entailment_id(inf_ext_options in varchar2)
    return number
      ;

  --
  -- This method extracts the entaliment signature from
  -- the inf_ext_options that is passed into a user's inference
  -- extension function.
  -- A NULL value will be returned if the inf_ext_options
  -- is using an unexpected syntax.
  --
  function extract_entailment_sig(inf_ext_options in varchar2)
    return varchar2
      ;

  -- Returns a lexical form of the given RDF resource ID
  -- If the resource ID does not exist in MDSYS.RDF_VALUE$,
  -- then a NULL value will be returned.
  function oracle_orardf_vid2lex(vid in number) return varchar2
      deterministic parallel_enable -- result_cache
      ;

  -- Returns a lexical form of the given RDF resource ID
  -- If the resource ID does not exist or it is not representing
  -- a URI, then a NULL value will be returned.
  function oracle_orardf_vid2uri(vid in number) return varchar2
      deterministic parallel_enable -- result_cache
      ;

  -- Returns a lexical form (without leading and trailing double quotes)
  -- of the given RDF resource ID
  -- If the resource ID does not exist or it is not representing
  -- a literal, then a NULL value will be returned.
  function oracle_orardf_vid2lit(vid in number) return varchar2
      deterministic parallel_enable -- result_cache
      ;

  -- Returns a lexical form (without leading and trailing double quotes)
  -- of the given RDF resource ID
  -- If the resource ID does not exist or it is not representing
  -- a blank node, then a NULL value will be returned.
  function oracle_orardf_vid2bnode(vid in number) return varchar2
      deterministic parallel_enable -- result_cache
      ;


  -- Returns a lexical form of the given RDF resource ID
  -- If the resource ID does not exist in MDSYS.RDF_VALUE$,
  -- then a NULL value will be returned.
  procedure oracle_orardf_vid2lex(vid   in number
                                , res  out varchar2
                                , lt   out varchar2
                                , lang out varchar2)
      deterministic parallel_enable
      ;


  --
  -- A few internal string manipulation helper functions
  --
  function extract_fname(v varchar2) return varchar2;
  function extract_uname(v varchar2) return varchar2;
  function extract_callout_func_names(vcInfExtUserFuncNames varchar2)
    return mdsys.rdf_longVarcharArray;
  function extract_labels(vcLabelString varchar2)
    return mdsys.rdf_longVarcharArray;

  procedure enforce_definer( vcUser varchar2
                           , vcSpecifiedUser varchar2
                           , infExtUserFuncName varchar2);

  function is_user_label(nLabel number) return boolean;
  procedure set_label(nLabel number);
  procedure set_label_wrapper(nLabel number);
  procedure set_row_label_wrapper(nLabel number);
  function numeric_label_wrapper(policy_name in varchar2) return number;
  function numeric_row_label_wrapper(policy_name in varchar2) return number;

  --
  -- Print the execution plan for last SQL Statement using DBMS_OUTPUT
  --
  procedure print_plan(nStartTime number default null, vcLineStart varchar2 default null);
 end;
/

