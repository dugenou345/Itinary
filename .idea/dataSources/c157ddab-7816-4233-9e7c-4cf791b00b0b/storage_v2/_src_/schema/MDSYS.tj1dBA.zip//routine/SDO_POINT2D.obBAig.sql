create FUNCTION sdo_point2d return NUMBER is
  BEGIN
  return 2001;
  END sdo_point2d;
/

