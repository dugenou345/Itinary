create type       WfscomplexType as object ( ns varchar2(30), name varchar2(30))
  alter type       WfscomplexType modify attribute ( ns varchar2(128), name varchar2(128) ) cascade including table data
/

