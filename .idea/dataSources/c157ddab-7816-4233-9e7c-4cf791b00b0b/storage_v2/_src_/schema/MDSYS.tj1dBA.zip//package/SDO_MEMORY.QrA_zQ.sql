create PACKAGE       sdo_memory wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
c0 ce
LAt0ti+9Tetm2ykBy0AnOpjqVGgwgxDZ2ssVZ3RGOPxuFWxaaMo9EbEUFvjxsbppvjdlGI7F
SK6ms2lQ//6uNxN8fFVkbdfEQpMsRuiGMbf2Zm53owGod+LvxayorCfVbLhoL6/mHEeELf7P
5pkjGom2LJKuT6T4G1lcqCf3C6dtvvdV0ra4m7XO7RDW3TA6nym/rt+JggU=
/

