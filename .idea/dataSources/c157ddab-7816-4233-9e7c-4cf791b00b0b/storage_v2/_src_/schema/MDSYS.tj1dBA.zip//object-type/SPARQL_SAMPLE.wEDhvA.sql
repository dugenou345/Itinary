create TYPE SPARQL_Sample authid current_user AS OBJECT(

curr_val      MDSYS.SDO_RDF_TERM,

STATIC FUNCTION ODCIAggregateInitialize(
        sctx IN OUT SPARQL_Sample)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateIterate(
         self       IN OUT SPARQL_Sample
       , value      IN MDSYS.SDO_RDF_TERM)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateMerge(
        self IN OUT SPARQL_Sample
       ,ctx2 IN SPARQL_Sample)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateTerminate (
        self IN SPARQL_Sample
       ,return_value OUT MDSYS.SDO_RDF_TERM
       ,flags IN NUMBER)
RETURN NUMBER
);
/

