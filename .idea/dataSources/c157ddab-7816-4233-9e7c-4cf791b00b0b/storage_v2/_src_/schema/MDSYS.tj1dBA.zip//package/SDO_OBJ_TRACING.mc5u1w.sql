create PACKAGE       SDO_OBJ_TRACING AUTHID current_user AS
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

 FUNCTION multipoint_from_points (point_cursor SYS_REFCURSOR)
  RETURN SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

 ----------------------------------------------------------------------------------------------------
 -- Function get_all_durations - Performs GPS based contact tracing
 ----------------------------------------------------------------------------------------------------
 FUNCTION get_all_durations (
  user_id                      NUMBER,
  start_time                   DATE,
  end_time                     DATE,
  distance                     NUMBER,
  time_tolerance_in_sec        NUMBER  := 5,
  chaining_tolerance_in_sec    NUMBER  := 60,
  track_table_name             VARCHAR2,
  geom_column_name             VARCHAR2,
  user_id_column_name          VARCHAR2,
  time_column_name             VARCHAR2,
  date_as_number_column_name   VARCHAR2,
  accuracy_column_name         VARCHAR2 := NULL,          -- optional
  accuracy_filter_value        NUMBER   := NULL,          -- optional
  must_match_columns           SDO_STRING_ARRAY := NULL)  -- optional
    RETURN MDSYS.DURATION_TABLE_TYPE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION next_time (user_id              NUMBER,
                      current_time         DATE,
                      max_time_range_value DATE,
                      table_name           VARCHAR2,
                      time_col_name        VARCHAR2,
                      user_id_col_name     VARCHAR2)
          RETURN DATE PARALLEL_ENABLE;

  FUNCTION previous_time (user_id              NUMBER,
                          current_time         DATE,
                          min_time_range_value DATE,
                          table_name           VARCHAR2,
                          time_col_name        VARCHAR2,
                          user_id_col_name     VARCHAR2)
        RETURN DATE PARALLEL_ENABLE;

  ----------------------------------------------------------------------------------------------------
  -- Function get_all_swipe_io_durations - Performs swipe in/out contact tracing
  ----------------------------------------------------------------------------------------------------
  FUNCTION get_all_swipe_io_durations (
    user_id                      NUMBER,
    start_time                   DATE,
    end_time                     DATE,
    track_table_name             VARCHAR2,
    user_id_column_name          VARCHAR2,
    building_id_column_name      VARCHAR2,
    floor_id_column_name         VARCHAR2 := NULL,          -- optional
    room_id_column_name          VARCHAR2 := NULL,          -- optional
    swipe_io_column_name         VARCHAR2,
    time_column_name             VARCHAR2,
    must_match_columns           SDO_STRING_ARRAY := NULL,  -- optional
    search_cutoff_time_in_sec    NUMBER  := NULL)           -- optional
      RETURN MDSYS.SWIPE_IO_DURATION_TABLE_TYPE DETERMINISTIC PARALLEL_ENABLE;

END SDO_OBJ_TRACING;
/

