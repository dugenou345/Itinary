create package sdo_sem_utl AUTHID CURRENT_USER as

  -- Constants for default namespaces and aliases
  RDF_ALIAS     CONSTANT VARCHAR2(3) := 'rdf';
  RDFS_ALIAS    CONSTANT VARCHAR2(4) := 'rdfs';
  XSD_ALIAS     CONSTANT VARCHAR2(3) := 'xsd';
  OWL_ALIAS     CONSTANT VARCHAR2(3) := 'owl';
  DC_ALIAS      CONSTANT VARCHAR2(2) := 'dc';
  DCTERMS_ALIAS CONSTANT VARCHAR2(7) := 'dcterms';
  ORARDF_ALIAS  CONSTANT VARCHAR2(6) := 'orardf';

  RDF_NS     CONSTANT VARCHAR2(43) := 'http://www.w3.org/1999/02/22-rdf-syntax-ns#';
  RDFS_NS    CONSTANT VARCHAR2(37) := 'http://www.w3.org/2000/01/rdf-schema#';
  XSD_NS     CONSTANT VARCHAR2(33) := 'http://www.w3.org/2001/XMLSchema#';
  OWL_NS     CONSTANT VARCHAR2(30) := 'http://www.w3.org/2002/07/owl#';
  DC_NS      CONSTANT VARCHAR2(32) := 'http://purl.org/dc/elements/1.1/';
  DCTERMS_NS CONSTANT VARCHAR2(25) := 'http://purl.org/dc/terms/';
  ORARDF_NS  CONSTANT VARCHAR2(28) := 'http://xmlns.oracle.com/rdf/';

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  function getIdSco return number;
  function getIdType return number;
  function getIdComp return number;
  function getIdDisj return number;
  function getIdEquc return number;
  function getIdEqup return number;
  function getIdIo return number;
  function getIdSam return number;
  function getIdDif return number;
  function getIdDom return number;
  function getIdRan return number;
  function getIdSpo return number;
  function getIdTP return number;
  function getIdFP return number;
  function getIdSymP return number;
  function getIdIFP return number;
  function getIdCMP return number;
  function getIdMbr return number;

  function getIdPropDisj return number;
  function getIdSkosxlLabel return number;
  function getIdSkosxlLiteralForm return number;

  function getIdNPA return number;
  function getIdSrcInd return number;
  function getIdAssPro return number;
  function getIdTgtInd return number;
  function getIdTgtVal return number;

  function getIdMaxQCard return number;
  function getIdMaxCard return number;
  function getId0Int return number;
  function getIdIrreflexiveProperty return number;
  function getIdAsymmetricProperty return number;
  function getIdOP return number;
  function getIdOC return number;
  function getIdThing return number;

  function getIdNothing return number;

  procedure setInferTmpTabName(v varchar2);
  PROCEDURE copy_network_info_to_pkg_vars;

  /**
   * Computes the expected length needed for the
   * non-value_name portion of an RDF term
   */
  function computeNonVnLen(lang   varchar2,
                           ltype  varchar2)
  return number;

  /**
   * Computes the expected length of an RDF term with
   * these components.
   */
  function computeTermLen(vnameLen number,
                          lang     varchar2,
                          ltype    varchar2)
  return number;

  /**
   * Shortens a long literal while taking into account
   * literal type and language information so that the
   * resulting full RDF term is exactly 4K in length.
   */
  function shortenClobToVc(vname clob,
                           lang  varchar2,
                           ltype varchar2)
  return varchar2;

  /**
   * Shortens a varchar literal while taking into account
   * literal type and language information so that the
   * resulting full RDF term is exactly 4K in length.
   */
  function shortenVc(vname varchar2,
                     lang  varchar2,
                     ltype varchar2)
  return varchar2;

  /**
   * Converts a number list into a VARCHAR2 string for an
   * IN LIST containing the numbers. IN keyword is not included
   * only a list of numbers and enclosing parenthesis.
   */
  function numToInList(numList SYS.ODCINumberList)
  return varchar2;

  /**
   * Returns true if filter f is safe w.r.t. SQL injection
   */
  function isSafeFilter(f varchar2)
  return boolean;

  /**
   * Adjusts a timestamp value based on the given prefix
   * '+' add 1 day
   * '-' subtract 1 day
   * '@' no adjustment
   */
  function adjTsForPrefix(ts timestamp, prefix varchar2)
  return timestamp deterministic;
  pragma restrict_references (adjTsForPrefix,WNDS,RNDS,WNPS,RNPS);

  /**
   * Adjusts a timestamp with time zone value based on the given prefix
   * '+' add 1 day
   * '-' subtract 1 day
   * '@' no adjustment
   */
  function adjTsTzForPrefix(ts timestamp with time zone, prefix varchar2)
  return timestamp with time zone deterministic;
  pragma restrict_references (adjTsTzForPrefix,WNDS,RNDS,WNPS,RNPS);

  /**
   * Returns true if numList contains num, false otherwise
   * NOTE: it is ok for numList to be null
   */
  function numberListContains(numList SYS.ODCINumberList, num number)
  return boolean;

  /**
   * Returns the collection type from an AnyType type definition.
   */
  function getCollectionElementType(typ SYS.AnyType)
  return SYS.AnyType;

  /**
   * Expands the list of graph names based on the input
   * namespace prefixes.
   */
  function expandGraphNames (graphs  MDSYS.RDF_Graphs,
                             aliases MDSYS.RDF_Aliases)
  return MDSYS.RDF_Graphs;


  /**
   * Builds a meaningful error message from a java exception
   * and raises a SQL error
   */
  procedure raiseJavaQueryError(errm VARCHAR2);

  function get_sub_hint return varchar2;
  procedure set_sub_hint_aj;
  procedure set_sub_hint_empty;
  procedure set_sub_hint_aj_no_push_pred;

  function init_already return boolean;
  function get_all_property_id return sys.odciNumberList;

  /**
   * If returns NULL, it means that MDSYS has no privilege to read
   */
  function get_session_parallel_query_dop return number;


  /**
   * If returns NULL, it means that MDSYS has no privilege to read
   */
  function get_session_parallel_dml_dop return number;


  /**
   * This method returns TRUE if there is at least one user
   * defined rule in one of the rulebase specified by the list
   * of input rulebase IDs.
   *
   * NOTE: it is ok for @param nlRulbaseIDs to be NULL.
   */
  function checkUserRules(nlRulbaseIDs sys.ODCINumberList) return boolean;

  /**
   * This method returns TRUE if vcPtnName partition exists in table
   * vcTableName. It is done here since we need to check against
   * MDSYS' user_tab_partitions.
   */
  function check_partition_exists(vcTableName in varchar2,
                                 vcPtnName   in varchar2) return boolean;

  function check_table_exists(vcTableName in varchar2) return boolean;

  PROCEDURE W_enable_all_triggers( user_name   IN  varchar2,
                                   apptab_name IN  varchar2);

  PROCEDURE enable_all_triggers( user_name   IN  varchar2,
                                 apptab_name IN  varchar2);

  PROCEDURE W_run_dml_stmt_merge(model_to_id     number,
                         stmt_name  varchar2,
                         dump_plan  boolean default false,
                         parallel   int default 1);

  PROCEDURE run_dml_stmt_merge(model_to_id     number,
                         stmt_name  varchar2,
                         dump_plan  boolean default false,
                         parallel   int     default 1);


  PROCEDURE W_disable_all_triggers(user_name   IN  varchar2,
                                   apptab_name IN  varchar2);

  PROCEDURE disable_all_triggers(user_name   IN  varchar2,
                                 apptab_name IN  varchar2);

  function get_parameter(vcOptions in varchar2,
                            vcMark in varchar2,
                             vcEnd in varchar2 default null) return varchar2;

  function get_string_parameter(vcOptions in varchar2,
                                   vcMark in varchar2,
                                    vcEnd in varchar2 default null) return varchar2;

  function get_int_parameter(vcOptions in varchar2,
                                vcMark in varchar2) return int;


--  function build_models_union_clause(models            mdsys.rdf_models,
--                                     bJustModels       boolean,
--                                     bProof            boolean,
--                                     vcRuleIdxPartView varchar2,
--                                     bForceUsePCSMIdx  boolean) return varchar2;

  /* MERGE MODELS HELPER FUNCTIONS - these need to be ran as MDSYS */
  PROCEDURE w_merge_models_swap_tmp_merge(tbs_name varchar2,
                                  model_to_id      number,
                                  tmp_tab_name     varchar2,
                                  parallel         number);

  PROCEDURE merge_models_swap_tmp_merge_to(tbs_name varchar2,
                                model_to_id      number,
                                tmp_tab_name     varchar2,
                                parallel         number);

  FUNCTION W_merge_models_create_tmp_tab(tbs_name varchar2,
                                  model_from_id    number,
                                  model_to_id      number,
                                  merge_to_count   number,
                                  merge_from_count number,
                                  user_name        varchar2,
                                  tmp_tab_count    IN OUT number,
                                  parallel         number,
                                  options          IN varchar2,
                                  NLTH             number,
                                  model_from_table IN varchar2 default null)
                                  RETURN varchar2;

  FUNCTION merge_models_create_tmp_tab(tbs_name varchar2,
                                model_from_id    number,
                                model_to_id      number,
                                merge_to_count   number,
                                merge_from_count number,
                                user_name        varchar2,
                                tmp_tab_count    IN OUT number,
                                parallel         number,
                                options          IN varchar2,
                                NLTH             number,
                                model_from_table IN varchar2 default null)
                                RETURN varchar2;

  PROCEDURE W_merge_models_update_linktab(tbs_name IN varchar2,
                                  merge_from_model IN varchar2,
                                  merge_to_model   IN varchar2,
                                  model_to_id      IN number,
                                  merge_to_count   IN number,
                                  tmp_tab_Name     IN varchar2,
                                  tmp_tab_count    IN number,
                                  parallel         IN number,
                                  ITH              IN number,
                                  merge_from_table IN varchar2 default null,
                                  user_name        IN varchar2 default null
                                 );

  PROCEDURE merge_models_update_linktab(tbs_name IN varchar2,
                                merge_from_model IN varchar2,
                                merge_to_model   IN varchar2,
                                model_to_id      IN number,
                                merge_to_count   IN number,
                                tmp_tab_Name     IN varchar2,
                                tmp_tab_count    IN number,
                                parallel         IN number,
                                ITH              IN number,
                                merge_from_table IN varchar2 default null,
                                user_name        IN varchar2 default null
                               );
   /* END MERGE MODELS HELPER FUNCTIONS */


   GET_STATS constant varchar2(1000) := '
    select name, value from (
      select ''stat.. '' || n.name name, t.value  value
        from v$mystat   t join v$statname n on t.statistic# = n.statistic#
       where n.name in (''redo size'', ''db block gets'', ''consistent gets'',
                        ''physical reads'',''sorts (memory)'',''sorts (disk)'',
                        ''recursive calls'',''redo write time'',
                        ''physical writes'',''rows processed'',
                        ''bytes sent via SQL*Net to client'',
                        ''bytes received via SQL*Net from client'',
                        ''SQL*Net roundtrips to/from client'')
          or (n.name like ''%ga %'')
          or (n.name like ''%direct temp%'')
    union all
      select ''latch. '' || n.name name, n.gets  value
        from v$latch n
       where n.name in (''library cache pin'', ''library cache pin allocation'',
                        ''library cache'', ''shared pool'')
     )
     order by name
  ';


  -- v$sesstat does not help much
  GET_STATS_NEW constant varchar2(1000) := '
    select name, value from (
      select ''stat.. '' || n.name name, t.value  value
        from v$sesstat   t join v$statname n on t.statistic# = n.statistic#
       where t.sid = sys_context(''userenv'',''sid'')  and
          (n.name in (''redo size'', ''db block gets'', ''consistent gets'',
                        ''physical reads'',''sorts (memory)'',''sorts (disk)'',
                        ''recursive calls'',''redo write time'',
                        ''physical writes'',''rows processed'',
                        ''bytes sent via SQL*Net to client'',
                        ''bytes received via SQL*Net from client'',
                        ''SQL*Net roundtrips to/from client'')
          or (n.name like ''%ga %'')
          or (n.name like ''%direct temp%''))
    union all
      select ''latch. '' || n.name name, n.gets  value
        from v$latch n
       where n.name in (''library cache pin'', ''library cache pin allocation'',
                        ''library cache'', ''shared pool'')
     )
     order by name
  ';


  /**
   * Will collect statistics for table m_vcInferTmpTabName.
   */
  procedure W_collect_stats;
  procedure collect_stats;

  procedure exe_plan_prepare;
  procedure exe_plan_dump;

  function get_elapsed_time_in_sec(nStart number) return varchar2;
  function bool_to_str(b in boolean) return varchar2;


  procedure set_proof(b boolean);
  procedure set_anc(b boolean);
  function get_proof return boolean;
  function get_anc return boolean;

  /**
   * Note only model owner (or sys dba) is allowed to perform this action.
   * All information in the existing application table will be lost.
   * 'Triple' column will be reconstructed.
   */
  PROCEDURE W_remove_duplicates(model_name  in VARCHAR2,
                        model_id    in NUMBER,
                        apptab_name in VARCHAR2,
                        tbs_name    in VARCHAR2,
                        col_name    in VARCHAR2,
                        user_name   in VARCHAR2,
                        phase       in INTEGER,
                        owner_id  in out NUMBER,
                        table_id  in out NUMBER);

  PROCEDURE remove_duplicates(model_name  in VARCHAR2,
                        model_id    in NUMBER,
                        apptab_name in VARCHAR2,
                        tbs_name    in VARCHAR2,
                        col_name    in VARCHAR2,
                        user_name   in VARCHAR2,
                        phase       in INTEGER,
                        owner_id  in out NUMBER,
                        table_id  in out NUMBER);

  /**
   * Get the value of the iPos'th number out from
   * the given string that is delimited by a single space ' '
   *
   * @param iPos MUST be a positive integer.
   */
  function get_number_in_pos(vcVal in varchar2,
                             iPos  in int ) return number;

  function get_uri(vid number) return varchar2;
  function convert_mapped2raw(i int) return varchar2;
  function wrap_raw_col2num(vcRawColName varchar2) return varchar2;
  function wrap_num_col2raw(vcNumColName varchar2) return varchar2;
  function use_raw return boolean;

  FUNCTION get_value_type (value IN OUT varchar2) return varchar2;

  function get_safe_rowcount(cnt int) return int;

  procedure set_use_prh(b boolean);
  procedure set_use_raw8(b boolean);
  function extract_marker(vcStmt varchar2) return varchar2;

--  function run_ddl_stmt(iRnd int,
--                        vcStmt varchar2,
--                        bPerfTuning boolean default false) return int;
  procedure set_start_time(n number);

  function get_columnar_compress_syn return varchar2;


  PROCEDURE W_export_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  PROCEDURE export_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  PROCEDURE W_import_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );

  procedure import_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure W_export_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  procedure export_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );


  procedure W_import_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );

  procedure import_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  PROCEDURE W_set_model_stats (
   model_name    VARCHAR2,
   numrows       NUMBER    DEFAULT NULL,
   numblks       NUMBER    DEFAULT NULL,
   avgrlen       NUMBER    DEFAULT NULL,
   flags         NUMBER    DEFAULT NULL,
   no_invalidate BOOLEAN   DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk     NUMBER    DEFAULT NULL,
   cachehit      NUMBER    DEFAULT NULL,
   force         BOOLEAN   DEFAULT FALSE
  );

  PROCEDURE set_model_stats (
   model_name    VARCHAR2,
   numrows       NUMBER    DEFAULT NULL,
   numblks       NUMBER    DEFAULT NULL,
   avgrlen       NUMBER    DEFAULT NULL,
   flags         NUMBER    DEFAULT NULL,
   no_invalidate BOOLEAN   DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk     NUMBER    DEFAULT NULL,
   cachehit      NUMBER    DEFAULT NULL,
   force         BOOLEAN   DEFAULT FALSE
  );


  PROCEDURE W_set_entailment_stats (
   entailment_name  VARCHAR2,
   numrows          NUMBER   DEFAULT NULL,
   numblks          NUMBER   DEFAULT NULL,
   avgrlen          NUMBER   DEFAULT NULL,
   flags            NUMBER   DEFAULT NULL,
   no_invalidate    BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk        NUMBER   DEFAULT NULL,
   cachehit         NUMBER   DEFAULT NULL,
   force            BOOLEAN  DEFAULT FALSE
  );

  PROCEDURE set_entailment_stats (
   entailment_name  VARCHAR2,
   numrows          NUMBER   DEFAULT NULL,
   numblks          NUMBER   DEFAULT NULL,
   avgrlen          NUMBER   DEFAULT NULL,
   flags            NUMBER   DEFAULT NULL,
   no_invalidate    BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk        NUMBER   DEFAULT NULL,
   cachehit         NUMBER   DEFAULT NULL,
   force            BOOLEAN  DEFAULT FALSE
  );

  procedure W_delete_network_stats(
    cascade_parts    IN BOOLEAN  DEFAULT TRUE,
    cascade_columns  IN BOOLEAN  DEFAULT TRUE,
    cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
    no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    force            IN BOOLEAN  DEFAULT FALSE,
    options          IN VARCHAR2 DEFAULT NULL
  )
  ;

  procedure delete_network_stats(
    cascade_parts    IN BOOLEAN  DEFAULT TRUE,
    cascade_columns  IN BOOLEAN  DEFAULT TRUE,
    cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
    no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    force            IN BOOLEAN  DEFAULT FALSE,
    options          IN VARCHAR2 DEFAULT NULL
  )
  ;

  procedure W_export_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
  );

  procedure export_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
  );

  procedure W_import_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
  );

  procedure import_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
  );

end;
/

