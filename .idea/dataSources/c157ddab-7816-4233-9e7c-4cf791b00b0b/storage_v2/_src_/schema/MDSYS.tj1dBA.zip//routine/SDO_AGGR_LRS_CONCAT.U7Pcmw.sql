create function       SDO_Aggr_LRS_Concat wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
ad be
0Ky8vQ/CDrxk+4Ad9qfmClTv3C0wgwJKLcsVfHSiWPiUHDjuW3VmxlT3414x/8g+5nRVZ+Zz
qvfRAYp5sOuYmBKU0sM2Vqccp0MFLCekJLuxxwBbyWzL3Flst/bWvUqJjCqYSmGyM9/rAXzy
h1z5k5qZ763e3PFHttz4ysMMFUs6CFttcKUFKVuBWNWb
/

