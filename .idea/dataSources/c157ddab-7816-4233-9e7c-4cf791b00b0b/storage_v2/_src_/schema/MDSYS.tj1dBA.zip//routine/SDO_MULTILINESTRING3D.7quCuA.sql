create FUNCTION sdo_multilinestring3d return NUMBER is
 BEGIN
 return 3006;
 END sdo_multilinestring3d;
/

