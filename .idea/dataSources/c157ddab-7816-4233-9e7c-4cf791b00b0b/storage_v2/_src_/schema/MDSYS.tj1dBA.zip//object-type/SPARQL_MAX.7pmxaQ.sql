create TYPE SPARQL_max authid current_user AS OBJECT(

curr_max      NUMBER,
curr_val      MDSYS.SDO_RDF_TERM,

STATIC FUNCTION ODCIAggregateInitialize(
        sctx IN OUT SPARQL_max)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateIterate(
         self       IN OUT SPARQL_max
       , value      IN MDSYS.SDO_RDF_TERM)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateMerge(
        self IN OUT SPARQL_max
       ,ctx2 IN SPARQL_max)
RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateTerminate (
        self IN SPARQL_max
       ,return_value OUT MDSYS.SDO_RDF_TERM
       ,flags IN NUMBER)
RETURN NUMBER
);
/

