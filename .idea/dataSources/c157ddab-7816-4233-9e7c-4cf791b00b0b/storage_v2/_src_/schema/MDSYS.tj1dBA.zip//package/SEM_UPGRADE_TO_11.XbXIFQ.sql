create PACKAGE sem_upgrade_to_11 AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE unload_all_into_staging_tables(downgrade BOOLEAN DEFAULT FALSE);
  PROCEDURE empty_app_tabs_drop_RDF_cols(downgrade BOOLEAN DEFAULT FALSE);

  PROCEDURE setup_for_loading_in_11;
  PROCEDURE create_all_models_in_11;
  PROCEDURE load_from_all_staging_tables(user_name VARCHAR2);

  PROCEDURE save_10_2_RDF_network_for_11(user_name varchar2);
  PROCEDURE restore_10_2_RDF_network_in_11(
    user_name VARCHAR2
  );
END sem_upgrade_to_11;
/

