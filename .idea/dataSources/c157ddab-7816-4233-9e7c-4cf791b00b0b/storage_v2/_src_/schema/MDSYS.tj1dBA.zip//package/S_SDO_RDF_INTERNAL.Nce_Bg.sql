create PACKAGE S_sdo_rdf_internal AS

  DEFAULT_MODEL_ID CONSTANT NUMBER := 0; -- same value as in SDO_RDF package (not reused from there to avoid dependency)

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  PROCEDURE refresh_query_state;

  PROCEDURE create_rdf_network (
    user_name       in varchar2
  , tablespace_name in varchar2
  , roles_and_privs in varchar2
  , options         in varchar2 default null);

  PROCEDURE drop_rdf_network (
    user_name varchar2
  , roles_and_privs varchar2
  , cascade in boolean default false
  , options in varchar2 default null
  );

  PROCEDURE refresh_rdf_model_tbl (
    user_name        IN VARCHAR2
  , roles_and_privs  IN VARCHAR2
  );

  PROCEDURE create_rdf_model (
    model_name       IN  VARCHAR2
  , table_name       IN  VARCHAR2
  , column_name      IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , table_id         IN  NUMBER
  , model_tablespace IN  VARCHAR2 default NULL
  , tab_owner_name   IN  VARCHAR2 default NULL
  , model_type_id    IN  NUMBER   default mdsys.sdo_rdf_internal.MODEL_TYPE_ID_REGULAR
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_rdf_model (
    model_name       IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , tab_owner_name   IN  VARCHAR2 default NULL
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE create_rdf_model_views (
    model_name       IN  VARCHAR2
  , model_id         IN  NUMBER
  , model_type       IN  VARCHAR2
  , semmToo          IN  BOOLEAN
  , recreate         IN  BOOLEAN
  , user_name        IN  VARCHAR2
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE create_virtual_model (
    vm_name          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , models           IN  MDSYS.RDF_Models default NULL
  , rulebases        IN  MDSYS.RDF_Rulebases default NULL
  , options          IN  VARCHAR2 default NULL
  , entailments      IN  MDSYS.RDF_Entailments default NULL
  );

  PROCEDURE drop_virtual_model (vm_name IN VARCHAR2, user_name IN VARCHAR2, roles_and_privs VARCHAR2, options IN VARCHAR2 default NULL);

  PROCEDURE create_materialized_view (
    mv_name          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , model_name       IN  VARCHAR2
  , compression      IN  boolean default true
  , inmemory         IN  boolean default false
  , values_as_vc     IN  boolean default false
  , refresh          IN  VARCHAR2 default 'C'
  , pred_list        IN  SYS.ODCIVARCHAR2LIST
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_materialized_view (
    mv_name         IN VARCHAR2
  , user_name       IN VARCHAR2
  , roles_and_privs IN VARCHAR2
  , options IN VARCHAR2 default NULL
  );

  PROCEDURE refresh_materialized_view (
    mv_name          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE create_mv_bitmap_index (
    mv_name             IN  VARCHAR2
  , user_name           IN  VARCHAR2
  , roles_and_privs     IN  VARCHAR2
  , idx_columns         IN  VARCHAR2
  , options             IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_mv_bitmap_index (
    mv_name          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , idx_columns      IN  VARCHAR2
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE set_callContext (info_type varchar2, options varchar2 default null, debug_trace boolean default true);

  PROCEDURE set_network_partition_info;

  PROCEDURE set_model_partition_info (modelID number);

  PROCEDURE merge_models_swap_tmp_merge_to(tbs_name varchar2,
                                model_to_id      number,
                                tmp_tab_name     varchar2,
                                parallel         number);

  FUNCTION merge_models_create_tmp_tab(tbs_name varchar2,
                                model_from_id    number,
                                model_to_id      number,
                                merge_to_count   number,
                                merge_from_count number,
                                user_name        varchar2,
                                tmp_tab_count    IN OUT number,
                                parallel         number,
                                options          IN varchar2,
                                NLTH             number,
                                model_from_table IN varchar2 default null)
                                RETURN varchar2;

  PROCEDURE merge_models_update_linktab(tbs_name IN varchar2,
                                merge_from_model IN varchar2,
                                merge_to_model   IN varchar2,
                                model_to_id      IN number,
                                merge_to_count   IN number,
                                tmp_tab_Name     IN varchar2,
                                tmp_tab_count    IN number,
                                parallel         IN number,
                                ITH              IN number,
                                merge_from_table IN varchar2 default null,
                                user_name        IN varchar2 default null
                               );
  PROCEDURE get_value$_type$ (
    model_id      IN     NUMBER
  , subject       IN OUT VARCHAR2
  , property      IN OUT VARCHAR2
  , object        IN OUT VARCHAR2
  , sv_type       OUT    VARCHAR2
  , pv_type       OUT    VARCHAR2
  , ov_type       OUT    VARCHAR2
  , lit_type      OUT    VARCHAR2
  , lit_lang      OUT    VARCHAR2
  , model_name    IN     VARCHAR2 default NULL -- model name opt w/ graph name
  );

  PROCEDURE parse_subject_node (
    v_subject        IN  VARCHAR2
  , sv_type          IN  VARCHAR2
  , sv_id            OUT NUMBER
  , new_sv           OUT BOOLEAN
  );

  PROCEDURE parse_property_value (
    v_property       IN  VARCHAR2
  , pv_type          IN  VARCHAR2
  , pv_id            OUT NUMBER
  , new_pv           OUT BOOLEAN
  , flags            IN  VARCHAR2 DEFAULT NULL
  );

  PROCEDURE parse_object_node (
    v_object         IN  VARCHAR2
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  PROCEDURE parse_object_node (
    v_object         IN  CLOB
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  PROCEDURE insert_triple (
    m_id             IN  NUMBER
  , subject          IN  VARCHAR2
  , property         IN  VARCHAR2
  , object           IN  VARCHAR2
  , pl_id            OUT NUMBER
  , sv_id            OUT NUMBER
  , pv_id            OUT NUMBER
  , ov_id            OUT NUMBER
  , batch_mode       IN  BOOLEAN -- true => old batch mode insert(from NTriple)
  , reuse_mode       IN  BOOLEAN -- true => reuse blank nodes from same model
  , m_name           IN  VARCHAR2 default NULL -- (chg to REQUIRED param) model name optionally including graph name
  , nonauto          IN  BOOLEAN  default FALSE -- true => use non-autonomous value creation
  , options          IN  VARCHAR2 default NULL
  );

  -- CLOB version
  PROCEDURE insert_triple (
    m_id             IN  NUMBER
  , subject          IN  VARCHAR2
  , property         IN  VARCHAR2
  , object           IN  CLOB -- CLOB version
  , pl_id            OUT NUMBER
  , sv_id            OUT NUMBER
  , pv_id            OUT NUMBER
  , ov_id            OUT NUMBER
  , batch_mode       IN  BOOLEAN -- true => old batch mode insert(from NTriple)
  , reuse_mode       IN  BOOLEAN -- true => reuse blank nodes from same model
  , m_name           IN  VARCHAR2 default NULL
  , nonauto          IN  BOOLEAN  default FALSE -- true => use non-autonomous value creation
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE parse_triple (
    m_id             IN  NUMBER
  , pv_id            IN  NUMBER
  , sv_id            IN  NUMBER
  , ov_id            IN  NUMBER
  , cov_id           IN  NUMBER
  , new_sv           IN  BOOLEAN
  , new_ov           IN  BOOLEAN
  , new_pv           IN  BOOLEAN
  , pl_id            OUT NUMBER
  , label_num        IN  NUMBER DEFAULT NULL
  , triple_level_ols IN  BOOLEAN DEFAULT FALSE
  , options          IN  VARCHAR2 DEFAULT NULL
  , p_network_owner  IN  dbms_id DEFAULT NULL
  , p_network_name   IN  varchar2 DEFAULT NULL
  );

  PROCEDURE maintain_aux_tables (
    m_id             IN  NUMBER
  , pv_id            IN  NUMBER
  , sv_id            IN  NUMBER
  , ov_id            IN  NUMBER
  , cov_id           IN  NUMBER
  , options          IN  VARCHAR2 DEFAULT NULL
  , p_network_owner  IN  dbms_id DEFAULT NULL
  , p_network_name   IN  varchar2 DEFAULT NULL
  );

  PROCEDURE LOAD_BATCH_VALUES_TABLE (
    Batch_Values_Tab       IN  varchar2
  , tbs_name               IN  varchar2
  , Staging_Tab            IN  varchar2
  , modelID                IN  number
  , Event_Trace_Tab        IN  varchar2
  , flags                  IN  varchar2
  , owner                  IN  varchar2 default 'MDSYS'
  , Bad_Rows_Tab           IN  dbms_id default NULL
  );

  PROCEDURE MERGE_BATCH_VALUES (
    Batch_Values_Tab           IN  varchar2
  , modelID                    IN  number
  , owner                      IN  varchar2 default 'MDSYS'
  , collision_cnt              IN  number default 0
  , Event_Trace_Tabname        IN  varchar2 default NULL
  , flags                      IN  varchar2 default NULL
  );

  PROCEDURE BULK_LOAD_FROM_STAGING_TABLE (
    model               IN            varchar2,
    staging_table_owner IN            varchar2,
    staging_table_name  IN            varchar2,
    user_name           IN            varchar2,
    flags               IN            varchar2 default NULL,
    debug               IN            PLS_INTEGER default NULL,
    start_comment       IN            varchar2 default NULL,
    end_comment         IN            varchar2 default NULL,
    roles_and_privs     IN            varchar2 default ' MDSYS.RDF_PRIV$:READ ' -- passed in from corr SDO_RDF routine
  );

  PROCEDURE refresh_sem_tablespace_names (
    model_name                 VARCHAR2 default NULL  -- NULL => all
  , user_id                    NUMBER default NULL    -- NULL => DBA
  );

  PROCEDURE refresh_sem_network_index_info (
    model_id_list sys.ODCINumberList
  , roles_and_privs VARCHAR2
  , options       VARCHAR2 default NULL
  );

  PROCEDURE gather_stats (just_on_values_table in boolean  default false,
                                        degree in number   default DBMS_STATS.AUTO_DEGREE,
                              estimate_percent in number   default DBMS_STATS.AUTO_SAMPLE_SIZE,
                              value_method_opt in varchar2 default null,
                               link_method_opt in varchar2 default null);

  PROCEDURE analyze_aux_tables(model_name  IN VARCHAR2,
                          estimate_percent IN NUMBER default DBMS_STATS.AUTO_SAMPLE_SIZE,
                          method_opt       IN VARCHAR2 default null,
                          degree           IN NUMBER default DBMS_STATS.AUTO_DEGREE
                         );

  PROCEDURE load_rdfview_schema (
    model_name           varchar2
  , map_type             varchar2
  , model_id             number
  , schgraph_id          number
  , R2R_Tab_Name         varchar2
  , gen_schema_tab_name  varchar2
  , schema_table_owner   varchar2
  , schema_table_name    varchar2
  , options              varchar2 default NULL
  );

  PROCEDURE truncate_rdfview_model(
    model_id      NUMBER,
    keep_r2rtab   BOOLEAN,
    truncate_model BOOLEAN default true
  );

  PROCEDURE replace_ref_prop_rows_with_agg(
    R2R_Tab_Name varchar2
  , options varchar2 default NULL
  );

  PROCEDURE add_DBColInfo_for_Tmap(
    model_id                  number
  , R2R_Tab_Name              varchar2
  , ltab_tabName              varchar2
  , ltab_Tmap                 varchar2
  , col_cnt                   number
  , desc_tbl                  dbms_sql.desc_tab3
  , Tmap_idx                  number
  , user_name                 varchar2
  , subj_template_prefix      varchar2
  , col_wkt_srid_list         sys.odcinumberlist
  , options                   varchar2 default NULL
  );

  PROCEDURE create_rdfview_model (
    model_name          IN  VARCHAR2
  , user_name           IN  VARCHAR2
  , map_type            OUT VARCHAR2
  , model_id            OUT NUMBER
  , schgraph_id         OUT NUMBER
  , R2R_Tab_Name        OUT VARCHAR2
  , gen_r2rml_tab_name  OUT VARCHAR2
  , gen_schema_tab_name OUT VARCHAR2
  , tables              IN  SYS.ODCIVarchar2List
  , prefix              IN  VARCHAR2 default NULL
  , r2rml_table_owner   IN  VARCHAR2 default NULL
  , r2rml_table_name    IN  VARCHAR2 default NULL
  , schema_table_owner  IN  VARCHAR2 default NULL
  , schema_table_name   IN  VARCHAR2 default NULL
  , options             IN  VARCHAR2 default NULL
  , r2rml_string        IN CLOB CHARACTER SET ANY_CS default NULL
  , r2rml_string_fmt    IN VARCHAR2 default NULL
  );

  PROCEDURE drop_rdfview_model (
    model_name        IN VARCHAR2
  , user_name         IN VARCHAR2
  , options           IN VARCHAR2 default NULL
  );

  PROCEDURE delete_model_stats(
      model_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
  );

  PROCEDURE delete_rules_index_stats(
      index_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
  );

  PROCEDURE swap_model_names(m1  in VARCHAR2,
                             m2  in VARCHAR2, user_id NUMBER, user_name dbms_id
  );

  PROCEDURE rename_entailment(old_name  in VARCHAR2,
                              new_name  in VARCHAR2, user_name VARCHAR2
  );

  PROCEDURE rename_model(old_name  in VARCHAR2,
                         new_name  in VARCHAR2, user_id NUMBER, user_name dbms_id
  );

  PROCEDURE FIND_VALUES_TO_REPLACE (
    valueMapTab_owner        varchar2
  , valueMapTab_name         varchar2
  , esc_reserved_chars       boolean default false
  , options                  varchar2 default NULL
  );

  PROCEDURE REPLACE_VALUES (
    valueMapTab_owner        varchar2
  , valueMapTab_name         varchar2
  , options                  varchar2 default NULL
  );

  PROCEDURE gather_rdf_stats;

  PROCEDURE gather_model_stats (
    model_name       IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_model_stats (
    model_name       IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  );

  --
  -- for RDF_APIS_INTERNAL subprograms
  --

  FUNCTION get_model_stats (
     model_name       IN VARCHAR2
  ,  model_id         IN NUMBER
  ,  stats_type       IN VARCHAR2
  ,  value_ids        IN SYS.ODCINumberList
  , options           IN VARCHAR2 default NULL
  )
  RETURN SYS_REFCURSOR;

  PROCEDURE notify_model_DML     (modelID    int,      dmltyp varchar2);

  PROCEDURE enable_change_tracking(uname     varchar2,
                                   models_in mdsys.rdf_models
  );

  PROCEDURE disable_change_tracking(uname     varchar2,
                                    models_in mdsys.rdf_models
  );

  PROCEDURE enable_inc_inference(user_name         varchar2,
                                 rule_index_id     number,
                                 bDoStatusCheck    boolean default true
  );

  PROCEDURE disable_inc_inference(user_name     varchar2,
                                  rule_index_id  number
  );

  FUNCTION get_tracking_start_time(model_id number) RETURN timestamp;

  PROCEDURE get_app_table_info(model_id     IN number,
                               owner        OUT varchar2,
                               app_tab_name OUT varchar2,
                               col_name     OUT varchar2,
			       model_name   OUT varchar2
  );

  FUNCTION is_inc_inf_enabled(rule_index_id number) RETURN boolean;

  PROCEDURE drop_inf_working_tabs(rule_index_id number);

  FUNCTION  get_prev_inf_start_time(rule_index_ID number) RETURN timestamp;

  PROCEDURE update_time_stamp(model_id number, rule_index_ID number, ts timestamp);

  PROCEDURE update_rdf_delta_ts(rule_index_id  number);

  PROCEDURE purge_rdf_delta(rule_index_id number);

  FUNCTION get_owners(modelIds   in SYS.ODCINumberList,
                      precompIdx in varchar2,
                      entIds     in SYS.ODCINumberList)
  RETURN SYS.ODCIVarchar2List;

  FUNCTION getNumericEvent(key varchar2) return int;

  PROCEDURE CLEANUP_FAILED(
    user_name          varchar2
  , rdf_object_type    varchar2
  , rdf_object_name    varchar2
  );

  PROCEDURE drop_user(uname varchar2);

  PROCEDURE LOOKUP_CREATE_LITERAL(
      lit varchar2, typ varchar2, lang varchar2,
      canonID OUT int, exactID OUT int, new_value OUT int);

  PROCEDURE LOOKUP_CREATE_LITERAL(
      lit CLOB,     typ varchar2,  lang varchar2,
      canonID OUT int, exactID OUT int, new_value OUT int);

  PROCEDURE CREATE_RULEBASE (user_name     VARCHAR2,
                             rulebase_name VARCHAR2,
                             options       VARCHAR2 DEFAULT NULL);

  PROCEDURE DROP_RULEBASE   (user_name      VARCHAR2,
                             rulebase_name  VARCHAR2,
                             ID             int DEFAULT NULL,
                             check_owner    boolean default TRUE);

  -- this one is from SDO_SEM_IN_INTERNAL
  procedure create_rules_index(user_name_in      varchar2,
                               index_name_in     varchar2,
                               models_in         mdsys.rdf_models,
                               rulebases_in      mdsys.rdf_rulebases,
                               passes            integer  default 0,
                               inf_components_in varchar2 default null,
                               options           varchar2 default null,
                               delta_in          mdsys.rdf_models default null,
                               ng_tab_name       varchar2,
                               ng_tab_schema     varchar2 default null,
                               inf_ng_name       varchar2 default null,
                               inf_ext_user_func_name varchar2 default null,
                               ols_ladder_inf_lbl_seq varchar2 default null  -- A string a numeric labels
                                                                             -- delimited by a space
                               );

  PROCEDURE add_rdf_index (
    index_code      IN  VARCHAR
  , table_name      IN  VARCHAR2 default NULL
  , index_name_pfx  IN  VARCHAR2 default NULL
  , index_name_sfx  IN  VARCHAR2 default NULL
  , status          IN  VARCHAR2 default NULL
  , parallel        IN  PLS_INTEGER default NULL
  , online          IN  BOOLEAN default FALSE
  , tablespace_name IN  VARCHAR2 default NULL
  , compression_length IN  PLS_INTEGER default NULL
  , flags           IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_rdf_index (
    index_code      IN   VARCHAR2
  , index_name_pfx  IN  VARCHAR2 default NULL
  , index_name_sfx  IN  VARCHAR2 default NULL
  );

  PROCEDURE alter_index_on_rdf_graph (
    modelID          IN  NUMBER
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , parallel         IN  PLS_INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  , tablespace_name  IN  VARCHAR2 default NULL
  , rules_index_name IN  VARCHAR2 default NULL
  , use_compression  IN  BOOLEAN default NULL
  );

  PROCEDURE alter_rdf_graph (
    modelID          IN  NUMBER
  , command          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , parallel         IN  PLS_INTEGER default NULL
  , rules_index_name IN  VARCHAR2 default NULL
  );

  PROCEDURE alter_rdf_indexes (
    attr_name IN varchar2
  , new_val   IN varchar2
  , options   IN VARCHAR2 default NULL
  , roles_and_privs IN varchar2
  );

  PROCEDURE get_rdf_index_info (
    user_name IN VARCHAR2
  , flags     IN VARCHAR2 default NULL
  );

  PROCEDURE build_spm_tab (
    model_name         IN varchar2
  , user_name          IN  VARCHAR2
  , pred_info_tabname  IN dbms_id default NULL
  , pred_name          IN varchar2 default NULL
  , tablespace_name    IN dbms_id default null
  , degree             IN number default null
  , pred_info_owner   IN dbms_id default NULL
  , options            IN varchar2 default null
  );

  PROCEDURE alter_spm_tab (
    model_name         IN varchar2
  , user_name          IN VARCHAR2
  , pred_name          IN varchar2
  , command            IN varchar2
  , degree             IN number default null
  , options            IN varchar2 default null
  );

  PROCEDURE create_index_on_spm_tab (
    index_name         IN varchar2
  , model_name         IN varchar2
  , key_string         IN varchar2 default NULL
  , pred_name          IN varchar2 default NULL
  , tablespace_name    IN dbms_id default null
  , degree             IN number default null
  , prefixes           IN varchar2 default NULL
  , prefix_length      IN number default NULL
  , options            IN varchar2 default null
  );

  PROCEDURE analyze_rules_index(index_name IN VARCHAR2,
                          estimate_percent IN NUMBER,
                          method_opt       IN VARCHAR2,
                          degree           IN NUMBER,
                          cascade          IN BOOLEAN,
                          no_invalidate    IN BOOLEAN,
                          force            IN BOOLEAN DEFAULT FALSE
                         );

  PROCEDURE analyze_model(model_name       IN VARCHAR2,
                          estimate_percent IN NUMBER,
                          method_opt       IN VARCHAR2,
                          degree           IN NUMBER,
                          cascade          IN BOOLEAN,
                          no_invalidate    IN BOOLEAN,
                          force            IN BOOLEAN DEFAULT FALSE
                         );

  PROCEDURE start_batch$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , tempTblName           IN  VARCHAR2
  , model_id              IN  NUMBER
  , model_name            IN  VARCHAR2
  , rdf_tablespace        IN  VARCHAR2
  , exchange              IN  NUMBER DEFAULT NULL
  );

  PROCEDURE exchange_model_part$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , model_id       IN  NUMBER
  , rdf_tablespace IN  VARCHAR2
  );

  -- from SDO_SEM_UTL

  PROCEDURE remove_duplicates(model_name  in VARCHAR2,
                        model_id    in NUMBER,
                        apptab_name in VARCHAR2,
                        tbs_name    in VARCHAR2,
                        col_name    in VARCHAR2,
                        user_name   in VARCHAR2,
                        phase       in INTEGER,
                        owner_id  in out NUMBER,
                        table_id  in out NUMBER);

  PROCEDURE export_model_stats(
    model_name      varchar2,
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  PROCEDURE import_model_stats(
    model_name      varchar2,
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    no_invalidate   BOOLEAN DEFAULT FALSE,
    force           BOOLEAN DEFAULT FALSE,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  procedure export_entailment_stats(
    entailment_name varchar2,
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  procedure import_entailment_stats(
    entailment_name varchar2,
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    no_invalidate   BOOLEAN DEFAULT FALSE,
    force           BOOLEAN DEFAULT FALSE,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );

  PROCEDURE set_model_stats (
    model_name    VARCHAR2,
    numrows       NUMBER    DEFAULT NULL,
    numblks       NUMBER    DEFAULT NULL,
    avgrlen       NUMBER    DEFAULT NULL,
    flags         NUMBER    DEFAULT NULL,
    no_invalidate BOOLEAN   DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    cachedblk     NUMBER    DEFAULT NULL,
    cachehit      NUMBER    DEFAULT NULL,
    force         BOOLEAN   DEFAULT FALSE
  );

  PROCEDURE set_entailment_stats (
    entailment_name  VARCHAR2,
    numrows          NUMBER   DEFAULT NULL,
    numblks          NUMBER   DEFAULT NULL,
    avgrlen          NUMBER   DEFAULT NULL,
    flags            NUMBER   DEFAULT NULL,
    no_invalidate    BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    cachedblk        NUMBER   DEFAULT NULL,
    cachehit         NUMBER   DEFAULT NULL,
    force            BOOLEAN  DEFAULT FALSE
  );

  PROCEDURE delete_network_stats(
    cascade_parts    IN BOOLEAN  DEFAULT TRUE,
    cascade_columns  IN BOOLEAN  DEFAULT TRUE,
    cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
    no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    force            IN BOOLEAN  DEFAULT FALSE,
    options          IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE export_network_stats(
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
    options         VARCHAR2 DEFAULT NULL
  );

  PROCEDURE import_network_stats(
    stattab         VARCHAR2,
    statid          VARCHAR2 DEFAULT NULL,
    cascade         BOOLEAN  DEFAULT TRUE,
    statown         VARCHAR2 DEFAULT NULL,
    no_invalidate   BOOLEAN DEFAULT FALSE,
    force           BOOLEAN DEFAULT FALSE,
    stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
    options         VARCHAR2 DEFAULT NULL
  );

  -- from RDF_APIS_INTERNAL
  PROCEDURE DROP_RULES_INDEX (user_name   varchar2,
                              index_name  varchar2,
                              check_owner boolean default TRUE,
                              nlGraphIds  SYS.ODCINumberList default null,
                              drop_when_in_progress boolean default FALSE,
                              dop         int     default 1);

  PROCEDURE getPrecompStatus(owner          varchar2,
                             index_name     varchar2,
                             precompsig     varchar2,
                             ModelIDs       SYS.ODCINumberList,
                             RulebaseIDs    SYS.ODCINumberList,
                             precompID  OUT int,
                             status     OUT varchar2,
                             matchedsig OUT varchar2,
                             options        varchar2 default NULL);

   PROCEDURE setPrecompStatus (PCmodelID int,
                               status    varchar2);

   FUNCTION createPrecompStatus (owner          varchar2,
                                 index_name     varchar2,
                                 precompsig     varchar2,
                                 ModelIDs       SYS.ODCINumberList,
                                 RulebaseIDs    SYS.ODCINumberList,
                                 options        varchar2 default NULL)
   RETURN int;

  FUNCTION get_rdf_sequence_nextval (sequence_name varchar2)
  RETURN number;

  PROCEDURE deleteRedundantTrips(modelIDs    SYS.ODCINumberList,
                                 ptnName     varchar2,
                                 tripIDlimit int,
                                 dop         int default 1,
                                 inf_mode    varchar2 default 'GI',
                                 inf_ng_id   int default null);

  PROCEDURE CleanupRulesIndex (user_name varchar2,
                               precompID int,
                               index_name varchar2);

  PROCEDURE create_clique_ts_tables(v_tablespace_name varchar2 default null);

  FUNCTION rulebasePropIDs(rulebases MDSYS.RDF_Rulebases)
      return SYS.ODCINumberList;

  PROCEDURE create_rules_index_trns(uname     varchar2,
                                    rulebases MDSYS.RDF_Rulebases,
                                    tabname   varchar2,
                                    diag_ev   binary_integer,
                                    modelID   varchar2);

  FUNCTION get_tablespace_name RETURN varchar2;

  FUNCTION get_rules_index_pname(index_name IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION get_model_pname(model_name IN VARCHAR2) RETURN VARCHAR2;

  PROCEDURE PrecompSetStatus(typ varchar2, id int, status varchar2, p_network_owner dbms_id default NULL, p_network_name varchar2 default NULL);
  PROCEDURE PrecompDelete(user_name varchar2, typ varchar2, id int);

--------
  PROCEDURE autonomousDDLAP(ptnName varchar2,  precompModelID_s varchar2);
  PROCEDURE autonomousDDLAPD(ptnName varchar2,  precompModelID_s varchar2);
  PROCEDURE autonomousDDLCT(shadowTabName varchar2,  ts varchar2);
  PROCEDURE autonomousDDLGP(shadowTabName varchar2);
  PROCEDURE autonomousDDLGTP(t varchar2);
  PROCEDURE autonomousDDLTP(ptnName varchar2);
  PROCEDURE autonomousDDLDT(trnsName0 varchar2);
  PROCEDURE autonomousDDLCRV(viewName varchar2, ptnName varchar2);
  PROCEDURE autonomousDDLGV(viewName varchar2, uname varchar2);
  PROCEDURE autonomousDDLDV(rulebase_name varchar2);
  PROCEDURE autonomousDDLDTP(t varchar2);

  PROCEDURE autonomousDMLIL(ptnName varchar2, precompModelID_s varchar2, trnsName0 varchar2);
  PROCEDURE autonomousDMLUPV(precompModelID int);
  PROCEDURE autonomousDMLUP(rbID int);

----------

  PROCEDURE collect_stats;

  FUNCTION resolveEntailments (entailments IN MDSYS.RDF_Entailments, models_list OUT MDSYS.RDF_Models)
  RETURN SYS.ODCINumberList;

  FUNCTION resolveEntailments (entailments IN MDSYS.RDF_Models, models_list OUT MDSYS.RDF_Models)
  RETURN SYS.ODCINumberList;

  FUNCTION resolveRulesIndex(owner      varchar2,
                             index_name varchar2)
    return int;

  -- OLS/VPD related
  PROCEDURE rdfvpd_set_trusted_prog (val BOOLEAN);

  FUNCTION get_ols_policy_name return varchar2;

  FUNCTION has_ols_policy return BOOLEAN;

  FUNCTION has_enabled_ols_policy return BOOLEAN;

  FUNCTION has_triple_level_ols return BOOLEAN;

  FUNCTION get_rdf_parameter (p_namespace   VARCHAR2,
                              p_attribute   VARCHAR2) return VARCHAR2;

  FUNCTION storage_version_enabled RETURN NUMBER;

  FUNCTION has_version_enabled_model (modelIds sys.ODCINumberList)
     RETURN NUMBER;

  FUNCTION is_security_or_version_enabled(modelIds sys.ODCINumberList)
    RETURN BOOLEAN;
  -- end OLS/VPD related

  FUNCTION is_change_tracking_enabled(model_id number) RETURN boolean;

  FUNCTION getStatusForVM (vmID IN NUMBER) RETURN VARCHAR2;

  FUNCTION getPrecompIdxName(
    modelIDs      SYS.ODCINumberList,
    rulebaseIDs   SYS.ODCINumberList,
    reqIdxStatus  varchar2,
    idxID     OUT number,
    idxStatus OUT varchar2)
  RETURN varchar2;

  FUNCTION fetchIDList(QueryNames IN OUT NOCOPY MDSYS.rdf_apis.nameSet,
                       IDcol                    varchar2,
                       srctab                   varchar2,
                       nameCol                  varchar2,
                       exactMatch               boolean default TRUE)
  RETURN SYS.ODCINumberList;

  PROCEDURE add_datatype_index(
    datatype            IN VARCHAR2
  , user_name           IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_datatype_index(
    datatype            IN VARCHAR2
  , force_drop          IN BOOLEAN default FALSE
  );

  PROCEDURE alter_datatype_index(
    datatype            IN VARCHAR2
  , command             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  );

  PROCEDURE run_dml_stmt_merge(model_to_id  number,
                               stmt_name    varchar2,
                               dump_plan    boolean default false,
                               parallel     int     default 1);

  PROCEDURE enable_all_triggers( user_name   IN  varchar2,
                                 apptab_name IN  varchar2);

  PROCEDURE disable_all_triggers(user_name   IN  varchar2,
                                 apptab_name IN  varchar2);

  PROCEDURE create_rdf_triggers (
    model_name       IN  VARCHAR2
  , tab_owner_name   IN  VARCHAR2 default NULL
  );

  PROCEDURE create_rdf_aview_trigger (
    model_owner      IN  VARCHAR2
  , model_name       IN  VARCHAR2 -- EXPECT: val_cvt_rdf_name MUST have already been applied
  , p_network_pfx    IN  VARCHAR2
  , p_network_owner  IN  VARCHAR2
  , p_network_name   IN  varchar2
  , has_triple_level_ols IN  boolean
  , tab_owner_name       IN  VARCHAR2 default NULL
  );

  -- data migration procedures
  PROCEDURE convert_old_rdf_data (
    log_level       IN PLS_INTEGER default 10
  , migrate         IN BOOLEAN     default TRUE
  , flags           IN VARCHAR2    default NULL
  , tablespace_name IN VARCHAR2    default NULL
  );

  PROCEDURE migrate_data_to_current (
    user_name       in VARCHAR2
  , roles_and_privs in VARCHAR2
  , options         in VARCHAR2 default NULL
  );
  -- end data migration procedures

  -- datapump import/export procedures
  --
  -- Note: export/import may run as SYS, and SYS cannot call MDSYS
  -- invoker rights procedures or you will get ORA-06598: insufficient
  -- INHERIT PRIVILEGES privilege. import/export calls S_SDO_RDF_INTERNAL
  -- directly to avoid ORA-06598. This means that we cannot depend on
  -- network_owner/network_name getting set before the S_SDO_RDF_INTERNAL
  -- call, so we need to set network_owner to MDSYS if it is not already set.
  PROCEDURE system_callout (
    prepost        IN    PLS_INTEGER,
    version        IN    VARCHAR2
  );

  PROCEDURE instance_export_action (
          obj_name      IN   VARCHAR2,
          obj_schema    IN   VARCHAR2,
          obj_type      IN   NUMBER,
          tgt_version   IN   VARCHAR2,
          action        OUT  VARCHAR2,
          alt_name      OUT  VARCHAR2,
          where_clause  OUT  VARCHAR2
  );

  PROCEDURE instance_callout_imp (
             obj_name   IN   VARCHAR2,
             obj_schema IN   VARCHAR2,
             obj_type   IN   NUMBER,
             prepost    IN   PLS_INTEGER,
             action     OUT  VARCHAR2,
             alt_name   OUT  VARCHAR2
  );

  PROCEDURE system_callout_imp (
             user_name  IN   VARCHAR2,
             prepost    IN   PLS_INTEGER
  );
  -- end datapump procedures

  -- upgrade/downgrade related procedures
  --
  -- Note: upgrade/downgrade runs as SYS, and SYS cannot call MDSYS
  -- invoker rights procedures or you will get ORA-06598: insufficient
  -- INHERIT PRIVILEGES privilege. upgrade/downgrade calls S_SDO_RDF_INTERNAL
  -- directly to avoid ORA-06598. This means that we cannot depend on
  -- network_owner/network_name getting set before the S_SDO_RDF_INTERNAL
  -- call, so we need to set network_owner to MDSYS if it is not already set.
  PROCEDURE create_rdf_ddl_trigger;

  PROCEDURE populate_crs_table;

  PROCEDURE recreate_link_views(options  IN  VARCHAR2 default NULL);

  PROCEDURE recreate_rulebase_views (
    user_name IN VARCHAR2
  );

  PROCEDURE recreate_stats_partitions;

  PROCEDURE recreate_app_triggers;

  PROCEDURE recreate_meta_views (
    options  IN VARCHAR2 default NULL
  );

  PROCEDURE grant_pdb_dba_privs;

  -- end upgrade/downgrade related procedures

  -- begin IMVC related fucntions/procedures
  FUNCTION GetVal(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetPref(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetSuff(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetValTyp(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetOrdTyp(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC parallel_enable;

  FUNCTION GetOrdNum(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC parallel_enable;

  FUNCTION GetOrdDate(i_id NUMBER)
         RETURN TIMESTAMP WITH TIME ZONE DETERMINISTIC parallel_enable;

  FUNCTION GetLitType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetLangType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  PROCEDURE REMOVE_IM_VIRTUAL_COLUMNS;

  -- end IMVC related fucntions/procedures

  FUNCTION get_model_id (
    model_name       IN  VARCHAR2
  , flags            IN  VARCHAR2 default NULL
  ) RETURN               NUMBER;

  FUNCTION get_model_name (
    model_id         IN  NUMBER
  , flags            IN  VARCHAR2 default NULL
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               VARCHAR2
  , model_name           VARCHAR2 default NULL
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               CLOB
  , model_name           VARCHAR2 default NULL
  ) RETURN               VARCHAR2;

  PROCEDURE enable_inmemory(
      populate_wait IN BOOLEAN
    , options in varchar2 default null
    , roles_and_privs IN varchar2);

  PROCEDURE disable_inmemory (roles_and_privs varchar2);

  PROCEDURE enable_inmemory_for_model (
    model_id     IN          integer
  , roles_and_privs IN varchar2);

  PROCEDURE disable_inmemory_for_model (
    model_id     IN          integer
  , roles_and_privs IN varchar2);

  PROCEDURE enable_inmemory_for_ent (
    entailment_id     IN          integer
  , roles_and_privs IN varchar2);

  PROCEDURE disable_inmemory_for_ent (
    entailment_id     IN          integer
  , roles_and_privs IN varchar2);

END S_sdo_rdf_internal;
/

