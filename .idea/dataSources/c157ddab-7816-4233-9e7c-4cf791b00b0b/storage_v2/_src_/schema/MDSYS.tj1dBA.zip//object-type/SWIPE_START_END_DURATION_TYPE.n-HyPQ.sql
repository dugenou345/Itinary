create TYPE       swipe_start_end_duration_type AS OBJECT (
  start_time DATE,
  end_time   DATE,
  duration   NUMBER)
/

