create PACKAGE       opg_apis authid current_user AS

  -- start of error code
  ECODE_INVALID_NAME            constant integer := -20900;
  ECODE_INVALID_NUM_PTNS        constant integer := -20901;
  ECODE_INVALID_MARKER_TOO_LONG constant integer := -20902;
  ECODE_INVALID_ARGUMENT        constant integer := -20903;
  ECODE_GET_LOCK                constant integer := -20904;
  ECODE_RELEASE_LOCK            constant integer := -20905;


  OPG_TMP_TAB_PREFIX constant varchar2(200) := 'opg_tmptab_';

  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  /**
   * Return sombrero patch version
   */
  function get_opg_version return varchar2;

  function validate_name(s varchar2) return varchar2;

  /**
   * This API creates a set of property graph "schema" tables for a new property graph.
   */
  procedure create_pg(graph_name    varchar2,
                      dop           integer default null,
                      num_hash_ptns integer default 8,
                      tbs           varchar2 default null,
                      options       varchar2 default null
                     );


  /**
   * This API creates a property graph owned by graph_owner.
   */
  procedure create_pg(graph_owner   varchar2,
                      graph_name    varchar2,
                      dop           integer default null,
                      num_hash_ptns integer default 8,
                      tbs           varchar2 default null,
                      tbs_set        varchar2 default null,
                      options       varchar2 default null
                     );

  /**
   * This API migrates old property graph schema tables to current
   * property graph schema
   */
  procedure migrate_pg_to_current(graph_name    varchar2,
                                  dop           integer default null,
                                  num_hash_ptns integer default 8,
                                  tbs           varchar2 default null,
                                  options       varchar2 default null
                                 );


  /**
   * This API migrates old property graph schema tables owned by graph_owner
   * to current property graph schema
   */
  procedure migrate_pg_to_current(graph_owner   varchar2,
                                  graph_name    varchar2,
                                  dop           integer default null,
                                  num_hash_ptns integer default 8,
                                  tbs           varchar2 default null,
                                  tbs_set        varchar2 default null,
                                  options       varchar2 default null
                                 );


  procedure create_pg_snapshot_tab(graph_name    varchar2,
                                   dop           integer default null,
                                   tbs           varchar2 default null,
                                   options       varchar2 default null
                                   );


  procedure create_pg_textidx_tab(graph_name    varchar2,
                                  dop           integer default null,
                                  tbs           varchar2 default null,
                                  options       varchar2 default null
                                  );


  /**
   * This API creates a property graph owned by graph_owner.
   */
  procedure create_pg(graph_owner   varchar2,
                      graph_name    varchar2,
                      dop           integer default null,
                      num_hash_ptns integer default 8,
                      tbs           varchar2 default null,
                      options       varchar2 default null
                     );


  /**
   * This API migrates old property graph schema tables owned by graph_owner
   * to current property graph schema
   */
  procedure migrate_pg_to_current(graph_owner   varchar2,
                                  graph_name    varchar2,
                                  dop           integer default null,
                                  num_hash_ptns integer default 8,
                                  tbs           varchar2 default null,
                                  options       varchar2 default null
                                 );


  -- rename a property graph
  procedure rename_pg(graph_name     varchar2,
                      new_graph_name varchar2);


  -- create the schema table for the index table
  procedure create_pg_textidx_tab(graph_owner   varchar2,
                                  graph_name    varchar2,
                                         dop    integer  default null,
                                         tbs    varchar2 default null,
                                     options in varchar2 default null);


  /**
   * Adds the metadata information from a SolrCloud Text index into the IT$ table
   */
  procedure add_index_metadata_solrcloud(indexName      nvarchar2,
                                         entityType     int,
                                         indexType      int,
                                         searchEngine   int,
                                         configName     nvarchar2,
                                         solrServerUrl  nvarchar2,
                                         solrAdminUrl   nvarchar2,
                                         zkTimeout      int,
                                         numShards      int,
                                         repFactor      int,
                                         maxShards      int,
                                         strKey         nvarchar2,
                                         graph_owner    nvarchar2,
                                         graph_name     nvarchar2
                         );


  /**
   * Adds the metadata information from an Apache Lucene Text index into the IT$ table
   */
  procedure add_index_metadata_lucene(indexName    nvarchar2,
                                      entityType   int,
                                      indexType    int,
                                      searchEngine int,
                                      dirType      int,
                                      location     nvarchar2,
                                      strKey       nvarchar2,
                                      numdirs      int,
                                      version      nvarchar2,
                                      usedt        int,
                                      graph_owner  nvarchar2,
                                      graph_name   nvarchar2
                         );


  /**
   * Adds the metadata information from an Oracle Text index into the IT$ table
   */
  procedure add_index_metadata_oratext(indexName    nvarchar2,
                                       entityType   int,
                                       indexType    int,
                                       searchEngine int,
                                       strKey       nvarchar2,
                                       prefOwner    nvarchar2,
                                       datastore    nvarchar2,
                                       filter       nvarchar2,
                                       storage      nvarchar2,
                                       wordlist     nvarchar2,
                                       stoplist     nvarchar2,
                                       lexer        nvarchar2,
                                       options      nvarchar2,
                                       graph_owner  nvarchar2,
                                       graph_name   nvarchar2
                         );


  /**
   * Deletes all the metadata information of the given Text index from the IT$ table
   */
  procedure delete_index_metadata(indexName    nvarchar2,
                                  graph_owner  nvarchar2,
                                  graph_name   nvarchar2
                         );


  /**
   * Deletes all the metadata information of the given Text index from the IT$ table
   */
  procedure delete_index_metadata_key(indexName    nvarchar2,
                                      strKey       nvarchar2,
                                      graph_owner  nvarchar2,
                                      graph_name   nvarchar2
                         );


  -- create the schema table for storing property graph snapshots
  procedure create_pg_snapshot_tab(graph_owner    varchar2,
                                    graph_name    varchar2,
                                           dop    integer  default null,
                                           tbs    varchar2 default null,
                                       options in varchar2 default null);


  -- Clears the schema tables of a property graph
  -- This operation cannot be undone.
  procedure clear_twotables_graph_table(table_name varchar2);


  -- create the schema table for the two tables vertex table
  -- opg_apis.create_two_tables_vertex(:1, :2, :3, :4, :5, :6)
  procedure create_two_tables_vertex(table_owner     varchar2,
                                     table_name      varchar2,
                                     property_names  t_varchar2_array,
                                     property_types  t_varchar2_array,
                                     tbs             varchar2 default null,
                                     options         varchar2 default null
                     );

  -- create the schema table for the two tables vertex table
  -- opg_apis.create_two_tables_vertex(:1, :2, :3, :4, :5, :6)
  procedure create_two_tables_vertex(table_owner     varchar2,
                                     table_name      varchar2,
                                     vid_colname     varchar2,
                                     vid_property_type varchar2,
                                     property_names  t_varchar2_array,
                                     property_types  t_varchar2_array,
                                     tbs             varchar2 default null,
                                     options         varchar2 default null
                     );


  -- create the schema table for the two tables vertex table
  -- opg_apis.create_two_tables_vertex(:1, :2, :3, :4, :5, :6)
  procedure create_two_tables_vertex(table_owner     varchar2,
                                     table_name      varchar2,
                                     vid_colname     varchar2,
                                     property_names  t_varchar2_array,
                                     property_types  t_varchar2_array,
                                     tbs             varchar2 default null,
                                     options         varchar2 default null
                     );

  -- create the schema table for the two tables edge table
  procedure create_two_tables_edge(table_owner     varchar2,
                                   table_name      varchar2,
                                   property_names  t_varchar2_array,
                                   property_types  t_varchar2_array,
                                   tbs           varchar2 default null,
                                   options       varchar2 default null
                     );


  -- create the schema table for the two tables edge table
  procedure create_two_tables_edge(table_owner     varchar2,
                                   table_name      varchar2,
                                   eid_colname     varchar2,
                                   el_colname      varchar2,
                                   svid_colname    varchar2,
                                   dvid_colname    varchar2,
                                   property_names  t_varchar2_array,
                                   property_types  t_varchar2_array,
                                   tbs           varchar2 default null,
                                   options       varchar2 default null
                     );

  -- create the schema table for the two tables edge table
  procedure create_two_tables_edge(table_owner     varchar2,
                                   table_name      varchar2,
                                   eid_colname     varchar2,
                                   el_colname      varchar2,
                                   svid_colname    varchar2,
                                   dvid_colname    varchar2,
                                   vid_property_type varchar2,
                                   eid_property_type varchar2,
                                   property_names  t_varchar2_array,
                                   property_types  t_varchar2_array,
                                   tbs           varchar2 default null,
                                   options       varchar2 default null
                     );
  -- drop the schema tables
  procedure drop_pg(graph_name varchar2);

  -- Drops the schema tables of a property graph
  -- This operation cannot be undone.
  procedure drop_pg(graph_name varchar2,
                    options    varchar2);

  -- Drops the schema tables of a property graph
  -- This operation cannot be undone.
  procedure drop_pg(graph_owner varchar2,
                    graph_name  varchar2,
                    options     varchar2);


  -- Drops the view definition of a property graph
  -- This operation cannot be undone.
  procedure drop_pg_view(graph_name varchar2,
                    options    varchar2);

  -- remove contents
  procedure clear_pg(graph_name varchar2);

  -- remove indices content (used on drop indices)
  procedure clear_pg_indices(graph_name varchar2);

  function show_path_bd(node in number,
                        src  in number,
                       dest  in number,
                      expTab in varchar2,
                    weights out varchar2
                       )
  return varchar2;

  procedure get_elapsed_time (
                vcTimeSec out varchar2,
                tsCurrent out timestamp,
         m_tsStartTime in out timestamp);


  function get_logline_header(m_tsStartTime in out timestamp)
      return varchar2;

  procedure plan_start(bPerfTuning in boolean,
                        nStartTime in out number,
                        nEndTime   in out number
                       );

  procedure plan_done(bPerfTuning in boolean,
                       nStartTime in out number,
                       nEndTime   in out number
                      );

  -- statistic related APIs start here

  /*
   * Not all parameters of dbms_stats.gather_table_stats make sense here.
   */
  PROCEDURE analyze_pg(graph_name       IN VARCHAR2,
                       estimate_percent IN NUMBER,
                       method_opt       IN VARCHAR2,
                       degree           IN NUMBER,
                       cascade          IN BOOLEAN,
                       no_invalidate    IN BOOLEAN,
                       force            IN BOOLEAN DEFAULT FALSE,
                       graph_owner      IN VARCHAR2 DEFAULT NULL
                       );

  /*
   * Not all parameters of dbms_stats.gather_table_stats make sense here.
   */
  PROCEDURE analyze_pg(graph_name       IN VARCHAR2,
                       estimate_percent IN NUMBER,
                       method_opt       IN VARCHAR2,
                       degree           IN NUMBER,
                       cascade          IN BOOLEAN,
                       no_invalidate    IN BOOLEAN,
                       force            IN BOOLEAN DEFAULT FALSE,
                       options          IN VARCHAR2 DEFAULT 'GATHER',
                       graph_owner      IN VARCHAR2 DEFAULT NULL
                       );

  /*
   * Not all parameters of dbms_stats.gather_table_stats make sense here.
   */
  PROCEDURE analyze_pg(graph_name       IN VARCHAR2,
                       degree           IN NUMBER,
                       cascade          IN BOOLEAN,
                       no_invalidate    IN BOOLEAN,
                       force            IN BOOLEAN DEFAULT FALSE,
                       graph_owner      IN VARCHAR2 DEFAULT NULL
                       );

  /*
   * Not all parameters of dbms_stats.gather_table_stats make sense here.
   */
  PROCEDURE analyze_pg(graph_name       IN VARCHAR2,
                       degree           IN NUMBER,
                       cascade          IN BOOLEAN,
                       no_invalidate    IN BOOLEAN,
                       force            IN BOOLEAN DEFAULT FALSE,
                       options          IN VARCHAR2 DEFAULT 'GATHER',
                       graph_owner      IN VARCHAR2 DEFAULT NULL
                       );

  procedure create_stat_table(stattab   IN varchar2,
                              tblspace  VARCHAR2 DEFAULT NULL
                              );

  procedure exp_vertex_tab_stats(
   graph_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure exp_edge_tab_stats(
   graph_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure imp_edge_tab_stats(
   graph_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure imp_vertex_tab_stats(
   graph_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );
  -- statistic related APIs done


  procedure cf_prep(edge_tab_name   in     varchar2,
                    wt_l            in out varchar2,
                    wt_r            in out varchar2,
                    wt_l1           in out varchar2,
                    wt_r1           in out varchar2,
                    wt_i            in out varchar2,
                    wt_ld           in out varchar2,
                    wt_rd           in out varchar2,
                    options         in varchar2 default null
                   );

  procedure cf(edge_tab_name        in varchar2,
               edge_label           in varchar2,
               rating_property      in varchar2,
               iterations           in integer default 10,
               min_error            in number default 0.001,
               k                    in integer default 5,
               learning_rate        in number default 0.0002,
               decrease_rate        in number default 0.95,
               regularization       in number default 0.02,
               dop                  in number default 8,
               wt_l                 in out varchar2,
               wt_r                 in out varchar2,
               wt_l1                in out varchar2,
               wt_r1                in out varchar2,
               wt_i                 in out varchar2,
               wt_ld                in out varchar2,
               wt_rd                in out varchar2,
               tbs           in varchar2 default null,
               options              in varchar2 default null
              );

  procedure cf_cleanup(edge_tab_name   in     varchar2,
                       wt_l            in out varchar2,
                       wt_r            in out varchar2,
                       wt_l1           in out varchar2,
                       wt_r1           in out varchar2,
                       wt_i            in out varchar2,
                       wt_ld           in out varchar2,
                       wt_rd           in out varchar2,
                       options         in varchar2 default null
                      );



  procedure find_sp_prep(
                    edge_tab_name   in varchar2,
                    exp_tab         in out varchar2,
                    options         in varchar2 default null
                    )
  ;

  procedure find_sp(
                    edge_tab_name     varchar2,
                    source            number,
                    dest              number,
                    exp_tab           varchar2,
                    dop               integer,
                    stats_freq        integer   default 20000,
                    path_output    out varchar2,
                    weights_output out varchar2,
                    options         in varchar2 default null,
                    scn             in number   default null
                    );


  procedure find_sp_cleanup(
                    edge_tab_name   in     varchar2,
                    exp_tab         in out varchar2,
                    options         in     varchar2 default null
                    );

  function get_version              return varchar2;
  function get_build_id             return varchar2;
  function get_spatial_property_key return varchar2 deterministic parallel_enable ;

  function get_scn return number;

  function get_tmp_work_tab_name(marker in varchar2) return varchar2;

  function get_session_id return varchar2;

  /**
   * This function validates the name (of tablespace, user, column, etc.) passed in.
   */
  function validate_non_graphname(s varchar2) return varchar2;

  /**
   * SE2
   */
  PROCEDURE set_event_for_partitioning (level integer);

  FUNCTION get_table_compression_clause RETURN varchar2;

  function get_compress_str(options varchar2) return varchar2;


  /**
   * This function formats 1.2 as 1.2, 1,2 (in certain NLS_LANG) as 1.2
   */
  function format_num_for_sql(n number) return varchar2 deterministic parallel_enable;

  /**
   * This function returns a unique name
   * that can be used to create an intermediate
   * working table
   * Note that session ID will be used as part of the
   * table name.
   * Also, marker will be included in the name to differentiate
   * different categories of tables.
   */
  function generate_graph_tmp_work_tab(
   graph  in varchar2,
   marker in varchar2 default '$TW'
   )
  return varchar2;

  /**
   * This function returns a unique name
   * that can be used to create an intermediate
   * working table
   * Note that session ID will be used as part of the
   * table name.
   * Also, marker will be included in the name to differentiate
   * different categories of tables.
   */
  function generate_graph_tmp_work_tab(
   graph  in varchar2,
   sid    in integer,
   marker in varchar2 default '$TW'
   )
  return varchar2;


  /**
   * This function returns a string in the form of
   * "parallel dop" and this string can be used in a
   * CTAS statement
   */
  function get_parallel_clause_for_ctas(dop integer) return varchar2;


  /**
   * This procedure does preparation work for triangle counting.
   * The preparation work here involves setting up all the necessary
   * intermediate working table names.
   */
  procedure count_triangle_prep(
                    edge_tab_name   in varchar2,
                    wt_undBM        in out varchar2,
                    wt_rnmap        in out varchar2,
                    wt_undAM        in out varchar2,
                    options         in varchar2 default null
                    );


  function count_triangle(
                    edge_tab_name   in varchar2,
                    wt_und          in varchar2,
                    num_sub_ptns    in integer default 1,
                    dop             in integer default 1,
                    tbs             in varchar2 default null,
                    options         in varchar2 default null
                    )
  return number;


  function count_triangle_renum(
                    edge_tab_name   in varchar2,
                    wt_undBM        in varchar2,
                    wt_rnmap        in varchar2,
                    wt_undAM        in varchar2,
                    num_sub_ptns    in integer default 1,
                    dop             in integer default 1,
                    tbs             in varchar2 default null,
                    options         in varchar2 default null
                    )
  return number;


  /**
   * This procedure does cleanup work for triangle counting.
   * All the intermediate tables, if created, will be truncated and
   * dropped.
   */
  procedure count_triangle_cleanup(
                    edge_tab_name   in varchar2,
                    wt_undBM        in out varchar2,
                    wt_rnmap        in out varchar2,
                    wt_undAM        in out varchar2,
                    options         in varchar2 default null
                    );


  function estimate_triangle_renum(
                    edge_tab_name   in varchar2,
                    wt_undBM        in varchar2,
                    wt_rnmap        in varchar2,
                    wt_undAM        in varchar2,
                    num_sub_ptns    in integer default 1,
                    chunk_id        in integer default 1,
                    dop             in integer default 1,
                    tbs             in varchar2 default null,
                    options         in varchar2 default null
                    )
  return number;


  function get_option_val(options  in varchar2,
                          optName  in varchar2 /* should not include '=' */,
                          defVal   in varchar2 /* either 'T' or 'F', or null */)
   return boolean;


  function get_work_tab_name_if_empty(graph_name     in varchar2,
                                      input_tab_name in varchar2,
                                      marker         in varchar2 default '$TW'
                                     )
   return varchar2;


  /**
   * This procedure does preparation work for page rank calculation.
   * The work table names will be generated and returned if they
   * are not set to begin with.
   */
  procedure pr_prep(
                    edge_tab_name   in varchar2,
                    wt_node_pr      in out varchar2,
                    wt_node_nextpr  in out varchar2,
                    wt_edge_tab_deg in out varchar2,
                    wt_delta        in out varchar2,
                    options         in varchar2 default null
                    );

  /**
   * This procedure does cleanup work for page ranking.
   * All the intermediate tables, if created, will be truncated and
   * dropped.
   */
  procedure pr_cleanup(
                    edge_tab_name   in varchar2,
                    wt_node_pr      in out varchar2,
                    wt_node_nextpr  in out varchar2,
                    wt_edge_tab_deg in out varchar2,
                    wt_delta        in out varchar2,
                    options         in varchar2 default null
                    );

  /**
   * This procedure calculates Page Rank values of the vertices of a given graph (edge table).
   * The page rank values of vertices of the graph will be stored in
   * the table with a name provided in wt_node_pr.
   * This procedure will make use of serveral intermediate working tables including
   * wt_node_nextpr, wt_edge_tab_deg, and wt_delta.
   * The working tables wt_edge_tab_deg, and wt_delta will not be dropped because they
   * can be used to conduct more iterations of PR calculation, if necessary.
   */
  procedure pr(edge_tab_name    in varchar2,
               d                number   default 0.85,
               num_iterations   number   default 10,
               convergence      number   default 0.1,
               dop              integer  default 4,
               wt_node_pr       in out varchar2,
               wt_node_nextpr   in out varchar2,
               wt_edge_tab_deg  in out varchar2,
               wt_delta         in out varchar2,
               tablespace       varchar2 default null,
               options          varchar2 default null,
               num_vertices out number
              );

  /**
   * This function returns a safe name for the given name of a table
   * or a view.
   * The input can be something like 'tname', or 'scott.tname', or '"SCOTT".tname'
   * or '"SCOTT"."TNAME"'
   * Illegal input will be rejected.
   */
  function validate_tab_view_name(s varchar2) return varchar2;


  procedure truncate_and_drop_ignore(tname varchar2, err_code number);


  /**
   * This API does preparation work before running graph sparsification.
   */
  procedure sparsify_graph_prep(
                    edge_tab_name        varchar2,
                    wt_out_tab    in out varchar2,
                    wt_und_tab    in out varchar2,
                    wt_hsh_tab    in out varchar2,
                    wt_mch_tab    in out varchar2,
                    options       in     varchar2  default null
                    );


  /**
   * This API does cleanup work after running graph sparsification.
   */
  procedure sparsify_graph_cleanup(
                    edge_tab_name        varchar2,
                    wt_out_tab    in out varchar2,
                    wt_und_tab    in out varchar2,
                    wt_hsh_tab    in out varchar2,
                    wt_mch_tab    in out varchar2,
                    options       in     varchar2  default null
                    );

  /**
   * This API sparsifies a graph. The remaining edges will be stored in
   * the wt_out_tab.
   */
  procedure sparsify_graph(
                    edge_tab_name        varchar2,
                    threshold            number    default 0.5,
                    min_keep             integer   default 1,
                    dop                  integer   default 4,
                    wt_out_tab    in out varchar2,
                    wt_und_tab    in out varchar2,
                    wt_hsh_tab    in out varchar2,
                    wt_mch_tab    in out varchar2,
                    tbs                  varchar2  default null,
                    options       in     varchar2  default null
                    );


  /**
   * This API does preparation work before running cluster detection
   */
  procedure find_clusters_prep(
                    edge_tab_name        varchar2,
                    wt_clusters   in out varchar2,
                    wt_undir      in out varchar2,
                    wt_cluas      in out varchar2,
                    wt_newas      in out varchar2,
                    wt_delta      in out varchar2,
                    options       in     varchar2  default null
                    );


  /**
   * This API does cleanup work after running cluster detection
   */
  procedure find_clusters_cleanup(
                    edge_tab_name        varchar2,
                    wt_clusters   in out varchar2,
                    wt_undir      in out varchar2,
                    wt_cluas      in out varchar2,
                    wt_newas      in out varchar2,
                    wt_delta      in out varchar2,
                    options       in     varchar2  default null
                    );


  /**
   * This API finds connected components in the original graph.
   * All connected components will be stored in the given wt_clusters.
   * The wt_clusters is supposed to have these two columns: (vid, cluster_id)
   * Note that the original graph will be treated as undirected.
   */
  procedure find_cc_mapping_based(
                    edge_tab_name         varchar2,
                    wt_clusters   in out  varchar2,
                    wt_undir      in out  varchar2,
                    wt_cluas      in out  varchar2,
                    wt_newas      in out  varchar2,
                    wt_delta      in out  varchar2,
                    dop                   integer   default 4,
                    rounds                integer   default 0,  -- continue till all CC founds
                    tbs                   varchar2  default null,
                    options       in      varchar2  default null
                    );


  /**
   * Returns true if the input string is null or empty
   */
  function not_null_or_empty(s in varchar2) return boolean;

  /**
   * This API makes a clone of the original graph
   */
  procedure clone_graph(
                    orgGraph         varchar2,
                    newGraph         varchar2,
                    dop              integer   default 4,
                    num_hash_ptns    integer   default 8,
                    tbs              varchar2  default null,
                    options       in varchar2  default null
                    );


  /**
   * This API does some preparation work before a text index can be created
   * on NVARCHAR2 column
   */
  procedure prepare_text_index;


  /**
   * Grant access of a PG to another user
   * The privilege argument can contain a mix of 'R', 'S', 'I', 'D', or 'U'
   * and they are for: read, select, insert, delete, and update, respectively.
   */
  procedure grant_access(graph_owner  varchar2,
                         graph_name   varchar2,
                         other_user   varchar2,
                         privilege    varchar2
                         );


  /**
   * Revoke access of a PG from another user.
   * The privilege argument can contain a mix of 'R', 'S', 'I', 'D', or 'U'
   * and they are for: read, select, insert, delete, and update, respectively.
   */
  procedure revoke_access(graph_owner  varchar2,
                          graph_name   varchar2,
                          other_user   varchar2,
                          privilege    varchar2
                          );


  /**
   * This API drops a text index on property graph vertex table
   */
  procedure drop_vertices_text_idx(
                      graph_owner   varchar2,
                      graph_name    varchar2,
                      options       varchar2 default null
                     );


 /**
   * This API drops a text index on property graph edge table
   */
  procedure drop_edges_text_idx(
                      graph_owner   varchar2,
                      graph_name    varchar2,
                      options       varchar2 default null
                     );

  /**
   * This API drops a text index on property graph table
   */
  procedure drop_element_text_idx(
                      element_type  varchar2,
                      graph_owner   varchar2,
                      graph_name    varchar2,
                      options       varchar2 default null
                     );

  /**
   * This API creates a text index on property graph vertex table
   */
  procedure create_vertices_text_idx(
                      graph_owner   varchar2,
                      graph_name    varchar2,
                      pref_owner    varchar2 default null,
                      datastore     varchar2 default null,
                      filter        varchar2 default null,
                      storage       varchar2 default null,
                      wordlist      varchar2 default null,
                      stoplist      varchar2 default null,
                      lexer         varchar2 default null,
                      dop           integer default null,
                      options       varchar2 default null
                     );

  /**
   * This API creates a text index on property graph edge table
   */
  procedure create_edges_text_idx(
                      graph_owner   varchar2,
                      graph_name    varchar2,
                      pref_owner    varchar2 default null,
                      datastore     varchar2 default null,
                      filter        varchar2 default null,
                      storage       varchar2 default null,
                      wordlist      varchar2 default null,
                      stoplist      varchar2 default null,
                      lexer         varchar2 default null,
                      dop           integer default null,
                      options       varchar2 default null
                     );


 /**
  * Turn on force tmp segment loads
  */
  procedure start_ftsl;


 /**
  * Turn off force tmp segment loads
  */
  procedure end_ftsl;


 /**
  * Set session parameters according to the name and value provided.
  */
  procedure set_session_param(param_name        in varchar2,
                              value             in boolean);

  /**
   * This procedure configures the trace setting
   */
  procedure process_trace_setting(options varchar2);


  /**
   * This function returns the current time in millseconds from 1970/01/01
   */
  function currentTimeMillis return number;



  /**
   * This function returns a partition list clause
   */
  function get_partitions_list(num_hash_ptns integer, bShardingDb boolean default false)
    return varchar2;

  function lock_vertices(graph_owner    varchar2,
                         graph_name     varchar2,
                         lockmode       int,
                         lockhandle OUT varchar2,
                         wait           boolean,
                         txndur         boolean default true
                        )
    return int;


  function lock_edges(graph_owner    varchar2,
                      graph_name     varchar2,
                      lockmode       int,
                      lockhandle OUT varchar2,
                      wait           boolean,
                      txndur         boolean default true
                      )
    return int;


  function lock_skel(graph_owner    varchar2,
                      graph_name     varchar2,
                      lockmode       int,
                      lockhandle OUT varchar2,
                      wait           boolean,
                      txndur         boolean default true
                      )
    return int;


  function lock_index_mata(graph_owner    varchar2,
                      graph_name     varchar2,
                      lockmode       int,
                      lockhandle OUT varchar2,
                      wait           boolean,
                      txndur         boolean default true
                      )
    return int;


  procedure release_lock(lockhandle int);


  /**
   * This API creates a sub graph which is an expansion from a given vertex.
   * The depth of expansion is customizable.
   */
  procedure create_sub_graph(
                    graph_owner      varchar2,
                    orgGraph         varchar2,
                    newGraph         varchar2,
                    nSrc             number,
                    depth            integer,
                    dop              integer   default 4,
                    nPQThreshold     integer   default 10000,
                    tbs              varchar2  default null,
                    options       in varchar2  default null
                    );


  function get_long_lat_geometry (x in number, y in number, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable ;

  function get_geometry_from_v_t_cols (v in nvarchar2, t in int, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_geometry_from_v_col (v in nvarchar2, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_longlat_from_v_col (v in nvarchar2, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_latlong_from_v_col (v in nvarchar2, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_longlat_from_v_t_cols (v in nvarchar2, t in int, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_latlong_from_v_t_cols (v in nvarchar2, t in int, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_wktgeometry_from_v_col (v in nvarchar2, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  function get_wktgeometry_from_v_t_cols (v in nvarchar2, t in int, srid number default 8307)
    return mdsys.sdo_geometry deterministic parallel_enable;

  -- Two helper functions to get the column definitions in case one needs to
  -- create his/her own VT$ or GE$
  function get_vertex_tab_col_def return varchar2;
  function get_edge_tab_col_def  return varchar2;

  function get_int_in_brackets(t in varchar2, d in integer) return integer;

  -- This function checks the column type
  -- It MUST match oracle.pg.rdbms.OraclePropertyGraphUtils.getPropertyTypeAsSQLType
  function check_col_type(t  in varchar2) return varchar2;
END opg_apis;
/

