create PACKAGE sdo_sem_perf AUTHID CURRENT_USER AS
  --
  -- NOTE: SEM_PERF is factored out so that DBA or MDSYS can grant it
  -- on a per-user basis. Table statistics gathering is considered heavy-duty
  -- and not every single user should perform this action carelessly.
  --
  -- NOTE: (Feb. 2018 - new model for local sem network)
  -- SEM_PERF is now granted to public so that non-DBA network owners can gather
  -- stats on their own semantic network. We now manually enforce that invoker
  -- has DBA/PDB_DBA role or is the network owner.
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);
  --PRAGMA SUPPLEMENTAL_LOG_DATA(default, AUTO);

  PROCEDURE copy_network_info_to_pkg_vars;

  PROCEDURE drop_extended_stats(network_owner dbms_id default NULL, network_name varchar2 default NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_extended_stats,AUTO_WITH_COMMIT);

  PROCEDURE gather_stats (just_on_values_table in boolean  default false,
                                        degree in number   default DBMS_STATS.AUTO_DEGREE,
                              estimate_percent in number   default DBMS_STATS.AUTO_SAMPLE_SIZE,
                              value_method_opt in varchar2 default null,
                               link_method_opt in varchar2 default null,
                                 network_owner IN dbms_id  DEFAULT NULL,
                                  network_name IN varchar2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(gather_stats,AUTO_WITH_COMMIT);

  PROCEDURE analyze_aux_tables(model_name  IN VARCHAR2,
                          estimate_percent IN NUMBER default DBMS_STATS.AUTO_SAMPLE_SIZE,
                          method_opt       IN VARCHAR2 default null,
                          degree           IN NUMBER default DBMS_STATS.AUTO_DEGREE
                        , network_owner    IN dbms_id  DEFAULT NULL
                        , network_name     IN varchar2 DEFAULT NULL
                         );
  PRAGMA SUPPLEMENTAL_LOG_DATA(analyze_aux_tables,AUTO_WITH_COMMIT);

  --
  -- This procedure call sets the limit on maximum number of new resources
  -- that are allowed to be added to ' || V_PFX_FOR_RDF_OBJ_NAME || 'RDF_VALUE$ in a single inference
  -- extension function call. Note that a commit will be executed at the end
  -- of this procedure call.
  --
  PROCEDURE set_inf_ext_max_values(max_val int, network_owner dbms_id default NULL, network_name varchar2 default NULL);

  --
  -- This procedure call gets the limit on maximum number of new resources
  -- that are allowed to be added to ' || V_PFX_FOR_RDF_OBJ_NAME || 'RDF_VALUE$ in a single inference
  -- extension function call. Note that number 0 will be returned if
  -- set_inf_ext_max_values has never been invoked before.
  --
  FUNCTION get_inf_ext_max_values(network_owner dbms_id default NULL, network_name varchar2 default NULL) return int;
  --PRAGMA SUPPLEMENTAL_LOG_DATA(get_inf_ext_max_values,NONE);

  --
  -- This procedure call sets the limit on maximum number of new triples (quads)
  -- that are allowed to be added to the entailment graph in any single inference
  -- extension function call. Note that a commit will be executed at the end
  -- of this procedure call.
  --
  PROCEDURE set_inf_ext_max_new_triples(max_val int, network_owner dbms_id default NULL, network_name varchar2 default NULL);

  --
  -- This procedure call sets the limit on maximum number of new triples (quads)
  -- that are allowed to be added to the entailment graph in any single inference
  -- extension function call. Note that number 0 will be returned if
  -- set_inf_ext_max_new_triples has been been invoked before.
  --
  FUNCTION get_inf_ext_max_new_triples(network_owner dbms_id default NULL, network_name varchar2 default NULL) return int;
  --PRAGMA SUPPLEMENTAL_LOG_DATA(get_inf_ext_max_new_triples,NONE);


  procedure export_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
 , network_owner   dbms_id DEFAULT NULL
 , network_name    varchar2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(export_network_stats,AUTO_WITH_COMMIT);


  procedure import_network_stats(
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS',
   options         VARCHAR2 DEFAULT NULL
 , network_owner   dbms_id DEFAULT NULL
 , network_name    varchar2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(import_network_stats,AUTO_WITH_COMMIT);


  procedure delete_network_stats(
    cascade_parts    IN BOOLEAN  DEFAULT TRUE,
    cascade_columns  IN BOOLEAN  DEFAULT TRUE,
    cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
    no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
    force            IN BOOLEAN  DEFAULT FALSE,
    options          IN VARCHAR2 DEFAULT NULL
  , network_owner    IN dbms_id DEFAULT NULL
  , network_name     IN varchar2 DEFAULT NULL
  );
  PRAGMA SUPPLEMENTAL_LOG_DATA(delete_network_stats,AUTO_WITH_COMMIT);

END;
/

