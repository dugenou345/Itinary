create FUNCTION sdo_multicurve3d return NUMBER is
 BEGIN
 return 3006;
 END sdo_multicurve3d;
/

