create function       SDO_Aggr_ConvexHull wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
c3 c2
P4SRIpnHvbzqaI6SJYj3LYARZpswg8eZgcfLCNL+XuefCNC/Wa6WGL//ctUMO6UW1/qzuPW/
KMAyv3RSMr+B/jKyvRjDjwnKmc5FNoA5Hvs7plgE04iP5b0hFoUqFCGFKKgfKMSVlSrbKoWx
63KCV9vrWJm5ngJQcK4kv0QvmjGalkcqFe93xsbs+6b52pbM
/

