create TYPE       SDO_GEORASTER
                                                                                  
      AS OBJECT
      (
        rasterType        NUMBER,
        spatialExtent     MDSYS.SDO_GEOMETRY,
        rasterDataTable   VARCHAR2(32),
        rasterID          NUMBER,
        metadata          SYS.XMLType
      )
  alter type       SDO_GEORASTER
   modify attribute ( rasterDataTable VARCHAR2(128) ) cascade including table data
/

