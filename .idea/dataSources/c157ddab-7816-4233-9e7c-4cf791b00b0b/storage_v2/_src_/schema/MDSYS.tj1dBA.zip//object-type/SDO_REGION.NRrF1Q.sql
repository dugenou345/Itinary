create TYPE SDO_REGION
                                                                      
AS OBJECT (
        id number,
        geometry mdsys.sdo_geometry)
/

