create PACKAGE S_sdo_rdf_query AS
  -- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
  PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

  DEFAULT_MODEL_ID CONSTANT NUMBER := 0; -- same value as in SDO_RDF package (not reused from there to avoid dependency)

  FUNCTION resolveModels (models MDSYS.RDF_Models, flags varchar2 default NULL)
  RETURN SYS.ODCINumberList;

  FUNCTION resolveTables (tables SYS.ODCIVarchar2List, owners SYS.ODCIVarchar2List)
  RETURN SYS.ODCINumberList;

  FUNCTION resolveRulebases (uname varchar2, rulebases MDSYS.RDF_RuleBases, initRuleBase boolean default false)
  RETURN SYS.ODCINumberList;

  PROCEDURE checkRDFVWModel(models IN MDSYS.RDF_Models,
                           isRelTab OUT SYS.ODCINumberList,
                           isRdfVModel OUT boolean);

  FUNCTION popIDsFromVM(vmId        in number,
                        modelIds    in out SYS.ODCINumberList,
                        rulebaseIds in out SYS.ODCINumberList,
                        entIDs      in out SYS.ODCINumberList)
  RETURN BOOLEAN;

  FUNCTION has_vpd_enabled_model (modelIds sys.ODCINumberList)
  RETURN BOOLEAN;

  FUNCTION getVMViewName(vmId     in number,
                         vmName   in varchar2,
                         options  in varchar2,
                         strictVM in boolean)
  RETURN varchar2;

  PROCEDURE populateEntInfo(useMagicSets   IN      integer,
                            reqIdxStatus   IN      varchar2,
                            modelIDs       IN      SYS.ODCINumberList,
                            rulebaseIDs    IN      SYS.ODCINumberList,
                            vmViewName     IN      varchar2,
                            vmId           IN      number,
                            precompIdx     IN OUT  varchar2,
                            idxID          IN OUT  number,
                            idxStatus      IN OUT  varchar2,
                            vcSameasOption IN OUT  varchar2);

END S_sdo_rdf_query;
/

