create FUNCTION sdo_collection2d return NUMBER is
 BEGIN
 return 2004;
 END sdo_collection2d;
/

