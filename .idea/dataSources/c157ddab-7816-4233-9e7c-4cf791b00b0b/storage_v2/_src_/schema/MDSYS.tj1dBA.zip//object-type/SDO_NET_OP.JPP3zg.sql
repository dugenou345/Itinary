create TYPE SDO_NET_OP
    AS OBJECT (id             NUMBER,
               operation      VARCHAR2(3))
/

