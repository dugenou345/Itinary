create PACKAGE       SDO_CSWADM AS

-- #28103358: MDSYS packages require PRAGMA for DBMS_ROLLING upgrade support
PRAGMA SUPPLEMENTAL_LOG_DATA(default, NONE);

--------------------------------------------------------------------------------
-- Description:
-- Registers an XSD.
--------------------------------------------------------------------------------
/*
procedure register_xsd
(
    xsd_url      IN VARCHAR2,
    xsd_doc_lob  IN CLOB
);


--------------------------------------------------------------------------------
-- Description:
-- Registers the XSDS corresponding to the xsd_type where each XSD is fetched
-- from MDSYS.SDO_XSD_TABLE (old name MDSYS.CSW_XSD_TABLE$).
-- xsd_type could be DCMI, ISO19139 or INSPIRE.
--------------------------------------------------------------------------------

procedure register_xsds
(
    --record_type_name      IN VARCHAR2,
    --record_type_namespace IN VARCHAR2,
    xsd_type              IN VARCHAR2

);
*/

--------------------------------------------------------------------------------
-- Cleanup MDSYS.SDO_XSD_TABLE (old name MDSYS.CSW_XSD_TABLE$) for a specific
-- XSD type i.e., DCMI, ISO19139 or INSPIRE.
-- owner is MDSYS by default.
--------------------------------------------------------------------------------

procedure delete_from_SDO_XSD_TABLE
(
    xsd_type IN VARCHAR2,
    owner    IN VARCHAR2 DEFAULT 'MDSYS'
);


--------------------------------------------------------------------------------
-- Delete XSD schema corresponding to the xsd_url if it exists.
--------------------------------------------------------------------------------
/*
procedure delete_schema
(
    xsd_url IN VARCHAR2

);
*/
END;
/

