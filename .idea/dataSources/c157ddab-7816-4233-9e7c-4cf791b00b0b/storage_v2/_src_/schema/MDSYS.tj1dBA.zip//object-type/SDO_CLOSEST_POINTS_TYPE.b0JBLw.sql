create TYPE SDO_CLOSEST_POINTS_TYPE
                                                                      
AS OBJECT (
        dist  NUMBER,
        geoma MDSYS.SDO_GEOMETRY,
        geomb MDSYS.SDO_GEOMETRY)
/

