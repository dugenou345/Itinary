create type RDF_Alias as object (
      namespace_id  varchar2(128),
      namespace_val varchar2(4000))
/

