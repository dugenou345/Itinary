create TYPE       tile_geom_type AS OBJECT (
  tile_id      NUMBER,
  status       CHAR,
  percent      NUMBER,
  tile_center  SDO_GEOMETRY,
  geom         SDO_GEOMETRY);
/

