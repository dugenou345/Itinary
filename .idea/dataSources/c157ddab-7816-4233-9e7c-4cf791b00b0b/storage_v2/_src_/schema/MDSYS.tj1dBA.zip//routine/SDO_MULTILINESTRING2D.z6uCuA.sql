create FUNCTION sdo_multilinestring2d return NUMBER is
 BEGIN
 return 2006;
 END sdo_multilinestring2d;
/

