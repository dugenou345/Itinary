create TYPE service_t FORCE IS OBJECT (
                                  svc_name        varchar2(64),
                                  svc_network_name              varchar2(512),
                                  svc_failover_method           varchar2(64),
                                  svc_failover_type             varchar2(64),
                                  svc_failover_retries          number(10),
                                  svc_failover_delay            number(10),
                                  svc_runtime_balance           varchar2(12),
                                  svc_dtp                       varchar2(1),
                                  svc_notification              varchar2(3),
                                  svc_load_balance              varchar2(5),
                                  svc_edition                   varchar2(128),
                                  svc_commit_outcome            varchar2(3),
                                  svc_retention_timeout         number,
                                  svc_replay_initiation_timeout number,
                                  svc_session_state_consistency varchar2(128),
                                  svc_pdb                       varchar2(128),
                                  svc_sql_translation_profile   varchar2(261),
                                  svc_lag                       varchar(128),
                                  svc_locality                  number,
                                  svc_region_failover           number,
                                  svc_table_family_id           number);
/

