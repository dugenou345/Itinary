create view DUPLICATED_TABLE_DETAILS$
            (OWNER, TABLE_NAME, REFRESH_INTERVAL, LAST_SUCCESSFUL_REFRESH_TIME, NEXT_REFRESH_TIME, RGROUP_OWNER,
             RGROUP_NAME) as
WITH
    dup_obj AS (
      SELECT
        obj.owner,
        obj.object_name,
        cast(sr.snaptime as timestamp) reftime
      FROM
        dba_objects obj, sys.snap_reftime$ sr
      WHERE obj.duplicated = 'Y'
        AND obj.owner = sr.sowner
        AND obj.object_name = sr.vname
    ),
    st AS (
      SELECT
        CASE (SELECT min(value) FROM sys.v_$parameter
              WHERE name='_sysdate_at_dbtimezone')
              WHEN 'TRUE' THEN DBTIMEZONE
        ELSE (SELECT concat(concat(extract(timezone_hour FROM systimestamp),':')
                                  , extract(timezone_minute FROM systimestamp))
              FROM sys.dual)
        end systimezone
      FROM sys.dual
    ),
    job AS (
      SELECT
        mv.owner,
        mv.name,
        mv.rowner,
        mv.rname,
        to_number(REGEXP_SUBSTR(mv.interval, '\d+')) interval,
        j.NEXT_RUN_DATE
      FROM
        dba_scheduler_jobs j,
        DBA_REFRESH_CHILDREN mv
      WHERE mv.rowner = j.owner
        AND mv.JOB_NAME = j.JOB_NAME
    )
  SELECT
      dup_obj.owner,
      dup_obj.object_name,
      job.interval,
      from_tz(dup_obj.reftime, st.systimezone) at time zone SESSIONTIMEZONE,
      job.NEXT_RUN_DATE at time zone SESSIONTIMEZONE,
      job.rowner,
      job.rname
  FROM
    st, dup_obj, job
  WHERE job.owner(+) = dup_obj.owner
    AND job.name(+) = dup_obj.object_name
WITH READ ONLY
/

