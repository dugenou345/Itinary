create view SHA_DATABASES
            (DB_UNIQUE_NAME, REGION_NAME, CONNECT_STRING, DB_CREATED, STATUS, VERSION, RAC_TYPE, SHARDGROUP, LAST_DDL,
             DDL_ERROR, DEPLOYMENT_STATE, DG_BROKER_ID, SHARDSPACE, DB_UP, IS_PRIMARY, DB_HOST, ORACLE_HOME)
as
SELECT
   d.name,
   r.name,
   d.connect_string,
   CASE d.conv_state
      WHEN 'S' THEN 'N'
      WHEN 'C' THEN 'Y'
      ELSE 'UNKNOWN' END,
   CASE d.status
      WHEN 'U' THEN 'UNDEPLOYED'
      WHEN 'R' THEN 'REPLICATON_CONFIGURED'
      WHEN 'D' THEN 'GSM_SET_UP'
      WHEN 'I' THEN 'ADD_INCOMPLETE'
      WHEN 'S' THEN 'NEEDS_RESYNC'
      ELSE 'UNKNOWN' END,
   dbms_gsm_utility.dbVersRevLookup(d.version),
   CASE d.db_type
      WHEN 'N' THEN 'NON_RAC'
      WHEN 'A' THEN 'ADMIN_RAC'
      WHEN 'P' THEN 'POLICY_RAC'
      WHEN 'S' THEN 'SIHA'
      WHEN 'U' THEN 'UNKNOWN'
      ELSE 'UNKNOWN' END,
   s.name,
   d.ddl_num,
   d.ddl_error,
   CASE d.dpl_status
      WHEN 0 THEN 'NOT_DEPLOYED'
      WHEN 1 THEN 'DEPLOY_REQUESTED'
      WHEN 2 THEN 'REPLICATION_CONFIGURED'
      WHEN 3 THEN 'HAS_CHUNKS'
      WHEN 4 THEN 'DEPLOYED'
      WHEN 5 THEN 'OGG DEPLOYED'
      ELSE 'UNKNOWN' END,
   d.drset_number,
   ss.name,
   CASE BITAND(d.flags, 1)
      WHEN 1 THEN 'Y'
      ELSE 'N' END,
   CASE BITAND(d.flags,2)
      WHEN 2 THEN 'Y'
      ELSE 'N' END,
   v.hostname,
   d.oracle_home
FROM database d
   LEFT JOIN region r ON (d.region_num = r.num)
   LEFT JOIN shard_group s ON (d.shardgroup_id = s.shardgroup_id)
   LEFT JOIN shard_space ss ON (d.shardspace_id = ss.shardspace_id)
   LEFT JOIN vncr v ON (d.hostid = v.hostid)
/

