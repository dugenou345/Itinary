create TYPE grp_record_t IS OBJECT (
                        name        varchar2(128),
                        scn         number,
                        time        timestamp(9),
                        replicated  varchar2(3));
/

