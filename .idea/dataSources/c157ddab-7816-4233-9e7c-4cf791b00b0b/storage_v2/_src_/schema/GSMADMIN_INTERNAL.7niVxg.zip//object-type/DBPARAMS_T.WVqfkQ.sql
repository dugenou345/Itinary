create TYPE dbparams_t AS OBJECT (
    param_name     VARCHAR2(30),
    param_value    VARCHAR2(100))
 ALTER TYPE dbparams_t
   MODIFY ATTRIBUTE param_name        VARCHAR2(128) CASCADE
/

