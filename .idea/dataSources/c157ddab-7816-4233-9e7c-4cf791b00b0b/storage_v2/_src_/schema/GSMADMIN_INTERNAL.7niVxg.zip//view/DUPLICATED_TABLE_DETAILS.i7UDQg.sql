create view DUPLICATED_TABLE_DETAILS as
SELECT
  ora_shard_id,
  owner,
  table_name,
  refresh_interval,
  last_successful_refresh_time,
  next_refresh_time,
  rgroup_owner,
  rgroup_name
FROM
  SHARDS(gsmadmin_internal.duplicated_table_details$)
WITH READ ONLY
/

