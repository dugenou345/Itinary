create type database_dsc_t as object (
  version     number,

  do_sync_db   number,
  do_start_svc number,
  do_mod_local_svc number,

  want_ons_config number,

  db_number   number,
  cloud_name  varchar2(128),
  dbpool_name varchar2(128),
  region_name varchar2(128),
  shdgrp_name varchar2(128),
  shdgrp_id   number,
  num_inst    number,
  cpu_thld    number,
  disk_thld   number,
  do_force    number,
  chunks      number,
  service_list   service_dsc_list_t,
  region_list    region_list_t,
  gsm_list       gsm_list_t,

  ons_port  varchar2(256),
  scan_name varchar2(256),
  hostname  varchar2(256),
  db_type   char,

  sharding_type number,
  deploy_as number,
  status number,
  shardspace_name varchar2(128),
  shardspace_id number,
  repl_type number,
  MINNUM NUMBER,
  MAXNUM NUMBER,
  DBLPWD VARCHAR2(64),
  DBLEP VARCHAR2(256),
  GWM_INTDBNUM NUMBER,
  FEDERATED_DB NUMBER,
  CONSTRUCTOR FUNCTION database_dsc_t (SELF IN OUT NOCOPY database_dsc_t,
                                      dbnum NUMBER)
                                     RETURN SELF AS RESULT
);
/

